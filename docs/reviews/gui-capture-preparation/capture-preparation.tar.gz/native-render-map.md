# Native render map — aa10645

Valid until: different Social main/core capture bootstrap — then treat as history.

Read-only source map at `aa10645922ad708db66c9ca0ce982e9f70e4a190`; no HTTP/DB/browser execution, golden capture or owner signoff. Effective registrations and delegated view selectors take precedence over historical Django route names.

**91 loader files = 84 port + 7 frozen. 84 files have source-backed native paths (78 port +6 frozen); seven have no current native loader entry.** The reachability 84 is a different set from the port 84. All runtime captures/gates remain pending.

Dynamic defaults at `web/views.go:26`, `public_pages.go:30`, `account_pages.go:114`, `social_pages.go:218`, forms at `social_forms.go:21/125`, payments at `payments.go:53` and SPA override at `server.go:234-254` are included. `views.go:16-24` delegates Public → Account → Social before generic cases; shadowed generic duplicate strings are not extra effective entries.

## Inline native outputs and ownership holds

| Current native output | Effective renderer | Historical loader |
|---|---|---|
| GET /login/, GET /register/ | services/authcore/ui.go:33 → services/authcore/ui.go:29 | web/login.html, web/register.html |
| POST /login/ | services/server/internal/accounts/login_pages.go:90 → services/server/internal/accounts/login_pages.go:126 | web/login.html |
| GET /account/restricted/, POST /account/restricted/ | services/server/internal/safety/restricted.go:44 → services/server/internal/safety/restricted.go:119 | web/account_restricted.html |
| GET /moderation/, POST /moderation/ | services/server/internal/safety/console.go:12 → services/server/internal/safety/console.go:109 | web/moderation/dashboard.html |

GET login/register uses Romanian shared authcore login/signup shell, browser POST errors use English app `sourceLoginPage`; capture separately. API login is browser=false. Never capture Django auth history as native Live or alter pinned shared source without authorized core ownership.

Safety exact registration `safety/http.go:17-20`, assembled at `app.go:306`, supersedes typed catch-all HTML. `/moderation/` uses RequireActor → `a.Moderator()` (`safety/http.go:48-57`, `platform/platform.go:23-24`). Administrator `/admin/` operations is separate (`admin/http.go:22/31/146`), outside 91 files. Native moderation carries concerns inline, never the old concern_detail file.

`_breadcrumbs` has no caller. Registered concern-detail and `/app/preview/` have no native view case: private anonymous GET redirects and admitted GET returns ErrNotFound (`server.go:186`, `views.go:188`). `/inbox/` likewise lacks native view/template. All seven loader files remain inventoried with owner oracle-resolution holds; this draft adds no handler, discards no file and signs no safety change.

## Exact 91-file loader map

Paths in table are repo-relative; JSON carries absolute evidence and per-entry full transitive chains. GET roots are summarized here; POST error/message/challenge parents are explicit JSON entries. Source path reachability remains unexecuted.

| Loader file | Disposition | Native entries / provenance |
|---|---|---|
| `web/_activity_card.html` | port | /places/<int:pk>/ services/server/internal/web/public_pages.go:70 → web/place_detail.html:86 include web/_activity_card.html<br>/places/<int:pk>/<slug:slug>/ services/server/internal/web/public_pages.go:70 → web/place_detail.html:86 include web/_activity_card.html<br>/ services/server/internal/web/social_pages.go:220 → web/home.html:81 include web/_activity_card.html<br>/activities/ services/server/internal/web/social_pages.go:222 → web/activities.html:43 include web/_activity_card.html<br>/communities/<slug:slug>/ services/server/internal/web/social_pages.go:225 → web/community_detail.html:17 include web/_activity_card.html<br>/groups/<int:pk>/ services/server/internal/web/social_pages.go:235 → web/group_detail.html:122 include web/_activity_card.html |
| `web/_activity_form_wizard.html` | port | /activities/new/ services/server/internal/web/social_forms.go:21 → web/activity_form.html:33 include web/_activity_form_wizard.html<br>/activities/<int:pk>/edit/ services/server/internal/web/social_forms.go:21 → web/activity_edit.html:30 include web/_activity_form_wizard.html |
| `web/_activity_header.html` | port | /activities/<int:pk>/ services/server/internal/web/social_pages.go:230 → web/activity_detail.html:5 include web/_activity_header.html |
| `web/_activity_membership.html` | port | /activities/<int:pk>/ services/server/internal/web/social_pages.go:230 → web/activity_detail.html:7 include web/_activity_membership.html |
| `web/_activity_organizer.html` | port | /activities/<int:pk>/ services/server/internal/web/social_pages.go:230 → web/activity_detail.html:6 include web/_activity_organizer.html |
| `web/_activity_safe_exit.html` | port | /activities/<int:pk>/ services/server/internal/web/social_pages.go:230 → web/activity_detail.html:7 include web/_activity_membership.html,web/_activity_membership.html:157 include web/_activity_safe_exit.html<br>/activities/<int:pk>/ services/server/internal/web/social_pages.go:233 → web/activity_safe_exit.html:9 include web/_activity_safe_exit.html |
| `web/_activity_safety.html` | port | /activities/<int:pk>/ services/server/internal/web/social_pages.go:230 → web/activity_detail.html:5 include web/_activity_header.html,web/_activity_header.html:34 include web/_activity_safety.html |
| `web/_activity_thread.html` | port | /activities/<int:pk>/ services/server/internal/web/social_pages.go:230 → web/activity_detail.html:8 include web/_activity_thread.html |
| `web/_breadcrumbs.html` | port | orphan_partial_no_native_include: No current extends/include or non-test renderer entry references this partial; do not fabricate a capture route. |
| `web/_near_me.html` | port | /places/list/ services/server/internal/web/public_pages.go:44 → web/places_list.html:16 include web/_near_me.html<br>/ services/server/internal/web/social_pages.go:220 → web/home.html:80 include web/_near_me.html<br>/activities/ services/server/internal/web/social_pages.go:222 → web/activities.html:20 include web/_near_me.html |
| `web/_person_card.html` | port | /people/<uuid:public_id>/ services/server/internal/web/views.go:147 → web/person.html:16 include web/_person_card.html<br>/people/<uuid:public_id>/card/ services/server/internal/web/views.go:154 |
| `web/_post.html` | port | /activities/<int:pk>/ services/server/internal/web/social_pages.go:230 → web/activity_detail.html:8 include web/_activity_thread.html,web/_activity_thread.html:66 include web/_post.html<br>/groups/<int:pk>/ services/server/internal/web/social_pages.go:235 → web/group_detail.html:75 include web/_post.html |
| `web/_post_sentiment.html` | port | /activities/<int:pk>/ services/server/internal/web/social_pages.go:230 → web/activity_detail.html:8 include web/_activity_thread.html,web/_activity_thread.html:66 include web/_post.html,web/_post.html:81 include web/_post_sentiment.html<br>/groups/<int:pk>/ services/server/internal/web/social_pages.go:235 → web/group_detail.html:75 include web/_post.html,web/_post.html:81 include web/_post_sentiment.html |
| `web/_share_box.html` | port | /places/<int:pk>/ services/server/internal/web/public_pages.go:70 → web/place_detail.html:312 include web/_share_box.html<br>/places/<int:pk>/<slug:slug>/ services/server/internal/web/public_pages.go:70 → web/place_detail.html:312 include web/_share_box.html<br>/events/<int:pk>/ services/server/internal/web/public_pages.go:146 → web/event_detail.html:65 include web/_share_box.html<br>/events/<int:pk>/<slug:slug>/ services/server/internal/web/public_pages.go:146 → web/event_detail.html:65 include web/_share_box.html<br>/activities/<int:pk>/ services/server/internal/web/social_pages.go:230 → web/activity_detail.html:5 include web/_activity_header.html,web/_activity_header.html:45 include web/_share_box.html |
| `web/_you_tabs.html` | port | /you/ services/server/internal/web/account_pages.go:143 → web/you.html:6 include web/_you_tabs.html<br>/profile/ services/server/internal/web/account_pages.go:144 → web/profile.html:6 include web/_you_tabs.html<br>/settings/ services/server/internal/web/account_pages.go:216 → web/settings.html:6 include web/_you_tabs.html<br>/my-privacy/ services/server/internal/web/account_pages.go:244 → web/my_privacy.html:6 include web/_you_tabs.html<br>/display/ services/server/internal/web/account_pages.go:121 → web/display_preferences.html:6 include web/_you_tabs.html<br>/guardianship/ services/server/internal/web/account_pages.go:119 → web/guardianship.html:6 include web/_you_tabs.html<br>/interests/ services/server/internal/web/views.go:41 → web/interests.html:6 include web/_you_tabs.html<br>/my-donations/ services/server/internal/web/payments.go:24 → web/my_donations.html:6 include web/_you_tabs.html |
| `web/access_preferences.html` | port | /access/ services/server/internal/web/account_pages.go:302 |
| `web/account_delete.html` | port | /account/delete/ services/server/internal/web/account_pages.go:309 |
| `web/account_restricted.html` | port | historical_native_inline_supersedes: Native production HTML is inline Go outside loader; retain file ownership, never label Django historical output native Live. |
| `web/activities.html` | port | /activities/ services/server/internal/web/social_pages.go:222 |
| `web/activity_detail.html` | port | /activities/<int:pk>/ services/server/internal/web/social_pages.go:230 |
| `web/activity_edit.html` | port | /activities/<int:pk>/edit/ services/server/internal/web/social_forms.go:21 |
| `web/activity_form.html` | port | /activities/new/ services/server/internal/web/social_forms.go:21 |
| `web/activity_log.html` | port | /my-activity-log/ services/server/internal/web/account_pages.go:226 |
| `web/activity_safe_exit.html` | port | /activities/<int:pk>/ services/server/internal/web/social_pages.go:233 |
| `web/campaigns.html` | port | /campaigns/ services/server/internal/web/payments.go:53 |
| `web/communities.html` | port | /communities/ services/server/internal/web/social_pages.go:225 |
| `web/communities_graph.html` | port | /communities/graph/ services/server/internal/web/social_pages.go:225 |
| `web/community_detail.html` | port | /communities/<slug:slug>/ services/server/internal/web/social_pages.go:225 |
| `web/connections.html` | port | /connections/ services/server/internal/web/views.go:137 |
| `web/discover.html` | port | /discover/ services/server/internal/web/public_pages.go:153 |
| `web/display_preferences.html` | port | /display/ services/server/internal/web/account_pages.go:121 |
| `web/donate.html` | port | /donate/ services/server/internal/web/payments.go:53 |
| `web/event_detail.html` | port | /events/<int:pk>/ services/server/internal/web/public_pages.go:146<br>/events/<int:pk>/<slug:slug>/ services/server/internal/web/public_pages.go:146 |
| `web/events.html` | port | /events/ services/server/internal/web/public_pages.go:139 |
| `web/gauge_convert.html` | port | /gauges/<int:pk>/convert/ services/server/internal/web/social_forms.go:21 |
| `web/gauge_detail.html` | port | /gauges/<int:pk>/ services/server/internal/web/social_pages.go:263 |
| `web/gauge_form.html` | port | /gauges/new/ services/server/internal/web/social_forms.go:21 |
| `web/gauges.html` | port | /gauges/ services/server/internal/web/social_pages.go:263 |
| `web/group_detail.html` | port | /groups/<int:pk>/ services/server/internal/web/social_pages.go:235 |
| `web/group_form.html` | port | /groups/new/ services/server/internal/web/social_forms.go:21 |
| `web/guardianship.html` | port | /guardianship/ services/server/internal/web/account_pages.go:119 |
| `web/home.html` | port | / services/server/internal/web/social_pages.go:220 |
| `web/interests.html` | port | /interests/ services/server/internal/web/views.go:41 |
| `web/landing.html` | port | / services/server/internal/web/views.go:36 |
| `web/landing_city.html` | port | /things-to-do/<slug:area_slug>/ services/server/internal/web/public_landings.go:51 |
| `web/landing_detail.html` | port | /things-to-do/<slug:area_slug>/<slug:activity_slug>/ services/server/internal/web/public_landings.go:85 |
| `web/landing_index.html` | port | /things-to-do/ services/server/internal/web/public_landings.go:42 |
| `web/login.html` | port | historical_native_inline_supersedes: Native production HTML is inline Go outside loader; retain file ownership, never label Django historical output native Live. |
| `web/messages.html` | port | /messages/ services/server/internal/web/messaging.go:64 |
| `web/moderation/concern_detail.html` | port | historical_no_native_view: Route registry exists but effective view chain has no matching non-test case; anonymous private GET redirects, admitted GET returns ErrNotFound. |
| `web/moderation/dashboard.html` | port | historical_native_inline_supersedes: Native production HTML is inline Go outside loader; retain file ownership, never label Django historical output native Live. |
| `web/my_donations.html` | port | /my-donations/ services/server/internal/web/payments.go:24 |
| `web/my_meetups.html` | port | /my-meetups/ services/server/internal/web/social_pages.go:320 |
| `web/my_privacy.html` | port | /my-privacy/ services/server/internal/web/account_pages.go:244 |
| `web/my_venues.html` | port | /my-venues/ services/server/internal/web/social_pages.go:320 |
| `web/notification_preferences.html` | port | /notifications/preferences/ services/server/internal/web/account_pages.go:288 |
| `web/notifications.html` | port | /notifications/ services/server/internal/web/views.go:131 |
| `web/open_data.html` | port | /open-data/ services/server/internal/web/public_pages.go:165 |
| `web/organize.html` | port | /organize/ services/server/internal/web/social_pages.go:289 |
| `web/partners.html` | port | /partners/ services/server/internal/web/payments.go:53 |
| `web/person.html` | port | /people/<uuid:public_id>/ services/server/internal/web/views.go:147 |
| `web/place_claim.html` | port | /places/<int:pk>/claim/ services/server/internal/web/public_pages.go:93 |
| `web/place_detail.html` | port | /places/<int:pk>/ services/server/internal/web/public_pages.go:70<br>/places/<int:pk>/<slug:slug>/ services/server/internal/web/public_pages.go:70 |
| `web/place_propose.html` | port | /places/propose/ services/server/internal/web/public_pages.go:71 |
| `web/places.html` | port | /places/ services/server/internal/web/public_pages.go:43 |
| `web/places_list.html` | port | /places/list/ services/server/internal/web/public_pages.go:44 |
| `web/places_pending.html` | port | /places/pending/ services/server/internal/web/public_pages.go:87 |
| `web/privacy.html` | port | /privacy/ services/server/internal/web/account_pages.go:121 |
| `web/profile.html` | port | /profile/ services/server/internal/web/account_pages.go:144 |
| `web/register.html` | port | historical_native_inline_supersedes: Native production HTML is inline Go outside loader; retain file ownership, never label Django historical output native Live. |
| `web/report.html` | port | /report/ services/server/internal/web/views.go:47 |
| `web/safety_record.html` | port | /my-safety-record/ services/server/internal/web/account_pages.go:232 |
| `web/saved_searches.html` | port | /saved-searches/ services/server/internal/web/views.go:50 |
| `web/series_detail.html` | port | /activities/series/<int:pk>/ services/server/internal/web/social_pages.go:241 |
| `web/series_form.html` | port | /activities/series/new/ services/server/internal/web/social_forms.go:21 |
| `web/series_list.html` | port | /activities/series/ services/server/internal/web/social_pages.go:239 |
| `web/settings.html` | port | /settings/ services/server/internal/web/account_pages.go:216 |
| `web/snapshots/events.html` | frozen | /events/ [SPA events] services/server/internal/web/server.go:234 → web/spa.html:18 include web/snapshots/events.html |
| `web/snapshots/landing_city.html` | frozen | /things-to-do/<slug:area_slug>/ [SPA things-city] services/server/internal/web/server.go:234 → web/spa.html:18 include web/snapshots/landing_city.html |
| `web/snapshots/landing_detail.html` | frozen | /things-to-do/<slug:area_slug>/<slug:activity_slug>/ [SPA things-detail] services/server/internal/web/server.go:234 → web/spa.html:18 include web/snapshots/landing_detail.html |
| `web/snapshots/landing_index.html` | frozen | /things-to-do/ [SPA things-index] services/server/internal/web/server.go:234 → web/spa.html:18 include web/snapshots/landing_index.html |
| `web/snapshots/places.html` | frozen | /places/list/ [SPA places] services/server/internal/web/server.go:234 → web/spa.html:18 include web/snapshots/places.html |
| `web/spa.html` | frozen | / [SPA home] services/server/internal/web/server.go:234<br>/organize/ [SPA organize] services/server/internal/web/server.go:234<br>/places/list/ [SPA places] services/server/internal/web/server.go:234<br>/events/ [SPA events] services/server/internal/web/server.go:234<br>/things-to-do/ [SPA things-index] services/server/internal/web/server.go:234<br>/things-to-do/<slug:area_slug>/ [SPA things-city] services/server/internal/web/server.go:234<br>/things-to-do/<slug:area_slug>/<slug:activity_slug>/ [SPA things-detail] services/server/internal/web/server.go:234<br>/activities/ [SPA browse] services/server/internal/web/server.go:234<br>/saved-searches/ [SPA saved-searches] services/server/internal/web/server.go:234<br>/you/ [SPA you] services/server/internal/web/server.go:234<br>/settings/ [SPA settings] services/server/internal/web/server.go:234<br>/interests/ [SPA interests] services/server/internal/web/server.go:234<br>/topics/ [SPA topics] services/server/internal/web/server.go:234<br>/access/ [SPA access] services/server/internal/web/server.go:234<br>/profile/ [SPA profile] services/server/internal/web/server.go:234<br>/notifications/ [SPA notifications] services/server/internal/web/server.go:234<br>/notifications/preferences/ [SPA notification-preferences] services/server/internal/web/server.go:234<br>/communities/ [SPA communities] services/server/internal/web/server.go:234<br>/communities/<slug:slug>/ [SPA community-detail] services/server/internal/web/server.go:234<br>/connections/ [SPA connections] services/server/internal/web/server.go:234 |
| `web/spa_preview.html` | frozen | historical_no_native_view: Route registry exists but effective view chain has no matching non-test case; anonymous private GET redirects, admitted GET returns ErrNotFound. |
| `web/terms.html` | port | /terms/ services/server/internal/web/account_pages.go:121 |
| `web/topic_preferences.html` | port | /topics/ services/server/internal/web/views.go:44 |
| `web/transparency.html` | port | /transparency/ services/server/internal/web/payments.go:53 |
| `web/verify_age.html` | port | /verify-age/ services/server/internal/web/account_pages.go:280 |
| `web/wards.html` | port | /wards/ services/server/internal/web/account_pages.go:315 |
| `web/you.html` | port | /you/ services/server/internal/web/account_pages.go:143 |
| `base.html` | port | /places/ services/server/internal/web/public_pages.go:43 → web/places.html:1 extends base.html<br>/places/list/ services/server/internal/web/public_pages.go:44 → web/places_list.html:1 extends base.html<br>/places/<int:pk>/ services/server/internal/web/public_pages.go:70 → web/place_detail.html:1 extends base.html<br>/places/<int:pk>/<slug:slug>/ services/server/internal/web/public_pages.go:70 → web/place_detail.html:1 extends base.html<br>/places/propose/ services/server/internal/web/public_pages.go:71 → web/place_propose.html:1 extends base.html<br>/places/pending/ services/server/internal/web/public_pages.go:87 → web/places_pending.html:1 extends base.html<br>/places/<int:pk>/claim/ services/server/internal/web/public_pages.go:93 → web/place_claim.html:1 extends base.html<br>/events/ services/server/internal/web/public_pages.go:139 → web/events.html:1 extends base.html<br>/events/<int:pk>/ services/server/internal/web/public_pages.go:146 → web/event_detail.html:1 extends base.html<br>/events/<int:pk>/<slug:slug>/ services/server/internal/web/public_pages.go:146 → web/event_detail.html:1 extends base.html<br>/discover/ services/server/internal/web/public_pages.go:153 → web/discover.html:1 extends base.html<br>/open-data/ services/server/internal/web/public_pages.go:165 → web/open_data.html:1 extends base.html<br>/things-to-do/ services/server/internal/web/public_landings.go:42 → web/landing_index.html:1 extends base.html<br>/things-to-do/<slug:area_slug>/ services/server/internal/web/public_landings.go:51 → web/landing_city.html:1 extends base.html<br>/things-to-do/<slug:area_slug>/<slug:activity_slug>/ services/server/internal/web/public_landings.go:85 → web/landing_detail.html:1 extends base.html<br>/you/ services/server/internal/web/account_pages.go:143 → web/you.html:1 extends base.html<br>/profile/ services/server/internal/web/account_pages.go:144 → web/profile.html:1 extends base.html<br>/settings/ services/server/internal/web/account_pages.go:216 → web/settings.html:1 extends base.html<br>/my-privacy/ services/server/internal/web/account_pages.go:244 → web/my_privacy.html:1 extends base.html<br>/my-activity-log/ services/server/internal/web/account_pages.go:226 → web/activity_log.html:1 extends base.html<br>/my-safety-record/ services/server/internal/web/account_pages.go:232 → web/safety_record.html:1 extends base.html<br>/verify-age/ services/server/internal/web/account_pages.go:280 → web/verify_age.html:1 extends base.html<br>/wards/ services/server/internal/web/account_pages.go:315 → web/wards.html:1 extends base.html<br>/notifications/preferences/ services/server/internal/web/account_pages.go:288 → web/notification_preferences.html:1 extends base.html<br>/access/ services/server/internal/web/account_pages.go:302 → web/access_preferences.html:1 extends base.html<br>/account/delete/ services/server/internal/web/account_pages.go:309 → web/account_delete.html:1 extends base.html<br>/display/ services/server/internal/web/account_pages.go:121 → web/display_preferences.html:1 extends base.html<br>/privacy/ services/server/internal/web/account_pages.go:121 → web/privacy.html:1 extends base.html<br>/terms/ services/server/internal/web/account_pages.go:121 → web/terms.html:1 extends base.html<br>/guardianship/ services/server/internal/web/account_pages.go:119 → web/guardianship.html:1 extends base.html<br>/ services/server/internal/web/social_pages.go:220 → web/home.html:1 extends base.html<br>/activities/ services/server/internal/web/social_pages.go:222 → web/activities.html:1 extends base.html<br>/communities/ services/server/internal/web/social_pages.go:225 → web/communities.html:1 extends base.html<br>/communities/<slug:slug>/ services/server/internal/web/social_pages.go:225 → web/community_detail.html:1 extends base.html<br>/communities/graph/ services/server/internal/web/social_pages.go:225 → web/communities_graph.html:1 extends base.html<br>/activities/<int:pk>/ services/server/internal/web/social_pages.go:230 → web/activity_detail.html:1 extends base.html<br>/groups/<int:pk>/ services/server/internal/web/social_pages.go:235 → web/group_detail.html:1 extends base.html<br>/activities/series/ services/server/internal/web/social_pages.go:239 → web/series_list.html:1 extends base.html<br>/activities/series/<int:pk>/ services/server/internal/web/social_pages.go:241 → web/series_detail.html:1 extends base.html<br>/gauges/ services/server/internal/web/social_pages.go:263 → web/gauges.html:1 extends base.html<br>/gauges/<int:pk>/ services/server/internal/web/social_pages.go:263 → web/gauge_detail.html:1 extends base.html<br>/organize/ services/server/internal/web/social_pages.go:289 → web/organize.html:1 extends base.html<br>/my-meetups/ services/server/internal/web/social_pages.go:320 → web/my_meetups.html:1 extends base.html<br>/my-venues/ services/server/internal/web/social_pages.go:320 → web/my_venues.html:1 extends base.html<br>/activities/<int:pk>/ services/server/internal/web/social_pages.go:233 → web/activity_safe_exit.html:1 extends base.html<br>/activities/new/ services/server/internal/web/social_forms.go:21 → web/activity_form.html:1 extends base.html<br>/activities/<int:pk>/edit/ services/server/internal/web/social_forms.go:21 → web/activity_edit.html:1 extends base.html<br>/activities/series/new/ services/server/internal/web/social_forms.go:21 → web/series_form.html:1 extends base.html<br>/groups/new/ services/server/internal/web/social_forms.go:21 → web/group_form.html:1 extends base.html<br>/gauges/new/ services/server/internal/web/social_forms.go:21 → web/gauge_form.html:1 extends base.html<br>/gauges/<int:pk>/convert/ services/server/internal/web/social_forms.go:21 → web/gauge_convert.html:1 extends base.html<br>/interests/ services/server/internal/web/views.go:41 → web/interests.html:1 extends base.html<br>/topics/ services/server/internal/web/views.go:44 → web/topic_preferences.html:1 extends base.html<br>/report/ services/server/internal/web/views.go:47 → web/report.html:1 extends base.html<br>/saved-searches/ services/server/internal/web/views.go:50 → web/saved_searches.html:1 extends base.html<br>/notifications/ services/server/internal/web/views.go:131 → web/notifications.html:1 extends base.html<br>/connections/ services/server/internal/web/views.go:137 → web/connections.html:1 extends base.html<br>/people/<uuid:public_id>/ services/server/internal/web/views.go:147 → web/person.html:1 extends base.html<br>/messages/ services/server/internal/web/messaging.go:64 → web/messages.html:1 extends base.html<br>/donate/ services/server/internal/web/payments.go:53 → web/donate.html:1 extends base.html<br>/transparency/ services/server/internal/web/payments.go:53 → web/transparency.html:1 extends base.html<br>/campaigns/ services/server/internal/web/payments.go:53 → web/campaigns.html:1 extends base.html<br>/partners/ services/server/internal/web/payments.go:53 → web/partners.html:1 extends base.html<br>/my-donations/ services/server/internal/web/payments.go:24 → web/my_donations.html:1 extends base.html<br>/ services/server/internal/web/views.go:36 → web/landing.html:1 extends base.html<br>/ [SPA home] services/server/internal/web/server.go:234 → web/spa.html:1 extends base.html<br>/organize/ [SPA organize] services/server/internal/web/server.go:234 → web/spa.html:1 extends base.html<br>/places/list/ [SPA places] services/server/internal/web/server.go:234 → web/spa.html:1 extends base.html<br>/events/ [SPA events] services/server/internal/web/server.go:234 → web/spa.html:1 extends base.html<br>/things-to-do/ [SPA things-index] services/server/internal/web/server.go:234 → web/spa.html:1 extends base.html<br>/things-to-do/<slug:area_slug>/ [SPA things-city] services/server/internal/web/server.go:234 → web/spa.html:1 extends base.html<br>/things-to-do/<slug:area_slug>/<slug:activity_slug>/ [SPA things-detail] services/server/internal/web/server.go:234 → web/spa.html:1 extends base.html<br>/activities/ [SPA browse] services/server/internal/web/server.go:234 → web/spa.html:1 extends base.html<br>/saved-searches/ [SPA saved-searches] services/server/internal/web/server.go:234 → web/spa.html:1 extends base.html<br>/you/ [SPA you] services/server/internal/web/server.go:234 → web/spa.html:1 extends base.html<br>/settings/ [SPA settings] services/server/internal/web/server.go:234 → web/spa.html:1 extends base.html<br>/interests/ [SPA interests] services/server/internal/web/server.go:234 → web/spa.html:1 extends base.html<br>/topics/ [SPA topics] services/server/internal/web/server.go:234 → web/spa.html:1 extends base.html<br>/access/ [SPA access] services/server/internal/web/server.go:234 → web/spa.html:1 extends base.html<br>/profile/ [SPA profile] services/server/internal/web/server.go:234 → web/spa.html:1 extends base.html<br>/notifications/ [SPA notifications] services/server/internal/web/server.go:234 → web/spa.html:1 extends base.html<br>/notifications/preferences/ [SPA notification-preferences] services/server/internal/web/server.go:234 → web/spa.html:1 extends base.html<br>/communities/ [SPA communities] services/server/internal/web/server.go:234 → web/spa.html:1 extends base.html<br>/communities/<slug:slug>/ [SPA community-detail] services/server/internal/web/server.go:234 → web/spa.html:1 extends base.html<br>/connections/ [SPA connections] services/server/internal/web/server.go:234 → web/spa.html:1 extends base.html |

## Complete 155-name route registry classification

Registry presence alone is not a template render. JSON includes declared-method source positions and entry IDs.

| Route | Pattern | Effective GET | Effective POST |
|---|---|---|---|
| home | `/` | native_template_view | not_admitted_or_no_handler |
| my_meetups | `/my-meetups/` | native_template_view | not_admitted_or_no_handler |
| my_venues | `/my-venues/` | native_template_view | not_admitted_or_no_handler |
| service_worker | `/sw.js` | native_non_html_download | not_admitted_or_no_handler |
| organize | `/organize/` | native_template_view | not_admitted_or_no_handler |
| register | `/register/` | native_inline_mux_override | auth_admission_then_pinned_signup_status_or_redirect |
| login | `/login/` | native_inline_mux_override | accounts_LoginPOST_inline_failure_or_status_redirect |
| logout | `/logout/` | method_not_admitted_as_page | native_action_status_or_redirect_without_template |
| account_restricted | `/account/restricted/` | native_inline_mux_override | native_inline_safety_mux_override |
| places_map | `/places/` | native_template_view | not_admitted_or_no_handler |
| places_list | `/places/list/` | native_template_view | not_admitted_or_no_handler |
| place_propose | `/places/propose/` | native_template_view | native_template_on_specific_error_message_or_challenge_branch |
| place_claim | `/places/<int:pk>/claim/` | native_template_view | native_template_on_specific_error_message_or_challenge_branch |
| place_official_image | `/places/<int:pk>/official-image/` | admitted_redirect_to_place_detail | native_template_on_specific_error_message_or_challenge_branch |
| places_pending | `/places/pending/` | native_template_view | not_admitted_or_no_handler |
| place_confirm | `/places/pending/<int:proposal_id>/confirm/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| place_detail | `/places/<int:pk>/` | native_template_view | not_admitted_or_no_handler |
| edge_vote | `/places/<int:pk>/edges/<int:edge_id>/vote/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| fact_vote | `/places/<int:pk>/facts/vote/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| place_correction_propose | `/places/<int:pk>/corrections/propose/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| place_correction_confirm | `/places/<int:pk>/corrections/<int:correction_id>/confirm/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| place_open_now_report | `/places/<int:pk>/hours-wrong/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| place_open_now_reset | `/places/<int:pk>/hours-reset/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| place_closure_report | `/places/<int:pk>/closed/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| place_closure_reset | `/places/<int:pk>/closed-reset/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| place_detail_slug | `/places/<int:pk>/<slug:slug>/` | native_template_view | not_admitted_or_no_handler |
| events_feed | `/events/feed/` | native_non_html_download | not_admitted_or_no_handler |
| events_feed_atom | `/events/feed/atom/` | native_non_html_download | not_admitted_or_no_handler |
| events_list | `/events/` | native_template_view | not_admitted_or_no_handler |
| event_detail | `/events/<int:pk>/` | native_template_view | not_admitted_or_no_handler |
| event_report | `/events/<int:pk>/report/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| event_report_reset | `/events/<int:pk>/report-reset/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| event_detail_slug | `/events/<int:pk>/<slug:slug>/` | native_template_view | not_admitted_or_no_handler |
| things_to_do_index | `/things-to-do/` | native_template_view | not_admitted_or_no_handler |
| things_to_do_city | `/things-to-do/<slug:area_slug>/` | native_template_view | not_admitted_or_no_handler |
| things_to_do | `/things-to-do/<slug:area_slug>/<slug:activity_slug>/` | native_template_view | not_admitted_or_no_handler |
| activity_list | `/activities/` | native_template_view | not_admitted_or_no_handler |
| activity_create | `/activities/new/` | native_template_view | native_template_on_specific_error_message_or_challenge_branch |
| series_list | `/activities/series/` | native_template_view | not_admitted_or_no_handler |
| series_create | `/activities/series/new/` | native_template_view | native_template_on_specific_error_message_or_challenge_branch |
| series_detail | `/activities/series/<int:pk>/` | native_template_view | not_admitted_or_no_handler |
| series_pause | `/activities/series/<int:pk>/pause/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| series_resume | `/activities/series/<int:pk>/resume/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| series_set_next_note | `/activities/series/<int:pk>/next-note/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| series_end | `/activities/series/<int:pk>/end/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| activity_detail | `/activities/<int:pk>/` | native_template_view | not_admitted_or_no_handler |
| activity_edit | `/activities/<int:pk>/edit/` | native_template_view | native_template_on_specific_error_message_or_challenge_branch |
| activity_cancel | `/activities/<int:pk>/cancel/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| activity_announce | `/activities/<int:pk>/announce/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| activity_add_supervisor | `/activities/<int:pk>/supervisor/add/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| activity_set_supervision | `/activities/<int:pk>/supervision/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| activity_grant_coorg | `/activities/<int:pk>/co-org/grant/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| activity_revoke_coorg | `/activities/<int:pk>/co-org/revoke/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| activity_transfer_owner | `/activities/<int:pk>/transfer/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| activity_rsvp | `/activities/<int:pk>/rsvp/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| activity_support_companion | `/activities/<int:pk>/support-person/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| activity_arrived | `/activities/<int:pk>/arrived/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| activity_transit | `/activities/<int:pk>/transit/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| activity_departing | `/activities/<int:pk>/departing/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| activity_met | `/activities/<int:pk>/met/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| activity_join | `/activities/<int:pk>/join/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| activity_leave | `/activities/<int:pk>/leave/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| activity_unsafe | `/activities/<int:pk>/unsafe/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| activity_post | `/activities/<int:pk>/post/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| share_to_thread | `/share/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| activity_post_edit | `/activities/<int:pk>/post/<int:post_id>/edit/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| activity_post_delete | `/activities/<int:pk>/post/<int:post_id>/delete/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| activity_post_react | `/activities/<int:pk>/post/<int:post_id>/react/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| activity_post_dissent | `/activities/<int:pk>/post/<int:post_id>/dissent/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| activity_post_concern | `/activities/<int:pk>/post/<int:post_id>/concern/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| activity_photo | `/activities/<int:pk>/photo/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| membership_vote | `/activities/<int:pk>/members/<int:membership_id>/vote/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| saved_searches | `/saved-searches/` | native_template_view | not_admitted_or_no_handler |
| saved_search_create | `/saved-searches/create/` | method_not_admitted_as_page | native_action_status_or_redirect_without_template |
| saved_search_delete | `/saved-searches/<int:pk>/delete/` | method_not_admitted_as_page | native_action_status_or_redirect_without_template |
| you | `/you/` | native_template_view | not_admitted_or_no_handler |
| settings | `/settings/` | native_template_view | not_admitted_or_no_handler |
| api_token_revoke | `/settings/api-token/revoke/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| inbox | `/inbox/` | no_native_view_case_private_redirect_or_404 | not_admitted_or_no_handler |
| interests | `/interests/` | native_template_view | native_action_status_or_redirect_without_template |
| topic_preferences | `/topics/` | native_template_view | native_action_status_or_redirect_without_template |
| access_preferences | `/access/` | native_template_view | native_template_on_specific_error_message_or_challenge_branch |
| profile | `/profile/` | native_template_view | not_admitted_or_no_handler |
| avatar_upload | `/profile/avatar/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| avatar_style | `/profile/avatar-style/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| person | `/people/<uuid:public_id>/` | native_template_view | not_admitted_or_no_handler |
| person_card | `/people/<uuid:public_id>/card/` | native_template_view | not_admitted_or_no_handler |
| verify_age | `/verify-age/` | native_template_view | native_template_on_specific_error_message_or_challenge_branch |
| wards | `/wards/` | native_template_view | not_admitted_or_no_handler |
| guardian_invite_create | `/wards/invite/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| guardian_revoke | `/wards/<int:ward_pk>/revoke/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| guardian_guardrail_set | `/wards/<int:ward_pk>/limits/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| ward_topics_set | `/wards/<int:ward_pk>/topics/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| my_guardians | `/guardianship/` | native_template_view | not_admitted_or_no_handler |
| guardian_invite_accept | `/guardian-invites/<str:token>/accept/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| guardian_invite_decline | `/guardian-invites/<str:token>/decline/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| notifications | `/notifications/` | native_template_view | not_admitted_or_no_handler |
| notifications_read_all | `/notifications/read-all/` | method_not_admitted_as_page | native_action_status_or_redirect_without_template |
| notification_preferences | `/notifications/preferences/` | native_template_view | native_template_on_specific_error_message_or_challenge_branch |
| messages | `/messages/` | native_template_view | not_admitted_or_no_handler |
| groups | `/groups/` | redirect_to_communities | not_admitted_or_no_handler |
| group_create | `/groups/new/` | native_template_view | native_template_on_specific_error_message_or_challenge_branch |
| group_detail | `/groups/<int:pk>/` | native_template_view | not_admitted_or_no_handler |
| group_join | `/groups/<int:pk>/join/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| group_leave | `/groups/<int:pk>/leave/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| group_post | `/groups/<int:pk>/post/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| group_post_edit | `/groups/<int:pk>/posts/<int:post_id>/edit/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| group_post_delete | `/groups/<int:pk>/posts/<int:post_id>/delete/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| group_post_react | `/groups/<int:pk>/posts/<int:post_id>/react/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| group_post_dissent | `/groups/<int:pk>/posts/<int:post_id>/dissent/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| group_post_concern | `/groups/<int:pk>/posts/<int:post_id>/concern/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| group_announce | `/groups/<int:pk>/announce/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| group_ask | `/groups/<int:pk>/ask/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| group_archive | `/groups/<int:pk>/archive/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| gauges | `/gauges/` | native_template_view | not_admitted_or_no_handler |
| gauge_create | `/gauges/new/` | native_template_view | native_template_on_specific_error_message_or_challenge_branch |
| gauge_detail | `/gauges/<int:pk>/` | native_template_view | not_admitted_or_no_handler |
| gauge_interested | `/gauges/<int:pk>/interested/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| gauge_uninterested | `/gauges/<int:pk>/uninterested/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| gauge_convert | `/gauges/<int:pk>/convert/` | native_template_view | native_template_on_specific_error_message_or_challenge_branch |
| communities | `/communities/` | native_template_view | not_admitted_or_no_handler |
| community_graph | `/communities/graph/` | native_template_view | not_admitted_or_no_handler |
| community_detail | `/communities/<slug:slug>/` | native_template_view | not_admitted_or_no_handler |
| connections | `/connections/` | native_template_view | not_admitted_or_no_handler |
| connection_request | `/connections/request/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| connection_respond | `/connections/<int:pk>/respond/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| connection_withdraw | `/connections/<int:pk>/withdraw/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| connection_remove | `/connections/remove/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| connection_message | `/connections/message/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| donate | `/donate/` | native_template_view | native_template_on_specific_error_message_or_challenge_branch |
| transparency | `/transparency/` | native_template_view | not_admitted_or_no_handler |
| my_donations | `/my-donations/` | native_template_view | not_admitted_or_no_handler |
| campaigns | `/campaigns/` | native_template_view | not_admitted_or_no_handler |
| partners | `/partners/` | native_template_view | not_admitted_or_no_handler |
| open_data | `/open-data/` | native_template_view | not_admitted_or_no_handler |
| open_data_snapshot | `/open-data/snapshot/<str:name>` | native_non_html_download | not_admitted_or_no_handler |
| discover | `/discover/` | native_template_view | not_admitted_or_no_handler |
| activity_listing_toggle | `/activities/<int:pk>/listing/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| group_listing_toggle | `/groups/<int:pk>/listing/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| report | `/report/` | native_template_view | native_template_on_specific_error_message_or_challenge_branch |
| block_user | `/users/<int:pk>/block/` | method_not_admitted_as_page | native_action_status_or_redirect_without_template |
| unblock_user | `/users/<int:pk>/unblock/` | method_not_admitted_as_page | native_action_status_or_redirect_without_template |
| display_preferences | `/display/` | native_template_view | native_action_status_or_redirect_without_template |
| privacy | `/privacy/` | native_template_view | not_admitted_or_no_handler |
| terms | `/terms/` | native_template_view | not_admitted_or_no_handler |
| my_privacy | `/my-privacy/` | native_template_view | not_admitted_or_no_handler |
| activity_log | `/my-activity-log/` | native_template_view | not_admitted_or_no_handler |
| safety_record | `/my-safety-record/` | native_template_view | not_admitted_or_no_handler |
| safety_record_appeal | `/my-safety-record/contest/` | method_not_admitted_as_page | native_template_on_specific_error_message_or_challenge_branch |
| account_export | `/account/export/` | native_non_html_download | not_admitted_or_no_handler |
| my_calendar | `/account/calendar.ics` | native_non_html_download | not_admitted_or_no_handler |
| account_delete | `/account/delete/` | native_template_view | native_template_on_specific_error_message_or_challenge_branch |
| moderation_dashboard | `/moderation/` | native_inline_mux_override | native_inline_safety_mux_override |
| moderation_concern | `/moderation/concern/<int:pk>/` | no_native_view_case_private_redirect_or_404 | not_admitted_or_no_handler |
| spa_preview | `/app/preview/` | no_native_view_case_private_redirect_or_404 | not_admitted_or_no_handler |

## Capture conditions

- Every entry requires admitted synthetic authority/domain state; gate refusal outputs are separate matrix rows. Includes may be conditional.
- SPA enables 20 contracts; only events, places-list and three things-to-do variants include their corresponding snapshots. `_data=1` is JSON and anonymous home stays landing.
- POST helpers bypass SPA; successful actions usually redirect. Form/error/message/busy/challenge branches remain native-authoritative and synthetic-only.
- `Renderer.Bootstrap` lacks a non-test caller, groups redirects before view, official-image GET redirects before render. Literal references do not invent coverage.
- Native inline/orphan historical ownership, exact bold matrix, independent reviewer and owner Live approval remain holds. No changed report/cohort/privacy semantics are chosen.

## Commands and boundaries

Read-only git/rg/nl and Python source/dependency/hash validation ran. No builds/tests, database/services, codecs, network/user data, live moderation or golden captures ran. Only this Markdown and JSON companion were written.

Validation: all 91 loader hashes independently match `git show aa10645:<path>`; 196 unique native render entries resolve every file reference; all runtime flags false; shared repository remains clean. Authenticated POST share-to-thread maps home only, never the anonymous landing branch.
