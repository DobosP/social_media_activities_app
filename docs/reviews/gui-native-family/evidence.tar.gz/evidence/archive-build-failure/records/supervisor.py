#!/usr/bin/env python3
"""Detach only the reviewed canonical qualification command; retain its exit."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def save(record):
    pending = ROOT / 'supervisor-status.tmp'
    pending.write_text(json.dumps(record, indent=2) + '\n')
    pending.replace(ROOT / 'supervisor-status.json')

parser = argparse.ArgumentParser()
parser.add_argument('--launch', action='store_true')
parser.add_argument('--sha', required=True)
args = parser.parse_args()
repo = Path('/home/dobo/work/_worktrees/social_media_activities_app/feat__gui-app-migration-a')
method = repo / 'tools/gui-native-family/qualify.py'
if args.launch:
    if (ROOT / 'supervisor-status.json').exists():
        raise SystemExit('Existing supervisor status must be reviewed before another launch')
    with (ROOT / 'supervisor.log').open('xb', buffering=0) as log:
        child = subprocess.Popen([sys.executable, '-I', str(Path(__file__).resolve()), '--sha', args.sha],
                                 stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                                 start_new_session=True, close_fds=True)
    (ROOT / 'supervisor.pid').write_text(str(child.pid) + '\n')
    print(json.dumps({'supervisor_pid': child.pid, 'root': str(ROOT)}))
    raise SystemExit(0)

# The canonical method owns all source fences, tests, runtime and cleanup. This
# wrapper adds no acceptance criteria or source mutations.
command = [sys.executable, '-I', str(method), '--sha', args.sha, '--execute',
           '--repo', str(repo), '--scratch', str(ROOT), '--go', '/usr/local/go/bin/go',
           '--cache', '/home/dobo/work/_temp/gui-functional-hub/go-cache',
           '--modcache', '/home/dobo/work/_temp/feat__gui-app-migration-a/social_media_activities_app/go-mod']
record = {'schema': 1, 'operator': 'agent:codex (PROGRAM E8)', 'status': 'RUNNING',
          'source': args.sha, 'command': command, 'supervisor_pid': os.getpid(),
          'started_utc': now(), 'method_sha256': hashlib.sha256(method.read_bytes()).hexdigest()}
save(record)
with (ROOT / 'supervised-gate.log').open('xb', buffering=0) as log:
    child = subprocess.Popen(command, cwd=repo, stdin=subprocess.DEVNULL, stdout=log,
                             stderr=subprocess.STDOUT, start_new_session=True)
    record['gate_pid'] = child.pid
    save(record)
    code = child.wait()
record.update(status='PASS' if code == 0 else 'FAIL', gate_child_exit=code,
              finished_utc=now(), stdout_sha256=hashlib.sha256((ROOT / 'supervised-gate.log').read_bytes()).hexdigest())
save(record)
