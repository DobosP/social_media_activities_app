#!/usr/bin/env python3
"""Read-only Group feature collection; excludes source exports/binaries/cache/archive duplicates."""
import hashlib,io,json,os,stat,subprocess,tarfile
from decimal import Decimal
from pathlib import Path
ROOT=Path('/home/dobo/work/_temp/feat__gui-app-migration-a/social-family')
REPO=Path('/home/dobo/work/_worktrees/social_media_activities_app/feat__gui-app-migration-a')
DRAFT=Path(__file__).parent/'draft'
PRODUCER='1f8c9742de327a6758224a22bf9f7919245ec9a3'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def need(ok,msg):
 if not ok:raise RuntimeError(msg)
def read(p):
 s=p.lstat();need(stat.S_ISREG(s.st_mode) and s.st_size<64*1024*1024,'bounded regular file required '+str(p));raw=p.read_bytes();a=p.stat();need((s.st_ino,s.st_size,s.st_mtime_ns)==(a.st_ino,a.st_size,a.st_mtime_ns) and len(raw)==s.st_size,'source changed');return raw,s
def load(p):return json.loads(read(p)[0])
def git(*args):return subprocess.check_output(['git','-C',str(REPO),*args])
def main():
 need(not DRAFT.exists() and not git('status','--porcelain'),'fresh output and clean source required');head=git('rev-parse','HEAD').decode().strip();need(head.startswith('d05343bb'),'exact presentation source required')
 bridge=json.loads(subprocess.check_output(['python3','-I',str(REPO/'tools/gui-native-group/prepare-ui-overlay.py'),'--repo',str(REPO),'--producer-source',PRODUCER,'--check-bridge']))
 run=next((ROOT/'group-pg-qa-successor').glob('run-1f8c9742de32-*'));pg=load(run/'result.json');need(pg['source']==PRODUCER and pg['method_pass'] is True and not pg['errors'] and len(pg['lanes'])==6 and all(x['state']=='PASS' and x['tests']['fail']==x['tests']['skip']==0 for x in pg['lanes'].values()),'actual whole6 PG required')
 totals={k:sum(x['tests'][k] for x in pg['lanes'].values()) for k in ['top_level','named_passes']};need(totals=={'top_level':408,'named_passes':1190},'exact actual PG totals')
 ui=ROOT/'group-ui-qa';dr=load(ui/'presentation-desktop/desktop-results.json');need(sha(read(ui/'presentation-desktop/desktop-results.json')[0])=='877693363ca5afc19890fa2e039f6b1987debadbfd9340cd514b8b12f5f95411' and dr['status']=='pass' and not dr['failures'] and dr['sourceUnchanged'] and len(dr['states'])==10 and len(dr['noJavaScript'])==2 and all(v is True for k,v in dr['ownership'].items() if k!='userProfile') and dr['ownership']['userProfile'] is False,'actual UI10/2 cleanup required')
 phases=[p for state in dr['states'] for p in state['auditStates']['records']];need(len(phases)==30 and all(not p['axe']['violations'] and not p['axe']['incomplete'] for p in phases),'all30 strict full-document Axe required')
 bench=load(ui/'benchmark-result.json');need(bench['actual_waited_child_exit']==0 and len(bench['rows'])==12 and sha(read(ui/'benchmark.stdout')[0])==bench['raw_stdout_sha256']=='5d0740c341af9f65c18f89885156aa3dde0435208494a517e36b13ec995ae842','actual matched benchmark required')
 need(sha(read(ui/'actual-form.json')[0])=='e2d06a8dffbbd7f00250cb219a2ee58ac59630388142ebf6a716086a0e981dbb','immutable actual producer capture')
 payload={};omitted=[]
 def add(p,name):
  need(name not in payload,'duplicate archive name');raw,s=read(p);payload[name]=(raw,s,str(p))
 def tree(p,prefix,filter_fn=None):
  for f in sorted(p.rglob('*')):
   if filter_fn is not None and not filter_fn(f):continue
   need(not f.is_symlink(),'evidence symlink refused')
   if f.is_file():add(f,prefix+'/'+f.relative_to(p).as_posix())
 def pg_run(p,label):
  r=load(p/'result.json');archive_sha=r['git_archive'].get('sha256');archive_paths={c['stdout']['path'] for c in r['commands'] if c['stdout']['sha256']==archive_sha}
  for f in sorted(p.iterdir()):
   if f.is_file():add(f,'evidence/'+label+'/'+f.name)
  for f in sorted((p/'proof').iterdir()):
   if f.relative_to(p).as_posix() in archive_paths:omitted.append({'path':str(f),'sha256':archive_sha,'reason':'duplicate full Git archive stdout; source commit/tree/manifest retained'});continue
   if f.is_file():add(f,'evidence/'+label+'/proof/'+f.name)
  tree(p/'socket','evidence/'+label+'/socket')
 pg_run(run,'PG-final')
 first=next((ROOT/'group-pg-qa').glob('run-1dd7b0c31e95-*'));pg_run(first,'PG-first-failed')
 # Keep two failed-state initial images and all six causal geometry views;
 # superseded successful-state PNGs are manifested but not duplicated.
 def ui_filter(f):
  relative=f.relative_to(ui)
  if f.suffix=='.png' and relative.parts[0] in ('desktop','geometry'):
   keep=(relative.parts[0]=='desktop' and f.name in ('group-positive-ro-desktop.png','group-escaping-ro-desktop.png')) or (relative.parts[0]=='geometry' and '-audit-' in f.name)
   if not keep:omitted.append({'path':str(f),'sha256':sha(read(f)[0]),'bytes':f.stat().st_size,'reason':'superseded PNG; latest40 verified captures and causal8 retained'})
   return keep
  return True
 tree(ui,'evidence/UI',ui_filter)
 for name in ['group-final-independent-review','group-fresh-independent-review','group-source-guard-repair','group-opaque-header-repair','group-ui-geometry-diagnostic','group-ui-method-proposal']:
  for f in sorted((ROOT/name).iterdir()):
   if f.is_file() and f.suffix in ('.json','.patch','.mjs','.py','.txt') and f.name not in ('audit_teacher_keeper.py','teacher-auth-evidence-review.json','teacher-dashboard-contract-review.json'):add(f,'evidence/'+name+'/'+f.name)
 for name in ['group-pg-qa','group-pg-qa-successor']:
  for f in sorted((ROOT/name).iterdir()):
   if f.is_file():add(f,'evidence/'+name+'/'+f.name)
 for name in ['superseded-export-retention.json']:add(ROOT/'retention'/name,'evidence/retention/'+name)
 for name in ['gui-native-group','gui-native-family']:
  for f in sorted((REPO/'tools'/name).rglob('*')):
   if f.is_file():add(f,'reproduce/tools/'+name+'/'+f.relative_to(REPO/'tools'/name).as_posix())
 add(Path(__file__).resolve(),'reproduce/collection/collect.py')
 DRAFT.mkdir();archive=DRAFT/'evidence.tar.gz';manifest=[]
 with tarfile.open(archive,'w:gz',format=tarfile.PAX_FORMAT) as out:
  for name,(raw,s,p) in sorted(payload.items()):
   e=tarfile.TarInfo(name);e.size=len(raw);e.mode=stat.S_IMODE(s.st_mode);e.uid=s.st_uid;e.gid=s.st_gid;e.mtime=s.st_mtime_ns//10**9;e.pax_headers={'mtime':str(e.mtime)+'.'+str(s.st_mtime_ns%10**9).zfill(9)};out.addfile(e,io.BytesIO(raw));manifest.append({'member':name,'original_path':p,'bytes':len(raw),'sha256':sha(raw),'mode':e.mode,'uid':e.uid,'gid':e.gid,'mtime_ns':s.st_mtime_ns})
 with tarfile.open(archive,'r:gz') as inp:
  members=inp.getmembers();need([x.name for x in members]==[r['member'] for r in manifest],'complete archive inventory')
  for x,r in zip(members,manifest):need(x.isfile() and x.size==r['bytes'] and x.mode==r['mode'] and x.uid==r['uid'] and x.gid==r['gid'] and int(Decimal(x.pax_headers['mtime'])*10**9)==r['mtime_ns'] and sha(inp.extractfile(x).read())==r['sha256'],'complete byte/metadata readback')
 def write(name,r):(DRAFT/name).write_text(json.dumps(r,indent=2)+'\n')
 write('archive-manifest.json',{'archive_sha256':sha(archive.read_bytes()),'complete_roundtrip':True,'members':manifest})
 write('omitted-artifacts.json',{'scope':'Raw files omitted from compact keeper; physical retention state is separately recorded; original Git branches preserved','rows':omitted})
 write('result.json',{'schema':1,'status':'EXECUTED_FEATURE_COMPOSITE_PENDING_FINAL_INDEPENDENT_ACCEPTANCE','operator':'agent:codex (PROGRAM E8)','PG_source':PRODUCER,'presentation_source':head,'PG_result_sha256':sha(read(run/'result.json')[0]),'PG':{'complete_affected_packages':6,**totals,'skips':0,'failures':0},'presentation_bridge':bridge,'UI':{'states':10,'strict_whole_document_Axe_audits':30,'no_JS':2,'PNGs':40,'findings':0,'result_sha256':sha(read(ui/'presentation-desktop/desktop-results.json')[0]),'cleanup':True,'family_bodies_byte_exact':8},'benchmark':{'scope':'Actual same-form EN/RO nonstaff cachedPongo/native body only on PG producer source; CSS repair leaves body measurement code and inputs exact','raw_stdout_sha256':bench['raw_stdout_sha256'],'limitation':'Native smaller HTML/gzip/allocatedbytes but higher CPU and allocation count; no general speedup claim'},'archive':{'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'members':len(manifest)},'history':['Initial1dd web historical sourceguard failures remain red; capture inadmissible there','First desktop/geometry two contrast incompletes retained; account menu disproved as cause','Exact scoped opaque header repaired presentation, all runtimeGo unchanged','Earlier broad pure unit selected two DB roots withoutDSN; skipped and unqualified; final exact10pure roots48named zero skips','Original Go export tool stdout not independently saved; successor presentation export raw stream retained'],'limits':['Not exact-final completePG on later CSS/test presentation source','No full21/current-image/main/milestone/deployment/realchild claim'],'retention':'Older export retention365b9 and explicit omitted-raw inventory retained; no source branches or other owners work pruned'})
 print(json.dumps({'archive_sha256':sha(archive.read_bytes()),'members':len(manifest),'bytes':archive.stat().st_size,'result_sha256':sha((DRAFT/'result.json').read_bytes())}))
if __name__=='__main__':main()
