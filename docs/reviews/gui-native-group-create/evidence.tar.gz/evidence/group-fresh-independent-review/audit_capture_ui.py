import base64, collections, gzip, hashlib, json, pathlib, re, subprocess, tarfile
repo=pathlib.Path('/home/dobo/work/_worktrees/social_media_activities_app/feat__gui-app-migration-a')
out=pathlib.Path('/home/dobo/work/_temp/feat__gui-app-migration-a/social-family/group-fresh-independent-review')
run=out.parent/'group-pg-qa-successor/run-1f8c9742de32-e9f8010a-d5ae-4ca6-bf47-607d280e1638'
ui=out.parent/'group-ui-qa';sha='1f8c9742de327a6758224a22bf9f7919245ec9a3';findings=[]
def h(b):return hashlib.sha256(b).hexdigest()
def need(ok,msg):
 if not ok:findings.append(msg)
a=json.loads((ui/'actual-form.json').read_bytes());r=json.loads((run/'result.json').read_bytes());m=json.loads((ui/'fixtures/fixtures.json').read_bytes());source={x['path']:x for x in json.loads((run/'source-manifest.json').read_bytes())}
need(a['source_sha']==sha and a['producer_root']=='TestNativeGroupSemanticSnapshotUsesExistingBoundValuesAndCleaner','capture exact producer')
for key,file in [('result_sha256','result.json'),('source_manifest_sha256','source-manifest.json'),('raw_event_sha256','proof/web-test2json.stdout')]:need(a[key]==h((run/file).read_bytes()),'capture actual '+key)
need(a['qualifier_method_sha256']==r['method_sha256'],'capture method identity')
projection=base64.b64decode(a['projection_base64'],validate=True);need(h(projection)==a['projection_sha256'],'projection digest')
events=[json.loads(x)for x in(run/'proof/web-test2json.stdout').read_bytes().splitlines()];root=a['producer_root']
text=''.join(e.get('Output','')for e in events if e.get('Action')=='output'and e.get('Test')==root)
captures=re.findall(r'NATIVE_GROUP_FORM_V1 ([^\r\n]+)',text);need(len(captures)==1 and captures[0].encode()==projection,'captured projection exact raw actual producer t.Log')
need(sum(e.get('Action')=='run'and e.get('Test')==root for e in events)==sum(e.get('Action')=='pass'and e.get('Test')==root for e in events)==1,'producer root once RUN PASS')
need(len(a['source_rows'])==37 and len({x['path']for x in a['source_rows']})==37,'capture source closure37')
for x in a['source_rows']:
 need(all(x[k]==source[x['path']][k] for k in ['path','bytes','sha256']),'capture qualified source '+x['path'])
 need(h((repo/x['path']).read_bytes())==x['sha256'],'capture current source '+x['path'])
value=json.loads(projection);need(set(value)=={'actor','native_group','as_p','schema','errors'}and value['schema']==1 and value['errors']==''and value['native_group']['Staff']is False,'finite capture shape')
need(value['actor']['username']=='legacy-organiser'and value['actor']['role']=='user'and value['actor']['cohort']==value['actor']['age_band']=='adult'and value['actor']['identity_verified']and value['actor']['is_active']and not value['actor']['is_staff']and not value['actor']['is_superuser'],'synthetic nonstaff actor')
need([f['Name']for f in value['native_group']['Fields']]==['city','activity_type','title','description'],'capture field inventory')
need(m['PG_producer_source']==m['UI_method_source']==sha and m['source_unchanged']and m['sources_before']==m['sources_after'],'fixture producer/current/source fence')
need(len(m['sources_before'])==41 and len({x['path']for x in m['sources_before']})==41,'fixture sources41')
for x in m['sources_before']:need(len((repo/x['path']).read_bytes())==x['bytes']and h((repo/x['path']).read_bytes())==x['sha256'],'fixture current source '+x['path'])
need(len(m['states'])==10 and len({x['name']for x in m['states']})==10,'ten unique UI fixture states')
for x in m['states']:
 raw=(ui/'fixtures'/(x['name']+'.html')).read_bytes();need(len(raw)==x['bytes']and h(raw)==x['sha256'],'fixture body '+x['name'])
 need(b'<script'not in raw and b'PRIVATE-'not in raw,'fixture no active/unadmitted markup '+x['name'])
 need(x['renderer_headers']['Content-Type']=='text/html; charset=utf-8'and x['renderer_headers']['Cache-Control']=='private, no-cache'and x['renderer_headers']['Vary']=='Cookie'and x['renderer_csp_report_only'],'fixture original Renderer headers '+x['name'])
baseline=json.loads((repo/'tools/gui-native-group/family-html-baseline.json').read_bytes());byname={x['path']:x for x in baseline['html']}
prior=repo/'docs/reviews/gui-native-family/evidence.tar.gz'
with tarfile.open(prior,'r:gz')as t:
 report=t.extractfile('evidence/selected/ui-qa/desktop-v3/desktop-results.json').read();need(h(report)==baseline['accepted_UI_report_sha256'],'family baseline accepted real V3 report hash')
 for x in m['family_byte_equality']:
  raw=(ui/'fixtures/family'/(x['name']+'.html')).read_bytes();old=t.extractfile('evidence/ui/html/'+x['name']+'.html').read();pin=byname[x['name']+'.html']
  need(raw==old and len(raw)==x['bytes']==pin['bytes']and h(raw)==x['sha256']==pin['sha256']and x['equal']is True,'family actual old/new bytes '+x['name'])
need(len(m['family_byte_equality'])==8,'eight family bodies')
report={'schema':1,'source':sha,'status':'PASS'if not findings else 'FAIL','scope':'Actual successful PG producer capture, actual10group fixture exports and8family byte equality only; desktop/benchmark/keeper pending','capture_sha256':h((ui/'actual-form.json').read_bytes()),'projection_sha256':h(projection),'actual_projection_bytes':len(projection),'capture_source_rows':37,'fixture_source_rows':41,'fixture_manifest_sha256':h((ui/'fixtures/fixtures.json').read_bytes()),'native_states':10,'family_bodies_compared_byte_for_byte_to_accepted_archive':8,'findings':findings}
(out/'capture-fixture-review.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
