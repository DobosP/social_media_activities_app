import collections, hashlib, json, pathlib, re, stat, subprocess

repo=pathlib.Path('/home/dobo/work/_worktrees/social_media_activities_app/feat__gui-app-migration-a')
out=pathlib.Path('/home/dobo/work/_temp/feat__gui-app-migration-a/social-family/group-fresh-independent-review')
run=out.parent/'group-pg-qa-successor/run-1f8c9742de32-e9f8010a-d5ae-4ca6-bf47-607d280e1638'
sha='1f8c9742de327a6758224a22bf9f7919245ec9a3'
base='7b514f08e76e4a33a325281f6ecf44ed99bed75e'
j=json.loads((run/'result.json').read_bytes()); findings=[]
def need(ok,msg):
 if not ok:findings.append(msg)
def h(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(repo),*args])
need(git('rev-parse','HEAD').decode().strip()==sha and git('status','--porcelain')==b'', 'clean exact HEAD')
need(j['source']==sha and j['tree']==git('rev-parse',sha+'^{tree}').decode().strip() and j['method_pass'] is True and j['errors']==[], 'result source/pass')
rows=j['artifact_rows'];need(len(rows)==len({r['path'] for r in rows}),'artifact row uniqueness')
for r in rows:
 p=run/r['path'];raw=p.read_bytes();need(len(raw)==r['bytes'] and h(raw)==r['sha256'],'artifact hash '+r['path'])
source=json.loads((run/'source-manifest.json').read_bytes()); tracked={x.decode() for x in git('ls-files','-z').split(b'\0') if x}
need({r['path'] for r in source}==tracked,'source manifest exact tracked paths')
for r in source:
 for root in [repo,run/'source']:
  p=root/r['path']; raw=p.read_bytes();mode=stat.S_IMODE(p.stat().st_mode)
  mode_ok=(mode==r['mode']) if root==run/'source' else ((mode&0o111)==(r['mode']&0o111))
  need(len(raw)==r['bytes'] and h(raw)==r['sha256'] and mode_ok,'source bytes/Git-executable-mode '+str(p))
archive=git('archive','--format=tar',sha);need(len(archive)==j['git_archive']['bytes'] and h(archive)==j['git_archive']['sha256'],'recomputed Git archive')
for r in j['method_inputs']:
 raw=(repo/r['path']).read_bytes();need(len(raw)==r['bytes'] and h(raw)==r['sha256'],'method hash '+r['path'])
expected=json.loads((repo/j['catalog_reference_source']['path']).read_bytes());expected={k:sorted(v,key=lambda r:r['id']) for k,v in expected.items()}
inventories={}; refs={}; inspections=[]
for lane,l in j['lanes'].items():
 events=[json.loads(x) for x in (run/f'proof/{lane}-test2json.stdout').read_bytes().splitlines()]
 runs=[e['Test'] for e in events if e['Action']=='run' and 'Test'in e]; passes=[e['Test'] for e in events if e['Action']=='pass' and 'Test'in e]
 listed=[x for x in (run/f'proof/{lane}-list.stdout').read_text().splitlines() if x.startswith('Test')]; roots=[x for x in runs if '/' not in x]
 need(set(e.get('Package') for e in events)=={'github.com/DobosP/social_media_activities_app/services/server/internal/'+lane},'package frames '+lane)
 need(collections.Counter(runs)==collections.Counter(passes) and len(runs)==len(set(runs)) and set(roots)==set(listed),'exact runs/passes/list '+lane)
 need(not any(e['Action']in('skip','fail') or '(cached)'in e.get('Output','') or 'DATA RACE'in e.get('Output','') for e in events),'no skip/fail/cache/race '+lane)
 need(sum(e['Action']=='pass'and 'Test'not in e for e in events)==1,'one package pass '+lane)
 need(l['tests']['identities']==runs and l['tests']['named_passes']==len(passes) and l['tests']['top_level']==len(roots),'result inventories '+lane)
 old=git('grep','-h','-E',r'^func Test[A-Za-z0-9_]+\(',base,'--',f'services/server/internal/{lane}/*_test.go').decode()
 oldnames=re.findall(r'^func (Test\w+)\(',old,re.M)
 need(set(oldnames)<=set(roots),'old declarations retained '+lane)
 native=(run/f'proof/{lane}-native.stdout').read_bytes();need(b'FAIL'not in native and b'DATA RACE'not in native and b'(cached)'not in native,'raw native pass '+lane)
 need((run/f'proof/{lane}-native.stderr').read_bytes()==b'','empty native stderr '+lane)
 binary=run/f'binaries/{lane}.test';need(h(binary.read_bytes())==l['binary']['sha256'],'binary hash '+lane)
 for point in ['before','after']:
  actual=json.loads((run/f'proof/{lane}-pg-{point}-reference.stdout').read_bytes());need(actual==expected,'canonical five datasets '+lane+' '+point)
  binding=json.loads((run/f'proof/{lane}-pg-{point}.stdout').read_bytes());need(binding=={k:v for k,v in l['pg_'+point].items() if k!='catalog_reference'},'raw pg binding '+lane+' '+point)
 need(l['pg_before']==l['pg_after'],'same before/after pg '+lane)
 r=j['retired_databases'][lane];need(r['database']==l['pg_after']['database'] and r['oid']==l['pg_after']['oid'],'retirement bound identity '+lane)
 for phase,key in [('before','before_drop'),('dropped','after_drop'),('checkpointed','after_checkpoint')]:
  catalog=json.loads((run/f'proof/{lane}-retire-{phase}-catalog.stdout').read_bytes())
  tmpfs=(run/f'proof/{lane}-retire-{phase}-tmpfs.stdout').read_text().splitlines()[1].split()
  catalog['tmpfs']={'bytes':int(tmpfs[0]),'used_bytes':int(tmpfs[1]),'available_bytes':int(tmpfs[2])}
  need(catalog==r[key],'raw retirement storage/catalog snapshot '+lane+' '+phase)
 need(any(d['name']==r['database']and d['oid']==r['oid']and d['client_connections']==0 for d in r['before_drop']['databases']),'retirement own idle identity '+lane)
 need(all(not any(d['name']==r['database']or d['oid']==r['oid'] for d in r[k]['databases']) for k in ['after_drop','after_checkpoint']),'retirement name/OID absence '+lane)
 need((run/f'proof/{lane}-retire-drop.stdout').read_text().strip()=='DROP DATABASE' and (run/f'proof/{lane}-retire-checkpoint.stdout').read_text().strip()=='CHECKPOINT','raw drop/checkpoint '+lane)
 inventories[lane]={'top_level':len(roots),'named_passes':len(passes),'retained_old_declarations':len(oldnames),'new_group_roots':[x for x in roots if x.startswith('TestNativeGroup')]}
for c in j['commands']:
 a=c['argv']
 for stream in ['stdout','stderr']:
  r=c[stream]; raw=(run/r['path']).read_bytes();need(len(raw)==r['bytes'] and h(raw)==r['sha256'],'command raw '+r['path'])
 if len(a)>3 and a[:3]==['docker','container','inspect'] and c['exit']==0:
  raw=(run/c['stdout']['path']).read_bytes()
  try:s=json.loads(raw)
  except:continue
  if not isinstance(s,dict):continue
  isdb=s['id']==j['cleanup']['db']['cid'];need(s['memory']==(2147483648 if isdb else 3221225472) and s['cpus']==(1000000000 if isdb else 2000000000) and s['pids']==(256 if isdb else 512),'inspect resource caps')
  need(s['network']=='none' and not s['ports'] and s['readonly'] and not s['privileged'] and s['caps']==['ALL'] and s['security']==['no-new-privileges'] and not s['oom'],'inspect boundary/oom')
  if isdb:need(s['tmpfs']['/var/lib/postgresql/data']=='rw,nosuid,nodev,size=1g,uid=999,gid=999,mode=0700','fixed PG tmpfs')
  inspections.append(s)
for name,r in j['cleanup'].items():
 cid=(run/(name+'.cid')).read_text().strip();need(cid==r['cid']and r['id_absent'] and r['name_absent']and r['stopped'],'cleanup CID '+name)
 removes=[c for c in j['commands'] if c['argv']==['docker','container','rm',cid]];need(len(removes)==1 and removes[0]['exit']==0,'raw CID removal '+name)
 probes=[c for c in j['commands'] if c['argv'][:4]==['docker','container','ls','-aq'] and any(x=='id='+cid for x in c['argv'])];need(len(probes)==1 and probes[0]['exit']==0 and (run/probes[0]['stdout']['path']).read_bytes()==b'','raw CID absence '+name)
 names={s['name'] for s in inspections if s['id']==cid};need(len(names)==1,'observed unique container name '+name)
 actualname=next(iter(names));after_remove=j['commands'][j['commands'].index(removes[0])+1:];nameprobes=[c for c in after_remove if c['argv'][:4]==['docker','container','ls','-aq']and 'name=^'+actualname+'$'in c['argv']];need(len(nameprobes)==1 and nameprobes[0]['exit']==0 and (run/nameprobes[0]['stdout']['path']).read_bytes()==b'','raw name absence '+name)
for lane in j['lanes']:
 compiles=[c for c in j['commands'] if c['argv'][0]==j['go']['actual_executable'] and '-race'in c['argv'] and '-c'in c['argv'] and c['argv'][-1]=='./internal/'+lane]
 need(len(compiles)==1 and compiles[0]['exit']==0,'race compiled actual binary '+lane)
need(len(j['cleanup'])==13,'13 owned cleanup')
need(json.loads((run/'socket/pg-cleanup.json').read_bytes())==j['pg_cleanup']=={'owned_pid':24,'pid_and_socket_files_absent':1,'pid_probe_exit':1,'status_exit':3,'stop_exit':0},'raw PG cleanup')
log=(run/'proof/database-final-log.stdout').read_text();need(not re.search(r'PANIC|No space left|database system was interrupted|automatic recovery|redo starts|invalid checkpoint',log,re.I),'PG raw panic/space/recovery')
need('database system is shut down'in log and 'pg_ctl: no server running'in log,'PG raw clean stop')
family=['services/server/internal/web/family.go','services/server/internal/web/family_copy.go','services/server/internal/web/family_render.go','services/server/internal/web/pages/family-shell.gohtml','services/server/internal/web/pages/family-wards.gohtml','services/server/internal/web/pages/family-guardianship.gohtml','static/css/family-native.css']
need(git('diff','--name-only',base,sha,'--',*family)==b'','seven family product sources exact')
changed=git('diff','--name-only',base,sha).decode().splitlines();need(not any(p.startswith('services/authcore/') or p.endswith(('go.mod','go.sum')) or '/migrations/'in p or p.startswith('locale/') or p.startswith('apps/') or p=='static/css/base.css' for p in changed),'no forbidden dependency/schema/authcore/catalogue/original template/baseCSS delta')
report={'schema':1,'source':sha,'base':base,'scope':'read-only six-package Group source and actual raw runtime audit; UI/capture/benchmark acceptance pending','result_sha256':h((run/'result.json').read_bytes()),'source_manifest_sha256':h((run/'source-manifest.json').read_bytes()),'recomputed_git_archive_sha256':h(archive),'proof_artifact_rows_rehashed':len(rows),'tracked_source_rows_rehashed_at_checkout_and_export':len(source),'raw_command_receipts_rehashed':len(j['commands']),'raw_inspections_checked':len(inspections),'inventories':inventories,'canonical_catalogue_rows':{k:len(v) for k,v in expected.items()},'raw_pg_log_errors':[x for x in log.splitlines()if 'ERROR:'in x],'findings':findings,'status':'PASS'if not findings else 'FAIL'}
(out/'pg-source-review.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
