import collections, hashlib, json, pathlib, re, subprocess, tarfile
repo=pathlib.Path('/home/dobo/work/_worktrees/social_media_activities_app/feat__gui-app-migration-a')
root=pathlib.Path('/home/dobo/work/_temp/feat__gui-app-migration-a/social-family')
ui=root/'group-ui-qa';p=ui/'presentation-desktop';f=ui/'presentation-fixtures';out=root/'group-fresh-independent-review'
PG='1f8c9742de327a6758224a22bf9f7919245ec9a3';head='d05343bb0ea10836feb9d7e62fd2325c8c85bb7a';findings=[]
def h(b):return hashlib.sha256(b).hexdigest()
def need(ok,msg):
 if not ok:findings.append(msg)
def load(p):return json.loads(p.read_bytes())
def git(*a):return subprocess.check_output(['git','-C',str(repo),*a])
j=load(p/'desktop-results.json');m=load(f/'fixtures.json');old=load(ui/'fixtures/fixtures.json');addendum=load(out/'opaque-header-root-addendum-review.json')
need(h((p/'desktop-results.json').read_bytes())=='877693363ca5afc19890fa2e039f6b1987debadbfd9340cd514b8b12f5f95411'and j['status']=='pass'and not j['failures'],'actual desktop PASS')
need(git('rev-parse','HEAD').decode().strip()==head and not git('status','--porcelain'),'exact clean presentation HEAD')
need(h(git('diff','--binary',PG,head))==addendum['complete_seven_file_diff_sha256'],'exact approved seven-file delta')
for row in addendum['reviewed_rows']:need(len((repo/row['path']).read_bytes())==row['bytes']and h((repo/row['path']).read_bytes())==row['sha256'],'approved source row '+row['path'])
need(j['gitBridgeBefore']==j['gitBridgeAfter']and j['gitBridgeBefore']['producer_source']==PG and j['gitBridgeBefore']['ui_head']==head,'exact source bridge before/after')
need(len(j['gitBridgeBefore']['presentation_changed_paths'])==2,'paired presentation delta')
for row in j['gitBridgeBefore']['presentation_changed_paths']:need(h(git('show',PG+':'+row['path']))==row['PG_source_sha256']and h((repo/row['path']).read_bytes())==row['UI_source_sha256'],'exact pinned presentation pair')
need(j['sourcesBefore']==j['sourcesAfter']and j['sourceUnchanged']and m['sources_before']==m['sources_after']and m['source_unchanged'],'stable source frame')
need(len(m['sources_before'])==41 and len({r['path']for r in m['sources_before']})==41,'41 UI source paths')
for row in m['sources_before']:need(len((repo/row['path']).read_bytes())==row['bytes']and h((repo/row['path']).read_bytes())==row['sha256'],'UI source hash '+row['path'])
need([{k:r[k]for k in ['path','sha256']}for r in m['sources_before']]==j['sourcesBefore'],'fixture/desktop source join')
need(h((f/'fixtures.json').read_bytes())==j['fixtureManifestSHA256']and m['PG_producer_source']==PG and m['UI_method_source']==head,'fixture manifest/source join')
need(len(j['states'])==10 and len(j['noJavaScript'])==2 and [s['name']for s in j['states']]==[s['name']for s in m['states']],'10 desktop/2 no-JS inventory')
audits=0;points=0;screenshots=0;axe_passes=0
for s,x in zip(j['states'],m['states']):
 raw=(f/(s['name']+'.html')).read_bytes();need(len(raw)==x['bytes']and h(raw)==x['sha256']==s['fixtureSHA256'],'native HTML '+s['name'])
 need(raw==(ui/'fixtures'/(s['name']+'.html')).read_bytes(),'CSS repair leaves HTML body exact '+s['name'])
 image=(p/(s['name']+'-desktop.png')).read_bytes();need(h(image)==s['screenshotSHA256'],'default PNG '+s['name']);screenshots+=1
 a=s['axe'];need(not a['violations']and not a['incomplete'],'original strict Axe '+s['name']);axe_passes+=a['passes']
 metrics=s['metrics'];need(metrics['overflow']==0 and not metrics['duplicateIDs']and not metrics['unresolved']and not metrics['unlabelled']and metrics['scripts']==0 and metrics['inline']==0,'DOM/form metric boundaries '+s['name'])
 need(s['steadyState']['initialColorsEqualSettled']and s['steadyState']['remainingAnimations']==0,'unchanged initial/settled colors '+s['name'])
 records=s['auditStates']['records'];need([z['name']for z in records]==['forced-open','closed','keyboard-open'],'three disclosure audits '+s['name'])
 for z in records:
  audits+=1;need(not z['axe']['violations']and not z['axe']['incomplete'],'full document strict audit '+s['name']+' '+z['name'])
  need(h((p/z['screenshot']).read_bytes())==z['screenshotSHA256'],'audit PNG '+s['name']+' '+z['name']);screenshots+=1
  g=z['geometry'];need(g['viewport']=={'width':1280,'height':720}and re.fullmatch(r'rgb\(\d+,\s*\d+,\s*\d+\)',g['header']['style']['backgroundColor']),'actual opaque header/desktop geometry')
  need(g['scroll']==records[0]['geometry']['scroll'],'no disclosure scroll normalization')
  for link in g['links']:
   if 'nav-link'not in link['element']['classes']:continue
   for pt in link['points']:
    if pt['insideViewport']:points+=1;need(pt['targetOrDescendantAtTop'],'visible nav point occluded '+s['name'])
 need(records[0]['geometry']['details'][0]['open']and not records[1]['geometry']['details'][0]['open']and records[2]['geometry']['details'][0]['open'],'actual open/closed/open states')
for s in j['noJavaScript']:need(s['javaScriptEnabled']is False and s['metrics']['scripts']==0 and s['metrics']['overflow']==0,'actual no-JS metrics')
need(not j['requestFailures']and not j['pageErrors']and not j['cspConsole']and all(r['method']=='GET'and r['local']for r in j['requests']),'only local GET/no runtime errors')
need(all(r['status']==200 for r in j['assetResponses'])and len(j['assetResponses'])==58,'58 successful assets')
need(j['ownership']=={'userProfile':False,'browserClosed':True,'noJSContextClosed':True,'serverStopped':True,'profileRemoved':True},'owned cleanup')
with tarfile.open(repo/'docs/reviews/gui-native-family/evidence.tar.gz','r:gz')as archive:
 for row in m['family_byte_equality']:
  raw=(f/'family'/(row['name']+'.html')).read_bytes();need(raw==archive.extractfile('evidence/ui/html/'+row['name']+'.html').read()and len(raw)==row['bytes']and h(raw)==row['sha256'],'actual accepted family body '+row['name'])
need(len(m['family_byte_equality'])==8 and m['family_byte_equality']==j['familyByteEquality'],'eight family equality rows')
cheap=load(root/'group-opaque-header-repair/actual-cheap-checks.json');pure=(root/'group-opaque-header-repair/final-pure.stdout').read_bytes();need(h(pure)==cheap['web_pure']['raw_stdout_sha256'],'pure raw receipt')
runs=re.findall(rb'^\s*=== RUN\s+(\S+)',pure,re.M);passes=re.findall(rb'^\s*--- PASS:\s+(\S+)\s+\(',pure,re.M)
need(collections.Counter(runs)==collections.Counter(passes)and len(passes)==48 and sum(b'/'not in x for x in passes)==10 and not re.search(rb'--- (FAIL|SKIP):|DATA RACE|\(cached\)',pure),'10 root/48 named pure run/pass join')
need((root/'group-opaque-header-repair/final-pure.stderr').read_bytes()==b''and(ui/'presentation-export.stderr').read_bytes()==b''and(ui/'presentation-desktop.stderr').read_bytes()==b'','pure/export/desktop stderr empty')
need(re.search(rb'^ok\s+\S+\s+0.149s$',(ui/'presentation-export.stdout').read_bytes(),re.M),'actual fixture export receipt')
report={'schema':1,'verdict':'ACCEPT_ACTUAL_REPAIRED_PRESENTATION_UI_EVIDENCE','PG_source':PG,'presentation_source':head,'desktop_report_sha256':h((p/'desktop-results.json').read_bytes()),'fixture_manifest_sha256':h((f/'fixtures.json').read_bytes()),'source_paths_rehashed':41,'native_HTML_bodies_exact_before_after_CSS_repair':10,'family_bodies_compared_to_accepted_archive':8,'full_document_Axe_audits':audits,'original_Axe_pass_predicates':axe_passes,'desktop_states':10,'no_JS_states':2,'PNG_hashes_recomputed':screenshots,'visible_nav_hit_tests_topmost':points,'all_asset_200_responses':58,'pure_roots':10,'pure_named_passes':48,'findings':findings,'visual_inspection':'Viewed all ten current default full-page PNGs and all nine naturally scrolled audit PNGs (three phases each for staff-ro, positive-ro and escaping-ro). No new clipping, overlap or unreadable content. Prior translucent header blur is absent.', 'operator_receipt_limit':'Database-free App GET/HEAD transport root passed in actual tool-returned output, 1.055s; no separately retained raw stdout exists. Kept as explicitly identified operator evidence, not fabricated raw stream. Vet/syntax/docs checks are operator exit receipts.', 'scope':'Runtime acceptance of this presentation epoch plus prior exact PG/capture/benchmark evidence; final compact keeper and metadata review remain pending. No complete six-lane PG claim on d05343bb, no all21/current-image/main/milestone/deployment/device/provider/real-child authority.'}
(out/'presentation-ui-review.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
