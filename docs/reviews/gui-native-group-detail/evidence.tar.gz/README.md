# Social group-detail evidence candidate

Qualified source: `fa3e7c90bf736f63981b00d2f117417d01b26cd2`.
This records the complete affected six-package run and native desktop presentation.
It does not qualify all 21 packages, a deployment image, main, a milestone,
production, mobile devices, providers or real-child activation.

The final native run has 292 command receipts, 597 original artifact rows and
428 root / 1,246 named passes, with zero skips or race findings. Its binary
Git archive stdout is intentionally excluded; the other 596 proof rows,
unaltered result, complete source manifest and cleanup receipts are retained.
The final UI run retains all 67 artifacts, including 28 PNGs and 25 HTML bodies.
Seven JS and seven no-JS states passed 21 whole-document audits: 498 Axe pass
occurrences, no violations/incompletes, seven canceled native confirmations,
and 18 previous family/creation bodies unchanged.

Earlier dc1 native failure, qualified 7fb native run, failed 099 UI, initial
Node preflight refusal and failed local CSS experiment remain separate history.
The CSS experiment had nine-to-zero Axe incompletes but still failed 14 asset
guards; it ran no benchmark. Historical duplicate bodies are explicit aliases,
with their original stat metadata; unique causal bodies remain physical members.
See `selection.json`, `content-aliases.json` and `excluded.json` for exact custody.
No scratch inputs are deleted by collection. Earlier pruned outputs are history
only where the retained manifest says so; this archive does not recreate them.

The descriptive benchmark uses the same actual synthetic admitted EN/RO body
projection, three samples of 100 iterations per engine/language. EN body CPU was
essentially equal and RO modestly lower in these samples; native used about40%
fewer allocated bytes, about22% less HTML and about14% less gzip, but about14%
more allocations. This is not a full HTTP, SQL, throughput or general speedup claim.

Reproduce on the exact clean Git source using `reproduce/group-detail/README.md`;
the archive contains selected committed methods, not a complete repository,
installed browser, dependencies, Go module cache or database. External runtime
identities and exact invocations remain in the raw results. Collection itself
performs file/Git reads and archive verification only, with no product runtime.

The result is a keeper candidate until Root and an independent reviewer accept it.

[Committed reproduction instructions](../../../tools/gui-native-group-detail/README.md)
