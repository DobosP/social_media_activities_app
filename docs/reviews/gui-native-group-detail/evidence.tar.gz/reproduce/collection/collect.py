#!/usr/bin/env python3
"""Collect an explicitly reviewed Group-detail selection; never run or delete product inputs."""
import argparse
import collections
from decimal import Decimal
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import tarfile

DRAFT = Path(__file__).absolute().parent
ROOT = Path('/home/dobo/work/_temp/feat__gui-app-migration-a/social-family')
REPO = Path('/home/dobo/work/_worktrees/social_media_activities_app/feat__gui-app-migration-a')
SOURCE = 'fa3e7c90bf736f63981b00d2f117417d01b26cd2'
TREE = '6534fc70fa61b2e21ba61d909c4d7d7d69ed54dc'
LANES = ('web', 'app', 'accounts', 'recommendations', 'social', 'messaging')
PREFIX = 'github.com/DobosP/social_media_activities_app/services/server/internal/'
MAXIMUM = 64 << 20


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def literal(value):
    need(isinstance(value, str) and not value.startswith('/') and '\\' not in value
         and all(p not in ('', '.', '..') for p in value.split('/')), 'Literal relative member required')
    return value


def metadata(info):
    return dict(mode=stat.S_IMODE(info.st_mode), uid=info.st_uid, gid=info.st_gid,
                mtime_ns=info.st_mtime_ns)


def read(path):
    need(path.is_absolute() and path.resolve() == path, 'Canonical unaliased input required: ' + str(path))
    before = path.lstat()
    need(stat.S_ISREG(before.st_mode) and 0 <= before.st_size <= MAXIMUM, 'Bounded regular input required')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        opened = os.fstat(fd)
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            raw = stream.read(MAXIMUM + 1)
        after = os.fstat(fd)
        keys = ('st_dev', 'st_ino', 'st_mode', 'st_uid', 'st_gid', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
        need(all(getattr(before, k) == getattr(opened, k) == getattr(after, k) for k in keys)
             and len(raw) == after.st_size <= MAXIMUM, 'Input changed while read')
        return raw, after
    finally:
        os.close(fd)


def pinned(row):
    path = Path(row['source'])
    allowed = (ROOT, Path('/home/dobo/work/_temp/gd-ui'), REPO)
    need(any(path.is_relative_to(p) for p in allowed), 'Input outside selected owned roots')
    need('programme-ledger-review.json' != path.name and not any(
        x in path.parts for x in ('node_modules', 'binaries', 'bin', 'go-cache', 'go-mod', 'source', 'profiles')),
        'Disallowed workspace/cache/export input')
    raw, info = read(path)
    need(len(raw) == row['bytes'] and sha(raw) == row['sha256']
         and metadata(info) == {k: row[k] for k in metadata(info)}, 'Input hash/stat differs: ' + str(path))
    return raw, info


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def fence(source_rows):
    need(git('rev-parse', 'HEAD').decode().strip() == SOURCE and not git('status', '--porcelain')
         and git('rev-parse', SOURCE + '^{tree}').decode().strip() == TREE, 'Exact clean qualified source required')
    tree = {}
    for item in git('ls-tree', '-r', '-z', SOURCE).split(b'\0'):
        if item:
            header, name = item.split(b'\t', 1)
            tree[name.decode()] = tuple(header.decode().split())
    need(len(source_rows) == 2158 == len(tree) and len({r['path'] for r in source_rows}) == 2158,
         'Complete original source manifest required')
    for row in source_rows:
        name = literal(row['path'])
        raw, info = read(REPO / name)
        blob = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
        mode = '100755' if row['mode'] & 0o111 else '100644'
        need(len(raw) == row['bytes'] and sha(raw) == row['sha256']
             and tree.get(name) == (mode, 'blob', blob)
             and bool(info.st_mode & 0o111) == bool(row['mode'] & 0o111), 'Git/current/source manifest differs: ' + name)


def tests(lane, listed, raw, stored):
    names = [s for s in listed.decode().splitlines() if re.fullmatch(r'(?:Test|Example|Fuzz)[A-Za-z0-9_]+', s)]
    need(names and len(names) == len(set(names)), 'Complete unique test inventory required')
    events = [json.loads(line) for line in raw.splitlines()]
    need(events and all(e.get('Package') == PREFIX + lane for e in events), 'Wrong actual test package')
    need(not any(e.get('Action') in ('fail', 'skip') for e in events), 'Actual fail/skip receipt')
    runs = [e['Test'] for e in events if e.get('Action') == 'run']
    passes = [e['Test'] for e in events if e.get('Action') == 'pass' and e.get('Test')]
    need(collections.Counter(runs) == collections.Counter(passes)
         and all(n == 1 for n in collections.Counter(runs).values())
         and {n for n in runs if '/' not in n} == set(names)
         and len([e for e in events if e.get('Action') == 'pass' and not e.get('Test')]) == 1,
         'Every named case and listed root must pass exactly once')
    need(stored['top_level'] == len(names) and stored['named_passes'] == len(passes)
         and stored['fail'] == stored['skip'] == 0
         and collections.Counter(stored['identities']) == collections.Counter(runs), 'Stored test receipt differs')
    return len(names), len(passes)


def admit(selection, payload):
    def raw(member):
        return payload[literal(member)][0]
    def data(member):
        return json.loads(raw(member))
    native = data('evidence/native-final/result.json')
    need(native['source'] == SOURCE and native['tree'] == TREE and native['method_pass'] is True
         and native['errors'] == [] and len(native['commands']) == 292 and len(native['artifact_rows']) == 597
         and set(native['lanes']) == set(LANES), 'Final native receipt differs')
    roles = {'db', *LANES, *('reference-' + n for n in LANES)}
    need(set(native['cleanup']) == roles and all(v.get('stopped') is True and v.get('id_absent') is True
         and v.get('name_absent') is True for v in native['cleanup'].values()), 'Thirteen recorded cleanup receipts required')
    pc = native['pg_cleanup']
    need(pc['stop_exit'] == 0 and pc['status_exit'] == 3 and pc['owned_pid'] > 0 and pc['pid_probe_exit'] == 1
         and pc['pid_and_socket_files_absent'] == 1 and native['pg_storage_initial']['tmpfs']['bytes'] == 1 << 30,
         'Original fixed-cap PG/shutdown receipts required')
    counts = []
    for lane in LANES:
        v, retired = native['lanes'][lane], native['retired_databases'][lane]
        need(v['state'] == 'PASS' and v['pg_before'] == v['pg_after'] and v['pg_after']['fixtures'] == 0
             and retired['checkpoint_completed'] is True and retired['name_and_oid_absent'] is True
             and retired['database'] == v['pg_after']['database'] and retired['oid'] == v['pg_after']['oid'], 'Lane lifecycle differs')
        counts.append(tests(lane, raw('evidence/native-final/proof/' + lane + '-list.stdout'),
                            raw('evidence/native-final/proof/' + lane + '-test2json.stdout'), v['tests']))
    need(tuple(map(sum, zip(*counts))) == (428, 1246), 'Actual complete six counts differ')
    ui = data('evidence/ui-final/result.json')
    desktop = data('evidence/ui-final/desktop/desktop-results.json')
    need(ui['status'] == 'PASS' and ui['failures'] == [] and ui['PG_producer_source'] == ui['UI_method_source'] == SOURCE
         and len(ui['artifacts']) == 67 and len(ui['commands']) == 5 and all(c['exit_code'] == 0
         and c['timed_out'] is False for c in ui['commands']) and ui['owned_temp']['removed'] is True
         and ui['git_after'] == {'head': SOURCE, 'porcelain_empty': True}, 'Actual final UI result differs')
    need(desktop['status'] == 'pass' and desktop['failures'] == [] and desktop['sourceUnchanged'] is True
         and desktop['sourcesBefore'] == desktop['sourcesAfter'] and len(desktop['states']) == 7
         and len(desktop['noJavaScriptStates']) == 7 and desktop['ownership']['serverStopped'] is True
         and all(p['closed'] is True and p['removed'] is True for p in desktop['ownership']['profiles'])
         and all(not desktop[k] for k in ('requestFailures', 'pageErrors', 'consoleErrors', 'cspConsole')),
         'Actual desktop/source/cleanup differs')
    audits = [a for s in desktop['states'] for a in s['audits']]
    need(len(audits) == 21 and all(a['axe']['violations'] == a['axe']['incomplete'] == [] for a in audits)
         and sum(len(a['axe']['passes']) for a in audits) == 498, 'Strict actual Axe audits differ')
    need(ui['benchmark_requested'] is True and ui['benchmark']['rows'] == 12
         and ui['benchmark']['stdout_sha256'] == sha(raw('evidence/ui-final/benchmark.stdout'))
         and ui['capture_sha256'] == sha(raw('evidence/ui-final/capture.json'))
         and ui['desktop_report_sha256'] == sha(raw('evidence/ui-final/desktop/desktop-results.json'))
         and ui['fixture_manifest_sha256'] == sha(raw('evidence/ui-final/fixtures/fixtures.json')), 'UI capture/benchmark bindings differ')
    for row in ui['artifacts']:
        member = 'evidence/ui-final/' + literal(row['path'])
        need(len(raw(member)) == row['bytes'] and sha(raw(member)) == row['sha256'], 'Original final UI artifact inventory differs')
    for label, expected in (('native-initial-failed', False), ('native-prior-qualified', True)):
        need(data('evidence/' + label + '/result.json')['method_pass'] is expected, 'Historical native disposition differs')
    need(data('evidence/ui-initial/result.json')['status'] == 'FAIL', 'Earlier UI must remain failed')
    comparison = data('evidence/css-diagnostic/comparison.json')
    need(comparison['candidate_expected_live_asset_guard_failures'] == 14, 'Local diagnostic failed disposition differs')
    for review, key, expected in (
        ('final-pg-review.json', 'verdict', 'ACCEPT_FINAL_ACTUAL_COMPLETE_SIX_GROUP_DETAIL_PG'),
        ('final-ui-benchmark-review.json', 'verdict', 'ACCEPT_FINAL_ACTUAL_GROUP_DETAIL_CAPTURE_UI_AND_DESCRIPTIVE_BENCHMARK')):
        need(data('evidence/packets/group-detail-fresh-review/' + review)[key] == expected, 'Required independent source/results review missing')
    for epoch in selection['native_epochs']:
        result = data('evidence/' + epoch['label'] + '/result.json')
        excluded = {c['stdout']['path'] for c in result['commands'] if c['argv'][0] == 'git' and 'archive' in c['argv']}
        need(len(excluded) == 1 and excluded == set(epoch['excluded_archive_stdout']), 'Exclude only original binary archive stdout')
        for row in result['artifact_rows']:
            name = 'evidence/' + epoch['label'] + '/' + literal(row['path'])
            if row['path'] not in excluded:
                need(len(raw(name)) == row['bytes'] and sha(raw(name)) == row['sha256'], 'Original raw proof inventory changed')
    return data('evidence/native-final/source-manifest.json')


def archive(path, payload):
    manifest = []
    with path.open('xb') as file:
        os.fchmod(file.fileno(), 0o600)
        with gzip.GzipFile(fileobj=file, mode='wb', compresslevel=9, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w|', format=tarfile.PAX_FORMAT) as output:
                for name, (raw, info, original) in sorted(payload.items()):
                    entry = tarfile.TarInfo(literal(name))
                    entry.size = len(raw)
                    entry.mode, entry.uid, entry.gid = stat.S_IMODE(info.st_mode), info.st_uid, info.st_gid
                    entry.mtime = info.st_mtime_ns // 1_000_000_000
                    entry.pax_headers = {'mtime': str(entry.mtime) + '.' + str(info.st_mtime_ns % 1_000_000_000).zfill(9)}
                    output.addfile(entry, io.BytesIO(raw))
                    manifest.append(dict(member=name, original=original, bytes=len(raw), sha256=sha(raw), **metadata(info)))
    with tarfile.open(path, 'r:gz') as restored:
        entries = restored.getmembers()
        need([e.name for e in entries] == [r['member'] for r in manifest], 'Exact archive member inventory required')
        for entry, row in zip(entries, manifest):
            stream = restored.extractfile(entry)
            need(entry.isfile() and stream is not None and entry.size == row['bytes'] and entry.mode == row['mode']
                 and entry.uid == row['uid'] and entry.gid == row['gid']
                 and int(Decimal(entry.pax_headers['mtime']) * 1_000_000_000) == row['mtime_ns']
                 and sha(stream.read()) == row['sha256'], 'Archive bytes/mode/owner/nanosecondmtime roundtrip differs')
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--selection', required=True, type=Path)
    parser.add_argument('--approved-selection-sha256', required=True)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    need(args.selection == DRAFT / 'selection.json' and re.fullmatch('[0-9a-f]{64}', args.approved_selection_sha256), 'Reviewed literal selection required')
    selected_raw, _ = read(args.selection)
    need(sha(selected_raw) == args.approved_selection_sha256, 'Approved selection hash differs')
    selection = json.loads(selected_raw)
    need(selection['schema'] == 1 and selection['qualified_source'] == SOURCE and selection['status'] == 'READY_FOR_ROOT_SELECTION_REVIEW_NOT_COLLECTED', 'Unexpected selection')
    payload = {}
    for row in selection['files']:
        member = literal(row['member'])
        need(member not in payload and member.startswith(('evidence/', 'reproduce/')), 'Duplicate/foreign member')
        raw, info = pinned(row)
        payload[member] = (raw, info, row['source'])
    for row in selection['content_aliases']:
        raw, _ = pinned(row)
        target = literal(row['content_member'])
        need(target in payload and raw == payload[target][0], 'Alias exact bytes/metadata join differs')
    source_rows = admit(selection, payload)
    fence(source_rows)
    output = args.output
    need(output.is_absolute() and output.parent == DRAFT and not output.exists() and not output.is_symlink(), 'Fresh direct owned output directory required')
    need(shutil.disk_usage(DRAFT).free > sum(len(v[0]) for v in payload.values()) * 2 + (64 << 20), 'Free disk insufficient')
    output.mkdir(mode=0o700)
    def emit(name, raw):
        with (output / literal(name)).open('xb') as file:
            os.fchmod(file.fileno(), 0o600)
            file.write(raw)
    emit('selection.json', selected_raw)
    emit('content-aliases.json', (json.dumps(selection['content_aliases'], indent=2) + '\n').encode())
    emit('excluded.json', (json.dumps(selection['excluded'], indent=2) + '\n').encode())
    readme = read(DRAFT / 'README.template.md')[0]
    emit('README.md', readme)
    emit('result.json', read(DRAFT / 'result.template.json')[0])
    for name in ('selection.json', 'content-aliases.json', 'excluded.json', 'README.md', 'result.json'):
        raw, info = read(output / name)
        payload[name] = (raw, info, str(output / name))
    manifest = archive(output / 'evidence.tar.gz', payload)
    emit('archive-manifest.json', (json.dumps(manifest, indent=2) + '\n').encode())
    # Re-read every selected input and alias after archive readback; no delete/cleanup action.
    for row in selection['files'] + selection['content_aliases']:
        pinned(row)
    fence(source_rows)
    archive_raw, _ = read(output / 'evidence.tar.gz')
    receipt = dict(schema=1, status='COLLECTED_PENDING_INDEPENDENT_KEEPER_REVIEW', qualified_source=SOURCE,
                   selection_sha256=sha(selected_raw), archive_sha256=sha(archive_raw), archive_bytes=len(archive_raw),
                   archive_members=len(manifest), archive_manifest_sha256=sha(read(output / 'archive-manifest.json')[0]),
                   aliases=len(selection['content_aliases']), inputs_unchanged=True, full_readback=True,
                   bytes_mode_UID_GID_nanosecondmtime=True, physical_deletion_performed=False)
    emit('collection-result.json', (json.dumps(receipt, indent=2) + '\n').encode())
    print(json.dumps(receipt))


if __name__ == '__main__':
    main()
