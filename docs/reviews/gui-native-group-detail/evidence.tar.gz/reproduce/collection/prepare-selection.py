#!/usr/bin/env python3
"""File-only selection preparation. Does not archive, delete, or run the collector."""
import hashlib
import json
import os
from pathlib import Path
import stat

ROOT = Path('/home/dobo/work/_temp/feat__gui-app-migration-a/social-family')
DRAFT = ROOT / 'group-detail-keeper'
REPO = Path('/home/dobo/work/_worktrees/social_media_activities_app/feat__gui-app-migration-a')
SOURCE = 'fa3e7c90bf736f63981b00d2f117417d01b26cd2'
PG = ROOT / 'group-detail-pg-qa'
UI = Path('/home/dobo/work/_temp/gd-ui/run-fa3e7c90bf73-d9999d11-182b-4fe4-a32a-91ab5c47b463')
OLD_UI = Path('/home/dobo/work/_temp/gd-ui/run-7fb35d0e6919-adc06c36-1b78-4d87-896f-205cecac5b1e')
FILES, ALIASES, EXCLUDED, EPOCHS = [], [], [], []
MEMBERS = set()


def row(path):
    assert path.is_absolute() and path.resolve() == path
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_size <= 64 << 20
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        opened = os.fstat(fd)
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            raw = stream.read((64 << 20) + 1)
        info = os.fstat(fd)
        keys = ('st_dev','st_ino','st_mode','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
        assert all(getattr(before,k) == getattr(opened,k) == getattr(info,k) for k in keys) and len(raw) == info.st_size
        return dict(source=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),mode=stat.S_IMODE(info.st_mode),uid=info.st_uid,gid=info.st_gid,mtime_ns=info.st_mtime_ns)
    finally:
        os.close(fd)


def add(path, member, category, expected=None):
    assert member not in MEMBERS and not member.startswith('/') and '..' not in member.split('/')
    entry = row(path)
    if expected is not None:
        assert entry['bytes'] == expected['bytes'] and entry['sha256'] == expected['sha256']
    entry.update(member=member,category=category)
    FILES.append(entry);MEMBERS.add(member)
    return entry


def native(label, name, expected_hash, passed):
    run = PG / name
    result_row = add(run/'result.json','evidence/'+label+'/result.json','native-result')
    assert result_row['sha256'] == expected_hash
    result = json.loads((run/'result.json').read_text())
    assert result['method_pass'] is passed
    add(run/'source-manifest.json','evidence/'+label+'/source-manifest.json','complete-source-manifest')
    for p in sorted(run.glob('*.cid')):
        add(p,'evidence/'+label+'/'+p.name,'owned-resource-receipt')
    archives = [c['stdout']['path'] for c in result['commands'] if c['argv'][0] == 'git' and 'archive' in c['argv']]
    assert len(archives) == 1
    for item in result['artifact_rows']:
        assert item['path'].startswith('proof/') and not '..' in item['path'].split('/')
        if item['path'] in archives:
            # Never open/read/hash archive stdout; its original recorded digest remains in result.
            EXCLUDED.append(dict(source=str(run/item['path']),**item,reason='Binary full Git archive stdout excluded by explicit Root selection. Original result/complete Git manifest/archive digest retained; no deletion performed.'))
        else:
            add(run/item['path'],'evidence/'+label+'/'+item['path'],'native-raw-proof',item)
    EPOCHS.append(dict(label=label,source=result['source'],tree=result['tree'],method_pass=passed,
                       original_commands=len(result['commands']),original_artifact_rows=len(result['artifact_rows']),
                       retained_raw_proof_rows=len(result['artifact_rows'])-1,excluded_archive_stdout=archives))


native('native-initial-failed','run-dc1c15caa140-80827a3c-328e-4b5f-8251-df819898caf2',
       'bdd12bdb2b93fb448804296e00ff3e53a4354e08bcd6cef951ec65b2c36d7894',False)
native('native-prior-qualified','run-7fb35d0e6919-05b5bdfb-4f6a-4cae-ab44-d99aba7327fe',
       'f56fb1e6a6863f30f834e0ff1972ca2560a61c0e109c14be0d6d987b89ed4e22',True)
native('native-final','run-fa3e7c90bf73-af3786aa-506c-4a81-ad95-3366c3e28abe',
       '5a9d28874abfddd6e801c5e4e72577ffe053e2e389e9127bcdf4582abe9fdd63',True)

for base,label,expected in [(UI,'ui-final','38705d6fd0d317006649871a777a371fc7c6bc0891dd0eb0e01db2418833440b'),
                            (OLD_UI,'ui-initial','75d2f5664e3badd11207fd4dcf2c7015343f9dc09d4c5a403db48b61cc3dd72b')]:
    result_row = add(base/'result.json','evidence/'+label+'/result.json','UI-result')
    assert result_row['sha256'] == expected
    result = json.loads((base/'result.json').read_text())
    if (base/'status.json').is_file():
        add(base/'status.json','evidence/'+label+'/status.json','UI-status')
    for item in result['artifacts']:
        if label == 'ui-initial' and item['path'].endswith(('.png','.html')):
            continue
        add(base/item['path'],'evidence/'+label+'/'+item['path'],'UI-raw-artifact',item)

alias_path = DRAFT/'png-html-alias-review.json'
add(alias_path,'evidence/packets/keeper/png-html-alias-review.json','independent-body-stat-review')
body = json.loads(alias_path.read_text())
origins = {k:Path(v) for k,v in body['roots'].items()}
prefixes = dict(final='evidence/ui-final/',old='evidence/ui-initial/',diagnostic='evidence/css-diagnostic/')
for item in body['physical_selection']:
    member = prefixes[item['origin']]+item['path']
    if member not in MEMBERS:
        add(origins[item['origin']]/item['path'],member,'unique-historical-causal-body',item)
for item in body['old_causal_records']+body['old_noncausal_records']+body['diagnostic_records']:
    if 'content_alias' not in item:
        continue
    target = item['content_alias']
    member = prefixes[target['origin']]+target['path']
    assert member in MEMBERS
    record = row(origins[item['origin']]/item['path'])
    assert record['sha256'] == item['sha256'] and record['bytes'] == item['bytes']
    record.update(content_member=member,original_member=prefixes[item['origin']]+item['path'],
                  disposition=item['disposition'],causal_record=item.get('causal_record',False),
                  acceptance='Historical/diagnostic byte identity only; not accepted-run identity or equal source metadata.')
    ALIASES.append(record)

# All controlled diagnostic reports/scripts/18 geometry comparisons remain; 56 PNG records are above.
diag = ROOT/'group-detail-link-cue-diagnostic'
for p in sorted(diag.rglob('*')):
    if p.is_file() and p.suffix != '.png':
        add(p,'evidence/css-diagnostic/'+str(p.relative_to(diag)),'failed-controlled-diagnostic')

# Curated compact source packets/proofs; exclude every full proposed/before/source tree.
packet_dirs = ('group-detail-checks','group-detail-fresh-review','group-detail-ui-dependency-repair',
               'group-detail-link-cue-repair','group-detail-reply-target-repair')
for directory in packet_dirs:
    for p in sorted((ROOT/directory).iterdir()):
        if p.is_file() and p.name not in ('programme-ledger-review.json','qualify-before.py','qualify-after.py'):
            add(p,'evidence/packets/'+directory+'/'+p.name,'source-review-or-actual-check')
for p in sorted((ROOT/'group-detail-implementation').iterdir()):
    if p.is_file() and p.suffix in ('.json','.patch','.md'):
        add(p,'evidence/packets/group-detail-implementation/'+p.name,'product-source-packet')
methods = ROOT/'group-detail-implementation/ui-method-proposal'
for p in sorted(methods.rglob('*')):
    if not p.is_file() or any(x in p.relative_to(methods).parts for x in ('proposed','before')):
        continue
    if p.suffix in ('.json','.patch'):
        add(p,'evidence/packets/group-detail-implementation/ui-method-proposal/'+str(p.relative_to(methods)),'method-source-packet')
for name in ('contract.md','fingerprints.json','contract-pre-publication.md','fingerprints-pre-publication.json'):
    add(ROOT/'next-group-owner-contract'/name,'evidence/packets/next-group-owner-contract/'+name,'approved-contract-source')
for p in [ROOT/'group-fresh-independent-review/next-group-detail-contract-review.json',
          ROOT/'group-detail-pg-qa/first-native-failure-independent-review.json',
          ROOT/'retention/superseded-export-retention.json']:
    add(p,'evidence/packets/'+str(p.relative_to(ROOT)),'earlier-source-retention-receipt')

# Exactly eight current executable/source reproduction methods, plus one baseline reference.
repro = ['tools/gui-native-group-detail/'+n for n in ('qualify.py','desktop-qa.mjs','README.md',
         'prepare-ui-overlay.py','fixture-export_test.go.txt','extract-projection.py')]
repro += ['tools/gui-native-family/ui/fixture-export_test.go.txt','tools/gui-native-group/fixture-export_test.go.txt']
for name in repro:
    if name.startswith('tools/gui-native-group-detail/'):
        member = 'reproduce/group-detail/'+Path(name).name
    elif name.startswith('tools/gui-native-family/'):
        member = 'reproduce/dependency-overlays/family-fixture-export_test.go.txt'
    else:
        member = 'reproduce/dependency-overlays/group-create-fixture-export_test.go.txt'
    add(REPO/name,member,'current-committed-reproduction-method')
add(REPO/'tools/gui-native-group-detail/prior-html-baseline.json','reproduce/group-detail/prior-html-baseline.json','prior-HTML-baseline-reference')
for name in ('collect.py','prepare-selection.py','README.template.md','result.template.json'):
    add(DRAFT/name,'reproduce/collection/'+name,'collection-method')

EXCLUDED += [dict(scope='Complete source exports, Go test executables/bootstrap binary, caches, database/socket/host-tmp/test-tmp trees, profiles',reason='Not selected. Exact source Git SHA/tree, complete source manifest, binary identities and original command/results remain. No deletion by collector.'),
             dict(scope='Foreign programme-ledger-review.json; Teacher and future notification source/review files',reason='Explicitly outside bounded Social group-detail keeper.'),
             dict(scope='Old duplicate HTML/PNG physical paths',reason='Every old25HTML/28PNG and diagnostic56PNG record retained as physical content or exact alias with original mode/UID/GID/nsmtime; no unique body omitted and no source input deleted.')]
selection = dict(schema=1,status='READY_FOR_ROOT_SELECTION_REVIEW_NOT_COLLECTED',qualified_source=SOURCE,
                 scope='Actual fa3 native six-lane and desktop feature evidence; history epochs separated, no all21/image/main/milestone/production/activation claim',
                 native_epochs=EPOCHS,files=sorted(FILES,key=lambda r:r['member']),
                 content_aliases=sorted(ALIASES,key=lambda r:r['original_member']),excluded=EXCLUDED,
                 methods=dict(current_reproduction_files=8,baseline_reference_files=1,requires_exact_clean_repository=True,
                              common_PG_method='Exact committed tools/gui-native-family method and invocation are pinned by original source manifest/native result; archive is not a full source/dependency distribution.'),
                 claims=dict(physical_deletion_performed=False,archive_created=False,byte_alias_preserves_metadata_in_record=True,
                             aliases_are_not_independent_archive_bodies=True,independent_keeper_acceptance='PENDING'))
(DRAFT/'selection.json').write_text(json.dumps(selection,indent=2)+'\n')
summary = dict(schema=1,status=selection['status'],selection_sha256=hashlib.sha256((DRAFT/'selection.json').read_bytes()).hexdigest(),
               physical_files=len(FILES),physical_bytes=sum(r['bytes']for r in FILES),content_aliases=len(ALIASES),
               alias_source_bytes=sum(r['bytes']for r in ALIASES),native_epochs=EPOCHS,
               final_UI_physical=67,unique_historical_bodies=4,current_reproduction_methods=8,
               excluded_binary_archive_stdout=3,archive_created=False,physical_deletion_performed=False)
(DRAFT/'selection-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
