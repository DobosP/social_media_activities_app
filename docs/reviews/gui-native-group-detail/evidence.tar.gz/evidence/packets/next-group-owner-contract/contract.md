# Next Social slice: group detail and existing owner controls

Status: source-only proposal; no implementation, runtime qualification or acceptance.
Rebound against clean published Group-creation feature `feebb5527a783f91133e614a90d9bdec9db84a17`.
Group creation is independently accepted (PG1f8/presentationd053, acceptance2304); this is the next unimplemented view.

## Selected scope

Rebuild the one existing logical `web/group_detail.html` view at `GET /groups/<int:pk>/` with cached typed Go HTML.
The useful module is the group overview, membership action, owner archive/listing and eligible roster, together with the current conversation and upcoming-activity sections needed by that same page.
This is one selected view, not a generic group engine or a conversion of activity/chat/discovery routes.
Do not ship an overview-only replacement that drops the current thread/feed, a new management route, placeholder links or disabled existing features.
Keep original templates, `_post.html`, `_activity_card.html`, services, routes, forms, scripts, catalogue and assertions intact; add native view sources and one exact renderer dispatch.
Native group-only subtemplates may consume current semantic post/activity projections; they must preserve shared behavior without changing the activity view or trusting widget HTML.
No group title/description editing, owner transfer, invitation, member eviction, deletion, new guardian role or bulk roster export exists in this scope.

## Current authority and data boundary

`socialGroupDetail` first calls `Social.Group`; ordinary viewers require active assigned same-cohort visibility, active/nonhidden group and no mutual owner block.
The existing staff metadata bypass is not general thread access. A staff curator outside the minor cohort sees only their own nonhidden announcements, never minor peer history, roster or upcoming-activity data from the bypass.
`CanReadThread`/`CanWriteThread` retain current participation, membership, cohort and owner-block gates; participation rechecks current database identity/assurance and under-16 consent.
`is_owner` is owner-ID equality; `is_member` is current member state AND thread-read permission. Preserve these existing presentation predicates; UI affordances never replace locked service checks.
Roster is absent (`nil`), including its heading/count, unless the existing web projection admits an adult member/readable adult group; an admitted empty roster remains a visible empty list.
Use only that already-filtered web roster (active matching cohort, mutual-block filter, original order and 1000-row cap); do not query or enumerate raw memberships in the template.
The separate API `GroupRoster` additionally checks each target's participation and returns names, not the web roster object shape. Do not conflate the two or silently change either policy in a rendering slice.
Group membership has no new guardian-observer capability. Existing read-only guardian restrictions on shared thread helpers remain unchanged; family relationships never grant group administration.
Keep group/author names, descriptions, fixed status/cohort labels and safe projected URLs escaped; expose no extra account IDs, emails, age evidence, consent or roster count outside admitted roster.
Use typed finite booleans/enums, fixed route constructors and current validated `PostForm` semantics; reject malformed projections rather than coercing unknown permission values true.
Do not add arbitrary `template.HTML`, widget/as_p trust or remote URL sinks. Any existing generated body markup must be traceable exclusively to the current `BodyMarkup` producer and its unchanged tests.

## Existing form/action contract

All forms use the real session, shared CSRF/Origin admission, `csrfmiddlewaretoken` and unchanged current Actor reload. Group identifier comes from the typed path, never an editable owner/cohort/member field.
- Nonowner: current `is_member` selects POST `.../leave/`; otherwise POST `.../join/`; neither form adds business fields.
- Owner: POST `.../archive/` with visible freeze explanation/confirmation behavior; success stays 302 `/communities/`. No delete or unarchive operation is introduced.
- Adult-group owner only: POST `.../listing/`, hidden `listed` exactly `0` or `1` and canonical local `next`; current handler treats only first value `1` as true and redirects to group detail. No minor publication control.
- Owner announcement: POST `.../announce/`, `body`; current owner-only UI stays owner-only even where the service has a staff curation exception.
- Existing writable conversation: POST `.../post/`, current semantic `body` and `reply_to`; preserve exact current group compose exposure, reply cancellation/anchors, post edits/deletes/react/dissent/concern/report URLs, no-JS POST and fetch responses.
- Eligible minor member of active staff-curated group: POST `.../ask/`, required `prompt` from exactly `next_meetup`, `where`, `what_to_bring`, `how_it_works`, `more_info`; no free text/private reply/member fan-out.
Current join is idempotent: an already-member returns before reserve/audit; a new membership reserves within 20/hour and audits. Owner leave is invalid. Leave/archive retain `privacyTransaction` rather than adding assurance/consent admission.
Listing retains audited participating adult-owner transaction; archive retains audited owner-or-staff service gate. Preserve `group.joined`, `group.left`, `group.public_listing`, `group.archived` and rollback behavior.
Group actions load visible parent before mutation; unlike activity safe exit, no block-bypassing group leave path is added. Existing lapsed-assurance leave-affordance differences are not claimed resolved.
Keep errors on the same authorized detail projection, fixed escaped public error vocabulary, existing notfound/405/fetch/302 behavior and renderer private cache/Vary/CSP headers.

## Conversation/feed preservation (dependency, not new functionality)

Retain current thread membership/read/write flags, owner announcements, announcement-only minor groups, fixed minor questions, child sentiment clamps, guardian write denials and unconditional report path.
Keep `_post` functional behavior: safe body markup, replies/snippets, edited/deleted/restoration limits, countless sentiment, native Respond disclosures and current media capability fields without enabling any media flag.
Retain `thread-list`, `thread-jump`, `compose`, `typing-indicator`, post/reply anchors and exact current configuration/nonce serialization; load unchanged `presend-nudge.js` before `thread-chat.js` only when current `show_thread` does.
Keep existing hovercard/site confirmation behavior or an independently reviewed equivalent; the native shell must not accidentally omit it merely because family/create pages use no product JS.
Keep current bounded post/reply/announcement selection, before/reply_to admission, query ordering and activity-feed visibility; no extra full-history query or new aggregate.
Preserve the existing feed/card capabilities and current empty-state organize link. No feed ranking, discovery, cohort or scheduling changes.
Ordinary EN/RO labels may use finite Go-owned fallbacks only for observed missing ordinary UI copy; frozen locale/legal/age-authority copy stays untouched.

## Qualification and custody before publication

Add typed escaping/shape tests plus real App cookie/CSRF/Origin tests for owner/adult-member/nonmember, mutual block, cross-cohort/inactive/current authority, minor member and staff curator; synthetic flags only, never real-child activation.
Prove join idempotence; owner leave rejection; adult-owner listing toggle and forged minor/nonowner refusal; archive redirect/freeze; audit failure rollback; no roster/count for nonmembers/minors and current filtered roster/order for adult members.
Prove the outside-minor-cohort staff metadata-bypass case sees only own announcements, no minor peer data/roster/compose/dissent/concern; preserve normal same-cohort authorized access. Closed question enum sends only existing notification/audit and creates no post.
Retain every original group/thread/source test and assertion. The fixed31-row Group afterimage includes renderer `6228270fd3343f7d352b79780bd9055ccbf9fe70b2d7917acdb4e0b6ffd31ed3`, forms `a9cc66599f770b3e6b30ea3bc4be7148253702c939d484ae6b7bea5d16af6717`, and walker `08a920a05fd36516a0787aa0842e2f19d60996897171a1831e06827a712b3dd2`.
Add exact newest inverses/current-reader bridges recovering that entire31-row afterimage, prior27 mutation scope and every original refusal, while current readers see the complete new physical chain. Do not merely increment old31/27 counters or rewrite pins; retain all138 physical preference tuples and immutable source registries.
Run all source-guard readers/refusal controls, existing populated-page/minor-group/thread/policy/rate tests and complete affected package qualification with committed methods and fresh fixed-limit synthetic fixtures.
Committed fixture/browser methods must cover EN/RO owner/member/outsider/minor/curator/error states, keyboard/native confirmation, no-JS forms, every Axe rule, assets/CSP/errors and initial-versus-settled button colors; repeat all existing8family fixture bodies byte-exact.
Any same-purpose Pongo/native body benchmark must use the same actual authorized view projection, distinguish query/build costs and record HTML/gzip/allocations honestly; no full-HTTP or speedup claim from body-only data.
Final source/tool/result/cleanup identities and independent review precede bounded feature publication. Social main/milestone/production/provider/real-child gates remain separate.

Fingerprints: `fingerprints.json`; file-only source/hash reads, no candidate parser, compiler, test, browser, service or DB execution.
No new ADR number is claimed. Audit all refs and current STATUS after active Group closure before preparing an implementation packet.
