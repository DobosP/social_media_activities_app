import pathlib,subprocess,json,hashlib,re
root=pathlib.Path('/home/dobo/work/_temp/feat__gui-app-migration-a/social-family/group-detail-implementation');repo=pathlib.Path('/home/dobo/work/_worktrees/social_media_activities_app/feat__gui-app-migration-a');out=root.parent/'group-detail-fresh-review';proof=json.loads((root/'product-v1-source-proof.json').read_bytes());base=proof['base_sha'];findings=[]
def h(x):return hashlib.sha256(x).hexdigest()
def git(*a):return subprocess.check_output(['git','-C',str(repo),*a])
def need(v,m):
 if not v:findings.append(m)
patch=(root/'product-v1.patch').read_bytes();need(h(patch)==proof['patch_sha256'],'patch hash');lines=patch.decode().splitlines(keepends=True);parts={};i=0
while i<len(lines):
 assert lines[i].startswith('--- ');old=lines[i][4:].strip();i+=1;assert lines[i].startswith('+++ ');path=lines[i][4:].strip()[2:];i+=1
 oldraw=b'' if old=='/dev/null' else git('show',base+':'+old[2:]);oldlines=oldraw.decode().splitlines(keepends=True);pos=0;new=[]
 while i<len(lines) and not lines[i].startswith('--- '):
  m=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',lines[i]);assert m,(i,lines[i]);start,count,newstart,newcount=[int(m[x])if m[x]is not None else 1 for x in range(1,5)];i+=1;start=max(start-1,0);assert start>=pos;new+=oldlines[pos:start];pos=start;oldn=newn=0
  while i<len(lines) and not lines[i].startswith(('@@ ','--- ')):
   line=lines[i];i+=1
   if line.startswith('\\ No newline'):raise AssertionError('unexpected no-newline')
   assert line[:1]in [' ','+','-']
   if line[0]in ' -':assert oldlines[pos]==line[1:],(path,pos);pos+=1;oldn+=1
   if line[0]in ' +':new.append(line[1:]);newn+=1
  assert oldn==count and newn==newcount,(path,oldn,count,newn,newcount)
 new+=oldlines[pos:];parts[path]=''.join(new).encode()
need(set(parts)=={r['path']for r in proof['rows']}and len(parts)==19,'exact nineteen path patch')
for row in proof['rows']:
 p=row['path'];raw=parts[p];need(h(raw)==row['after_sha256']and len(raw)==row['after_bytes'],'postimage '+p)
 old=b''if row['new']else git('show',base+':'+p);need(len(old)==row['before_bytes']and (row['new']or h(old)==row['before_sha256']),'preimage '+p)
 if not row['new']:need(old==(repo/p).read_bytes(),'current unchanged '+p)
for row in proof['source_inputs']:
 raw=git('show',base+':'+row['path']);need(len(raw)==row['bytes']and h(raw)==row['sha256']and raw==(repo/row['path']).read_bytes(),'selected source '+row['path'])
d=json.loads((root/'custody-delta.json').read_bytes());renderer=parts[d['renderer_path']];need(renderer.count(d['renderer_after_fragment'].encode())==1,'unique renderer inverse fragment');before=renderer.replace(d['renderer_after_fragment'].encode(),d['renderer_before_fragment'].encode(),1);need(before==git('show',base+':'+d['renderer_path']),'whole renderer inverse')
walkerpath='services/server/internal/web/gui_public_get_walk_test.go';walker=parts[walkerpath];added=d['walker_added_row'].encode();need(walker.count(added)==1,'unique added row');need(walker.replace(added,b'',1)==git('show',base+':'+walkerpath),'whole walker inverse')
body=walker.decode().split('func guiPublicGetRepairRows() []guiPublicGetRepairRow {',1)[1].split('\nfunc guiPublicGetRowsPreimage',1)[0];need(len(re.findall(r'^\s*path:',body,re.M))==32,'physical thirty-two repair rows')
pre='services/server/internal/web/'
p=pre+'group_create_custody_test.go';new=parts[p].decode();new=new.replace('\traw, rows = groupDetailGroupCustodyPreimage(t, raw, rows)\n','');new=new.replace('groupCreateCustodyRowsPreimage(path, raw, rows)','guiPublicGetRowsPreimage(path, raw)').replace('groupCreateCustodyRowsPreimage(path, changed, rows)','guiPublicGetRowsPreimage(path, changed)');need(new.encode()==git('show',base+':'+p),'whole old group custody restored with only declared adapter/call inverses')
p=pre+'group_create_source_guard_test.go';new=parts[p].decode();new=new.replace('groupDetailPreviousRepairRows(guiPublicGetRepairRows())','guiPublicGetRepairRows()');new=new.replace('\t\traw, err = groupDetailRendererPreimage(raw)\n\t\tif err != nil {\n\t\t\treturn guiG1Binding{}, err\n\t\t}\n','').replace('\t\traw, err = groupDetailWalkerPreimage(raw)\n\t\tif err != nil {\n\t\t\treturn guiG1Binding{}, err\n\t\t}\n','');need(new.encode()==git('show',base+':'+p),'whole old source guard restored by only declared inverse adapters')
need(git('rev-parse','HEAD').decode().strip()==base and not git('status','--porcelain'),'owning base clean')
report={'schema':1,'packet_sha256':h(patch),'proof_sha256':h((root/'product-v1-source-proof.json').read_bytes()),'base_sha':base,'postimages_reconstructed_from_patch':len(parts),'selected_source_refs_verified_current_and_Git':len(proof['source_inputs']),'not_transitive_source_closure':True,'whole_renderer_and_walker_preimages_exact':True,'whole_both_old_group_test_files_recovered_by_declared_inverses':True,'physical_current_rows':32,'retained_previous_rows':31,'original_mutation_rows':27,'original_physical_preference_rows':138,'mechanical_findings':findings,'source_findings_pending':['CanAsk presentation adds Member authority absent from unchanged producer','present chat config i18n missing-plus-extra key is admitted because missing lookup is valid empty text'],'scope':'Read-only V1 source binding, not product acceptance; focused correction remains required. No parser/compiler/test/browser/native/PG execution.'};(out/'v1-mechanical-bind.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
