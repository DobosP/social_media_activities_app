import pathlib,re,json,hashlib,subprocess,tarfile
root=pathlib.Path('/home/dobo/work/_temp/feat__gui-app-migration-a/social-family/group-detail-implementation');repo=pathlib.Path('/home/dobo/work/_worktrees/social_media_activities_app/feat__gui-app-migration-a');out=root.parent/'group-detail-fresh-review';findings=[]
def h(x):return hashlib.sha256(x).hexdigest()
def load(p):return json.loads(p.read_bytes())
def need(v,m):
 if not v:findings.append(m)
rows={r['path']:r for r in load(root/'product-v1-source-proof.json')['rows']};rows.update({r['path']:r for r in load(root/'product-v2-correction-source-proof.json')['rows']});join=load(root/'applied-product-format-join.json');need(h((root/'applied-product-format-join.json').read_bytes())=='b50103d1be5769161d54365b33edaf43bdc6c9dc8ff017e63ac10e440ba54678','frozen join identity')
# Source-text lexer only: preserve strings/runes/raw strings, normalized comment
# text, identifiers/numbers/operators; ignore layout and statement separators.
tokens=re.compile(r'//[^\n]*|/\*.*?\*/|`[^`]*`|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|[A-Za-z_][A-Za-z_0-9]*|[0-9][A-Za-z_0-9.]*|<<=|>>=|&\^=|\.\.\.|:=|\+\+|--|==|!=|<=|>=|&&|\|\||<-|<<|>>|&\^|\+=|-=|\*=|/=|%=|&=|\|=|\^=|[^\s]',re.S)
def lex(raw):
 result=[]
 for m in tokens.finditer(raw.decode()):
  t=m.group(0)
  if t==';':continue
  if t.startswith(('//','/*')):t=' '.join(t.split())
  result.append(t)
 return result
bound=[]
for row in join['rows']:
 p=row['path'];r=rows[p];packet=(root/'proposed'/p).read_bytes();actual=(repo/p).read_bytes();need(h(packet)==r['after_sha256']and len(packet)==r['after_bytes']and h(actual)==row['actual_sha256']and len(actual)==row['actual_bytes'],'exact packet and applied hashes '+p)
 if row['comparison']=='EXACT':need(packet==actual,'byte-exact seam/doc/template/css '+p)
 else:
  if row['comparison']=='EXACT_UNUSED_LOCAL_REMOVAL_PLUS_FORMAT':
   begin=packet.index(b'func TestNativeGroupDetailAssembledMandatoryAuditRollback(');end=packet.index(b'\nfunc ',begin+1);block=packet[begin:end];needle=b'ctx:=context.Background();';need(block.count(needle)==1,'one unused local only');packet=packet[:begin]+block.replace(needle,b'',1)+packet[end:]
  need(lex(packet)==lex(actual),'format-only ordered lexical tokens/comments/literals '+p)
 bound.append({'path':p,'bytes':len(actual),'sha256':h(actual),'relation':row['comparison']})
need(len(bound)==len(rows)==22,'all22 applied product paths')
method=root/'ui-method-proposal';pro=load(method/'producer-source-proof.json');peer=load(method/'manifest.json');allfiles=pro['paths']+peer['files'];need(len(allfiles)==8 and len({r['path']for r in allfiles})==8,'eight disjoint methods')
for packet,expect in [('producer-method.patch',pro['patch']['sha256']),('proposed.patch',load(method/'source-proof.json')['patch_sha256'])]:
 raw=(method/packet).read_bytes();need(h(raw)==expect,'method patch identity '+packet);chunks={};name=None
 for line in raw.decode().splitlines(keepends=True):
  if line.startswith('--- '):need(line=='--- /dev/null\n','only additive method preimages');name=None
  elif line.startswith('+++ b/'):name=line[6:].strip();chunks[name]=''
  elif line.startswith(('@@ ','diff --git ','new file mode ','index ')):continue
  elif line.startswith('+')and name:chunks[name]+=line[1:]
  else:need(False,'unexpected additive patch line')
 for p,data in chunks.items():need((method/'proposed'/p).read_bytes()==data.encode(),'full reconstructed method postimage '+p)
for row in allfiles:
 raw=(method/'proposed'/row['path']).read_bytes();want=row.get('sha256',row.get('after_sha256'));size=row.get('bytes',row.get('after_bytes'));need(h(raw)==want and len(raw)==size and not(repo/row['path']).exists(),'method exact source/absent owning preimage '+row['path'])
extract=(method/'proposed/tools/gui-native-group-detail/extract-projection.py').read_text();overlay=(method/'proposed/tools/gui-native-group-detail/prepare-ui-overlay.py').read_text();names=lambda s,key:re.findall(r"'([^']+)'",re.search('^'+key+r' = (\[.*\])$',s,re.M).group(1));product=names(overlay,'PRODUCT_INPUTS');UI=names(overlay,'UI_INPUTS');need(names(extract,'SOURCE_NAMES')==product and len(product)==85 and len(UI)==6 and len(set(product+UI))==91,'exact shared85+6 source references')
baseline=load(method/'proposed/tools/gui-native-group-detail/prior-html-baseline.json');canonical=repo/'docs/reviews/gui-native-group-create/evidence.tar.gz';need(h(canonical.read_bytes())==baseline['accepted_keeper_sha256']=='1bb27df97ec9641119a30e76afff1ab1181947f5036888f954a96a5b30f8adf9','canonical prior keeper identity');need(len(baseline['html'])==18,'all18 prior bodies')
with tarfile.open(canonical,'r:gz')as t:
 for row in baseline['html']:
  leaf=('family/'if row['kind']=='family'else'')+row['name']+'.html';raw=t.extractfile('evidence/UI/presentation-fixtures/'+leaf).read();old=t.extractfile('evidence/UI/fixtures/'+leaf).read();need(raw==old and len(raw)==row['bytes']and h(raw)==row['sha256']and row['equal']is True,'accepted actual previous body '+row['path'])
report={'schema':1,'verdict':'APPLIED22_AND_FINAL_METHOD_MECHANICAL_BIND_PASS','approved_product_source_review_sha256':'135233e64c2afb12ff5788a3079490876eeb9eed88e8797ee9eae068abc2ea1d','applied_join_sha256':h((root/'applied-product-format-join.json').read_bytes()),'applied_product_paths':bound,'method_paths':8,'producer_patch_sha256':h((method/'producer-method.patch').read_bytes()),'peer_patch_sha256':h((method/'proposed.patch').read_bytes()),'shared_product_source_paths':85,'shared_UI_source_paths':6,'prior_bodies_rehashed_against_actual_canonical_members_and_originals':18,'findings':findings,'pending':[],'execution':'Read-only source/hash/Git/canonical archive and scratch text/JSON only; no candidate parser/import/formatter/compiler/tests/browser/PG/runtime or owning writes.'};(out/'applied-method-mechanical-bind.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'review':str(out/'applied-method-mechanical-bind.json'),'sha256':h((out/'applied-method-mechanical-bind.json').read_bytes()),'findings':findings}))
