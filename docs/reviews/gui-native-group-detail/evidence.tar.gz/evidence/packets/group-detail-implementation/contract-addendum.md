# Group detail: narrow live-client correction

The approved whole-view contract remains retained at SHA30be79d10f7ef9a6704f755b9821de336d47e10effd15da9c2eca78229f6351f. Root approved this additive correction before implementation on2026-10-19.

The current outside-minor-cohort staff-owner fallback in `socialGroupDetail` sets `show_thread=true`, own announcements and `PostForm`, but does not run `socialThreadContext`, so `thread_chat_config` is absent. The original template emits null JSON and loads `thread-chat.js`; its unconditional `JSON.parse(...).i18n` access throws on null.

The native view preserves all static own-announcement, owner-announce, report and other current predicates. Its separate typed `LiveThread` is true only when the authorized current projection actually contains a valid existing chat configuration. Missing configuration does not invent a subscription or expose peer rows. Only unusable live-chat configuration/scripts are omitted in the metadata fallback; global hovercard/confirmation remain.

Source precision: the existing fallback condition is `owner && a.IsStaff` after the failed read, without a cohort-inequality requirement. The same static-own-broadcast shape can therefore occur in the same cohort after assurance or membership withdrawal. The native view preserves that shape too; cohort equality never creates live permission. Every fallback has no peer posts, admitted roster or composer, and only the curator's own announcements; same-cohort feed remains whatever the existing authorized projection supplies.

Ordinary authorized group views retain the original validated configuration, DOM hooks and script order. An explicitly malformed present configuration fails before output. The presend guard is validated against its separate existing producer and is not made an unrelated admission requirement. This changes no query, service, cohort, consent, membership or authority policy.

Required tests: ordinary live configuration/order, metadata fallback with no peer history/roster/feed/compose/client connection/pageerror, malformed-present config refusal, all static own broadcasts/forms retained. Source-only addendum; no runtime acceptance yet.

## Existing CanAsk compatibility edge

The supplied `can_ask` comes from raw stored membership, not `is_member` (which also requires CanReadThread). An active adult staff nonowner retaining membership in an active curated minor group can therefore have `can_ask=true`, `is_member=false`, `show_thread=false`. Preserve its metadata page and fixed question form; do not add a native member or viewer-cohort gate. The unchanged AskGroup service still rejects the cross-cohort submission, before any question audit/notification/post. Pure and real registered-App regressions retain this existing presentation/service distinction without granting permission or changing a backend query/policy. Root approved this clarification before source freeze.
