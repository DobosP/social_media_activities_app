from pathlib import Path
import hashlib, json, difflib
repo=Path('/home/dobo/work/_worktrees/social_media_activities_app/feat__gui-app-migration-a')
root=Path(__file__).parent.parent
diag=Path(__file__).parent
before=json.loads((diag/'before/desktop-results.json').read_text())
after=json.loads((diag/'candidate/desktop-results.json').read_text())
assert len(before['states'])==len(after['states'])==7
assert len(before['noJavaScriptStates'])==len(after['noJavaScriptStates'])==7
for d in [before,after]:
    assert d['ownership']['serverStopped'] and all(p['closed'] and p['removed'] for p in d['ownership']['profiles'])
def findings(d,key): return sum(len(a['axe'][key]) for s in d['states'] for a in s['audits'])
assert findings(before,'violations')==findings(after,'violations')==0
assert findings(before,'incomplete')==9 and findings(after,'incomplete')==0
assert len(after['failures'])==14 and all('asset absent/different /static/css/group-detail-native.css' in f for f in after['failures'])
geom_same=all_links=0
for b,a in zip(before['diagnosticGeometry'],after['diagnosticGeometry']):
    assert b['state']==a['state'] and len(b['data']['links'])==len(a['data']['links'])
    for x,y in zip(b['data']['links'],a['data']['links']):
        all_links+=1
        geom_same+=x['rect']==y['rect']
        assert x['href']==y['href'] and x['color']==y['color']
        assert x['decoration']=='none' and y['decoration']=='underline'
record={'scope':'Controlled local diagnostic only; both reports remain FAILED, not qualification',
 'before_report_sha256':hashlib.sha256((diag/'before/desktop-results.json').read_bytes()).hexdigest(),
 'candidate_report_sha256':hashlib.sha256((diag/'candidate/desktop-results.json').read_bytes()).hexdigest(),
 'JS_states':7,'noJS_states':7,'audits':21,'violations_before_after':[0,0],'incomplete_before_after':[9,0],
 'candidate_expected_live_asset_guard_failures':14,'original_HTML_fixtures_and_source_unchanged':True,
 'measured_link_frames':all_links,'exact_same_geometry_frames':geom_same,'same_colors_all_links':True,
 'decoration_before_after':['none','underline'],
 'actual_root_cause':'Message timestamp permalink shares adjacent muted text color and has no permanent non-color cue. At natural scroll it is clipped in thread and overlapped by sticky header, so Axe cannot establish its color difference. Source-scoped underline supplies a permanent link cue; it does not claim to eliminate natural offscreen/header overlap.',
 'source_HTML_PNG_raw_reports_retained':True,'benchmark':'Not executed; original wrapper flag requested but desktop failed first',
 'CSS':after['diagnosticCSSHashes']}
(diag/'comparison.json').write_text(json.dumps(record,indent=2)+'\n')
q=root/'group-detail-link-cue-repair'
q.mkdir()
patches=[]
rows=[]
csspath='static/css/group-detail-native.css'
old=(repo/csspath).read_text()
new=old+'\n.group-detail-page .post .meta a, .group-detail-page .reply-quote a { text-decoration: underline; text-underline-offset: .16em; }\n'
assert hashlib.sha256(new.encode()).hexdigest()==after['diagnosticCSSHashes']['after']
changes={csspath:(old,new)}
name='services/server/internal/app/group_detail_native_http_test.go'
text=(repo/name).read_text()
oldliteral='const expected = '+json.dumps(old,ensure_ascii=False)
newliteral='const expected = '+json.dumps(new,ensure_ascii=False)
assert text.count(oldliteral)==1
changes[name]=(text,text.replace(oldliteral,newliteral,1))
name='tools/gui-native-group-detail/qualify.py'
text=(repo/name).read_text()
oldfield='"benchmark": {"status": "NOT_REQUESTED"},'
newfield='"benchmark_requested": args.benchmark,\n        "benchmark": {"status": "REQUESTED_NOT_REACHED" if args.benchmark else "NOT_REQUESTED"},'
assert text.count(oldfield)==1
changes[name]=(text,text.replace(oldfield,newfield,1))
for name,(old,new) in changes.items():
    p=q/'proposed'/name
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(new)
    patches.extend(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile='a/'+name,tofile='b/'+name))
    rows.append({'path':name,'before_sha256':hashlib.sha256(old.encode()).hexdigest(),'after_sha256':hashlib.sha256(new.encode()).hexdigest()})
(q/'proposed.patch').write_text(''.join(patches))
proof={'status':'SOURCE_CANDIDATE_UNRUN_PRODUCT','base':'09955835daf991e1f308739f969b4c0d804bee37','paths':rows,
 'diagnostic_comparison_sha256':hashlib.sha256((diag/'comparison.json').read_bytes()).hexdigest(),
 'scope':'Only new page CSS link cue + exact existing new-App CSS expected bytes + truthful benchmark-intent metadata. All existing test predicates and Go runtime/queries/policies/original templates/assets unchanged. Candidate diagnostic remains failed because live CSS hash guard intentionally fails.',
 'qualification_next':'After independent source review apply/focused newApp CSS GET-HEAD+webpure/vet/docs then commit. Fresh complete6 on new producer before actualUI avoids a new CSS/test sourcebridge exception and binds exact current expected sheet; all original limits/assertions/cases stay.'}
(q/'source-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({'patch_sha256':hashlib.sha256((q/'proposed.patch').read_bytes()).hexdigest(),'proof_sha256':hashlib.sha256((q/'source-proof.json').read_bytes()).hexdigest(),'link_frames':all_links,'same_geometry':geom_same}))
