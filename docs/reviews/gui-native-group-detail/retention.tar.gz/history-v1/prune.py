#!/usr/bin/env python3
"""Verify the reviewed exact retention manifest; delete only with explicit --execute."""
import argparse
from decimal import Decimal
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import subprocess
import tarfile

HERE = Path(__file__).absolute().parent
BASE = Path('/home/dobo/work/_temp/feat__gui-app-migration-a/social-family')
REPO = Path('/home/dobo/work/_worktrees/social_media_activities_app/feat__gui-app-migration-a')
SOURCE = 'fa3e7c90bf736f63981b00d2f117417d01b26cd2'
ARCHIVE = 'f1fc63527352bbb41a4d7640a0634dac6164d7e34eaddca0209fe355ecc14153'
RUNS = (
    BASE / 'group-detail-pg-qa/run-dc1c15caa140-80827a3c-328e-4b5f-8251-df819898caf2',
    BASE / 'group-detail-pg-qa/run-7fb35d0e6919-05b5bdfb-4f6a-4cae-ab44-d99aba7327fe',
    BASE / 'group-pg-qa-successor/run-1f8c9742de32-e9f8010a-d5ae-4ca6-bf47-607d280e1638',
)
LATEST = BASE / 'group-detail-pg-qa/run-fa3e7c90bf73-af3786aa-506c-4a81-ad95-3366c3e28abe'
OLD_UI = Path('/home/dobo/work/_temp/gd-ui/run-7fb35d0e6919-adc06c36-1b78-4d87-896f-205cecac5b1e')
DIAG = BASE / 'group-detail-link-cue-diagnostic'


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def parent_fd(path):
    """Open every directory component without following any symlink."""
    need(path.is_absolute() and path == Path(os.path.normpath(path)), 'Literal absolute path required')
    fd = os.open('/', os.O_RDONLY | os.O_DIRECTORY)
    try:
        for part in path.parts[1:-1]:
            following = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            os.close(fd)
            fd = following
        return fd
    except BaseException:
        os.close(fd)
        raise


def same(info, row, directory=False, removing=False):
    good_type = stat.S_ISDIR(info.st_mode) if directory else stat.S_ISREG(info.st_mode)
    need(good_type and info.st_uid == row['uid'] == os.getuid()
         and info.st_gid == row['gid'] and stat.S_IMODE(info.st_mode) == row['mode'], 'Type/owner/mode differs')
    if 'dev' in row:
        need(info.st_dev == row['dev'] and info.st_ino == row['ino'], 'Original inode identity differs')
    if not directory:
        need(info.st_size == row['bytes'] and info.st_nlink == 1, 'Length/hardlink differs')
    if not removing:
        need(info.st_mtime_ns == row['mtime_ns'], 'Original nanosecondmtime differs')


def file_check(row, collect=False):
    path = Path(row.get('path', row.get('source', '')))
    parent = parent_fd(path)
    fd = None
    try:
        before = os.stat(path.name, dir_fd=parent, follow_symlinks=False)
        same(before, row)
        fd = os.open(path.name, os.O_RDONLY | os.O_NOFOLLOW, dir_fd=parent)
        opened = os.fstat(fd)
        need((before.st_dev, before.st_ino) == (opened.st_dev, opened.st_ino), 'Input swapped before open')
        digest = hashlib.sha256()
        chunks = []
        size = 0
        while True:
            block = os.read(fd, 1 << 20)
            if not block:
                break
            size += len(block)
            digest.update(block)
            if collect:
                need(size <= 16 << 20, 'Metadata/keeper input unexpectedly large')
                chunks.append(block)
        after = os.fstat(fd)
        same(after, row)
        need((before.st_dev, before.st_ino, before.st_ctime_ns) ==
             (after.st_dev, after.st_ino, after.st_ctime_ns)
             and size == row['bytes'] and digest.hexdigest() == row['sha256'], 'Input hash/stat changed')
        return b''.join(chunks) if collect else None
    finally:
        if fd is not None:
            os.close(fd)
        os.close(parent)


def directory_check(row, removing=False):
    path = Path(row['path'])
    parent = parent_fd(path)
    try:
        info = os.stat(path.name, dir_fd=parent, follow_symlinks=False)
        same(info, row, directory=True, removing=removing)
        fd = os.open(path.name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent)
        try:
            need(os.fstat(fd).st_ino == info.st_ino, 'Directory swapped')
            children = os.listdir(fd)
        finally:
            os.close(fd)
        if removing or row['category'] == 'owned-empty-temporary-directory':
            need(not children, 'Directory is not empty; no recursive fallback')
    finally:
        os.close(parent)


def verify_archive(archive_raw, manifest):
    """Recheck every regular keeper member, including exact source metadata."""
    need(len({r['member'] for r in manifest}) == len(manifest), 'Duplicate keeper member')
    with tarfile.open(fileobj=io.BytesIO(archive_raw), mode='r:gz') as archive:
        entries = archive.getmembers()
        need([e.name for e in entries] == [r['member'] for r in manifest], 'Keeper member inventory differs')
        for entry, row in zip(entries, manifest):
            need(entry.isfile() and not entry.name.startswith('/') and '..' not in Path(entry.name).parts
                 and entry.size == row['bytes'] and entry.mode == row['mode']
                 and entry.uid == row['uid'] and entry.gid == row['gid']
                 and int(Decimal(entry.pax_headers['mtime']) * 1_000_000_000) == row['mtime_ns'], 'Keeper type/full metadata differs')
            stream = archive.extractfile(entry)
            need(stream is not None, 'Missing regular keeper stream')
            digest = hashlib.sha256()
            for block in iter(lambda: stream.read(1 << 20), b''):
                digest.update(block)
            need(digest.hexdigest() == row['sha256'], 'Keeper member bytes differ')
    return {row['member']: row for row in manifest}


def permitted(path):
    if any(path.is_relative_to(root / child) for root in RUNS for child in ('source', 'binaries')):
        return True
    if path in {root / 'proof/command-006.stdout' for root in (*RUNS[:2], LATEST)}:
        return True
    return (path.is_relative_to(OLD_UI) and path.suffix in ('.html', '.png')) or (
        any(path.is_relative_to(DIAG / side) for side in ('before', 'candidate')) and path.suffix == '.png')


def prerequisites(plan):
    rows = plan['prerequisites']
    data = {name: file_check(row, collect=True) for name, row in rows.items()}
    acceptance = json.loads(data['detail_acceptance'])
    review = json.loads(data['detail_keeper_review'])
    need(acceptance['verdict'] == 'ACCEPT_COMPLETE_GROUP_DETAIL_FEATURE_ON_QUALIFIED_FEATURE_BRANCH_SOURCE'
         and acceptance['source_sha'] == SOURCE and acceptance['findings'] == []
         and acceptance['archive_sha256'] == ARCHIVE and review['verdict'] == 'ACCEPT_COMPACT_GROUP_DETAIL_KEEPER_CANDIDATE'
         and review['findings'] == [] and review['archive_sha256'] == ARCHIVE, 'Independent feature AND keeper acceptance required')
    collection = json.loads(data['detail_collection'])
    need(sha(data['detail_archive']) == ARCHIVE == collection['archive_sha256']
         and sha(data['detail_archive_manifest']) == acceptance['archive_manifest_sha256']
         and collection['full_readback'] is True and collection['bytes_mode_UID_GID_nanosecondmtime'] is True,
         'Actual accepted keeper custody differs')
    manifest = json.loads(data['detail_archive_manifest'])
    members = verify_archive(data['detail_archive'], manifest)
    need(len(members) == 1550 == acceptance['archive_members'], 'Exact final keeper count required')
    aliases = json.loads(data['detail_aliases'])
    selection = json.loads(data['detail_selection'])
    need(len(aliases) == 105 and aliases == selection['content_aliases']
         and sha(data['detail_selection']) == acceptance['keeper_selection_sha256'], 'Complete accepted alias/selection frame differs')
    by_source = {r['original']: r for r in manifest}
    aliases_by_source = {r['source']: r for r in aliases}
    for row in plan['files']:
        if row['category'] != 'superseded-historical-html-png':
            continue
        retained = by_source.get(row['path'])
        alias = aliases_by_source.get(row['path'])
        need(retained is not None or alias is not None, 'Historical body not retained in keeper')
        original = retained if retained is not None else alias
        need(all(row[k] == original[k] for k in ('bytes', 'sha256', 'mode', 'uid', 'gid', 'mtime_ns')), 'Historical original metadata/content differs')
        target = retained if retained is not None else members[alias['content_member']]
        need(row['bytes'] == target['bytes'] and row['sha256'] == target['sha256'], 'Alias physical bytes differ')
    excluded = {r['source']: r for r in selection['excluded'] if 'source' in r}
    for row in plan['files']:
        if row['category'] == 'redundant-binary-git-archive-stdout':
            need(row['path'] in excluded and all(row[k] == excluded[row['path']][k] for k in ('bytes', 'sha256')), 'Only three explicit archive exclusions may retire')
    create = json.loads(data['create_acceptance'])
    need(create['verdict'] == 'ACCEPT_SOCIAL_NATIVE_GROUP_FUNCTIONAL_FEATURE_COMPOSITE_AND_KEEPER_FOR_FEATURE_PUBLICATION'
         and create['findings'] == [] and create['PG_source'] == plan['epochs'][2]['source']
         and create['bindings']['archive_sha256'] == sha(data['create_archive'])
         and create['bindings']['archive_manifest_sha256'] == sha(data['create_archive_manifest']), 'Prior GroupCreate accepted keeper differs')
    verify_archive(data['create_archive'], json.loads(data['create_archive_manifest']))
    # Native artifact results/complete source manifests are retained, while
    # source-export/code bytes remain reproducible from the untouched Git refs.
    manifests = (manifest, json.loads(data['create_archive_manifest']))
    for index, epoch in enumerate(plan['epochs']):
        retained = {row['sha256'] for row in manifests[1 if index == 2 else 0]}
        need(epoch['result']['sha256'] in retained and epoch['source_manifest']['sha256'] in retained, 'Old result/source manifest missing from keeper')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--approved-manifest-sha256', required=True)
    parser.add_argument('--receipt', required=True, type=Path)
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    need(HERE == BASE / 'group-detail-keeper/retention' and len(args.approved_manifest_sha256) == 64, 'Literal reviewed manifest required')
    path = HERE / 'prune-manifest.json'
    need(not path.is_symlink() and path.is_file() and path.resolve() == path, 'Canonical plan required')
    raw = path.read_bytes()
    need(sha(raw) == args.approved_manifest_sha256, 'Approved exact manifest hash differs')
    plan = json.loads(raw)
    need(plan['schema'] == 1 and plan['status'] == 'PLAN_ONLY_NOT_AUTHORIZATION_TO_EXECUTE'
         and plan['owner_uid'] == os.getuid() and plan['qualified_latest_source'] == SOURCE
         and tuple(Path(e['root']) for e in plan['epochs']) == RUNS, 'Unexpected plan authority')
    need(args.receipt.is_absolute() and args.receipt.parent == HERE and not args.receipt.exists()
         and not args.receipt.is_symlink(), 'Fresh direct retention receipt required')
    files, directories = plan['files'], plan['directories_bottom_up']
    need(len(files) == 6572 and len(directories) == 718 and len({r['path'] for r in files}) == len(files)
         and sum(r['bytes'] for r in files) == 780572285 and all(permitted(Path(r['path'])) for r in files), 'Exact bounded deletion set differs')
    allowed_dirs = lambda p: any(p.is_relative_to(root / 'source') or p == root / 'binaries'
                                or p in (root / 'host-tmp', root / 'test-tmp') for root in RUNS)
    need(all(allowed_dirs(Path(r['path'])) for r in directories), 'Foreign directory requested')
    prerequisites(plan)
    all_cids, all_names = set(), set()
    for epoch in plan['epochs'] + [plan['latest_epoch']]:
        result = json.loads(file_check(epoch['result'], collect=True))
        file_check(epoch['source_manifest'])
        need(result['source'] == epoch['source'] and result['tree'] == epoch['tree']
             and result['cleanup'] == epoch['cleanup'] and result['pg_cleanup'] == epoch['pg_cleanup']
             and all(r['stopped'] is True and r['id_absent'] is True and r['name_absent'] is True for r in result['cleanup'].values())
             and result['pg_cleanup']['stop_exit'] == 0 and result['pg_cleanup']['status_exit'] == 3
             and result['pg_cleanup']['pid_and_socket_files_absent'] == 1, 'Original stopped/owned native run differs')
        tree = subprocess.check_output(['git', '-C', str(REPO), 'rev-parse', epoch['source'] + '^{tree}']).decode().strip()
        need(tree == epoch['tree'], 'Preserved source Git commit/tree unavailable')
        all_cids.update(row['cid'] for row in result['cleanup'].values())
        all_names.update(epoch['owned_names'])
    # Current read-only Docker inventory succeeds first; a failed inspect or
    # unavailable daemon is never treated as proof that an owned CID is absent.
    observed = subprocess.check_output(['docker', 'container', 'ls', '-a', '--no-trunc', '--format', '{{json .}}'])
    for line in observed.splitlines():
        value = json.loads(line)
        need(value['ID'] not in all_cids and not (set(value['Names'].split(',')) & all_names), 'An owned native container/name exists')
    for row in files:
        file_check(row)
    for row in directories:
        directory_check(row)
    # Refuse added files before deleting any source/export subtree.
    for root in RUNS:
        for name in ('source', 'binaries'):
            expected = {r['path'] for r in files if Path(r['path']).is_relative_to(root / name)}
            expected_dirs = {r['path'] for r in directories if Path(r['path']).is_relative_to(root / name)}
            actual, actual_dirs = set(), set()
            for current, children, names in os.walk(root / name, followlinks=False):
                actual_dirs.add(current)
                for child in children:
                    need(stat.S_ISDIR((Path(current) / child).lstat().st_mode), 'Unexpected symlink/non-directory in export')
                actual.update(str(Path(current) / n) for n in names)
            need(actual == expected and actual_dirs == expected_dirs, 'Additional/changed export, directory or binary entries found')
    result = {'schema': 1, 'status': 'VERIFIED_NOT_EXECUTED', 'manifest_sha256': sha(raw),
              'feature_keeper_archive_sha256': ARCHIVE, 'executed': False, 'deleted': [], 'removed_directories': [],
              'logical_bytes_deleted': 0, 'raw_deleted_paths_unavailable': False,
              'preserved': plan['preserved'], 'fresh_current_Docker_owned_CID_name_absence': True}
    try:
        if args.execute:
            result['executed'] = True
            result['status'] = 'PARTIAL_RETAIN_EXACT_DELETED_RECORDS'
            for row in files:
                file_check(row)
                parent = parent_fd(Path(row['path']))
                try:
                    same(os.stat(Path(row['path']).name, dir_fd=parent, follow_symlinks=False), row)
                    os.unlink(Path(row['path']).name, dir_fd=parent)
                finally:
                    os.close(parent)
                result['deleted'].append({'path': row['path'], 'bytes': row['bytes'], 'sha256': row['sha256'], 'category': row['category']})
                result['logical_bytes_deleted'] += row['bytes']
            for row in directories:
                directory_check(row, removing=True)
                parent = parent_fd(Path(row['path']))
                try:
                    os.rmdir(Path(row['path']).name, dir_fd=parent)
                finally:
                    os.close(parent)
                result['removed_directories'].append(row['path'])
            need(all(not Path(r['path']).exists() for r in files + directories), 'Deletion absence verification failed')
            result['status'] = 'COMPLETE_EXACT_OWNED_TRANSIENT_RETENTION'
    finally:
        result['raw_deleted_paths_unavailable'] = bool(result['deleted'])
        result['retained_history_semantics'] = 'Listed deleted raw source/binary/archive/HTML/PNG paths are unavailable. Source Git refs and compact manifests/results/logs/reviews remain; historical bodies survive only as verified keeper physical members or exact content aliases. No claim that deleted raw trees remain.'
        with args.receipt.open('x') as output:
            json.dump(result, output, separators=(',', ':'))
            output.write('\n')
        print(json.dumps({'status': result['status'], 'deleted_files': len(result['deleted']),
                          'logical_bytes_deleted': result['logical_bytes_deleted'], 'receipt': str(args.receipt)}))


if __name__ == '__main__':
    main()
