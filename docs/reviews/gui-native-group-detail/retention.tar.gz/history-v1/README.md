# Social Group-detail bounded retention plan

Prepared only. No deletion or prune-script execution has occurred. Root must
review this source and its exact manifest before running it. Independent keeper
2026e632 and whole-feature948fb5cb are prerequisites, not deletion receipts.

The pinned manifest selects6,572 files/780,572,285 logical bytes (~744MiB):
6,439 generated Git-export files (82,799,779B),21 native executables
(595,990,761B),three explicitly excluded binary Git archive stdout streams
(93,675,520B), and109 historical HTML/PNG files (8,106,225B).
It includes718 directories, of which six are proven-empty host/test temp roots.
Source/build roots are only exact dc1/7fb GroupDetail and1f8 GroupCreate runs.
Latestfa3 source/build/current67UI files and28PNGs remain rolling; only its
explicit excluded command-006.stdout is included. The older1f8 archive stdout
is not selected. All socket directories stay: they contain cleanup/ready/stop
receipts. Raw logs/JSON/reviews/source packets/branches/baselines/keepers,
all caches, Teacher and unrelated work remain. Generated source-export copies
of tracked JSON/docs/keepers are redundant copies, not the owning originals.

Every target has exact no-follow UID/GID/mode/nsmtime/inode/hash metadata.
The script verifies both accepted keepers member-by-member with full metadata,
all109 historical physical/alias joins, original source/result bindings and Git
commits, recorded stopped ownership and a fresh successful Docker CID/name
absence query. It refuses symlinks, hardlinks, changed/extra entries or unsafe
paths. No Docker stop, recursive-delete fallback, chmod or sudo exists.

Root may first run the default verification-only mode with a fresh receipt:

    python3 -I prune.py --approved-manifest-sha256 1e8f0d5b4e474c141bbcb2dddf42d0b252f57bbb2f262964771acc67143d6be4 --receipt /absolute/retention/verified-not-executed.json

After source review and successful verification, Root alone may use the same
arguments with a NEW receipt name and --execute. No execution is authorized by
this preparation. Each file is rechecked before exact unlink; directories use
empty-only rmdir. A completed or partial receipt lists actual removed paths and
states that their raw bytes are unavailable. An interrupted process must be
reconciled against the manifest; no auto-resume or skip-missing behavior exists.
