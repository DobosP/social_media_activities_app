#!/usr/bin/env python3
"""Inventory or verify exact superseded generated outputs. This script never deletes."""
import argparse
from decimal import Decimal
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import tarfile

HERE=Path(__file__).absolute().parent
ROOT=Path('/home/dobo/work/_temp/feat__gui-app-migration-a/social-family')
REPO=Path('/home/dobo/work/_worktrees/social_media_activities_app/feat__gui-app-migration-a')
OLD_UI=Path('/home/dobo/work/_temp/np-ui/run-7819bdfdb6ae-9c2051ca-f62b-4a2f-9fe9-de64a6713070')
DIAG=ROOT/'notification-browser-diagnostic'
LATEST=ROOT/'notification-preferences-pg-qa/run-e900960d50be-2503620e-5e0f-4acb-9ea2-09f713d162ae'
LATEST_UI=Path('/home/dobo/work/_temp/np-ui/run-e900960d50be-0985c564-20f7-4204-a04c-7bd40c6828a3')
EPOCHS=(
 ('group-detail',ROOT/'group-detail-pg-qa/run-fa3e7c90bf73-af3786aa-506c-4a81-ad95-3366c3e28abe','fa3e7c90bf736f63981b00d2f117417d01b26cd2','evidence/native-final/'),
 ('notification',ROOT/'notification-preferences-pg-qa/run-7819bdfdb6ae-fa50086a-086a-47ff-884f-23360ccc2e6d','7819bdfdb6ae001a83c7a05c6ab1f8d09431e4e4','evidence/native-initial-qualified/'),
)


def need(ok,message):
    if not ok:raise RuntimeError(message)


def digest(raw):return hashlib.sha256(raw).hexdigest()


def literal(value):
    need(isinstance(value,str) and not value.startswith('/') and '\\' not in value and all(v not in ('','.','..') for v in value.split('/')),'Literal relative archive path required')
    return value


def parent_fd(path):
    need(path.is_absolute() and path==Path(os.path.normpath(path)),'Literal absolute path required')
    fd=os.open('/',os.O_RDONLY|os.O_DIRECTORY)
    try:
        for part in path.parts[1:-1]:
            child=os.open(part,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=fd);os.close(fd);fd=child
        return fd
    except BaseException:os.close(fd);raise


def row(path,category,**extra):
    parent=parent_fd(path);fd=None
    try:
        before=os.stat(path.name,dir_fd=parent,follow_symlinks=False)
        need(stat.S_ISREG(before.st_mode) and before.st_uid==os.getuid() and before.st_nlink==1,'Owned regular single-link file required')
        fd=os.open(path.name,os.O_RDONLY|os.O_NOFOLLOW,dir_fd=parent);opened=os.fstat(fd);h=hashlib.sha256();count=0
        while chunk:=os.read(fd,1<<20):h.update(chunk);count+=len(chunk)
        after=os.fstat(fd);keys=('st_dev','st_ino','st_mode','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns','st_nlink')
        need(all(getattr(before,k)==getattr(opened,k)==getattr(after,k) for k in keys) and count==after.st_size,'Input changed during streamed read')
        return dict(path=str(path),category=category,bytes=count,sha256=h.hexdigest(),mode=stat.S_IMODE(after.st_mode),uid=after.st_uid,gid=after.st_gid,mtime_ns=after.st_mtime_ns,ctime_ns=after.st_ctime_ns,dev=after.st_dev,ino=after.st_ino,**extra)
    finally:
        if fd is not None:os.close(fd)
        os.close(parent)


def small(path):
    r=row(path,'metadata');need(r['bytes']<=16<<20,'Metadata unexpectedly large');parent=parent_fd(path);fd=None
    try:
        fd=os.open(path.name,os.O_RDONLY|os.O_NOFOLLOW,dir_fd=parent);info=os.fstat(fd)
        need(info.st_dev==r['dev'] and info.st_ino==r['ino'] and info.st_size==r['bytes'],'Metadata replaced')
        raw=b''
        while chunk:=os.read(fd,1<<20):
            raw+=chunk;need(len(raw)<=16<<20,'Metadata grew')
        need(len(raw)==r['bytes'] and digest(raw)==r['sha256'] and os.fstat(fd).st_ctime_ns==r['ctime_ns'],'Metadata changed');return raw
    finally:
        if fd is not None:os.close(fd)
        os.close(parent)


def directory(path,category):
    need(path.is_absolute() and path.resolve()==path,'Unaliased directory required')
    info=path.lstat();need(stat.S_ISDIR(info.st_mode) and info.st_uid==os.getuid(),'Owned directory required')
    return dict(path=str(path),category=category,mode=stat.S_IMODE(info.st_mode),uid=info.st_uid,gid=info.st_gid,mtime_ns=info.st_mtime_ns,dev=info.st_dev,ino=info.st_ino,entries=sorted(p.name for p in path.iterdir()))


def lifecycle(value):
    need(value['method_pass'] is True and not value['errors'] and len(value['cleanup'])==13 and all(r.get('stopped') is True and r.get('id_absent') is True and r.get('name_absent') is True for r in value['cleanup'].values()),'Actual native cleanup missing')
    p=value['pg_cleanup'];need(p['stop_exit']==0 and p['status_exit']==3 and p['pid_probe_exit']==1 and p['pid_and_socket_files_absent']==1,'PG stop/PID/socket absence missing')


def inventory():
    files=[];dirs=[];epochs=[];already=[]
    prior_retention=json.loads(small(ROOT/'group-detail-keeper/retention/retention-result.json'))
    for keeper,run,source,prefix in EPOCHS:
        result_raw=small(run/'result.json');result=json.loads(result_raw);lifecycle(result);need(result['source']==source,'Old native source differs')
        source_raw=small(run/'source-manifest.json');manifest=json.loads(source_raw);lookup={r['path']:r for r in manifest};need(len(lookup)==len(manifest),'Source manifest duplicate')
        actual={str(p.relative_to(run/'source')) for p in (run/'source').rglob('*') if p.is_file()};need(actual==set(lookup),'Generated source export differs from complete tracked source inventory')
        for name,expected in lookup.items():
            r=row(run/'source'/literal(name),'superseded-generated-source',epoch=keeper,relative=name)
            need(r['bytes']==expected['bytes'] and r['sha256']==expected['sha256'] and bool(r['mode']&0o111)==bool(expected['mode']&0o111),'Generated source differs from original qualified manifest');files.append(r)
        for p in sorted((run/'binaries').iterdir()):
            need(p.name in {k+'.test' for k in result['lanes']}|{'reference-bootstrap'},'Unexpected generated binary')
            expected=result['reference_bootstrap_binary']['sha256'] if p.name=='reference-bootstrap' else result['lanes'][p.stem]['binary']['sha256']
            r=row(p,'superseded-generated-binary',epoch=keeper);need(r['sha256']==expected,'Generated binary identity differs');files.append(r)
        for c in result['commands']:
            if c['argv'][0]=='git' and 'archive' in c['argv']:
                p=run/literal(c['stdout']['path'])
                if p.exists():
                    r=row(p,'redundant-binary-git-archive-stdout',epoch=keeper);need(r['bytes']==c['stdout']['bytes'] and r['sha256']==c['stdout']['sha256'],'Git archive differs from recorded original digest');files.append(r)
                else:
                    old=[r for r in prior_retention['deleted'] if r['path']==str(p)];need(len(old)==1 and old[0]['sha256']==c['stdout']['sha256'],'Missing Git archive not explained by prior verified retention')
                    already.append(dict(path=str(p),prior_deleted_record=old[0],raw_bytes_available=False,action='NONE_ALREADY_PRUNED'))
        for root in ('source','binaries'):
            for p in sorted([run/root]+[p for p in (run/root).rglob('*') if p.is_dir()],key=lambda p:len(p.parts),reverse=True):dirs.append(directory(p,'generated-directory-after-exact-files-only'))
        for name in ('host-tmp','test-tmp'):
            d=directory(run/name,'owned-empty-temporary-directory');need(not d['entries'],'Temporary directory not empty');dirs.append(d)
        epochs.append(dict(keeper=keeper,path=str(run),source=source,tree=result['tree'],result_sha256=digest(result_raw),source_manifest_sha256=digest(source_raw),keeper_prefix=prefix,files=len(manifest),source_bytes=sum(r['bytes'] for r in manifest),original_cleanup_recorded=True))
    ui=json.loads(small(OLD_UI/'result.json'))
    for r in ui['artifacts']:
        if Path(r['path']).suffix in ('.png','.html'):
            got=row(OLD_UI/literal(r['path']),'superseded-historical-html-png',epoch='notification');need(got['bytes']==r['bytes'] and got['sha256']==r['sha256'],'Initial UI body differs');files.append(got)
    for mode in ('before','menu-surface','intrinsic-menu','joint-layout-focus'):
        x=json.loads(small(DIAG/mode/'desktop-results.json'))
        for state in x['states']:
            for name,expected in [(state['screenshot'],state['screenshotSHA256'])]+[(a['screenshot'],a['screenshotSHA256']) for a in state['audits']]:
                got=row(DIAG/mode/literal(name),'superseded-historical-html-png',epoch='notification');need(got['sha256']==expected,'Diagnostic body differs');files.append(got)
    latest_record=json.loads(small(LATEST/'result.json'))
    for command in latest_record['commands']:
        if command['argv'][0]=='git' and 'archive' in command['argv']:
            item=row(LATEST/literal(command['stdout']['path']),'redundant-binary-git-archive-stdout',epoch='notification-final')
            need(item['sha256']==command['stdout']['sha256'] and item['bytes']==command['stdout']['bytes'],'Latest redundant Git archive differs from original history');files.append(item)
    need(len({r['path'] for r in files})==len(files),'Duplicate exact retention path')
    need(not any((Path(r['path']).is_relative_to(LATEST) and r['category']!='redundant-binary-git-archive-stdout') or Path(r['path']).is_relative_to(LATEST_UI) for r in files),'Latest setup/UI cannot be a target')
    latest_result=small(LATEST/'result.json');lifecycle(json.loads(latest_result));latest_UI=small(LATEST_UI/'result.json')
    need(json.loads(latest_UI)['status']=='PASS','Latest real UI successor is not complete')
    return dict(schema=1,status='PLAN_ONLY_NOT_ARCHIVE_CUSTODY_VERIFIED_NOT_EXECUTED',files=sorted(files,key=lambda r:r['path']),directories=sorted(dirs,key=lambda r:(-len(Path(r['path']).parts),r['path'])),epochs=epochs,already_unavailable=already,logical_bytes_candidate=sum(r['bytes'] for r in files),latest=dict(native_path=str(LATEST),native_result_sha256=digest(latest_result),UI_path=str(LATEST_UI),UI_result_sha256=digest(latest_UI),preserve_source_binaries_logs_and_UI_except_redundant_Git_archive_stdout=True),custody_required='Root must bind both canonical accepted keepers and verify all archived bytes/stat/aliases before any separate deletion. This script has no deletion mode.',preserved=['All branches/worktrees/unmerged source packets and original baselines','All canonical keepers, cached dependencies, raw logs/JSON/reviews and source packet files','Latest e900 source/binaries/logs/fullUI artifacts; only its redundant full Git tar stdout may be pruned after canonical custody','Nonempty socket directories with cleanup/ready/stop-request receipts','All Teacher/programme/unrelated owner work'],physical_deletion_performed=False)


def scalar_values(v):
    if isinstance(v,dict):
        for x in v.values():yield from scalar_values(x)
    elif isinstance(v,list):
        for x in v:yield from scalar_values(x)
    else:yield v


def keeper(spec):
    path=Path(spec['path']);need(path.parent==REPO/'docs/reviews' and path.name in ('gui-native-group-detail','gui-native-notification-preferences'),'Exact canonical keeper directory required')
    raw=small(path/'archive-manifest.json');need(digest(raw)==spec['archive_manifest_sha256'],'Canonical archive manifest differs');manifest=json.loads(raw)
    archive_row=row(path/'evidence.tar.gz','canonical-archive');need(archive_row['sha256']==spec['archive_sha256'],'Canonical archive differs')
    selection_raw=small(path/'selection.json');need(digest(selection_raw)==spec['selection_sha256'],'Canonical selection differs');selection=json.loads(selection_raw)
    needed={prefix+name for _,_,_,prefix in EPOCHS for name in ('result.json','source-manifest.json')};held={}
    with tarfile.open(path/'evidence.tar.gz','r:gz') as archive:
        members=archive.getmembers();need([m.name for m in members]==[r['member'] for r in manifest],'Canonical archive full member inventory differs')
        for member,expected in zip(members,manifest):
            literal(member.name);need(member.isfile() and not member.issym() and member.size==expected['bytes'] and member.mode==expected['mode'] and member.uid==expected['uid'] and member.gid==expected['gid'] and int(Decimal(member.pax_headers['mtime'])*1_000_000_000)==expected['mtime_ns'],'Canonical archive member stat differs')
            need(0<=member.size<=64<<20,'Canonical member exceeds bounded collection payload limit')
            stream=archive.extractfile(member);need(stream is not None,'Canonical body missing');body=stream.read(member.size+1);need(len(body)==member.size and digest(body)==expected['sha256'],'Canonical archive member byte readback differs')
            if member.name in needed:held[member.name]=json.loads(body)
            if member.name=='selection.json':need(body==selection_raw,'Outer/archived selection bytes differ')
    for filename,key in (('keeper-review.json','keeper_review_sha256'),('acceptance.json','acceptance_sha256')):
        review_raw=small(path/filename);need(digest(review_raw)==spec[key],'Canonical independent custody/feature receipt differs');review=json.loads(review_raw)
        need(str(review.get('verdict','')).startswith('ACCEPT_') and review.get('findings')==[] and spec['archive_sha256'] in list(scalar_values(review)),'Independent canonical archive custody/feature acceptance missing')
    return dict(manifest={r['member']:r for r in manifest},selection=selection,held=held,archive_sha256=spec['archive_sha256'])


def allowed_target(r):
    path=Path(r['path']);category=r['category']
    if r.get('epoch')=='notification-final':return category=='redundant-binary-git-archive-stdout' and path==LATEST/'proof/command-006.stdout'
    for keeper,run,_,_ in EPOCHS:
        if r.get('epoch')!=keeper:continue
        if category=='superseded-generated-source':return path==run/'source'/literal(r['relative'])
        if category=='superseded-generated-binary':return path.parent==run/'binaries' and path.name in {v+'.test' for v in ('web','app','accounts','recommendations','social','messaging')}|{'reference-bootstrap'}
        if category=='redundant-binary-git-archive-stdout':return path==run/'proof/command-006.stdout'
    if category=='superseded-historical-html-png' and r.get('epoch')=='notification':
        return path.suffix in ('.html','.png') and (path.is_relative_to(OLD_UI) or any(path.is_relative_to(DIAG/v) for v in ('before','menu-surface','intrinsic-menu','joint-layout-focus')))
    return False


def allowed_directory(d):
    path=Path(d['path'])
    return any(path.is_relative_to(run/'source') or path==run/'binaries' or path in (run/'host-tmp',run/'test-tmp') for _,run,_,_ in EPOCHS)


def verify(plan,binding):
    need(binding.get('status')=='BOUND_CANONICAL_KEEPERS_ACCEPTED','Canonical custody is unbound')
    need(len({r['path'] for r in plan['files']})==len(plan['files']) and all(allowed_target(r) for r in plan['files']) and all(allowed_directory(d) for d in plan['directories']),'Retention target outside exact owned scope')
    keepers={name:keeper(binding[name]) for name in ('group-detail','notification')}
    for epoch in plan['epochs']:
        k=keepers[epoch['keeper']];prefix=epoch['keeper_prefix'];result=k['held'][prefix+'result.json'];source_rows=k['held'][prefix+'source-manifest.json']
        need(k['manifest'][prefix+'result.json']['sha256']==epoch['result_sha256'] and k['manifest'][prefix+'source-manifest.json']['sha256']==epoch['source_manifest_sha256'],'Archived old native/source manifest differs')
        lifecycle(result);subprocess.check_call(['git','-C',str(REPO),'cat-file','-e',epoch['source']+'^{commit}'])
        lookup={r['path']:r for r in source_rows};targets=[r for r in plan['files'] if r['epoch']==epoch['keeper'] and r['category']=='superseded-generated-source'];need({r['relative'] for r in targets}==set(lookup),'Complete generated-source plan/keeper inventory differs')
        for r in targets:need(r['sha256']==lookup[r['relative']]['sha256'] and r['bytes']==lookup[r['relative']]['bytes'],'Generated source lacks archived manifest identity')
        for r in [r for r in plan['files'] if r['epoch']==epoch['keeper'] and r['category']=='superseded-generated-binary']:
            name=Path(r['path']).name;expected=result['reference_bootstrap_binary']['sha256'] if name=='reference-bootstrap' else result['lanes'][Path(name).stem]['binary']['sha256'];need(r['sha256']==expected,'Generated binary lacks archived identity')
        for r in [r for r in plan['files'] if r['epoch']==epoch['keeper'] and r['category']=='redundant-binary-git-archive-stdout']:need(r['sha256']==result['git_archive']['sha256'] and r['bytes']==result['git_archive']['bytes'],'Redundant Git archive lacks original history')
    final_native=keepers['notification']['held']['evidence/native-final/result.json']
    need(keepers['notification']['manifest']['evidence/native-final/result.json']['sha256']==plan['latest']['native_result_sha256'],'Latest native result lacks canonical custody')
    subprocess.check_call(['git','-C',str(REPO),'cat-file','-e',final_native['source']+'^{commit}'])
    for target in [r for r in plan['files'] if r['epoch']=='notification-final']:
        need(target['category']=='redundant-binary-git-archive-stdout' and target['sha256']==final_native['git_archive']['sha256'] and target['bytes']==final_native['git_archive']['bytes'],'Latest redundant Git archive lacks canonical digest/source history')
    notification=keepers['notification'];selection=notification['selection'];physical={r['source']:r for r in selection['files']};aliases={r['source']:r for r in selection['content_aliases']}
    for old in [r for r in plan['files'] if r['category']=='superseded-historical-html-png']:
        source=old['path'];need((source in physical)!=(source in aliases),'Historical content lacks unique canonical source/alias record');saved=physical.get(source,aliases.get(source));member=saved.get('member',saved.get('content_member'));stored=notification['manifest'][member]
        need(all(old[k]==saved[k] for k in ('bytes','sha256','mode','uid','gid','mtime_ns')) and stored['sha256']==old['sha256'] and stored['bytes']==old['bytes'],'Historical exact content/original stat differs from canonical custody')
    for r in plan['files']:need(row(Path(r['path']),r['category'],**{k:r[k] for k in ('epoch','relative') if k in r})==r,'Exact current target inode/stat/bytes differ')
    for d in plan['directories']:need(directory(Path(d['path']),d['category'])==d,'Exact current generated directory inventory/stat differs')
    need(digest(small(LATEST/'result.json'))==plan['latest']['native_result_sha256'] and digest(small(LATEST_UI/'result.json'))==plan['latest']['UI_result_sha256'],'Latest rolling successor changed')
    return dict(schema=1,status='READ_ONLY_RETENTION_DRY_RUN_CUSTODY_VERIFIED_NO_DELETION',target_files=len(plan['files']),target_directories=len(plan['directories']),logical_bytes_candidate=plan['logical_bytes_candidate'],full_canonical_archives_readback=True,current_target_hash_stat_inode_ownership_verified=True,all_source_commits_available=True,all_historical_bodies_resolve_to_exact_canonical_bytes=True,latest_setup_preserved=True,physical_deletion_performed=False)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('mode',choices=('inventory','verify'));p.add_argument('--plan',type=Path);p.add_argument('--custody',type=Path);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    need(a.output.parent==HERE and not a.output.exists(),'Fresh owned output required')
    if a.mode=='inventory':value=inventory()
    else:
        need(a.plan is not None and a.plan.parent==HERE and a.custody is not None and a.custody.parent==HERE,'Explicit reviewed plan/custody required');value=verify(json.loads(small(a.plan)),json.loads(small(a.custody)))
    with a.output.open('x') as f:json.dump(value,f,indent=2);f.write('\n')
    print(json.dumps({k:v for k,v in value.items() if k not in ('files','directories','epochs','preserved','already_unavailable')}))


if __name__=='__main__':main()
