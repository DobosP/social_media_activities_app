"""Execute only the reviewed exact owned transient manifest after full custody."""
import argparse,hashlib,importlib.util,json,os,subprocess
from pathlib import Path
HERE=Path(__file__).resolve().parent
PLAN_SHA='a5aeb91205eeb924d5162a91605ba41ff65c2e7032b1ad88f4a73db3a72e206a'
HELPER=Path('/home/dobo/work/_temp/feat__gui-app-migration-a/social-family/group-detail-keeper/retention/prune.py')
HELPER_SHA='7f3879d3fce07ccfbfb5c65c77dcdf7d0b617ff7913f728f6a365e8cd2a96327'
VERIFIER_SHA='7df0cfdf3042116f268506d93c817c97bf319b7b1a037cac1fba533d8e0e1fcc'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def module(name,path,expected):
 assert path.resolve()==path and sha(path)==expected
 spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value
p=argparse.ArgumentParser();p.add_argument('--execute',action='store_true');p.add_argument('--receipt',type=Path,required=True);a=p.parse_args()
assert a.receipt.parent==HERE and not a.receipt.exists() and not a.receipt.is_symlink()
assert sha(HERE/'retention-plan.json')==PLAN_SHA
v=module('notification_retention_verifier',HERE/'retention.py',VERIFIER_SHA);h=module('prior_reviewed_exact_removal_helpers',HELPER,HELPER_SHA)
plan=json.loads(v.small(HERE/'retention-plan.json'));custody=json.loads(v.small(HERE/'custody.json'))
check=v.verify(plan,custody)
assert check['target_files']==4511 and check['target_directories']==482 and check['logical_bytes_candidate']==559474592
cids=set();names=set()
for run in [Path(e['path']) for e in plan['epochs']]+[v.LATEST]:
 x=json.loads(v.small(run/'result.json'));v.lifecycle(x)
 cids.update(c['cid']for c in x['cleanup'].values())
 for c in x['commands']:
  argv=c['argv']
  if len(argv)>1 and argv[:2]==['docker','create'] and '--name'in argv:names.add(argv[argv.index('--name')+1])
assert len(cids)==len(names)==39
observed=subprocess.check_output(['docker','container','ls','-a','--no-trunc','--format','{{json .}}'])
for raw in observed.splitlines():
 x=json.loads(raw);assert x['ID']not in cids and not(set(x['Names'].split(','))&names)
# Both full source manifests, every target inode/hash/stat and complete directory
# inventory have already been verified before any removal; per-file checks repeat.
result={'schema':1,'status':'VERIFIED_NOT_EXECUTED','executed':False,'manifest_sha256':PLAN_SHA,'verifier_sha256':VERIFIER_SHA,'helper_sha256':HELPER_SHA,'custody_sha256':sha(HERE/'custody.json'),'all39owned_CIDs_and_names_currently_absent':True,'deleted':[],'removed_directories':[],'logical_bytes_deleted':0,'preserved':plan['preserved']}
try:
 if a.execute:
  result.update(status='PARTIAL_RETAIN_EXACT_DELETED_RECORDS',executed=True)
  for row in plan['files']:
   h.file_check(row);path=Path(row['path']);fd=h.parent_fd(path)
   try:
    h.same(os.stat(path.name,dir_fd=fd,follow_symlinks=False),row);os.unlink(path.name,dir_fd=fd)
   finally:os.close(fd)
   result['deleted'].append({k:row[k]for k in ('path','bytes','sha256','category')});result['logical_bytes_deleted']+=row['bytes']
  for row in plan['directories']:
   h.directory_check(row,removing=True);path=Path(row['path']);fd=h.parent_fd(path)
   try:os.rmdir(path.name,dir_fd=fd)
   finally:os.close(fd)
   result['removed_directories'].append(row['path'])
  assert all(not Path(row['path']).exists()for row in plan['files']+plan['directories'])
  assert sha(v.LATEST/'result.json')==plan['latest']['native_result_sha256'] and sha(v.LATEST_UI/'result.json')==plan['latest']['UI_result_sha256']
  assert (v.LATEST/'source').is_dir()and(v.LATEST/'binaries').is_dir()
  result['status']='COMPLETE_EXACT_OWNED_TRANSIENT_RETENTION'
finally:
 result['raw_deleted_paths_unavailable']=bool(result['deleted'])
 result['retained_history_semantics']='Deleted raw source/binary/Git-tar/HTML/PNG paths are unavailable. Exact source Git refs and compact manifests/results/logs/reviews remain. Historical image/body bytes survive only in verified canonical physical members or exact aliases; no claim of available deleted raw trees.'
 with a.receipt.open('x')as f:json.dump(result,f,separators=(',',':'));f.write('\n')
 print(json.dumps({'status':result['status'],'deleted':len(result['deleted']),'logical_bytes_deleted':result['logical_bytes_deleted']}))
