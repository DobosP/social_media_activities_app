# Native notification preferences — collected candidate

Exact source `e900960d50beed03ef387159da0e6d903ec5bf9a`. Independent keeper/feature acceptance remains pending.

Complete affected-six, actual desktop/no-JS, capture, benchmark and separate history are bound in result.json and selection.json. Benchmark is descriptive warmed body rendering only; no HTTP/DB/throughput/general-speedup claim.

Original failed histories remain failed. Aliases preserve original metadata and exact content, not independent tar bodies or accepted epoch identity. Excluded full Git archives retain original digest/tree/manifest history. No raw output was deleted by this collector.

Reproduce using [committed methods](../../../tools/gui-native-notification-preferences/README.md) and the exact clean qualified checkout; this archive is not a full source/dependency distribution. Canonical prior Group-detail baseline keeper remains a pinned dependency.

No all21/current-image/main/milestone/production/mobile/provider/government or real-child activation.
