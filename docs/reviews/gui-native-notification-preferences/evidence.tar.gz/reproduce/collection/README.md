# Notification keeper closure preparation

This is a scratch-only collector proposal. No archive, deletion, feature acceptance, milestone or owning-repository edit has been performed by this preparation task.

`keeper.py` carries forward the Group-detail collector’s bounded canonical regular-file reads, exact byte/stat pins, clean Git/source fence, explicit selection approval, nanosecond-metadata tar custody and complete archive readback. It independently rechecks complete native inventories, all UI/capture/artifact joins, strict whole-document Axe, raw benchmark groups and original failure dispositions. History aliases preserve exact bytes plus original metadata; they are not separate tar bodies or equal target metadata.

`config.json` pins known initial7819 PG PASS, initial UI FAIL, source/repair contracts and all five causal diagnostic reports. The joint diagnostic must remain FAIL with exactly12 stylesheet-substitution guards. Source packets/history, cheap-test failures, missing-scratch refusal, Root visual inspection and independent source reviews are selected; full proposed/before/export/binary/cache/profile trees are excluded. Both native Git-archive stdout files are excluded without being opened; their original recorded digests/tree/manifest remain.

All final UI artifacts stay physical. Only historical HTML/PNG bodies are deduplicated by full byte equality after hash/length match; every original path/mode/UID/GID/nsmtime remains in content-aliases.json. All raw nonbinary native proof streams, original result inventories, command receipts, source manifests, CIDs and full diagnostic JSON/geometry remain.

`final-binding.observed.json` records actual final result identities, with independent actual-result review slots deliberately null. This file cannot admit final results. Root must create `final-binding.json` from that file after actual PG and UI/capture/benchmark reviews are complete, set status `BOUND_ACTUAL_RESULTS_PENDING_KEEPER_REVIEW`, and provide each exact review path/SHA. Each review must have an ACCEPT_ verdict, empty findings and the exact final source/result digest as JSON values. No future result or acceptance is prefilled.

Commands (run from any directory, with explicit absolute paths):

```sh
python3 -I keeper.py inventory --output /absolute/notification-closure-preparation/history-inventory.json
python3 -I keeper.py prepare --binding /absolute/notification-closure-preparation/final-binding.json --output /absolute/notification-closure-preparation/selection.json
python3 -I keeper.py collect --binding /absolute/notification-closure-preparation/final-binding.json --selection /absolute/notification-closure-preparation/selection.json --approved-selection-sha256 <Root-reviewed-selection-SHA> --output /absolute/notification-closure-preparation/candidate-e900
```

`prepare` validates actuals/reviews and writes a selection only. `collect` rebuilds/fences the exact selection, refuses any change from Root’s approved hash, creates one fresh output, checks free disk, archives/readbacks every member and rereads every source/alias. All eight outer keeper files are generated; status remains pending independent keeper review. Collector never launches Go/browser/PG/container/network processes or deletes inputs. Git is read-only.

Before use, independent review must inspect this collector/config/schema and complete history/alias selection. After collection, an independent reviewer must verify the archive, all epochs, aliases, source joins, actual reviews and cautious benchmark wording. Root then records separate feature acceptance, promotes an immutable copy, performs separately reviewed retention only after custody, updates metadata and obtains publication review. Never prune unmerged source packets/branches, canonical keepers, original baselines, latest rolling setup or another owner’s work.

The canonical Group-detail baseline keeper remains a pinned dependency, not duplicated. The archive is not a complete source/dependency distribution; reproduction requires the exact clean repository and installed tools. No all21/current-image/main/milestone/production/mobile/provider/government/real-child activation claim follows.
