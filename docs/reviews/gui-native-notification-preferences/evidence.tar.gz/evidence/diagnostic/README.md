# Notification browser diagnostic

Source `7819bdfdb6ae001a83c7a05c6ab1f8d09431e4e4`. Scratch only; no application edits or qualification claim.

All original six JS/six no-JS fixtures, keyboard checks, natural scroll positions and Axe rules remain. Geometry records include text rectangles, computed colors, menu/form rectangles and hit-test stacks. Originals remain untouched.

The before run reproduces six color-contrast incomplete results. `candidate-menu-surface.css` is a failed diagnostic: explicit opaque link surfaces preserve geometry but do not clear them. Its raw report is retained.

`candidate-intrinsic-menu.css` gives the new page’s desktop dropdown intrinsic width with a viewport cap. The RO panel grows220→303.14px; overview label fits one line. All18 Axe audits have zero violations/incomplete (408 pass occurrences). Header/form geometry and natural scroll remain identical. Six separate save-focus failures and12 exact CSS substitution failures remain, so its report correctly remains FAIL.

The target was never visually occluded in measured open modes. This is evidence for a scoped presentation correction on these fixtures, not a claim about the internal Axe algorithm or mobile layout.

`causal-result.json` hashes the raw results and records each comparison. It separately records checkboxes orphaned by global flex wrapping. Root requested a joint scoped nowrap/input-flex/text-min-width candidate; that later diagnostic will preserve natural changed row heights and scroll.

Initial Chrome launch failed before any rendered state because the temporary socket path was too long. Failure and verified owned-profile cleanup are retained. Successful diagnostics use short owned `TMPDIR=/home/dobo/work/_temp/np-geom`.

Reproduction uses the committed desktop QA invocation with this directory’s diagnostic Node copy, original failed fixture directory and a fresh output directory; candidate comparison adds `--diagnostic-css` with the candidate path. No audit rules or original guards are excluded.

The final joint diagnostic (`joint-layout-focus`) uses Root keyboard patchf625 plus `candidate-combined-layout.css`. All6 JS/6 no-JS states preserve original semantics; all264 checkbox rows stay with their text and preserve intrinsic checkbox sizes. All12 Save focus records show active=true, focus-visible=true and solid3px outline. All18 Axe audits pass (408 occurrences), all25 prior bodies match, and only the12 intentional stylesheet-substitution guards fail. Natural row reflow changes scroll positions; no normalization is applied. See `joint-causal-result.json` and raw geometry/hit-test report.
