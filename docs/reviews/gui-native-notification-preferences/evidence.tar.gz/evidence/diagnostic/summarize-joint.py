from pathlib import Path
import hashlib,json,subprocess
p=Path(__file__).resolve().parent
sha=lambda x:hashlib.sha256(x).hexdigest()
b=json.loads((p/'before/desktop-results.json').read_text());j=json.loads((p/'joint-layout-focus/desktop-results.json').read_text())
assert j['sourceUnchanged'] and j['status']=='fail' and len(j['states'])==len(j['noJavaScriptStates'])==6
assert len(j['failures'])==12 and all('exact positive current asset missing/different /static/css/notification-preferences-native.css' in x for x in j['failures'])
rows=[]
for s in j['states']+j['noJavaScriptStates']:
 layout=s['presentationLayout'];assert len(layout)==22
 assert all(r['flexWrap']=='nowrap' and r['textMinWidth']=='0px' and r['inputFlex']=='0 0 auto' for r in layout)
 assert all(r['input']['bottom']>=r['text']['top'] and r['input']['top']<=r['text']['bottom'] and r['text']['right']<=r['row']['right']+.05 and r['text']['left']>=r['input']['right'] for r in layout)
 save=[r['saveButtonKeyboardFocus'] for r in s['keyboard'] if 'saveButtonKeyboardFocus' in r];assert len(save)==1
 assert save[0]=={'active':True,'focusVisible':True,'outlineStyle':'solid','outlineWidth':'3px'}
 assert s['metrics']['overflow']==0
 rows.append({'state':s['name'],'javaScriptEnabled':s['javaScriptEnabled'],'choice_rows':len(layout),'orphaned_checkboxes':0,'all_text_within_row_width':True,'save_focus':save[0],'original_semantics_checks_retained':True})
changes=[]
for bs,js in zip(b['states'],j['states']):
 assert all(r['input']['rect']['width']==n['input']['width'] and r['input']['rect']['height']==n['input']['height'] for r,n in zip(bs['audits'][0]['geometry']['choiceRows'],js['presentationLayout']))
 for ba,ja in zip(bs['audits'],js['audits']):
  assert not ja['axe']['incomplete'] and not ja['axe']['violations']
  assert ba['geometry']['header']==ja['geometry']['header']
  if ja['mode']!='header-closed':assert all(h['stack'][0]['href']=='/you/' for h in ja['geometry']['hitTests'])
  changes.append({'state':js['name'],'mode':ja['mode'],'before_scroll':ba['geometry']['scroll'],'after_scroll':ja['geometry']['scroll'],'header_geometry_and_color_identical':True,'checkbox_intrinsic_sizes_identical':True,'incomplete':0,'violations':0,'open_mode_target_hit_tests_all_target_first':True if ja['mode']!='header-closed' else None})
assert j['ownership']['serverStopped'] and all(r['closed'] and r['removed'] for r in j['ownership']['profiles'])
repo='/home/dobo/work/_worktrees/social_media_activities_app/feat__gui-app-migration-a'
result={'schema':1,'status':'JOINT_CAUSAL_DIAGNOSTIC_ONLY_NOT_QUALIFICATION','source':'7819bdfdb6ae001a83c7a05c6ab1f8d09431e4e4','source_clean':not subprocess.check_output(['git','-C',repo,'status','--porcelain']).strip(),'report_path':str(p/'joint-layout-focus/desktop-results.json'),'report_sha256':sha((p/'joint-layout-focus/desktop-results.json').read_bytes()),'combined_css_sha256':sha((p/'candidate-combined-layout.css').read_bytes()),'combined_patch_sha256':sha((p/'proposed-combined.patch').read_bytes()),'source_proposal_sha256':sha((p/'source-proposal.json').read_bytes()),'root_keyboard_patch_sha256':'f6258cebe200f8fe52659d6c08b80f4f11b22fe70f7f06bdba299a9cced6218d','joint_diagnostic_sha256':sha((p/'desktop-diagnostic-joint.mjs').read_bytes()),'matrix':rows,'audit_comparison':changes,'audits':18,'axe_pass_occurrences':sum(len(a['axe']['passes']) for s in j['states'] for a in s['audits']),'violations':0,'incomplete':0,'prior_body_equality':len(j['previousBodyEquality']),'requests':len(j['requests']),'asset_responses':len(j['assetResponses']),'only_expected_exact_asset_failures':j['failures'],'source_inputs_unchanged':True,'cleanup':j['ownership'],'visual_review':['Viewed full-page some-ro and natural all-open unassigned-en PNG; labels and checkboxes remain grouped; no clipping at tested1280x720.','Intrinsic desktop dropdown fits RO overview in one line. Header/form defaults and text retain existing rendering; source strings and values preserved by original checks.'],'limits':['Candidate is intentionally substituted behind original served stylesheet URL; all12 original exact CSS asset checks correctly fail, so overall FAIL retained.','Natural row reflow changes scroll coordinates in4 states. No scroll normalization, fixture hiding, Axe exclusion, contrast exception or original assertion weakening.','Existing source/default partial translations remain. No translation completeness, mobile, authenticated browser, delivery, PG or feature acceptance claim.']}
(p/'joint-causal-result.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'joint_causal_result_sha256':sha((p/'joint-causal-result.json').read_bytes()),'source_clean':result['source_clean'],'audits':result['audits'],'axe_pass_occurrences':result['axe_pass_occurrences'],'prior_bodies':result['prior_body_equality']},indent=2))
