import pathlib,json,hashlib,re,subprocess,collections,stat
p=pathlib.Path('/home/dobo/work/_temp/feat__gui-app-migration-a/social-family/notification-preferences-implementation')
root=p.parent
repo=pathlib.Path('/home/dobo/work/_worktrees/social_media_activities_app/feat__gui-app-migration-a')
base='99b88a446031cdf3d99bd04bdfcb41706d2a6aab'
findings=[]
def h(raw):return hashlib.sha256(raw).hexdigest()
def need(ok,message):
 if not ok:findings.append(message)
def git(*args):return subprocess.check_output(['git','-C',str(repo),*args])
def load(file):return json.loads(file.read_bytes())
def reconstruct(patch):
 lines=patch.decode().splitlines(keepends=True);i=0;parts={}
 while i<len(lines):
  assert lines[i].startswith('--- ')
  oldname=lines[i][4:].strip();i+=1
  assert lines[i].startswith('+++ b/')
  name=lines[i][6:].strip();i+=1
  old=b'' if oldname=='/dev/null' else git('show',base+':'+name)
  oldlines=old.decode().splitlines(keepends=True);pos=0;output=[]
  while i<len(lines)and not lines[i].startswith('--- '):
   match=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',lines[i]);assert match;i+=1
   start,n,_,k=[int(match[x]) if match[x] is not None else 1 for x in range(1,5)]
   start=max(start-1,0);output+=oldlines[pos:start];pos=start;oldn=newn=0
   while i<len(lines)and not lines[i].startswith(('--- ','@@ ')):
    line=lines[i];i+=1;assert line[0]in' +-'
    if line[0]in' -':assert oldlines[pos]==line[1:];pos+=1;oldn+=1
    if line[0]in' +':output.append(line[1:]);newn+=1
   assert (oldn,newn)==(n,k)
  output+=oldlines[pos:];parts[name]=''.join(output).encode()
 return parts
manifest=load(p/'manifest.json');proof=load(p/'source-proof.json')
need(git('rev-parse','HEAD').decode().strip()==base and not git('status','--porcelain'),'exact clean published closing99 source')
need(h((p/'proposed.patch').read_bytes())==proof['patch_sha256']=='e627e6657bf4b5b4711a3b87c2de7be976df71472d03683ee013d7926d5b834f','frozen V2 wholepatch')
need(h((p/'manifest.json').read_bytes())==proof['manifest_sha256']=='f22901d906825aee4f096f5e889edb9be9cef8990b2cef857fe1e4e6873ed89c','frozen V2 wholemanifest')
need(h((p/'source-proof.json').read_bytes())=='dd209b53a440fae6ee093e4b36a382ffbfa66361240a47467bccb4ffeae62ab2'and proof['paths']==15 and 'Entire15pathpacket'in proof['qualification'],'corrected proof-only15path precision')
parts=reconstruct((p/'proposed.patch').read_bytes());paths={row['path']for row in manifest}
need(len(parts)==len(paths)==15 and set(parts)==paths=={f.relative_to(p/'proposed').as_posix()for f in(p/'proposed').rglob('*')if f.is_file()},'exact15 postimages')
existing=[]
for row in manifest:
 name=row['path'];raw=parts[name]
 need(raw==(p/'proposed'/name).read_bytes()and len(raw)==row['after_bytes']and h(raw)==row['after_sha256'],'wholepatch/postimage hash '+name)
 if row['kind']=='existing':
  old=git('show',base+':'+name);need(old==(repo/name).read_bytes()and h(old)==row['before_sha256']and len(old)==row['before_bytes'],'complete originalpreimage '+name);existing.append(name)
 else:need(not(repo/name).exists()and row['before_bytes']==0 and row['before_sha256']is None,'newsource path absent '+name)
need(len(existing)==6,'six existing nine additive paths')
# Frozen V1 source remains reproducible from its original patch; production stayed exact.
oldpatch=p/'history-product-v1/proposed.patch';oldmanifest=p/'history-product-v1/manifest.json';oldproof=p/'history-product-v1/source-proof.json'
need(h(oldpatch.read_bytes())=='6af6f36c684584a325760c2d091b15cde7512bfb3d6ec66a4695231925114031'and h(oldmanifest.read_bytes())=='4e9de1ca14e3e3017b30f3eaf6c005524c02bc342e9f9543bd8d6b7213b94d96'and h(oldproof.read_bytes())=='f8807dd3cf22ab328c99f95091ef6f6cd1d4cf5b47128314e59c622df5203631','immutable V1history')
v1=reconstruct(oldpatch.read_bytes())
for name in ['services/server/internal/app/notification_preferences_native_http_test.go','services/server/internal/web/notification_preferences_native.go','services/server/internal/web/notification_preferences_native_test.go','services/server/internal/web/pages/notification-preferences.gohtml','services/server/internal/web/renderer.go','static/css/notification-preferences-native.css']:
 need(parts[name]==v1[name],'strictproduction/pure/App/CSS unchanged fromV1 '+name)
relations=load(p/'custody-relations.json');need(len(relations)==4 and h((p/'custody-relations.json').read_bytes())==proof['custody_relations_sha256']=='74daaa363cabf0ebaf9e79a31310c05fd5f4f69f7cda7fa9a5d22a7f87523143','four closed source relations')
for row in relations:
 name=row['path'];raw=parts[name];before=row['before'].encode();after=row['after'].encode();need(len(raw)==row['after_bytes']and h(raw)==row['after_sha256']and raw.count(after)==1,'strictcurrent relation '+name);old=raw.replace(after,before,1);need(old==git('show',base+':'+name)and len(old)==row['before_bytes']and h(old)==row['before_sha256'],'entire exactinverse '+name)
# The two remaining test adapter files recover only by exact declared additions.
name='services/server/internal/web/group_detail_custody_test.go';s=parts[name].decode()
for path in ['services/server/internal/web/renderer.go','services/server/internal/web/gui_public_get_walk_test.go']:
 block='\tvar notificationErr error\n\traw, notificationErr = notificationPreferencesPriorSource("'+path+'", raw)\n\tif notificationErr != nil {\n\t\treturn nil, notificationErr\n\t}\n';need(s.count(block)==1,'one retained prior-source adapter '+path);s=s.replace(block,'',1)
need(s.encode()==git('show',base+':'+name),'complete groupdetail control exactinverse')
name='services/server/internal/web/group_create_source_guard_test.go';s=parts[name].decode();block='\tif path == "services/server/internal/web/gui_preferences_layout_test.go" || path == "services/server/internal/web/gui_preferences_get_transport_test.go" {\n\t\tprevious, err = notificationPreferencesSourcePreimage(path, raw)\n\t\tif err != nil {\n\t\t\treturn guiG1Binding{}, err\n\t\t}\n\t\traw = previous\n\t}\n';need(s.count(block)==1,'one new physical source reader adapter');s=s.replace(block,'',1)
for helper in ['notificationPreferencesRendererPreimage','notificationPreferencesWalkerPreimage']:
 block='\t\traw, err = '+helper+'(raw)\n\t\tif err != nil {\n\t\t\treturn guiG1Binding{}, err\n\t\t}\n';need(s.count(block)==1,'one strict physicalreader '+helper);s=s.replace(block,'',1)
need(s.encode()==git('show',base+':'+name),'complete groupcreate reader exactinverse')
assertion_counts={}
for name,count in proof['original_assertion_lines_preserved'].items():
 old=git('show',base+':'+name).decode();new=parts[name].decode();lines=lambda text:[line for line in text.splitlines()if 't.Fatal' in line or 't.Error' in line];need(collections.Counter(lines(old))==collections.Counter(lines(new))and len(lines(old))==count,'everyoldassertionline/count '+name);assertion_counts[name]=len(lines(old))
need(sum(assertion_counts.values())==258,'all258 unchanged assertions')
# The whole old32-row repair function remains exact; source/data inversion replays its renderer chain.
walker=parts['services/server/internal/web/gui_public_get_walk_test.go'].decode();original=git('show',base+':services/server/internal/web/gui_public_get_walk_test.go').decode();first=original.index('func guiPublicGetRepairRows(');last=original.index('\n// guiPublicGetRowsPreimage',first);table=original[first:last];need(table in walker,'entire original32row function untouched')
pattern=r'path:\s*("(?:\\.|[^"\\])*")\s*,\s*beforeSHA:\s*("[0-9a-f]+")\s*,\s*afterSHA:\s*("[0-9a-f]+")\s*,\s*beforeBytes:\s*(\d+)\s*,\s*afterBytes:\s*(\d+)\s*,\s*before:\s*("(?:\\.|[^"\\])*"|`[^`]*`)\s*,\s*after:\s*("(?:\\.|[^"\\])*"|`[^`]*`)'
oldrows=[]
for match in re.finditer(pattern,table,re.S):
 vals=match.groups();oldrows.append(dict(path=json.loads(vals[0]),beforeSHA=json.loads(vals[1]),afterSHA=json.loads(vals[2]),beforeBytes=int(vals[3]),afterBytes=int(vals[4]),before=(vals[5][1:-1] if vals[5].startswith('`') else json.loads(vals[5])),after=(vals[6][1:-1] if vals[6].startswith('`') else json.loads(vals[6]))))
need(len(oldrows)==32,'all32literal rows independently decoded')
renderer=parts['services/server/internal/web/renderer.go'];rel=next(r for r in relations if r['path'].endswith('renderer.go'));raw=renderer.replace(rel['after'].encode(),rel['before'].encode(),1)
for row in oldrows:
 if row['path']!='services/server/internal/web/renderer.go':continue
 need(h(raw)==row['afterSHA']and len(raw)==row['afterBytes']and raw.count(row['after'].encode())==1,'retained exactrenderer afterimage');raw=raw.replace(row['after'].encode(),row['before'].encode(),1);need(h(raw)==row['beforeSHA']and len(raw)==row['beforeBytes'],'retained exactrenderer preimage')
need(len(raw)==5510 and h(raw)=='94f11a3f1849c919ba100c4ba68236263f71f07741006c1992dadc4020723e68','whole originalrenderer recovered after newest+32chain')
registry=repo/'services/server/internal/web/testdata/gui-preferences-get/registry.json';rr=load(registry);need(h(registry.read_bytes())=='9c863c11d8fc08379521cf08b8b004f01c823b81c6b4ee67b7f0899cbe52880a'and len(rr['Sources'])==138,'immutable registry138')
changed138=set(rr['Sources'])&paths;need(len(changed138)==3 and changed138<={r['path']for r in relations},'every changed physical preference source has one exact current bridge')
physical=[]
for name in sorted(rr['Sources']):
 file=repo/name;mode=file.stat().st_mode;raw=parts.get(name,file.read_bytes());physical.append({'path':name,'bytes':len(raw),'sha256':h(raw),'full_mode':mode})
need(len(physical)==138 and len({x['path']for x in physical})==138,'all138 physical tuples remain distinct; historical tuples not substituted')
# Exact current Server.page body must be recovered from the test-only clone with just two deltas.
source=(repo/'services/server/internal/web/server.go').read_bytes();start=source.index(b'func (s *Server) page(');end=source.index(b'\nfunc id(',start);page=source[start:end];need(h(page)=='547bc5c6506ce56ea98ccbe6efd5a5988eb4f640cd7087dd91a4e5d1c9b87498'and len(page)==2904,'exact current page547bc/2904')
reference=parts['services/server/internal/web/notification_preferences_reference_test.go'];a=reference.index(b'func notificationPreferencesFrozenReferencePage(');b=reference.index(b'\nfunc TestNativeNotificationPreferencesFrozenReference',a);clone=reference[a:b].strip();sig=b'func notificationPreferencesFrozenReferencePage(s *Server, w http.ResponseWriter, r *http.Request, name string) {';call=b'notificationPreferencesFrozenReferenceRender(s.Renderer, w, r, template, data)';need(clone.count(sig)==clone.count(call)==1,'one exact clone signature/finalcall');clone=clone.replace(sig,b'func (s *Server) page(w http.ResponseWriter, r *http.Request, name string) {',1).replace(call,b's.Renderer.Render(w, r, template, data)',1);need(clone==page.strip(),'entire source page clone differs only two exact deltas')
need(b'if name!="web/notification_preferences.html" { return renderer.Render(w,request,name,data) }'in reference and b'if r.Method==http.MethodGet && r.URL.Path==routeURL("notification_preferences")'in reference and b'next.ServeHTTP(w,r)'in reference,'onlynotification test-reference selectors; all other Render/mux delegate exact')
need(b'const notificationPreferencesFrozenAlias = "web/__notification_preferences_frozen_reference__.html"'in reference and b'return l.delegate.Get(name)'in reference and b'catalog:renderer.catalog'in reference,'privatealias existingloader/trace/catalog/currentcommonRenderer')
# Rebind partial source authority and original review without inventing transitive/full-runtime closure.
rebind=root/'next-social-notification-rebind';fp=load(rebind/'fingerprints.json');need(len(fp['files'])==32 and h((rebind/'contract.json').read_bytes())==proof['contract_sha256']=='93ded15b0686d88c72d6048efa3dfabd24a9cd4efcb5fd3c2fdaeae8da303135'and h((rebind/'fingerprints.json').read_bytes())==proof['fingerprints_sha256']=='69dae1566925fccecc8d5326b217bd7897030ce94e95a570e5000f6767311ba3','exact currentrebound contract/32references')
for row in fp['files']:need((repo/row['path']).read_bytes()==git('show',base+':'+row['path'])and len((repo/row['path']).read_bytes())==row['bytes']and h((repo/row['path']).read_bytes())==row['sha256'],'currentselected sourceauthority '+row['path'])
need(h((rebind/'prior-html-baseline.json').read_bytes())==proof['accepted_prior_body_baseline_sha256']=='635360ce3255659e7fa2fa920985df27bf868d5020741f8e29592b200915f360','accepted prior25body reference');need(h((root/'next-social-notification-contract/contract.json').read_bytes())=='0c600f60b9ee0cf8cc61958962d55350af815144201f042a6a1cef206b47e8bc'and h((root/'next-social-notification-contract-review/contract-review.json').read_bytes())=='0f457badc9612ace74c6bfda8e4d2912592761fcaa34f35cf442942af205b38c','original historicalcontract and independentreview untouched')
adr=load(p/'adr-namespace-audit.json');refs=git('for-each-ref','--format=%(refname)').decode().splitlines();need(set(adr['refs'])==set(refs)and len(refs)==34,'all34currentADRrefs')
for ref in refs:need(not any(pathlib.PurePosixPath(x).name.startswith('0064')for x in git('ls-tree','-r','--name-only',ref,'--','docs/adr').decode().splitlines()),'ADR0064free '+ref)
need(h((p/'app-proposal/independent-source-review.json').read_bytes())==proof['independent_App_review_sha256']=='fff44933076f75c96695cd160a6c9dd2297c64bc9db77aa47d88fbedd5c961cc'and h(parts['services/server/internal/app/notification_preferences_native_http_test.go'])=='4770fed142e8aa01a50dadffc603586614b8b43509ae659125e0b0a5ee583ea0','separate Appreview and our unchanged fullAppsource read')
# Original clinical/source assets and policy authorities cannot be modified by this packet.
need(not any(name.startswith(('services/authcore/','services/server/internal/accounts/','services/server/internal/platform/','apps/','templates/','locale/','frontend/'))or name in('services/server/go.mod','services/server/go.sum')for name in paths),'no forbidden policy/schema/authcore/dependency/originaltemplate/catalogue/frontend edits')
need(len(parts['static/css/notification-preferences-native.css'])==152,'only152B newscopedCSS')
need(git('rev-parse','HEAD').decode().strip()==base and not git('status','--porcelain'),'postreview unchanged clean source fence')
mechanical={'schema':1,'base':base,'patch_sha256':h((p/'proposed.patch').read_bytes()),'manifest_sha256':h((p/'manifest.json').read_bytes()),'source_proof_sha256':h((p/'source-proof.json').read_bytes()),'reconstructed_postimages':15,'existing_fullpreimages':6,'original_assertion_bearing_lines_including_quoted_source_controls':assertion_counts,'old_repair_rows':32,'original_renderer_preimage_sha256':h(raw) if False else '94f11a3f1849c919ba100c4ba68236263f71f07741006c1992dadc4020723e68','physical_preference_tuples':138,'physical_postimage_tuple_frame_sha256':h((json.dumps(physical,sort_keys=True,separators=(',',':'))+'\n').encode()),'exact_reference_page_source_sha256':h(page),'current_selected_source_references':32,'ADR_refs':34,'findings':findings};f=p/'independent-mechanical-bind-v2.json';f.write_text(json.dumps(mechanical,indent=2)+'\n');print(json.dumps({'path':str(f),'sha256':h(f.read_bytes()),'findings':findings},indent=2))
