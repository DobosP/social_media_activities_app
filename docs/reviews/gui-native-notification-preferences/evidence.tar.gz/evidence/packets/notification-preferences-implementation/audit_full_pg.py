import collections, hashlib, json, pathlib, re, stat, subprocess

repo=pathlib.Path('/home/dobo/work/_worktrees/social_media_activities_app/feat__gui-app-migration-a')
out=pathlib.Path('/home/dobo/work/_temp/feat__gui-app-migration-a/social-family/notification-preferences-implementation')
run=out.parent/'notification-preferences-pg-qa/run-7819bdfdb6ae-fa50086a-086a-47ff-884f-23360ccc2e6d'
sha='7819bdfdb6ae001a83c7a05c6ab1f8d09431e4e4'
base='99b88a446031cdf3d99bd04bdfcb41706d2a6aab'
j=json.loads((run/'result.json').read_bytes()); findings=[]
def need(ok,msg):
 if not ok:findings.append(msg)
def h(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(repo),*args])
need(git('rev-parse','HEAD').decode().strip()==sha and git('status','--porcelain')==b'', 'clean exact HEAD')
need(j['source']==sha and j['tree']==git('rev-parse',sha+'^{tree}').decode().strip() and j['method_pass'] is True and j['errors']==[], 'result source/pass')
rows=j['artifact_rows'];need(len(rows)==len({r['path'] for r in rows}),'artifact row uniqueness')
for r in rows:
 p=run/r['path'];raw=p.read_bytes();need(len(raw)==r['bytes'] and h(raw)==r['sha256'],'artifact hash '+r['path'])
source=json.loads((run/'source-manifest.json').read_bytes()); tracked={x.decode() for x in git('ls-files','-z').split(b'\0') if x}
need({r['path'] for r in source}==tracked,'source manifest exact tracked paths')
for r in source:
 for root in [repo,run/'source']:
  p=root/r['path']; raw=p.read_bytes();mode=stat.S_IMODE(p.stat().st_mode)
  mode_ok=(mode==r['mode']) if root==run/'source' else ((mode&0o111)==(r['mode']&0o111))
  need(len(raw)==r['bytes'] and h(raw)==r['sha256'] and mode_ok,'source bytes/Git-executable-mode '+str(p))
archive=git('archive','--format=tar',sha);need(len(archive)==j['git_archive']['bytes'] and h(archive)==j['git_archive']['sha256'],'recomputed Git archive')
for r in j['method_inputs']:
 raw=(repo/r['path']).read_bytes();need(len(raw)==r['bytes'] and h(raw)==r['sha256'],'method hash '+r['path'])
need('go1.27.1' in j['go']['version'] and h(pathlib.Path(j['go']['actual_executable']).read_bytes())==j['go']['sha256'],'actual installed Go identity')
expected=json.loads((repo/j['catalog_reference_source']['path']).read_bytes());expected={k:sorted(v,key=lambda r:r['id']) for k,v in expected.items()}
inventories={}; refs={}; inspections=[]
for lane,l in j['lanes'].items():
 events=[json.loads(x) for x in (run/f'proof/{lane}-test2json.stdout').read_bytes().splitlines()]
 runs=[e['Test'] for e in events if e['Action']=='run' and 'Test'in e]; passes=[e['Test'] for e in events if e['Action']=='pass' and 'Test'in e]
 listed=[x for x in (run/f'proof/{lane}-list.stdout').read_text().splitlines() if x.startswith('Test')]; roots=[x for x in runs if '/' not in x]
 need(set(e.get('Package') for e in events)=={'github.com/DobosP/social_media_activities_app/services/server/internal/'+lane},'package frames '+lane)
 need(collections.Counter(runs)==collections.Counter(passes) and len(runs)==len(set(runs)) and set(roots)==set(listed),'exact runs/passes/list '+lane)
 need(not any(e['Action']in('skip','fail') or '(cached)'in e.get('Output','') or 'DATA RACE'in e.get('Output','') for e in events),'no skip/fail/cache/race '+lane)
 need(sum(e['Action']=='pass'and 'Test'not in e for e in events)==1,'one package pass '+lane)
 need(l['tests']['identities']==runs and l['tests']['named_passes']==len(passes) and l['tests']['top_level']==len(roots),'result inventories '+lane)
 old=git('grep','-h','-E',r'^func Test[A-Za-z0-9_]+\(',base,'--',f'services/server/internal/{lane}/*_test.go').decode()
 oldnames=re.findall(r'^func (Test\w+)\(',old,re.M)
 need(set(oldnames)<=set(roots),'old declarations retained '+lane)
 native=(run/f'proof/{lane}-native.stdout').read_bytes();need(b'FAIL'not in native and b'DATA RACE'not in native and b'(cached)'not in native,'raw native pass '+lane)
 need((run/f'proof/{lane}-native.stderr').read_bytes()==b'','empty native stderr '+lane)
 binary=run/f'binaries/{lane}.test';need(h(binary.read_bytes())==l['binary']['sha256'],'binary hash '+lane)
 for point in ['before','after']:
  actual=json.loads((run/f'proof/{lane}-pg-{point}-reference.stdout').read_bytes());need(actual==expected,'canonical five datasets '+lane+' '+point)
  binding=json.loads((run/f'proof/{lane}-pg-{point}.stdout').read_bytes());need(binding=={k:v for k,v in l['pg_'+point].items() if k!='catalog_reference'},'raw pg binding '+lane+' '+point)
 need(l['pg_before']==l['pg_after'],'same before/after pg '+lane)
 r=j['retired_databases'][lane];need(r['database']==l['pg_after']['database'] and r['oid']==l['pg_after']['oid'],'retirement bound identity '+lane)
 for phase,key in [('before','before_drop'),('dropped','after_drop'),('checkpointed','after_checkpoint')]:
  catalog=json.loads((run/f'proof/{lane}-retire-{phase}-catalog.stdout').read_bytes())
  tmpfs=(run/f'proof/{lane}-retire-{phase}-tmpfs.stdout').read_text().splitlines()[1].split()
  catalog['tmpfs']={'bytes':int(tmpfs[0]),'used_bytes':int(tmpfs[1]),'available_bytes':int(tmpfs[2])}
  need(catalog==r[key],'raw retirement storage/catalog snapshot '+lane+' '+phase)
 need(any(d['name']==r['database']and d['oid']==r['oid']and d['client_connections']==0 for d in r['before_drop']['databases']),'retirement own idle identity '+lane)
 need(all(not any(d['name']==r['database']or d['oid']==r['oid'] for d in r[k]['databases']) for k in ['after_drop','after_checkpoint']),'retirement name/OID absence '+lane)
 need((run/f'proof/{lane}-retire-drop.stdout').read_text().strip()=='DROP DATABASE' and (run/f'proof/{lane}-retire-checkpoint.stdout').read_text().strip()=='CHECKPOINT','raw drop/checkpoint '+lane)
 inventories[lane]={'top_level':len(roots),'named_passes':len(passes),'retained_old_declarations':len(oldnames),'new_notification_roots':[x for x in roots if x.startswith('TestNativeNotification')]}
for c in j['commands']:
 a=c['argv']
 for stream in ['stdout','stderr']:
  r=c[stream]; raw=(run/r['path']).read_bytes();need(len(raw)==r['bytes'] and h(raw)==r['sha256'],'command raw '+r['path'])
 if len(a)>3 and a[:3]==['docker','container','inspect'] and c['exit']==0:
  raw=(run/c['stdout']['path']).read_bytes()
  try:s=json.loads(raw)
  except:continue
  if not isinstance(s,dict):continue
  isdb=s['id']==j['cleanup']['db']['cid'];need(s['memory']==(2147483648 if isdb else 3221225472) and s['cpus']==(1000000000 if isdb else 2000000000) and s['pids']==(256 if isdb else 512),'inspect resource caps')
  need(s['network']=='none' and not s['ports'] and s['readonly'] and not s['privileged'] and s['caps']==['ALL'] and s['security']==['no-new-privileges'] and not s['oom'],'inspect boundary/oom')
  if isdb:need(s['tmpfs']['/var/lib/postgresql/data']=='rw,nosuid,nodev,size=1g,uid=999,gid=999,mode=0700','fixed PG tmpfs')
  need(s['image']==(j['db_image'] if isdb else j['codec_image']['iid']),'exact recorded database/codec image identity')
  inspections.append(s)
for name,r in j['cleanup'].items():
 cid=(run/(name+'.cid')).read_text().strip();need(cid==r['cid']and r['id_absent'] and r['name_absent']and r['stopped'],'cleanup CID '+name)
 removes=[c for c in j['commands'] if c['argv']==['docker','container','rm',cid]];need(len(removes)==1 and removes[0]['exit']==0,'raw CID removal '+name)
 probes=[c for c in j['commands'] if c['argv'][:4]==['docker','container','ls','-aq'] and any(x=='id='+cid for x in c['argv'])];need(len(probes)==1 and probes[0]['exit']==0 and (run/probes[0]['stdout']['path']).read_bytes()==b'','raw CID absence '+name)
 names={s['name'] for s in inspections if s['id']==cid};need(len(names)==1,'observed unique container name '+name)
 actualname=next(iter(names));after_remove=j['commands'][j['commands'].index(removes[0])+1:];nameprobes=[c for c in after_remove if c['argv'][:4]==['docker','container','ls','-aq']and 'name=^'+actualname+'$'in c['argv']];need(len(nameprobes)==1 and nameprobes[0]['exit']==0 and (run/nameprobes[0]['stdout']['path']).read_bytes()==b'','raw name absence '+name)
for lane in j['lanes']:
 compiles=[c for c in j['commands'] if c['argv'][0]==j['go']['actual_executable'] and '-race'in c['argv'] and '-c'in c['argv'] and c['argv'][-1]=='./internal/'+lane]
 need(len(compiles)==1 and compiles[0]['exit']==0,'race compiled actual binary '+lane)
need(len(j['cleanup'])==13,'13 owned cleanup')
need(json.loads((run/'socket/pg-cleanup.json').read_bytes())==j['pg_cleanup']=={'owned_pid':24,'pid_and_socket_files_absent':1,'pid_probe_exit':1,'status_exit':3,'stop_exit':0},'raw PG cleanup')
log=(run/'proof/database-final-log.stdout').read_text();need(not re.search(r'PANIC|FATAL|No space left|database system was interrupted|automatic recovery|redo starts|invalid checkpoint',log,re.I),'PG raw panic/space/recovery')
need('database system is shut down'in log and 'pg_ctl: no server running'in log,'PG raw clean stop')
family=['services/server/internal/web/family.go','services/server/internal/web/family_copy.go','services/server/internal/web/family_render.go','services/server/internal/web/pages/family-shell.gohtml','services/server/internal/web/pages/family-wards.gohtml','services/server/internal/web/pages/family-guardianship.gohtml','static/css/family-native.css']
need(git('diff','--name-only',base,sha,'--',*family)==b'','seven family product sources exact')
changed=git('diff','--name-only',base,sha).decode().splitlines();need(not any(p.startswith('services/authcore/') or p.endswith(('go.mod','go.sum')) or '/migrations/'in p or p.startswith('locale/') or p.startswith('apps/') or p=='static/css/base.css' for p in changed),'no forbidden dependency/schema/authcore/catalogue/original template/baseCSS delta')
wanted={'web':(194,822),'app':(47,89),'accounts':(75,121),'messaging':(60,100),'recommendations':(8,24),'social':(52,123)}
need(set(inventories)==set(wanted) and all((inventories[k]['top_level'],inventories[k]['named_passes'])==v for k,v in wanted.items()),'six complete exact inventories')
need(sum(x['top_level']for x in inventories.values())==436 and sum(x['named_passes']for x in inventories.values())==1279,'all436 root and1279 named PASS')
need(h((repo/'static/css/group-detail-native.css').read_bytes())=='5c4f8e2e464e0073a36214c9b31f428a560ba02153d4b793846155f36ccfe4a0'and h((repo/'services/server/internal/app/group_detail_native_http_test.go').read_bytes())=='7933636fd95ac485169a1f44eaff28be9693471964d7c05c35a13ee9a06fabf4','final exact reviewed generic link cue and strict App expected CSS')
need(h((repo/'services/server/internal/web/group_detail_projection.go').read_bytes())=='50b56a0b825d3d836381c07d519f3b0e6fbca49acab724c746a6686cbf7e8913','reviewed typed-nil native repair exact')
need(j['method_sha256']=='24a62eb58c3feedd32721019c433a3f6d3140339c87f4e39338e60092bea4dca'and len(j['method_inputs'])==5,'original canonical qualifier/five inputs unchanged')
errors=collections.Counter(re.findall(r'\] (ERROR|FATAL|PANIC):\s+(.*)',log))
need(errors=={('ERROR','PRIVATE-SYNTHETIC-AUDIT-REFUSAL'):3,('ERROR','synthetic notification audit refused'):1,('ERROR','new row for relation "safety_auditlog" violates check constraint "bootstrap_fixture_refuse_audit"'):1,('ERROR','new row for relation "accounts_go_login_failure" violates check constraint "fixture_login_finalize_failure"'):1},'only six exact intentional SQL negative errors')

need(len(j['commands'])==293 and len(rows)==599 and all(c['exit']==0 for c in j['commands']),'all293waitedcommands0/all599rawartifacts')
need(len(source)==2186,'complete2186current/exporttrackedsourceframe')
for lane in j['lanes']:
 current=git('grep','-h','-E',r'^func Test[A-Za-z0-9_]+\(',sha,'--',f'services/server/internal/{lane}/*_test.go').decode()
 declarations=re.findall(r'^func (Test\w+)\(',current,re.M)
 events=[json.loads(line)for line in(run/f'proof/{lane}-test2json.stdout').read_bytes().splitlines()]
 actualroots=[e['Test']for e in events if e.get('Action')=='run'and e.get('Test')and '/'not in e['Test']]
 need(collections.Counter(declarations)==collections.Counter(actualroots),'everycurrentdeclaredroot actuallyran '+lane)
# Successful App root/each7finiteleaf once; test2json may split the long marker into several Output events.
app=[json.loads(line)for line in(run/'proof/app-test2json.stdout').read_bytes().splitlines()]
rootname='TestNativeNotificationPreferencesRegisteredHTTPAndDelivery'
required=['registered-get-is-self-scoped-and-side-effect-free','csrf-origin-and-current-unverified-account-policy','repeated-form-filter-sort-and-own-vs-other-boundary','mandatory-audit-refusal-rolls-back-and-renders-current-checks','actual-delivery-mandatory-bypass-and-absent-selection-clears','existing-spa-data-branch-and-mutation-return-path','registered-display-whitelist-and-current-inactive-account']
for name in [rootname]+[rootname+'/'+leaf for leaf in required]:
 need(sum(e.get('Action')=='run'and e.get('Test')==name for e in app)==sum(e.get('Action')=='pass'and e.get('Test')==name for e in app)==1,'mandatoryroot/leaf onceRUNPASS '+name)
actualleaves=[e['Test'][len(rootname)+1:]for e in app if e.get('Action')=='pass'and e.get('Test','').startswith(rootname+'/')]
need(collections.Counter(actualleaves)==collections.Counter(required),'exact7required leavesnoextra')
rootoutput=''.join(e.get('Output','')for e in app if e.get('Action')=='output'and e.get('Test')==rootname)
markers=re.findall(r'NATIVE_NOTIFICATION_PREFERENCES_V1 ([^\r\n]+)',rootoutput)
need(len(markers)==1,'onewholejoined actualroot marker')
marker=markers[0].encode();snapshot=json.loads(marker)
need(set(snapshot)=={'schema','variants'}and snapshot['schema']==1 and len(snapshot['variants'])==2,'exactbounded actualcapture wrapper')
need(len(marker)<=64<<10,'actual64KiBsourceproducer bound')
account=(repo/'services/server/internal/web/account_pages.go').read_text()
order=re.findall(r'"([^"\n]+)"',re.search(r'var accountNotificationOrder = \[\]string\{([^}]+)\}',account).group(1))
def stringmap(name):
 block=re.search(r'var '+name+r' = map\[string\]string\{(.*?)\}',account,re.S)
 entries=re.findall(r'("(?:\\.|[^"\\])*")\s*:\s*("(?:\\.|[^"\\])*")',block.group(1))
 return {json.loads(a):json.loads(b)for a,b in entries}
labels=stringmap('accountNotificationLabels');reasons=stringmap('accountNotificationReasons')
need(len(order)==22 and set(labels)==set(order)and set(reasons)==set(order)|{'system','moderation'},'unchangedauthoritative22choices plus2mandatory reasonstrings neveroffered')
variants=[]
for variant,language in zip(snapshot['variants'],['en','ro']):
 need(set(variant)=={'language','projection'}and variant['language']==language and set(variant['projection'])=={'rows'},'exactdisplayonlylanguage/rows wrapper')
 display=variant['projection']['rows'];need(len(display)==22 and [row['value']for row in display]==order,'actualordered22 display rows '+language)
 for row in display:
  need(set(row)=={'value','label','reason','muted'}and type(row['muted'])is bool and isinstance(row['label'],str)and isinstance(row['reason'],str)and row['label']==labels[row['value']]and row['reason']==reasons[row['value']]and row['muted']==(row['value']=='arrival'),'actualplain canonicaldisplay row/boolean '+language)
 variants.append({'language':language,'rows':len(display),'muted':[row['value']for row in display if row['muted']]})
need(not any(token in snapshot for token in ['cookie','session','csrf','nonce','actor','user','ward','access']),'nocredential/actor/privateoutercapturefields')
need(git('diff','--name-only',base,sha,'--','services/authcore','services/server/internal/accounts','services/server/internal/platform','services/server/internal/social','services/server/internal/messaging','services/server/internal/recommendations','apps','templates','locale','static/css/base.css')==b'','unchangedpriorservices/authcore/schema/originaltemplates/assets/catalogue')
source_approval=out/'committed-source-check-review.json';need(h(source_approval.read_bytes())=='35a83b519b551599b42ba716f4b518162dc822d8b5794f5e5c781b15cc0fda87','priorcommittedsource/actualcheapreview')
need(git('rev-parse','HEAD').decode().strip()==sha and not git('status','--porcelain'),'postreviewunchangedcleanfullsource')
report={'schema':1,'verdict':'ACCEPT_ACTUAL_COMPLETE_SIX_NOTIFICATION_PREFERENCES_PG','source_sha':sha,'source_tree':j['tree'],'accepted_previous_base_sha':base,'result_sha256':h((run/'result.json').read_bytes()),'source_manifest_sha256':h((run/'source-manifest.json').read_bytes()),'independent_committed_source_check_review_sha256':h(source_approval.read_bytes()),'proof_artifact_rows_rehashed':len(rows),'tracked_source_rows_rehashed_at_checkout_and_export':len(source),'recomputed_git_archive_sha256':h(archive),'recomputed_git_archive_bytes':len(archive),'actual_waited_command_receipts_all_exit0':len(j['commands']),'raw_resource_inspections_checked':len(inspections),'canonical_qualifier_sha256':j['method_sha256'],'canonical_method_inputs':len(j['method_inputs']),'wall_seconds':j['seconds'],'inventories':inventories,'total_root_passes':sum(v['top_level']for v in inventories.values()),'total_named_passes':sum(v['named_passes']for v in inventories.values()),'canonical_catalogue_rows_before_after_everylane':{key:len(value)for key,value in expected.items()},'guarded_retired_databases_with_name_OID_absence_and_checkpoints':len(j['retired_databases']),'owned_container_CID_name_removals_rawproof':len(j['cleanup']),'raw_PG_cleanup':j['pg_cleanup'],'raw_PG_synthetic_negative_errors':{message:count for(level,message),count in errors.items()},'actual_notification_App_root':rootname,'mandatory_notification_App_leaves_once_RUN_PASS':required,'actual_whole_joined_marker_sha256':h(marker),'actual_whole_joined_marker_bytes':len(marker),'actual_display_only_marker_variants':variants,'findings':findings,'checks':['Exactclean7819/tree and all2186trackedsourcebytes/executablebits independentlyjoin currentcheckout/retainedexport/Gitarchive3bdff; all599rawartifacts/293waitedcommandreceipts0/sixracebinaries/method5/installedGo1.27.1 identities rehashed. Originalcanonicalqualifier24a62 unchanged. Full sixcomplete inventories/currentallrootdeclarations andoldbase99declarations joined exactonceRUN/PASS/list with zero fail/skip/race/cache:436roots/1279named.','Original1GiBPGtmpfs/2GiBmemory/1CPU/pids256 andnative/reference3GiB/2CPU/pids512/noNetwork/noPorts/readOnly/capDropALL/noNewPrivileges/noOOM/exactDBcodecimages independentlyverified fromallrawinspectionreceipts. Fivecanonical reference datasets categories10/childvenues8/contenttypes91/relations9/types38 match before/after everylane. SixactualguardedidleDB name/OID retirements/DROP/checkpoints/catalog/tmpfs joins accepted.','ThirteenexactownedCID removals/uniqueobservednames andsuccessfulfreshpostremoveID/nameemptyinventories match rawcommands. PGcleanup rawjson stop0/status3/PIDprobe1/PIDsocketabsent plusrawfinaldatabase graceful shutdown/no-serverrunning agree. SixdeliberateSQLnegative errors only:3Familyauditrefusals+newnotification mandatoryauditrefusal+bootstrapconstraint+loginfinalizeconstraint; noPANIC/FATAL/space/recovery.','ActualnewnotificationApproots currentregistered7cases andstatictransport plusoldFamily/Create/Detail/auth/otherdeclarations allpass. Notificationrootandall7finiteleaves haveexactoneRUN/PASS, noextra leaf, andoneactualcompletejoinedtest2json marker. LongOutputchunks werejoined withinthatrootbeforeJSON validation; no shortfragment ordiagnosticfixture wasadmitted.','Actualmarker schema1/ENRO/rows22 each contains onlyvalue,label,reason,booleanmuted, in unchangedaccountsourceorder withcanonicalsource labels/reasons andonlyarrival muted. No cookie/session/CSRF/nonce/Actor/ward/access/privateaccount field. This is the successfulregisteredGET plussecondside-effect-free current-authorityAccountView producer projection explicitlydeclared bysource; not exactsameRender-invocation capture, authenticatedbrowser ornewpolicy proof.','All7qualifiedFamilyproductsources andpriorGroupdetailtypednil/linkcue/AppCSS bodies remain exact. Existingaccount/Notify/services/queries/authcore/schema/originaltemplates/baseCSS/catalogue/dependencies unchanged. Firstcheapadf5failure andmissing-owned-scratchpreoutputrefusal remainseparatehistoricalrecords; neitherwasqualification.'],'scope':'Complete affected6synthetic PostgreSQL/source/capture-producer/cleanup acceptance on exact7819 only. CurrentUI/capture-extractor/25bodyequality/noJS/Axe/measurement/keeper/finalfeature acceptance remain separate andunaccepted here; noall21/deploymentimage/main/milestone/production/mobile/provider/government/realchild authority.','execution':'Read-only currentGit/export/archive recomputation/rawJSON/native/test2json/list/command/binary/resource/catalogue/retirement/CID-name/PGshutdown/capture-marker/hash review+scratchreceipt only; no owningedits/native/compiler/test/browser/PG/container/process/network work.'}
(out/'full-pg-review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'path':str(out/'full-pg-review.json'),'sha256':h((out/'full-pg-review.json').read_bytes()),'roots':report['total_root_passes'],'named':report['total_named_passes'],'marker_bytes':len(marker),'findings':findings},indent=2))
