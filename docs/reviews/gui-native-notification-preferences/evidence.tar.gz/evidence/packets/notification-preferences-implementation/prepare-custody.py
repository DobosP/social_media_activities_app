from pathlib import Path
import json,hashlib
ROOT=Path('/home/dobo/work/_worktrees/social_media_activities_app/feat__gui-app-migration-a')
OUT=Path('/home/dobo/work/_temp/feat__gui-app-migration-a/social-family/notification-preferences-implementation/proposed')
def sha(s):return hashlib.sha256(s.encode()).hexdigest()
def quote(s):return json.dumps(s)
def put(name,s):(OUT/name).write_text(s)
def prefix(original,name,block):
 marker='func '+name
 start=original.index(marker);pos=original.index('{\n',start)+2
 return original[:pos]+block+original[pos:]
renderer='services/server/internal/web/renderer.go'
before_renderer=(ROOT/renderer).read_text();after_renderer=(OUT/renderer).read_text()
before_dispatch='\t} else {\n\t\ttemplate, parseErr := r.set.FromCache(name)'
after_dispatch='\t} else if name == "web/notification_preferences.html" {\n\t\traw, renderErr := r.renderNotificationPreferences(request, defaults)\n\t\tif renderErr != nil {\n\t\t\treturn renderErr\n\t\t}\n\t\t_, _ = output.Write(raw)\n'+before_dispatch
assert before_renderer.count(before_dispatch)==1 and after_renderer==before_renderer.replace(before_dispatch,after_dispatch)
walker='services/server/internal/web/gui_public_get_walk_test.go'
before_walker=(ROOT/walker).read_text()
walker_delta='\t// Exact new notification/source-control inverses precede the unchanged32-row\n\t// Group/family/historical chain. Live tuples stay physical.\n\tswitch path {\n\tcase "services/server/internal/web/renderer.go", "services/server/internal/web/gui_preferences_layout_test.go", "services/server/internal/web/gui_preferences_get_transport_test.go", "services/server/internal/web/gui_public_get_walk_test.go":\n\t\tvar err error\n\t\traw, err = notificationPreferencesSourcePreimage(path, raw)\n\t\tif err != nil {\n\t\t\treturn nil, err\n\t\t}\n\t}\n'
after_walker=prefix(before_walker,'guiPublicGetRowsPreimage(path string, raw []byte) ([]byte, error)',walker_delta)
put(walker,after_walker)
name='services/server/internal/web/group_detail_custody_test.go';s=(ROOT/name).read_text()
s=prefix(s,'groupDetailRendererPreimage(raw []byte) ([]byte, error)','\tvar notificationErr error\n\traw, notificationErr = notificationPreferencesPriorSource("services/server/internal/web/renderer.go", raw)\n\tif notificationErr != nil {\n\t\treturn nil, notificationErr\n\t}\n')
s=prefix(s,'groupDetailWalkerPreimage(raw []byte) ([]byte, error)','\tvar notificationErr error\n\traw, notificationErr = notificationPreferencesPriorSource("services/server/internal/web/gui_public_get_walk_test.go", raw)\n\tif notificationErr != nil {\n\t\treturn nil, notificationErr\n\t}\n')
put(name,s)
name='services/server/internal/web/group_create_source_guard_test.go';s=(ROOT/name).read_text()
for path,helper in [(renderer,'notificationPreferencesRendererPreimage'),(walker,'notificationPreferencesWalkerPreimage')]:
 marker='\tcase '+quote(path)+':\n';assert s.count(marker)==1
 s=s.replace(marker,marker+'\t\traw, err = '+helper+'(raw)\n\t\tif err != nil {\n\t\t\treturn guiG1Binding{}, err\n\t\t}\n',1)
anchor='\tvar err error\n\tswitch path {'
replacement='\tvar err error\n\tif path == "services/server/internal/web/gui_preferences_layout_test.go" || path == "services/server/internal/web/gui_preferences_get_transport_test.go" {\n\t\tprevious, err = notificationPreferencesSourcePreimage(path, raw)\n\t\tif err != nil {\n\t\t\treturn guiG1Binding{}, err\n\t\t}\n\t\traw = previous\n\t}\n\tswitch path {'
assert s.count(anchor)==1;s=s.replace(anchor,replacement,1)
put(name,s)
records=[]
for path,before,after,old,new in [(renderer,before_renderer,after_renderer,before_dispatch,after_dispatch),(walker,before_walker,after_walker,'',walker_delta)]:
 records.append(dict(path=path,before_sha256=sha(before),after_sha256=sha(after),before_bytes=len(before.encode()),after_bytes=len(after.encode()),before=old,after=new))
# Historical presentation adapters are fixed call-site additions only.
for path in ('services/server/internal/web/gui_preferences_layout_test.go','services/server/internal/web/gui_preferences_get_transport_test.go'):
    before=(ROOT/path).read_text();after=(OUT/path).read_text()
    if path.endswith('gui_preferences_layout_test.go'):
        old='\tif err := renderer.Render(response, request, "web/"+fixture.family+".html", data); err != nil {'
        new='\t// Retained notification bytes below are the frozen Pongo reference only;\n\t// current native22-row authority/markup is checked by the new App/UI suites.\n\tif err := notificationPreferencesFrozenReferenceRender(renderer, response, request, "web/"+fixture.family+".html", data); err != nil {'
    else:
        # One contiguous replacement covers both additions without accepting
        # arbitrary middle bytes: complete hashes also bind the full source.
        begin=before.index('\trenderer.set = pongo2.NewSet("native-social-current-preference", trace)')
        end=before.index('\tmux.ServeHTTP(response, request)\n',begin)+len('\tmux.ServeHTTP(response, request)\n')
        old=before[begin:end]
        new=old.replace('\trenderer.set = pongo2.NewSet("native-social-current-preference", trace)\n','\tif item.Route == "notification_preferences" {\n\t\t// Let the test-only alias retain original template-load trace identities.\n\t\trenderer.loader = trace\n\t}\n\trenderer.set = pongo2.NewSet("native-social-current-preference", trace)\n',1)
        new=new.replace('\tmux.ServeHTTP(response, request)\n','\t// Only retained notification form-byte predicates use the frozen reference.\n\t// Every other route still executes its current registered native mux.\n\tnotificationPreferencesFrozenReferenceHandler(s, mux).ServeHTTP(response, request)\n',1)
    assert before.count(old)==1 and after==before.replace(old,new,1)
    records.append(dict(path=path,before_sha256=sha(before),after_sha256=sha(after),before_bytes=len(before.encode()),after_bytes=len(after.encode()),before=old,after=new))
# New test-only bridge has exact complete bytes for each admitted source epoch.
source='''package web

import (
    "bytes"
    "fmt"
    "os"
    "path/filepath"
    "testing"
)

// One new exact inverse precedes the unchanged32-row relation. Only retained
// Group controls may explicitly consume that recovered prior source epoch;
// current live readers call the strict inverse and keep their physical tuple.
func notificationPreferencesSourceRelation(path string) (beforeSHA, afterSHA string, beforeBytes, afterBytes int, before, after string, ok bool) {
    switch path {
'''
for x in records:
 source+='    case '+quote(x['path'])+':\n        return '+', '.join([quote(x['before_sha256']),quote(x['after_sha256']),str(x['before_bytes']),str(x['after_bytes']),quote(x['before']),quote(x['after']),'true'])+'\n'
source+='''    }
    return "", "", 0, 0, "", "", false
}
func notificationPreferencesSourcePreimage(path string, raw []byte) ([]byte,error) {
    beforeSHA,afterSHA,beforeBytes,afterBytes,before,after,ok:=notificationPreferencesSourceRelation(path)
    if !ok || len(raw)!=afterBytes || guiPublicHash(raw)!=afterSHA || bytes.Count(raw,[]byte(after))!=1 { return nil,fmt.Errorf("notification-complete-current-source") }
    previous:=bytes.Replace(append([]byte(nil),raw...),[]byte(after),[]byte(before),1)
    if len(previous)!=beforeBytes || guiPublicHash(previous)!=beforeSHA { return nil,fmt.Errorf("notification-exact-source-preimage") }
    return previous,nil
}
func notificationPreferencesRendererPreimage(raw []byte)([]byte,error){return notificationPreferencesSourcePreimage("services/server/internal/web/renderer.go",raw)}
func notificationPreferencesWalkerPreimage(raw []byte)([]byte,error){return notificationPreferencesSourcePreimage("services/server/internal/web/gui_public_get_walk_test.go",raw)}
func notificationPreferencesPriorSource(path string,raw []byte)([]byte,error){
    beforeSHA,_,beforeBytes,_,_,_,ok:=notificationPreferencesSourceRelation(path)
    if ok && len(raw)==beforeBytes && guiPublicHash(raw)==beforeSHA { return append([]byte(nil),raw...),nil }
    return notificationPreferencesSourcePreimage(path,raw)
}

func TestNativeNotificationPreferencesCustodyKeepsCompletePriorChainsAndPhysicalInputs(t *testing.T){
    root,err:=filepath.Abs("../../../..");if err!=nil{t.Fatal(err)}
    rows:=guiPublicGetRepairRows()
    if len(rows)!=32 || len(groupDetailPreviousRepairRows(rows))!=31 || len(groupCreatePreviousRepairRows())!=27 { t.Fatal("prior32/31/27relations changed") }
    for _,path:=range []string{"services/server/internal/web/renderer.go","services/server/internal/web/gui_public_get_walk_test.go","services/server/internal/web/gui_preferences_layout_test.go","services/server/internal/web/gui_preferences_get_transport_test.go"}{
        physical,err:=os.ReadFile(filepath.Join(root,path));if err!=nil{t.Fatal(err)}
        previous,err:=notificationPreferencesSourcePreimage(path,physical);if err!=nil{t.Fatal("exact new inverse refused",path,err)}
        if _,err=notificationPreferencesSourcePreimage(path,previous);err==nil{t.Fatal("former source admitted as current",path)}
        for _,changed:=range [][]byte{append(append([]byte(nil),physical...), '\\n'),physical[:len(physical)-1],previous}{
            if _,err:=notificationPreferencesSourcePreimage(path,changed);err==nil{t.Fatal("rehashed drift/mixed epoch admitted",path)}
        }
        _,_,_,_,_,after,_:=notificationPreferencesSourceRelation(path)
        for _,changed:=range [][]byte{bytes.Replace(physical,[]byte(after),nil,1),append(append([]byte(nil),physical...),[]byte(after)...)}{
            if _,err:=notificationPreferencesSourcePreimage(path,changed);err==nil{t.Fatal("missing/duplicate literal relation admitted",path)}
        }
        if path=="services/server/internal/web/renderer.go"{
            historical,err:=guiPublicGetRowsPreimage(path,physical)
            if err!=nil||len(historical)!=5510||guiPublicHash(historical)!="94f11a3f1849c919ba100c4ba68236263f71f07741006c1992dadc4020723e68"{t.Fatal("new and all32prior inverses did not recover complete original renderer",err)}
        }
    }
    var registry guiPreferenceGETRegistry
    if guiG1StrictJSON(guiPreferencesGETRegistryBytes,&registry)!=nil{t.Fatal("immutable original registry unavailable")}
    inputs,err:=guiPreferenceGETInputs(root,registry)
    if err!=nil||len(inputs)!=138{t.Fatal("all138current physical tuples required",err)}
    for path,binding:=range inputs{
        _,physical,err:=guiCurrentTransportReadBinding(root,path,2<<20)
        if err!=nil||binding!=physical{t.Fatal("prior metadata leaked into current reader",path,err)}
    }
    for _,path:=range []string{"services/server/internal/web/renderer.go","services/server/internal/web/gui_public_get_walk_test.go"}{
        raw,physical,err:=guiCurrentTransportReadBinding(root,path,2<<20);if err!=nil{t.Fatal(err)};wanted:=registry.Sources[path]
        former,err:=notificationPreferencesSourcePreimage(path,raw);if err!=nil{t.Fatal(err)}
        for _,changed:=range [][]byte{append(append([]byte(nil),raw...), '\\n'),former}{
            binding:=guiG1Binding{len(changed),guiPublicHash(changed),physical.FullMode}
            if _,err:=groupCreatePreferenceSourceBinding(path,changed,binding,wanted);err==nil{t.Fatal("live reader admitted rehashed or former physical source",path)}
        }
    }
}
'''
put('services/server/internal/web/notification_preferences_custody_test.go',source)
Path('/home/dobo/work/_temp/feat__gui-app-migration-a/social-family/notification-preferences-implementation/custody-relations.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps([{k:v for k,v in x.items()if k not in ('before','after')}for x in records]))
