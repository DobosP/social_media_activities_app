from pathlib import Path
import json,hashlib,difflib
R=Path('/home/dobo/work/_worktrees/social_media_activities_app/feat__gui-app-migration-a')
B=Path('/home/dobo/work/_temp/feat__gui-app-migration-a/social-family/notification-preferences-first-unit-repair')
paths=['services/server/internal/web/renderer.go','services/server/internal/web/notification_preferences_custody_test.go','services/server/internal/web/notification_preferences_reference_test.go']
def sha(s):return hashlib.sha256(s.encode()).hexdigest()
def size(s):return len(s.encode())
def block(name,call):return '\t} else if name == "web/'+name+'.html" {\n\t\traw, renderErr := r.'+call+'(request, defaults)\n\t\tif renderErr != nil {\n\t\t\treturn renderErr\n\t\t}\n\t\t_, _ = output.Write(raw)\n'
for n in paths:assert(R/n).read_bytes()==(B/'before'/n).read_bytes(),'Applied source moved: '+n
old=(R/paths[0]).read_text();group=block('group_detail','renderGroupDetail');notice=block('notification_preferences','renderNotificationPreferences');assert old.count(group+notice)==1
new=old.replace(group+notice,notice+group,1);assert size(new)==size(old)==6349
fallback='\t} else {\n\t\ttemplate, parseErr := r.set.FromCache(name)';group_anchor='\t} else if name == "web/group_detail.html" {';old_after=group+fallback
assert old.count(old_after)==0 and new.count(old_after)==1
before_anchor=group_anchor;after_anchor=notice+group_anchor;assert new.count(after_anchor)==1
preimage=new.replace(after_anchor,before_anchor,1);assert size(preimage)==6146 and sha(preimage)=='3ba5b4456312437e8edf058b4f9967385bf14e483a0bb6d771b5881231d5c0e6'
bodies={paths[0]:new}
oldcustody=(R/paths[1]).read_text();start=oldcustody.index('\tcase "services/server/internal/web/renderer.go":\n')+len('\tcase "services/server/internal/web/renderer.go":\n');end=oldcustody.index('\n\tcase ',start)
expected='\t\treturn "3ba5b4456312437e8edf058b4f9967385bf14e483a0bb6d771b5881231d5c0e6", "'+sha(old)+'", 6146, 6349, '+json.dumps(fallback)+', '+json.dumps(notice+fallback)+', true';assert oldcustody[start:end]==expected
replacement='\t\treturn "3ba5b4456312437e8edf058b4f9967385bf14e483a0bb6d771b5881231d5c0e6", "'+sha(new)+'", 6146, 6349, '+json.dumps(before_anchor)+', '+json.dumps(after_anchor)+', true';bodies[paths[1]]=oldcustody[:start]+replacement+oldcustody[end:]
oldref=(R/paths[2]).read_text();anchor='\t\treference := httptest.NewRecorder()\n';assert oldref.count(anchor)==1;bodies[paths[2]]=oldref.replace(anchor,anchor+'\t\tdelete(data, "PRIVATE-foreign-preferences")\n',1)
# Audit the unchanged original negative replacements in their admitted source frames.
assert preimage.count(old_after)==1
groupframe=preimage.replace(old_after,fallback,1);assert size(groupframe)==5967 and sha(groupframe)=='6228270fd3343f7d352b79780bd9055ccbf9fe70b2d7917acdb4e0b6ffd31ed3'
groupcreate=block('group_form','renderGroupCreate');assert groupframe.count(groupcreate+fallback)==1
familyframe=groupframe.replace(groupcreate+fallback,fallback,1);assert size(familyframe)==5790 and sha(familyframe)=='e7c10feff706989b6141da3803e2ec4ff73c78a54f34c6e32db9e7b4937c6eee'
family_anchor='\t\t_, _ = output.Write(raw)\n\t} else {\n\t\ttemplate, parseErr := r.set.FromCache(name)';assert familyframe.count(family_anchor)==1
controls=[]
for label,frame,targets in [('Group-detail-physical',new,[old_after,'r.renderGroupDetail(request, defaults)']),('Group-create-recovered31',groupframe,[groupcreate+fallback,'r.renderGroupCreate(request, defaults)']),('Family-recovered',familyframe,[family_anchor,'r.renderFamily(request, name, defaults)'])]:
 for target in targets:
  assert frame.count(target)==1 and frame.replace(target,'',1)!=frame
  controls.append(dict(frame=label,target_sha256=sha(target),occurrences=1,removal_changes_bytes=True))
rows=[];patch=[]
for n in paths:
 before=(R/n).read_bytes();after=bodies[n].encode();p=B/'proposed'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(after)
 rows.append(dict(path=n,before_bytes=len(before),before_sha256=hashlib.sha256(before).hexdigest(),after_bytes=len(after),after_sha256=hashlib.sha256(after).hexdigest()));patch.extend(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+n,tofile='b/'+n))
(B/'proposed.patch').write_text(''.join(patch));(B/'manifest.json').write_text(json.dumps(rows,indent=2)+'\n')
checks=Path('/home/dobo/work/_temp/feat__gui-app-migration-a/social-family/notification-preferences-checks');records=[]
for n in ['web-unit.jsonl','static-unit.jsonl','first-iteration-result.json','applied-source.json','applied-format.json']:
 p=checks/n;raw=p.read_bytes();records.append(dict(path=str(p),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
proof=dict(schema=1,status='SOURCE_ONLY_THREE_PATH_REPAIR_UNRUN',base='Exact current applied gofmt source atop99b88a446031cdf3d99bd04bdfcb41706d2a6aab; not original unformatted packet',patch_sha256=hashlib.sha256((B/'proposed.patch').read_bytes()).hexdigest(),manifest_sha256=hashlib.sha256((B/'manifest.json').read_bytes()).hexdigest(),source_paths=3,actual_failure_records=records,first_iteration='Actualweb12roots68named failed2roots/3testnodes; Appstaticrace1passed. No PG/UI/benchmark ran. Rawfailures remain untouched.',causes=[{'observed':'OldGroup-detail missing-dispatch control reported unsupportedcurrentsourceadmitted.','source_proof':'Its exact immutable group-detail+genericelse string has0physical occurrences in originalapplied6349 source; bytes.Replace returned unchanged valid source, accepted correctly.','repair':'Move disjoint notification branch before Groupdetail; oldliteral occurs exactlyonce physically. New strict notification inverse restores identical prior6146/3ba5 source.'},{'observed':'Newreferencefixture Pongo checkForValidIdentifiers rejects PRIVATE-foreign-preferences.','repair':'Delete only that new native-only sentinel immediately before the NEW reference render. Native privacy fixture/helper/tests and all original tests unchanged.'}],renderer_old_after_occurrences={'failed_applied':0,'proposed_fixed':1},control_frames=controls,branch_equivalence='Exact existing disjoint name-equality branches swapped as complete blocks; defaults/callbacks/bodywrites/allotherbranch content unchanged. No fallback/22row/assertion/service/policy/cap changes.',source_custody='Only NEW notification relation renderer anchor/posthash changed;6146/3ba5 preimage/allotherrelation rows/unchanged32historical table and original32/31/27/138assertions/pins unchanged. NewstrictSource checks remainfullhash+bytes+oneliteral.',owning_writes=False,parser_compiler_tests_native_runtime_executed=False,raw_failure_history_preserved=True)
(B/'source-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(dict(patch=proof['patch_sha256'],manifest=proof['manifest_sha256'],proof=hashlib.sha256((B/'source-proof.json').read_bytes()).hexdigest(),renderer_after=sha(new),rows=rows)))
