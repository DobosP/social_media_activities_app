#!/usr/bin/env python3
"""Six synthetic refusal controls; no product/Git/DB/browser operation."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest import mock

HERE=Path('/home/dobo/work/_temp/feat__gui-app-migration-a/social-family/account-center-keeper')
ROOT=HERE.parent
c=None


class Refusals(unittest.TestCase):
    def setUp(self):
        self.fixture=Path(tempfile.mkdtemp(prefix='account-custody-control-',dir=ROOT))
        c.EARLIEST.clear();c.EARLIEST_LINKS.clear();c.EARLIEST_DIRS.clear();c.EARLIEST_EXCLUDED.clear()
    def tearDown(self):
        # Only this test's exclusively created tiny temporary directory.
        shutil.rmtree(self.fixture)
        self.assertFalse(self.fixture.exists())
    def test_pending_binding_before_any_source_or_process_effect(self):
        with mock.patch.object(c,'git',side_effect=AssertionError('no Git allowed')),mock.patch.object(c,'read',side_effect=AssertionError('no input traversal allowed')):
            with self.assertRaisesRegex(ValueError,'pending binding refuses'):
                c.admit({'schema':1,'status':'DISABLED'})
        self.assertEqual(list(self.fixture.iterdir()),[])
    def test_wrong_digest(self):
        p=self.fixture/'one';p.write_bytes(b'fixed synthetic')
        with self.assertRaisesRegex(ValueError,'digest differs'):
            c.bound(p,'0'*64)
    def test_earliest_bytes_or_fullstat_change(self):
        p=self.fixture/'one';p.write_bytes(b'one');c.read(p);p.write_bytes(b'two')
        with self.assertRaisesRegex(ValueError,'earliest'):
            c.read(p)
    def test_complete_directory_membership_drift(self):
        c.read_directory(self.fixture);(self.fixture/'new').write_bytes(b'synthetic')
        with self.assertRaisesRegex(ValueError,'earliest'):
            c.read_directory(self.fixture)
    def test_symlink_read_refused(self):
        p=self.fixture/'one';p.write_bytes(b'fixed');q=self.fixture/'alias';q.symlink_to(p)
        with self.assertRaisesRegex(ValueError,'unaliased'):
            c.read(q)
    def test_unsafe_archive_member_refused(self):
        for name in ('../outside','/absolute','bad\\alias','a/../b'):
            with self.assertRaisesRegex(ValueError,'safe canonical'):
                c.safe_member(name)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--source-review',type=Path,required=True);parser.add_argument('--source-review-sha256',required=True);args=parser.parse_args()
    if Path(__file__).resolve()!=HERE/'controls.py' or args.output!=HERE/'controls-result.json' or args.output.exists():
        raise ValueError('literal exclusive owned control receipt')
    review_path=args.source_review
    if review_path.parent!=HERE or review_path.resolve()!=review_path or review_path.is_symlink():
        raise ValueError('literal independent source review before import')
    raw=review_path.read_bytes()
    if len(raw)>65536 or hashlib.sha256(raw).hexdigest()!=args.source_review_sha256:
        raise ValueError('exact bounded source review before import')
    review=json.loads(raw)
    def scalars(value):
        if isinstance(value,str):return {value}
        if isinstance(value,dict):return set().union(*(scalars(x) for x in value.values()),set())
        if isinstance(value,list):return set().union(*(scalars(x) for x in value),set())
        return set()
    hashes={hashlib.sha256((HERE/name).read_bytes()).hexdigest() for name in ('collect.py','controls.py','profile.json')}
    field='status' if 'status' in review else 'verdict'
    if not str(review.get(field,'')).startswith('ACCEPT') or review.get('findings')!=[] or not hashes<=scalars(review):
        raise ValueError('independently accepted exact collector/control/profile required before import')
    global c
    spec=importlib.util.spec_from_file_location('account_collector_under_review',HERE/'collect.py')
    c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Refusals))
    count=len(result.failures)+len(result.errors)
    value={'schema':1,'status':'PASS_ACCOUNT_CUSTODY_CONTROLS_NOT_COLLECTION_ACCEPTANCE' if result.wasSuccessful() and result.testsRun==6 else 'FAIL',
           'collector_sha256':hashlib.sha256((HERE/'collect.py').read_bytes()).hexdigest(),
           'controls_source_sha256':hashlib.sha256((HERE/'controls.py').read_bytes()).hexdigest(),
           'tests_run':result.testsRun,'failures':count,'pending_refused_before_effects':result.wasSuccessful(),
           'owned_fixture_removed':result.wasSuccessful(),'scope':'Only six synthetic primitive refusals. No actual source inventory, product/Git/DB/browser/collector preparation/archive/deletion.'}
    with args.output.open('x') as stream:stream.write(json.dumps(value,indent=2,sort_keys=True)+'\n')
    raise SystemExit(0 if result.wasSuccessful() and result.testsRun==6 else 1)


if __name__=='__main__':
    main()
