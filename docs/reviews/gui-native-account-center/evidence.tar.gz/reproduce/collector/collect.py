#!/usr/bin/env python3
"""Finite account evidence prepare/collect; no deletion or acceptance."""
import argparse
from collections import Counter
from decimal import Decimal
import hashlib
import io
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import tarfile

ROOT=Path('/home/dobo/work/_temp/feat__gui-app-migration-a/social-family')
HERE=ROOT/'account-center-keeper'
REPO=Path('/home/dobo/work/_worktrees/social_media_activities_app/feat__gui-app-migration-a')
UI_ROOT=Path('/home/dobo/work/_temp/ac-ui')
STAT_KEYS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_size','st_nlink','st_mtime_ns','st_ctime_ns')
EARLIEST={}
EARLIEST_LINKS={}
EARLIEST_DIRS={}
MAX_FILE=64<<20
MAX_PAYLOAD=128<<20
FORBIDDEN={'data','pgdata','pg_wal','pg_xact','cache','node_modules','.git','binaries','source','host-tmp','test-tmp','__pycache__'}
NATIVE_R="02ac07258cca866180ef93aeeb6a17ecb07baae1"
METHOD_M="75edf1a051e95441248f58dbfed9e610cc4a00b6"
EARLIEST_EXCLUDED={}
PG_NAMES={"web","app","accounts","recommendations","social","messaging","notifications"}
MODES=("overview-basic-en","overview-guardian-ro","overview-ward-connections-en","overview-escaped-ro","settings-no-token-en","settings-token-ro","settings-expired-record-en","settings-revoke-error-ro")

def need(ok, message):
    if not ok:
        raise ValueError(message)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def hex64(value):
    return isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value) is not None

def safe_member(name):
    need(isinstance(name, str) and name and not Path(name).is_absolute() and '..' not in Path(name).parts
         and '\\' not in name and name != '.' and Path(name).as_posix() == name, 'safe canonical relative member required')
    return name

def read(path):
    path = Path(path)
    need(path.is_absolute() and path.resolve() == path, 'canonical unaliased input required')
    before = path.lstat()
    need(stat.S_ISREG(before.st_mode) and 0 <= before.st_size <= MAX_FILE, 'bounded regular nonsymlink input required')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        opened = os.fstat(fd)
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            raw = stream.read(MAX_FILE + 1)
        after = os.fstat(fd)
    finally:
        os.close(fd)
    before_stat = tuple(getattr(before, key) for key in STAT_KEYS)
    need(len(raw) == before.st_size and before_stat == tuple(getattr(opened, key) for key in STAT_KEYS)
         == tuple(getattr(after, key) for key in STAT_KEYS), 'input changed before/during read')
    snapshot = (raw, before_stat)
    need(path not in EARLIEST or EARLIEST[path] == snapshot, 'input differs from earliest bytes/fullstat')
    EARLIEST.setdefault(path, snapshot)
    return raw, before

def bound(path, digest):
    need(hex64(digest), 'explicit SHA-256 required')
    raw, info = read(path)
    need(sha(raw) == digest, 'bound input digest differs')
    return raw, info

def read_git_link(path):
    need(path.is_absolute() and path.parent.resolve() == path.parent and path.is_relative_to(REPO),
         'literal internal Git symlink input')
    before = path.lstat(); target = os.readlink(path).encode(); after = path.lstat()
    fingerprint = tuple(getattr(before, key) for key in STAT_KEYS)
    need(stat.S_ISLNK(before.st_mode) and path.resolve().is_relative_to(REPO)
         and fingerprint == tuple(getattr(after, key) for key in STAT_KEYS), 'Git symlink identity changed')
    snapshot = (target, fingerprint)
    need(path not in EARLIEST_LINKS or EARLIEST_LINKS[path] == snapshot, 'Git link differs from earliest bytes/fullstat')
    EARLIEST_LINKS.setdefault(path, snapshot)
    return target, before

def read_directory(path):
    need(path.is_absolute() and (path.is_relative_to(ROOT) or path.is_relative_to(UI_ROOT))
         and path.resolve() == path and not path.is_relative_to(HERE)
         and path not in HERE.parents and not any(part in FORBIDDEN for part in path.parts),
         'literal safe evidence directory; method/output/private trees cannot be censused')
    before = path.lstat()
    need(stat.S_ISDIR(before.st_mode), 'safe directory input required')
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        opened = os.fstat(fd); names = sorted(os.listdir(fd))
        need(len(names) <= 16384, 'bounded safe directory membership required')
        entries = []
        for name in names:
            info = os.stat(name, dir_fd=fd, follow_symlinks=False)
            need(stat.S_ISREG(info.st_mode) or stat.S_ISDIR(info.st_mode), 'safe evidence directory special entry refused')
            entries.append({'name': name, 'kind': 'directory' if stat.S_ISDIR(info.st_mode) else 'file'})
        after = os.fstat(fd)
    finally:
        os.close(fd)
    fingerprint = tuple(getattr(before, key) for key in STAT_KEYS)
    need(fingerprint == tuple(getattr(opened, key) for key in STAT_KEYS)
         == tuple(getattr(after, key) for key in STAT_KEYS), 'directory identity changed during census')
    snapshot = (tuple((row['name'], row['kind']) for row in entries), fingerprint)
    need(path not in EARLIEST_DIRS or EARLIEST_DIRS[path] == snapshot,
         'directory differs from earliest membership/fullstat')
    EARLIEST_DIRS.setdefault(path, snapshot)
    return entries, before

def observer_fence(view):
    need(set(view) == {'label', 'uid_map', 'gid_map'} and isinstance(view['label'], str) and view['label'],
         'one explicitly chosen observer view required')
    # These fixed proc metadata files are not payloads/ordinary st_size files.
    need(Path('/proc/self/uid_map').read_text() == view['uid_map']
         and Path('/proc/self/gid_map').read_text() == view['gid_map'], 'observer UID/GID mapping changed')

def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args], env={'PATH': os.defpath, 'LANG': 'C.UTF-8'})

def git_blob(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()

def git_objects(source):
    return {row.split(b'\t', 1)[1].decode(): row.split(b'\t', 1)[0].split()[2].decode()
            for row in git('ls-tree', '-r', '-z', source).split(b'\0') if row}

def write_payload(output, payload):
    need(not os.path.lexists(output) and output.parent == HERE and output.is_absolute()
         and output.resolve() == output and HERE.resolve() == HERE and HERE.stat().st_uid == os.getuid(),
         'exclusive fresh direct-child owned output')
    need(all(len(row[0]) <= MAX_FILE for row in payload.values()) and sum(len(row[0]) for row in payload.values()) <= MAX_PAYLOAD, 'bounded compact payload')
    output.mkdir(mode=0o700)
    archive_path = output / 'evidence.tar.gz'; manifest = []
    with tarfile.open(archive_path, mode='x:gz', format=tarfile.PAX_FORMAT) as archive:
        for member, (raw, info, path) in sorted(payload.items()):
            safe_member(member)
            entry = tarfile.TarInfo(member); entry.size = len(raw); entry.mode = stat.S_IMODE(info.st_mode)
            entry.uid = info.st_uid; entry.gid = info.st_gid; entry.mtime = info.st_mtime_ns // 10 ** 9
            entry.pax_headers = {'mtime': str(entry.mtime) + '.' + str(info.st_mtime_ns % 10 ** 9).zfill(9)}
            archive.addfile(entry, io.BytesIO(raw))
            manifest.append({'member': member, 'original': str(path), 'bytes': len(raw), 'sha256': sha(raw),
                             'mode': entry.mode, 'uid': entry.uid, 'gid': entry.gid, 'mtime_ns': info.st_mtime_ns})
    with tarfile.open(archive_path, mode='r:gz') as archive:
        entries = archive.getmembers()
        need([entry.name for entry in entries] == [row['member'] for row in manifest], 'complete archive member readback')
        for entry, row in zip(entries, manifest):
            need(entry.isfile() and entry.size == row['bytes'] and entry.mode == row['mode']
                 and entry.uid == row['uid'] and entry.gid == row['gid']
                 and int(Decimal(entry.pax_headers['mtime']) * 10 ** 9) == row['mtime_ns']
                 and sha(archive.extractfile(entry).read()) == row['sha256'], 'payload bytes/full portable metadata readback')
    return archive_path, manifest


def strings(value):
    if isinstance(value, str): return {value}
    if isinstance(value, dict): return set().union(*(strings(x) for x in value.values()), set())
    if isinstance(value, list): return set().union(*(strings(x) for x in value), set())
    return set()


def accepted(spec, required):
    need(isinstance(spec, dict) and set(spec) == {'path','sha256','field','expected'}
         and isinstance(spec['path'],str) and hex64(spec['sha256'])
         and spec['field'] in ('status','verdict') and isinstance(spec['expected'],str)
         and spec['expected'].startswith('ACCEPT'), 'explicit actual review spec required')
    path=Path(spec['path'])
    need(path.is_absolute() and path.parent in (HERE,ROOT/'account-center-checks')
         and path.resolve()==path and not any(part in FORBIDDEN for part in path.parts),
         'literal source/selection or account-check review role required before read')
    raw, _ = bound(path,spec['sha256']); value = json.loads(raw)
    need(value.get(spec['field']) == spec['expected'] and value.get('findings') == []
         and set(required) <= strings(value), 'actual independent accepted review with required identities')
    return value


def admit(binding):
    # This refusal is deliberately before Git, selection traversal or output.
    need(binding.get('schema') == 1 and binding.get('status') == 'BOUND_ACCOUNT_CUSTODY'
         and binding.get('source_sha') == METHOD_M and binding.get('native_source') == NATIVE_R,
         'pending binding refuses before source inventory, commands or output')
    bound(HERE / 'collect.py', binding['collector_sha256'])
    profile = json.loads(bound(HERE / 'profile.json', binding['profile_sha256'])[0])
    need(profile['status'] == 'BOUND_ACTUAL_ACCOUNT_UI_AND_MEASUREMENT' and profile['native_R'] == NATIVE_R
         and profile['method_M'] == METHOD_M and profile['protected_latest_R_all_artifacts'] is True,
         'actual final account profile required')
    bound(HERE/'controls.py',binding['controls_source_sha256'])
    pending=json.loads(bound(HERE/'binding.disabled.json',binding['pending_binding_sha256'])[0])
    need(pending.get('schema')==1 and str(pending.get('status','')).startswith('DISABLED')
         and pending.get('collector_sha256')==binding['collector_sha256']
         and pending.get('controls_source_sha256')==binding['controls_source_sha256'],
         'exact current disabled input for canonical pending refusal')
    for name,digest in profile['collector_history'].items():
        bound(HERE/'history-v1'/safe_member(name),digest)
    accepted(binding['source_review'], [binding['collector_sha256'],binding['controls_source_sha256'],
        binding['profile_sha256'],binding['pending_binding_sha256'],METHOD_M,NATIVE_R])
    accepted(profile['accepted_reviews']['native_PG'], [NATIVE_R, profile['PG_runs'][1]['result_sha256']])
    accepted(profile['accepted_reviews']['final_UI'], [NATIVE_R, METHOD_M, profile['final_UI']['result_sha256']])
    accepted(profile['accepted_reviews']['measurement'], [METHOD_M, profile['final_UI']['benchmark_sha256']])
    return profile


def row_for(path, member, role):
    safe_member(member)
    need(path.is_absolute() and path.resolve()==path
         and (path.is_relative_to(ROOT) or path.is_relative_to(UI_ROOT) or path.is_relative_to(REPO))
         and not any(part in FORBIDDEN for part in path.parts)
         and role in ('PG-S','PG-R','UI-first-failure','UI-benchmark-failure','UI-final',
                      'finite-account-source-or-reviewed-evidence','finite-current-source-image')
         and (role!='finite-current-source-image' or path.is_relative_to(REPO)),
         'finite safe payload scope/role required before read')
    raw, info = read(path)
    return {'path':str(path),'member':member,'role':role,'bytes':len(raw),'sha256':sha(raw),
            'stat':{k:getattr(info,k) for k in STAT_KEYS}}


def check_row(row):
    need(set(row) == {'path','member','role','bytes','sha256','stat'}, 'exact selected row schema')
    current = row_for(Path(row['path']), row['member'], row['role'])
    need(current == row, 'selected bytes/full observer metadata changed')
    return EARLIEST[Path(row['path'])][0], Path(row['path']).lstat()


def directory_row(path, role):
    entries, info = read_directory(path)
    return {'path':str(path),'role':role,'entries':entries,'stat':{k:getattr(info,k) for k in STAT_KEYS}}


def excluded(path, kind, source):
    # Only exact PG archive streams or generated directory roots, never payload.
    need(path.is_absolute() and path.resolve() == path and path.parent.resolve() == path.parent,
         'literal exclusion path')
    info = path.lstat(); result = {'path':str(path),'kind':kind,'source':source,
                                 'stat':{k:getattr(info,k) for k in STAT_KEYS}}
    if kind == 'duplicate-Git-archive-stdout':
        raw, info = read(path); result.update(bytes=len(raw),sha256=sha(raw))
    else:
        need(kind == 'generated-root-not-ingested' and path.name in ('source','binaries','host-tmp','test-tmp')
             and stat.S_ISDIR(info.st_mode) and not path.is_symlink(), 'literal generated root only')
        result['not_inventoried_or_archived'] = True
    need(path not in EARLIEST_EXCLUDED or EARLIEST_EXCLUDED[path] == result, 'exclusion identity changed')
    EARLIEST_EXCLUDED.setdefault(path,result)
    return result


def source_frame():
    need(git('rev-parse','HEAD').decode().strip() == METHOD_M and not git('status','--porcelain'),
         'actual final method source must remain clean')
    allowed = {'STATUS.md','docs/execplans/gui-native-account-center.md'} | {
        'tools/gui-native-account-center/'+name for name in ('qualify.py','desktop-qa.mjs','export_test.go.txt','README.md','source-bindings.json')}
    changed = set(git('diff','--name-only',NATIVE_R,METHOD_M).decode().splitlines())
    need(changed and changed <= allowed, 'exact unchanged nativeR to final method source bridge')
    frame=[]
    for name, blob in sorted(git_objects(METHOD_M).items()):
        path=REPO/safe_member(name); info=path.lstat()
        if stat.S_ISLNK(info.st_mode): raw,info=read_git_link(path); kind='symlink'
        else: raw,info=read(path); kind='file'
        need(git_blob(raw)==blob, 'full current tracked source/Git blob differs')
        frame.append({'path':name,'kind':kind,'bytes':len(raw),'sha256':sha(raw),
                      'stat':{k:getattr(info,k) for k in STAT_KEYS}})
    return frame


def pg_semantics(spec):
    run=Path(spec['path']); value=json.loads(bound(run/'result.json',spec['result_sha256'])[0])
    need(value['source']==spec['source'] and value['method_pass'] is True and value['errors']==[]
         and set(value['lanes'])==PG_NAMES and len(value['commands'])==340 and len(value['artifact_rows'])==695
         and len(value['method_inputs'])==8
         and sum(x['tests']['top_level'] for x in value['lanes'].values())==457
         and sum(x['tests']['named_passes'] for x in value['lanes'].values())==1368,
         'actual accepted seven-package native result inventory')
    need(all(x['state']=='PASS' and x['tests']['fail']==x['tests']['skip']==0 for x in value['lanes'].values())
         and len(value['cleanup'])==15 and all(x['stopped'] and x['id_absent'] and x['name_absent'] for x in value['cleanup'].values())
         and len(value['retired_databases'])==7 and all(x['checkpoint_completed'] and x['name_and_oid_absent'] for x in value['retired_databases'].values())
         and value['pg_cleanup']['stop_exit']==0 and value['pg_cleanup']['status_exit']==3
         and value['pg_cleanup']['pid_probe_exit']==1 and value['pg_cleanup']['pid_and_socket_files_absent']==1,
         'all native lanes/15roles/seven databases/privatePG retired')
    archives=[(i,c) for i,c in enumerate(value['commands']) if c['argv']==['git','-C',str(REPO),'archive','--format=tar.gz',spec['source']]]
    need(len(archives)==1 and archives[0][1]['exit']==0 and value['git_archive']['format']=='tar.gz', 'unique real full Git archive command')
    index,command=archives[0]; archive=run/safe_member(command['stdout']['path'])
    ledger=dict(excluded(archive,'duplicate-Git-archive-stdout',spec['source']))
    need(ledger['bytes']==command['stdout']['bytes']==value['git_archive']['bytes']
         and ledger['sha256']==command['stdout']['sha256']==value['git_archive']['sha256'], 'actual entire-source archive stream joins')
    ledger.update(command_index=index,retention='LIVE_PROTECTED_LATEST_R_ALL_ARTIFACTS' if spec['source']==NATIVE_R else 'SUPERSEDED_KEEP_UNTIL_SEPARATE_ACCEPTED_RETENTION')
    # Every real artifact is still checked physically, including large Gitstdout.
    for row in value['artifact_rows']:
        need(len(bound(run/safe_member(row['path']),row['sha256'])[0])==row['bytes'], 'all actual PG artifact bytes remain available')
    for c in value['commands']:
        need(type(c['exit']) is int and c['seconds']>=0 and c['timeout']>0 and isinstance(c['argv'],list), 'original command metadata')
        for key in ('stdout','stderr'):
            x=c[key];need(len(bound(run/safe_member(x['path']),x['sha256'])[0])==x['bytes'], 'all original command stream bytes')
    for row in value['method_inputs']:
        need(len(bound(REPO/safe_member(row['path']),row['sha256'])[0])==row['bytes'], 'all eight native method source roles unchanged')
    manifest=json.loads(read(run/'source-manifest.json')[0])
    need({x['path'] for x in manifest}==set(git_objects(spec['source'])) and len(manifest)==len(git_objects(spec['source'])),
         'historical native full source-manifest/Git path inventory')
    return value,archive,ledger


def ui_artifacts(spec):
    run=Path(spec['path']);value=json.loads(bound(run/'result.json',spec['result_sha256'])[0])
    need(value['owned_temp']['removed'] is True and not os.path.lexists(value['owned_temp']['path']), 'owned UI temporary setup removed')
    need(len(value['commands']) in (2,3) and all(c['timed_out'] is False for c in value['commands']), 'all original children waited without timeout')
    for row in value['artifacts']:
        need(len(bound(run/safe_member(row['path']),row['sha256'])[0])==row['bytes'], 'every actual UI artifact byte')
    return value


def final_ui_semantics(profile):
    spec=profile['final_UI'];run=Path(spec['path']);value=ui_artifacts(spec)
    need(value['status']=='PASS' and value['failures']==[] and value['PG_producer_source']==NATIVE_R
         and value['UI_method_source']==METHOD_M and value['git_after']=={'head':METHOD_M,'porcelain_empty':True}
         and len(value['artifacts'])==87 and len(value['commands'])==3
         and all(c['exit_code']==0 for c in value['commands']), 'final actual whole-wrapper source/PASS/children')
    for row in value['committed_method']:
        need(len(bound(REPO/safe_member(row['path']),row['sha256'])[0])==row['bytes'], 'exact final five committed method images')
    desktop=json.loads(bound(run/'desktop/desktop-results.json',value['desktop_report_sha256'])[0])
    need(desktop['status']=='pass' and desktop['failures']==[] and desktop['sourceUnchanged'] is True
         and desktop['sourcesBefore']==desktop['sourcesAfter'] and len(desktop['states'])==len(desktop['noJavaScriptStates'])==8
         and desktop['ownership']['serverStopped'] and len(desktop['ownership']['profiles'])==2
         and all(x['closed'] and x['removed'] and not os.path.lexists(x['path']) for x in desktop['ownership']['profiles']),
         'actual eightJS/eightnoJS/source/browser ownership')
    audits=[a for s in desktop['states'] for a in s['audits']]
    need(len(audits)==24 and all(not a['axe']['violations'] and not a['axe']['incomplete'] for a in audits)
         and len(desktop['requests'])==104 and len(desktop['assetResponses'])==88
         and all(x['method']=='GET' for x in desktop['requests'])
         and all(not desktop[n] for n in ('requestFailures','pageErrors','consoleErrors','cspConsole','webSockets')),
         'all strict whole-document audits/currentassets/localGET/noerror streams')
    fixture=json.loads(bound(run/'fixtures/fixtures.json',value['fixture_manifest_sha256'])[0])
    need(fixture['PG_producer_source']==NATIVE_R and fixture['UI_method_source']==METHOD_M
         and fixture['source_unchanged'] is True and fixture['sources_before']==fixture['sources_after']
         and tuple(s['name'] for s in fixture['states'])==MODES, 'eight fixed synthetic account source fixtures')
    for row in fixture['states']:
        body=bound(run/'fixtures'/safe_member(row['name']+'.html'),row['sha256'])[0]
        need(len(body)==row['bytes'] and b'PRIVATE-' not in body, 'current eight bodies/retained private probe does not leak')
    bench=value['benchmark'];raw=bound(run/'benchmark.stdout',spec['benchmark_sha256'])[0]
    need(bench['status']=='EXECUTED_SEPARATE_NOT_ADMITTED' and bench['rows']==48
         and bench['stdout_sha256']==spec['benchmark_sha256'], 'original benchmark pending-admission inner status preserved')
    samples=re.findall(r'^(BenchmarkSocialAccountCenterBodyRender/\S+)\s+([0-9]+)\s+(.+)$',raw.decode(),re.M)
    need(len(samples)==48 and all(n=='100' for _,n,_ in samples)
         and Counter(re.sub(r'-[0-9]+$','',name) for name,_,_ in samples)==Counter({
             'BenchmarkSocialAccountCenterBodyRender/'+mode+'/'+engine:3 for mode in MODES for engine in ('classic','native')}),
         'exact matched48 warmed body sample inventory')
    for _,_,metrics in samples:
        parts=metrics.split();need(len(parts)==10 and Counter(parts[1::2])==Counter(['ns/op','B/op','allocs/op','html-B/op','gzip9-B/op'])
            and all(re.fullmatch(r'[0-9]+(?:\.[0-9]+)?',x) for x in parts[::2]), 'all exact finite benchmark units')
    return value,desktop


def historical_semantics(profile):
    first=ui_artifacts(profile['UI_runs'][0]);second=ui_artifacts(profile['UI_runs'][1])
    first_reports=[row for row in first['artifacts'] if row['path']=='desktop/desktop-results.json']
    need(first['status']=='FAIL' and first['benchmark']['status']=='REQUESTED_NOT_REACHED'
         and 'desktop_report_sha256' not in first and len(first_reports)==1
         and first_reports[0]['sha256']=='37ad9d1b3118221c7e118de42d08afd178f46e20ed28f7196557ab72f9dceec1',
         'first strict-Axe failure unique original artifact/benchmark not reached remains immutable')
    first_raw=bound(Path(profile['UI_runs'][0]['path'])/'desktop/desktop-results.json',first_reports[0]['sha256'])[0]
    need(len(first_raw)==first_reports[0]['bytes'], 'first failed desktop actual raw/artifact byte join')
    need(second['status']=='FAIL' and second['benchmark']['status']=='REQUESTED_NOT_ADMITTED'
         and second['desktop_report_sha256']=='7a0f672213b2d248c3d49c6bb29cacc9c1c5462456bbdbfc81221f5451f9a5d3',
         'repaired desktop PASS but overall benchmark FAIL remains immutable')
    raw=read(Path(profile['UI_runs'][1]['path'])/'benchmark.stdout')[0].decode()
    need(raw.count("context-key 'PRIVATE-extra'")==8
         and len(re.findall(r'^BenchmarkSocialAccountCenterBodyRender/\S+/native\s+100\s+',raw,re.M))==24
         and not re.findall(r'^BenchmarkSocialAccountCenterBodyRender/\S+/classic\s+100\s+',raw,re.M),
         'eight classic failures/24native-only rows never matched acceptance')
    # Required independently reviewed chronology is selected as original bytes.
    for name,digest in (('final-full-pg-review.json','fffe5e68e82b293e32b17bfb5c7c4a6bf3f100184d716eca372f3bb9436cd6ec'),
        ('ui-first-independent-review.json','c733015b6eea9dd8c1f5202f0b263be3a035fccd52779701cc5b8b6a39807066'),
        ('ui-repair-first-independent-review.json','034dc4ffc888001de43d3f80ce1f666a90274004ed30443a78ae85463b2cf141'),
        ('paired-first-independent-review.json','d4a65ce5116c29ca9f3662347923f0486449fc79fe2562c45b288a1154e52aa8')):
        bound(ROOT/'account-center-checks'/name,digest)
    bound(ROOT/'account-center-method-controls/actual-control-review.json','55154c028c9d6885b97b5dffcbd334227cd9189d921337b862205cbf5cf3eed5')
    controls_root=ROOT/'account-center-method-controls/first-14-controls'
    controls=json.loads(bound(controls_root/'result.json','f8e5a625616a4979590f5273026895acfd456ad9041e3fa3d6603bc8f623c435')[0])
    need(controls['status']=='PASS_FOURTEEN_SYNTHETIC_NEGATIVE_REFUSALS_ONLY' and controls['failures']==[]
         and len(controls['cases'])==14 and controls['original_method_images_unchanged'] is True
         and controls['fixture']['removed'] is True and not os.path.lexists(controls['fixture']['path']), 'actual fourteen refusal control history')
    for case in controls['cases']:
        need(case['pass'] and case['zero_forbidden_effects'] and case['method_copy_unchanged']
             and case['command']['waited'] and case['command']['exit_code']==1 and not case['command']['timed_out']
             and case['trace']['forbidden_events']==case['trace']['sentinel_imports']==0,'original guard refusals only')
        for row in (case['command']['stdout'],case['command']['stderr'],case['trace']):
            bound(controls_root/safe_member(row['path']),row['sha256'])
    pair_root=UI_ROOT/'paired-header-flow-first'
    pair=json.loads(bound(pair_root/'result.json','c31b60e3767627a808b4e91a7bf37a23cabd94a1b22477172cf61bca85a30c36')[0])
    need(pair['status']=='PAIRED_DEBUG_EXPECTATIONS_MET_NOT_QUALIFICATION' and pair['failures']==[]
         and pair['servedRegistryUnchanged'] is True and [x['name'] for x in pair['variants']]==['baseline','candidate']
         and len(pair['cleanup'])==2 and all(x['contextClosed'] and x['profileRemoved'] and x['serverStopped']
            and not os.path.lexists(x['profile']) for x in pair['cleanup']),'paired causal debug status/ownedcleanup')
    for variant in pair['variants']:
        audits=[a for state in variant['states'] for a in state['audits']]
        need(len(variant['states'])==8 and len(audits)==24
             and not any(a['axe']['violations'] for a in audits),'full paired immutable48 strict audits')
        need(sum(bool(a['axe']['incomplete']) for a in audits)==(15 if variant['name']=='baseline' else 0),
             'exact baseline15 incompletes/candidatezero causal evidence only')
        for audit in audits:bound(pair_root/safe_member(audit['screenshot']),audit['screenshotSHA256'])
    bound(ROOT/'account-center-benchmark-key-repair/independent-source-review.json','1da0a5444765fbe9c715705db197c941779d27e62da4876b811668d881e3eb3b')
    bound(ROOT/'next-social-account-center-methods/operational-benchmark-repair/final-operational-review.json','c9b2e22e9d720c1ba085d7fb3b5814ccccbdf12919dc89828d5eee1077f69d62')


def baseline_37(profile,ui):
    spec=profile['baseline']['date'];root=Path(spec['canonical_root'])
    raw=bound(root/'evidence.tar.gz',spec['archive_sha256'])[0]
    manifest=json.loads(bound(root/'archive-manifest.json',spec['manifest_sha256'])[0])
    for name,key in (('keeper-review.json','keeper_review_sha256'),('acceptance.json','feature_review_sha256'),('publication-review.json','publication_review_sha256')):
        bound(root/name,spec[key])
    rows=ui['previous_body_equality']['rows'];by={x['baseline_member']:x for x in rows}
    need(ui['previous_body_equality']['literal_byte_equal'] is True and len(rows)==len(by)==37
         and ui['previous_body_equality']['archive_sha256']==spec['archive_sha256'], 'exact prior37 body map')
    members=manifest['members'];need(len(members)==1689 and manifest['archive_sha256']==spec['archive_sha256'], 'accepted date full member census')
    seen=set()
    with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as archive:
        entries=archive.getmembers();need([e.name for e in entries]==[x['member'] for x in members], 'entire reference-only baseline physical inventory')
        for entry,row in zip(entries,members):
            safe_member(entry.name);old=archive.extractfile(entry).read() if entry.isfile() else None
            need(entry.isfile() and entry.size==row['bytes'] and entry.mode==row['mode'] and entry.uid==row['uid'] and entry.gid==row['gid']
                 and int(Decimal(entry.pax_headers['mtime'])*10**9)==row['mtime_ns'] and sha(old)==row['sha256'], 'reference baseline exact bytes/portable metadata')
            if entry.name in by:
                now=by[entry.name];current=bound(Path(profile['final_UI']['path'])/'fixtures'/safe_member(now['path']),now['sha256'])[0]
                need(now['equal'] is True and len(current)==now['bytes'] and current==old, 'every literal physical37 body equality')
                seen.add(entry.name)
    need(seen==set(by), 'all reference-only prior bodies visited')
    return rows


def attempt_rows(profile):
    parents={ROOT/'account-center-pg-qa':{Path(x['path']).name for x in profile['PG_runs']}|{'runner.lock'},
             UI_ROOT:{Path(x['path']).name for x in profile['UI_runs']}|{'header-flow-diagnostic','paired-header-flow-first'}}
    output=[]
    for parent,expected in parents.items():
        row=directory_row(parent,'all-entry-attempt-parent')
        need({x['name'] for x in row['entries']}==expected, 'unknown complete/incomplete/non-run attempt; explicit rebind required')
        need(all(x['kind']==('file' if x['name']=='runner.lock' else 'directory') for x in row['entries']), 'attempt aliases/special entries refused')
        output.append(row)
    return output


def build_selection(profile):
    frame=source_frame();attempts=attempt_rows(profile);rows=[];directories=[];exclusions=[];seen=set()
    pg_values=[];skip={}
    for spec in profile['PG_runs']:
        value,archive,ledger=pg_semantics(spec);pg_values.append(value);skip[archive]=ledger
        for name in ('source','binaries','host-tmp','test-tmp'):
            path=Path(spec['path'])/name
            if os.path.lexists(path): skip[path]=excluded(path,'generated-root-not-ingested',spec['source'])
    final,desktop=final_ui_semantics(profile);historical_semantics(profile);body_rows=baseline_37(profile,final)
    def scan(path,prefix,role):
        directory=directory_row(path,role);directories.append(directory)
        for item in directory['entries']:
            child=path/item['name'];member=prefix+'/'+item['name']
            if child in skip: exclusions.append(skip[child]);continue
            if item['kind']=='directory': scan(child,member,role)
            else:
                need(child not in seen,'select each physical path once');seen.add(child);rows.append(row_for(child,member,role))
    for spec in profile['PG_runs']:scan(Path(spec['path']),'evidence/'+spec['role'],spec['role'])
    for spec in profile['UI_runs']:scan(Path(spec['path']),'evidence/'+spec['role'],spec['role'])
    for name in profile['packet_roots']:
        root=Path(name);scan(root,'evidence/packets/'+root.name,'finite-account-source-or-reviewed-evidence')
    current=set()
    for name,key in ((profile['current_source_manifest'],'files'),(profile['current_method_manifest'],'paths')):
        value=json.loads(read(Path(name))[0]);current|={x['path'] for x in value[key]}
    for value in pg_values:current|={x['path'] for x in value['method_inputs']}
    current|={x['path'] for x in json.loads(read(REPO/'tools/gui-native-account-center/source-bindings.json')[0])['unchanged_overlay_helpers']}
    for name in sorted(current):rows.append(row_for(REPO/safe_member(name),'reproduce/current/'+name,'finite-current-source-image'))
    need(len({x['path'] for x in rows})==len(rows) and len({x['member'] for x in rows})==len(rows), 'closed unique physical/member selection')
    need(len(rows)<=4096 and sum(x['bytes'] for x in rows)<=MAX_PAYLOAD, 'finite source/evidence payload caps')
    foreign=[x for x in rows if x['stat']['st_uid']!=os.getuid()]
    allowed_foreign={str(Path(spec['path'])/'socket'/name) for spec in profile['PG_runs'] for name in ('ready.json','pg-cleanup.json')}
    need({x['path'] for x in foreign}<=allowed_foreign and all(x['role'] in ('PG-S','PG-R') for x in foreign),
         'only exact reviewed foreign PG-ready/cleanup metadata; no ownership normalization')
    return {'schema':1,'source_sha':METHOD_M,'native_source':NATIVE_R,'source_tree':git('rev-parse',METHOD_M+'^{tree}').decode().strip(),
        'observer':{'label':'actual collector observer; no UID/GID normalization','uid_map':Path('/proc/self/uid_map').read_text(),'gid_map':Path('/proc/self/gid_map').read_text()},
        'rows':rows,'directory_censuses':directories,'attempt_censuses':attempts,'source_frame':frame,'exclusions':exclusions,
        'baseline_reference':profile['baseline'],'all37_body_rows':body_rows,'foreign_owned_payload_rows':foreign,
        'counts':{'selected_files':len(rows),'selected_bytes':sum(x['bytes'] for x in rows),'source_rows':len(frame),
                  'PG':{'lanes_per_run':7,'roots_per_run':457,'named_per_run':1368,'commands_per_run':340,'artifacts_per_run':695,'roles_per_run':15,'databases_per_run':7},
                  'UI':{'JS':8,'noJS':8,'strictAxe':24,'old_body_identities':37,'new_fixed_bodies':8,'matched_samples':48}},
        'latest_R_protected':'All695physical PG artifacts including duplicate Gitstdout remain inputs to qualified_pg; never delete them through this collector.'}


def recheck_all():
    for path in tuple(EARLIEST): read(path)
    for path in tuple(EARLIEST_LINKS): read_git_link(path)
    for path in tuple(EARLIEST_DIRS): read_directory(path)
    for path,row in tuple(EARLIEST_EXCLUDED.items()):
        current=excluded(path,row['kind'],row['source']);need(current==row,'excluded live root/archive identity changed')


def freeze_fence(profile,selection):
    need(source_frame()==selection['source_frame'] and attempt_rows(profile)==selection['attempt_censuses'], 'full source/all-entry attempt fence')
    for row in selection['directory_censuses']:
        need(directory_row(Path(row['path']),row['role'])==row,'complete selected tree directory membership/fullstat fence')
    for row in selection['rows']:check_row(row)
    observer_fence(selection['observer']);recheck_all()


def output_gate(output):
    need(output is not None and output.is_absolute() and output.parent==HERE
         and output.resolve()==output and not os.path.lexists(output)
         and HERE.resolve()==HERE and stat.S_ISDIR(HERE.stat().st_mode)
         and HERE.stat().st_uid==os.getuid(), 'exclusive fresh direct-child owned output before reads or traversal')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binding',type=Path,required=True)
    group=parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--prepare',action='store_true')
    group.add_argument('--output',type=Path)
    args=parser.parse_args()
    need(Path(__file__).resolve()==HERE/'collect.py' and args.binding.is_absolute()
         and args.binding.parent==HERE and args.binding.resolve()==args.binding,'literal reviewed source/binding')
    output_gate(HERE/'prepared-selection.json' if args.prepare else args.output)
    binding=json.loads(read(args.binding)[0]);profile=admit(binding)
    if args.prepare:
        selection=build_selection(profile);freeze_fence(profile,selection)
        raw=(json.dumps(selection,indent=2,sort_keys=True)+'\n').encode()
        need(len(raw)<=MAX_FILE,'bounded selection metadata')
        with (HERE/'prepared-selection.json').open('xb') as stream:stream.write(raw)
        print(json.dumps({'status':'PREPARED_PENDING_INDEPENDENT_SELECTION_AND_CONTROLS','selection_sha256':sha(raw),'counts':selection['counts']}));return
    selection_path=HERE/'prepared-selection.json';selection_raw=bound(selection_path,binding['selection_sha256'])[0];selection=json.loads(selection_raw)
    need(binding['selection_review']['path']!=binding['source_review']['path']
         and binding['selection_review']['sha256']!=binding['source_review']['sha256'],'separate later selection/control review required')
    accepted(binding['selection_review'],[binding['collector_sha256'],binding['controls_source_sha256'],binding['profile_sha256'],
        binding['pending_binding_sha256'],binding['selection_sha256'],binding['controls_sha256'],METHOD_M,NATIVE_R])
    controls=json.loads(bound(HERE/'controls-result.json',binding['controls_sha256'])[0])
    need(controls['status']=='PASS_ACCOUNT_CUSTODY_CONTROLS_NOT_COLLECTION_ACCEPTANCE'
         and controls['collector_sha256']==binding['collector_sha256']
         and controls['controls_source_sha256']==binding['controls_source_sha256']
         and controls['profile_sha256']==binding['profile_sha256']
         and controls['pending_binding_input_sha256']==binding['pending_binding_sha256'] and controls['tests_run']==6
         and controls['failures']==0 and controls['pending_refused_before_effects'] is True
         and controls['owned_fixture_removed'] is True and binding['pending_exit']==1 and binding['control_exit']==0,
         'actual finite same-source custody refusal controls')
    need(build_selection(profile)==selection,'reproduce frozen full finite selection before collection')
    payload={};physical=set()
    def add(path,member,digest=None):
        safe_member(member);need(member not in payload and str(path) not in physical,'select physical bytes exactly once')
        raw,info=bound(path,digest) if digest else read(path);payload[member]=(raw,info,path);physical.add(str(path))
    for row in selection['rows']:check_row(row);add(Path(row['path']),row['member'],row['sha256'])
    for name in ('collect.py','profile.json','controls.py','README.txt','SOURCE_PROOF.json','primitive-reuse.json','binding.disabled.json'):
        digest=binding['controls_source_sha256'] if name=='controls.py' else binding['pending_binding_sha256'] if name=='binding.disabled.json' else None
        add(HERE/name,'reproduce/collector/'+name,digest)
    for name,digest in sorted(profile['collector_history'].items()):
        add(HERE/'history-v1'/safe_member(name),'reproduce/collector/history-v1/'+name,digest)
    add(selection_path,'selection.json',binding['selection_sha256']);add(args.binding,'reproduce/collector/final-binding.json')
    add(HERE/'controls-result.json','evidence/collector-controls/result.json',binding['controls_sha256'])
    for role in ('source_review','selection_review'):
        spec=binding[role];add(Path(spec['path']),'evidence/collector-'+role+'.json',spec['sha256'])
    for name in ('controls.stdout','controls.stderr','pending.stdout','pending.stderr'):
        digest=binding['control_streams'][name];add(HERE/name,'evidence/collector-controls/'+name,digest)
    need(len(payload)<=4096 and sum(len(x[0]) for x in payload.values())<=MAX_PAYLOAD,'compact total archive limits')
    freeze_fence(profile,selection)
    archive,manifest=write_payload(args.output,payload)
    freeze_fence(profile,selection)
    archive_sha=sha(archive.read_bytes())
    def write(name,value):
        with (args.output/name).open('x') as stream:stream.write(json.dumps(value,indent=2,sort_keys=True)+'\n')
    write('archive-manifest.json',{'archive_sha256':archive_sha,'complete_bytes_mode_UID_GID_nsmtime_roundtrip':True,'members':manifest})
    write('result.json',{'schema':1,'status':'COLLECTED_PENDING_INDEPENDENT_KEEPER_AND_FEATURE_REVIEW','source_sha':METHOD_M,'native_source':NATIVE_R,
        'source_tree':selection['source_tree'],'observer':selection['observer'],'actuals':selection['counts'],
        'archive':{'sha256':archive_sha,'bytes':archive.stat().st_size,'members':len(manifest)},
        'baseline':{'archive_sha256':profile['baseline']['date']['archive_sha256'],'reference_only':True,'all37_physical_bytes_equal':True},
        'history':'FirstUIec7eFAIL; paireddebugonly; repaired desktop7a0f accepted but overallda4e benchmarkFAIL/24native-only notmatched; key1aea final949 PASS/48matched with separate actualreview. All original innerstatuses preserved.',
        'exclusions':'Generatedworkspaces/binaries/DB not ingested; exact duplicate Gitstdout metadata only. No deletion. ALLlatestR695PGartifact bytes including Gitstdout remain protected physical UI-reproduction inputs.',
        'limits':['No acceptance by collector; separate full keeper/feature reviews remain required.','Mixed fixed synthetic BODY tradeoff: native median elapsed 35.35-66.26% higher and allocation counts39.59-46.77% higher; allocated bytes14.50-23.39%,HTML37.15-42.27%,gzip26.38-30.11% lower. Three samples100iterationsCPU1; no HTTP/CPU-profile/general speedup claim.','No main/milestone/production/provider/government/real-child/legal activation.']})
    print(json.dumps({'output':str(args.output),'archive_sha256':archive_sha,'members':len(manifest),'result_sha256':sha(read(args.output/'result.json')[0])}))


if __name__=='__main__':
    main()
