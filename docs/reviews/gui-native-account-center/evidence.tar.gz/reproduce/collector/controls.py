#!/usr/bin/env python3
"""Six synthetic refusal controls; no product/Git/DB/browser operation."""
import sys
sys.dont_write_bytecode=True
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import tempfile
import types
import unittest
from unittest import mock

HERE=Path('/home/dobo/work/_temp/feat__gui-app-migration-a/social-family/account-center-keeper')
ROOT=HERE.parent
STAT_KEYS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_size','st_nlink','st_mtime_ns','st_ctime_ns')
TRUSTED={}
c=None


def trusted_read(path,maximum):
    # Independent trusted admission; do not import candidate read() to admit it.
    if not path.is_absolute() or path.parent!=HERE or path.resolve()!=path:
        raise ValueError('literal canonical direct-child trusted control input')
    before=path.lstat()
    if not stat.S_ISREG(before.st_mode) or not 0<=before.st_size<=maximum:
        raise ValueError('bounded regular trusted control input before open')
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
    try:
        opened=os.fstat(fd)
        with os.fdopen(fd,'rb',closefd=False) as stream:raw=stream.read(maximum+1)
        after=os.fstat(fd)
    finally:os.close(fd)
    fingerprint=tuple(getattr(before,key) for key in STAT_KEYS)
    if len(raw)!=before.st_size or fingerprint!=tuple(getattr(opened,key) for key in STAT_KEYS) or fingerprint!=tuple(getattr(after,key) for key in STAT_KEYS):
        raise ValueError('trusted control input changed before/during bounded read')
    snapshot=(raw,fingerprint,maximum)
    if path in TRUSTED and TRUSTED[path]!=snapshot:
        raise ValueError('trusted control input differs from earliest bytes/full9stat')
    TRUSTED.setdefault(path,snapshot)
    return raw


class Refusals(unittest.TestCase):
    def setUp(self):
        self.fixture=Path(tempfile.mkdtemp(prefix='account-custody-control-',dir=ROOT))
        c.EARLIEST.clear();c.EARLIEST_LINKS.clear();c.EARLIEST_DIRS.clear();c.EARLIEST_EXCLUDED.clear()
    def tearDown(self):
        # Only this test's exclusively created tiny temporary directory.
        shutil.rmtree(self.fixture)
        self.assertFalse(self.fixture.exists())
    def test_pending_binding_before_any_source_or_process_effect(self):
        with mock.patch.object(c,'git',side_effect=AssertionError('no Git allowed')),mock.patch.object(c,'read',side_effect=AssertionError('no input traversal allowed')):
            with self.assertRaisesRegex(ValueError,'pending binding refuses'):
                c.admit({'schema':1,'status':'DISABLED'})
        self.assertEqual(list(self.fixture.iterdir()),[])
    def test_wrong_digest(self):
        p=self.fixture/'one';p.write_bytes(b'fixed synthetic')
        with self.assertRaisesRegex(ValueError,'digest differs'):
            c.bound(p,'0'*64)
    def test_earliest_bytes_or_fullstat_change(self):
        p=self.fixture/'one';p.write_bytes(b'one');c.read(p);p.write_bytes(b'two')
        with self.assertRaisesRegex(ValueError,'earliest'):
            c.read(p)
    def test_complete_directory_membership_drift(self):
        c.read_directory(self.fixture);(self.fixture/'new').write_bytes(b'synthetic')
        with self.assertRaisesRegex(ValueError,'earliest'):
            c.read_directory(self.fixture)
    def test_symlink_read_refused(self):
        p=self.fixture/'one';p.write_bytes(b'fixed');q=self.fixture/'alias';q.symlink_to(p)
        with self.assertRaisesRegex(ValueError,'unaliased'):
            c.read(q)
    def test_unsafe_archive_member_refused(self):
        for name in ('../outside','/absolute','bad\\alias','a/../b'):
            with self.assertRaisesRegex(ValueError,'safe canonical'):
                c.safe_member(name)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--source-review',type=Path,required=True);parser.add_argument('--source-review-sha256',required=True);args=parser.parse_args()
    if Path(__file__).resolve()!=HERE/'controls.py' or args.output!=HERE/'controls-result.json' or os.path.lexists(args.output):
        raise ValueError('literal exclusive owned control receipt before input reads')
    if args.source_review.suffix!='.json' or len(args.source_review_sha256)!=64 or any(ch not in '0123456789abcdef' for ch in args.source_review_sha256):
        raise ValueError('JSON source-review role and explicit SHA required before read')
    raw=trusted_read(args.source_review,65536)
    if hashlib.sha256(raw).hexdigest()!=args.source_review_sha256:
        raise ValueError('exact bounded source review before candidate loading')
    review=json.loads(raw)
    def scalars(value):
        if isinstance(value,str):return {value}
        if isinstance(value,dict):return set().union(*(scalars(x) for x in value.values()),set())
        if isinstance(value,list):return set().union(*(scalars(x) for x in value),set())
        return set()
    admitted={name:trusted_read(HERE/name,1<<20) for name in ('collect.py','controls.py','profile.json','binding.disabled.json')}
    hashes={name:hashlib.sha256(raw).hexdigest() for name,raw in admitted.items()}
    field='status' if 'status' in review else 'verdict'
    if not str(review.get(field,'')).startswith('ACCEPT') or review.get('findings')!=[] or not set(hashes.values())<=scalars(review):
        raise ValueError('independently accepted exact collector/control/profile/pending input required before loading')
    global c
    # Execute ONLY the immutable admitted buffer. No SourceFileLoader reread or
    # bytecode cache is allowed; -I alone does not disable .pyc writes.
    sys.dont_write_bytecode=True
    c=types.ModuleType('account_collector_under_review');c.__file__=str(HERE/'collect.py')
    exec(compile(admitted['collect.py'],str(HERE/'collect.py'),'exec'),c.__dict__)
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Refusals))
    count=len(result.failures)+len(result.errors)
    for path,record in tuple(TRUSTED.items()):trusted_read(path,record[2])
    value={'schema':1,'status':'PASS_ACCOUNT_CUSTODY_CONTROLS_NOT_COLLECTION_ACCEPTANCE' if result.wasSuccessful() and result.testsRun==6 else 'FAIL',
           'collector_sha256':hashes['collect.py'],'controls_source_sha256':hashes['controls.py'],
           'profile_sha256':hashes['profile.json'],'pending_binding_input_sha256':hashes['binding.disabled.json'],
           'tests_run':result.testsRun,'failures':count,'pending_refused_before_effects':result.wasSuccessful(),
           'owned_fixture_removed':result.wasSuccessful(),'scope':'Only six synthetic primitive refusals. No actual source inventory, product/Git/DB/browser/collector preparation/archive/deletion.'}
    with args.output.open('x') as stream:stream.write(json.dumps(value,indent=2,sort_keys=True)+'\n')
    raise SystemExit(0 if result.wasSuccessful() and result.testsRun==6 else 1)


if __name__=='__main__':
    main()
