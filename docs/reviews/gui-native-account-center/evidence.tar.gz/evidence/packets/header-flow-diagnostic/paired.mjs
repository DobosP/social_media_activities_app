// DEBUG ONLY: paired immutable fixtures, not operational qualification.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import crypto from 'node:crypto';
import {createRequire} from 'node:module';
import {execFileSync} from 'node:child_process';
import {fileURLToPath,pathToFileURL} from 'node:url';

const option=name=>{const i=process.argv.indexOf(name);assert.ok(i>=2&&process.argv[i+1]);return path.resolve(process.argv[i+1]);};
const inputsFile=option('--inputs'),output=option('--output'),scratch=option('--scratch'),reviewFile=option('--admission');
const i=process.argv.indexOf('--admission-sha256'),reviewSHA=process.argv[i+1];assert.ok(i>=2&&/^[0-9a-f]{64}$/.test(reviewSHA));
const hash=raw=>crypto.createHash('sha256').update(raw).digest('hex');
const regular=file=>{assert.equal(fs.realpathSync(file),file);const b=fs.lstatSync(file,{bigint:true});assert.ok(b.isFile()&&b.size<=64n*1024n*1024n);const raw=fs.readFileSync(file),a=fs.lstatSync(file,{bigint:true});assert.ok(['dev','ino','mode','uid','gid','size','mtimeNs','ctimeNs','nlink'].every(k=>a[k]===b[k]));return raw;};
const inputsRaw=regular(inputsFile),inputs=JSON.parse(inputsRaw),code=regular(fileURLToPath(import.meta.url)),reviewRaw=regular(reviewFile),review=JSON.parse(reviewRaw);
const scalars=v=>typeof v==='string'?[v]:v&&typeof v==='object'?Object.values(v).flatMap(scalars):[];
assert.equal(hash(reviewRaw),reviewSHA);const accepted=review.verdict||review.status;assert.ok(accepted.includes('ACCEPT')&&!accepted.includes('NOT_ACCEPTED'));assert.deepEqual(review.findings,[]);
for(const digest of[hash(code),hash(inputsRaw),inputs.candidate_CSS.sha256])assert.ok(scalars(review).includes(digest),'independent exact debug source/input/CSS approval before output/dependency');
const repo=inputs.repo,fixtures=path.join(inputs.first_run,'fixtures'),cli=inputs.CLI,axeFile=cli['--axe-file'],chrome=cli['--chrome'],playwright=cli['--playwright-package'];
assert.equal(fs.realpathSync(process.execPath),cli['--node']);
const beforeCSS=regular(inputs.before_CSS.path),candidateCSS=regular(inputs.candidate_CSS.path);assert.equal(hash(beforeCSS),inputs.before_CSS.sha256);assert.equal(hash(candidateCSS),inputs.candidate_CSS.sha256);
const C=JSON.parse(regular(inputs.operational_C.path));assert.equal(hash(regular(inputs.operational_C.path)),inputs.operational_C.sha256);assert.ok(C.status.startsWith('ACCEPT'));assert.deepEqual(C.findings,[]);
const manifestRaw=regular(path.join(fixtures,'fixtures.json'));assert.equal(hash(manifestRaw),inputs.fixture_manifest_sha256);const manifest=JSON.parse(manifestRaw);
assert.equal(manifest.PG_producer_source,inputs.S);assert.equal(manifest.UI_method_source,inputs.M);assert.equal(manifest.states.length,8);assert.equal(manifest.source_unchanged,true);
assert.equal(hash(regular(path.join(inputs.first_run,'result.json'))),inputs.result_sha256);assert.equal(hash(regular(path.join(inputs.first_run,'desktop/desktop-results.json'))),inputs.desktop_sha256);
const git=(...args)=>execFileSync('git',['-C',repo,...args],{env:{PATH:'/usr/bin:/bin',LANG:'C.UTF-8'}});
const fence=()=>{const head=git('rev-parse','HEAD').toString().trim();assert.equal(head,inputs.R);assert.equal(git('rev-parse','HEAD^{tree}').toString().trim(),inputs.R_tree);assert.equal(git('status','--porcelain','--untracked-files=all').length,0);git('merge-base','--is-ancestor',inputs.M,head);const changed=git('diff','--name-only','--no-renames',inputs.M,head).toString().trim().split('\n').filter(Boolean);assert.ok(changed.every(n=>inputs.allowed_post_M_paths.includes(n)));for(const n of changed)assert.equal(hash(git('show',head+':'+n)),inputs.repair_after_hashes[n]);return{head,changed};};
const sourceAdmission=()=>{
const source=git('show',inputs.M+':tools/gui-native-account-center/desktop-qa.mjs').toString();assert.equal(hash(Buffer.from(source)),inputs.original_desktop_sha256);
const slices=[['dependencyHash','const dependencyHash=','assert.equal(fs.realpathSync(playwright)'],['settleAndColors','async function settleAndColors(','async function audit('],['audit','async function audit(','async function metricsFor('],['keyboardChecks','async function keyboardChecks(','async function exercise(']];
for(const[name,start,end]of slices){const text=source.slice(source.indexOf(start),source.indexOf(end)).trim();assert.equal(hash(Buffer.from(text)),inputs.literal_functions[name]);assert.ok(code.toString().includes(text),'exact reviewed literal function');}
assert.deepEqual(git('show',inputs.M+':static/css/account-center-native.css'),beforeCSS);
return fence();
};
let sourceBefore;

const dependencyHash=(file,executable)=>{
 assert.equal(fs.realpathSync(file),file);const before=fs.lstatSync(file,{bigint:true});assert.ok(before.isFile());if(executable)fs.accessSync(file,fs.constants.X_OK);else assert.ok(before.size<=64n*1024n*1024n);
 const keys=['dev','ino','mode','uid','gid','size','mtimeNs','ctimeNs','nlink'],same=info=>assert.ok(keys.every(key=>info[key]===before[key]),'dependency changed during exact read');
 const fd=fs.openSync(file,fs.constants.O_RDONLY|fs.constants.O_NOFOLLOW),digest=crypto.createHash('sha256');let count=0n;
 try{same(fs.fstatSync(fd,{bigint:true}));const buffer=Buffer.alloc(1<<20);for(;;){const n=fs.readSync(fd,buffer,0,buffer.length,null);if(!n)break;count+=BigInt(n);assert.ok(count<=before.size);digest.update(buffer.subarray(0,n));}same(fs.fstatSync(fd,{bigint:true}));assert.equal(count,before.size);}finally{fs.closeSync(fd);}
 same(fs.lstatSync(file,{bigint:true}));return digest.digest('hex');
};

async function settleAndColors(page) {
  return page.evaluate(async () => {
    const colors = () => [...document.querySelectorAll('.account-center-native .btn,.account-center-native .linkbtn')].map(element => {
      const style = getComputedStyle(element);
      return {action: element.closest('form')?.getAttribute('action') || '', label: element.textContent.trim(), color: style.color, backgroundColor: style.backgroundColor};
    });
    const before = colors(); document.documentElement.getBoundingClientRect();
    await document.fonts.ready;
    const frame = () => new Promise(resolve => requestAnimationFrame(resolve)), deadline = performance.now() + 4000, waits = [];
    for (;;) {
      await frame(); await frame();
      const active = document.getAnimations().filter(animation => animation.pending || animation.playState === 'running');
      if (!active.length) break;
      if (performance.now() >= deadline || active.some(animation => animation.effect?.getComputedTiming()?.iterations === Infinity)) throw new Error('Unsettled/infinite animation before whole-document audit');
      waits.push(...active.map(animation => ({type: animation.constructor.name, property: animation.transitionProperty || ''})));
      let timer;
      try {await Promise.race([Promise.allSettled(active.map(animation => animation.finished)), new Promise((_, reject) => {timer = setTimeout(() => reject(new Error('Animation completion deadline exceeded')), Math.max(1, deadline - performance.now()));})]);}
      finally {clearTimeout(timer);}
    }
    const after = colors(); await frame(); await frame();
    if (JSON.stringify(after) !== JSON.stringify(colors())) throw new Error('Computed styles changed after settling');
    return {before, after, waits, remainingAnimations: document.getAnimations().filter(animation => animation.pending || animation.playState === 'running').length};
  });
}

async function audit(page) {
  return page.evaluate(async () => {
    const raw = await window.axe.run(document, {runOnly: {type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21aa']}});
    const details = rows => rows.map(row => ({id: row.id, impact: row.impact, nodes: row.nodes.map(node => ({target: node.target, summary: node.failureSummary}))}));
    return {version: raw.testEngine.version, passes: raw.passes.map(row => row.id), violations: details(raw.violations), incomplete: details(raw.incomplete)};
  });
}

async function keyboardChecks(page,state,label){
 const records=[],targets=page.locator('main#main a[href],main#main button,main#main select');
 const wanted=[...state.expected.tabs.map(row=>'A:'+row.href)];
 if(state.expected.settings)wanted.push('SELECT:language','BUTTON:/i18n/setlang/');
 for(const group of state.expected.groups)for(const row of group.links)wanted.push('A:'+row.href);
 if(state.expected.settings){if(state.expected.has_token_record)wanted.push('BUTTON:/settings/api-token/revoke/');wanted.push('A:/account/export/','A:/account/delete/');}
 wanted.push('BUTTON:/logout/');check(await targets.count()===wanted.length,label+': exact independent main target census');await page.locator('main#main').focus();
 for(let i=0;i<wanted.length;i++){
  await page.keyboard.press('Tab');const row=await targets.nth(i).evaluate(e=>{const s=getComputedStyle(e);return{active:e===document.activeElement,focusVisible:e.matches(':focus-visible'),outline:s.outlineStyle,width:s.outlineWidth,destination:e.tagName+':'+(e.tagName==='SELECT'?e.name:e.getAttribute('href')||e.closest('form')?.getAttribute('action'))};});
  check(row.active&&row.focusVisible&&row.outline!=='none'&&parseFloat(row.width)>0&&row.destination===wanted[i],label+': real Tab visible target '+i);records.push(row);
 }
 // Never click/Enter submit controls, change auto-submit language, submit,
 // requestSubmit, or follow export/deletion/logout/action destinations.
 const account=page.locator('header details.nav-menu.nav-end'),summary=account.locator('summary');await summary.focus();await page.keyboard.press('Enter');check(await account.evaluate(e=>e.open),label+': account menu keyboard open');await page.keyboard.press('Tab');
 const first=await account.locator('a').first().evaluate(e=>{const s=getComputedStyle(e);return{active:e===document.activeElement,focusVisible:e.matches(':focus-visible'),outline:s.outlineStyle,width:s.outlineWidth};});check(first.active&&first.focusVisible&&first.outline!=='none'&&parseFloat(first.width)>0,label+': account menu first link real Tab');records.push({firstAccount:first});await summary.focus();await page.keyboard.press('Enter');check(!await account.evaluate(e=>e.open),label+': account menu keyboard closed');return records;
}


// The functions above are the byte-exact reviewed literals, including real Tab,
// natural scroll and strict whole-document Axe with zero rule exclusions.
const dependencyRows=[['go',cli['--go'],true],['node',cli['--node'],true],['chrome',chrome,true],['axe_file',axeFile,false],['playwright_package',path.join(playwright,'package.json'),false]].map(([name,file,executable])=>({name,path:file,sha256:dependencyHash(file,executable)}));
assert.deepEqual(Object.fromEntries(dependencyRows.map(r=>[r.name,r.sha256])),C.binding_epoch.dependency_sha256);
sourceBefore=sourceAdmission();
// Once-read admission before any Playwright import/output. The SAME buffers
// serve both variants; later fixture/Axe edits cannot change a served response.
const externalBuffers=[{kind:'baselineCSS',path:inputs.before_CSS.path,raw:beforeCSS},{kind:'candidateCSS',path:inputs.candidate_CSS.path,raw:candidateCSS}];
const axeBuffer=regular(axeFile);assert.equal(hash(axeBuffer),C.binding_epoch.dependency_sha256.axe_file);externalBuffers.push({kind:'Axe',path:axeFile,raw:axeBuffer});
const states=new Map(manifest.states.map(s=>[s.name,s])),htmlBuffers=new Map();
for(const state of states.values()){const file=path.join(fixtures,state.name+'.html'),raw=regular(file);assert.equal(hash(raw),state.sha256);assert.equal(raw.length,state.bytes);assert.ok(!raw.includes(Buffer.from('PRIVATE-')));htmlBuffers.set(state.name,raw);externalBuffers.push({kind:'HTML:'+state.name,path:file,raw});}
const assetCache=new Map();for(const name of['static/css/base.css','static/js/hovercard.js','static/js/site.js','static/fonts/bricolage-grotesque-latin-wght-normal.woff2','static/fonts/bricolage-grotesque-latin-ext-wght-normal.woff2','services/server/internal/web/assets/meetups-worker.js'])assetCache.set(name,git('show',inputs.M+':'+name));
const asset=name=>{assert.ok(assetCache.has(name),'only admitted frozenM asset');return assetCache.get(name);};
const servedIdentities=externalBuffers.map(({kind,path,raw})=>({kind,path,bytes:raw.length,sha256:hash(raw)})).concat([...assetCache].map(([path,raw])=>({kind:'GitMasset',path,source:inputs.M,bytes:raw.length,sha256:hash(raw)})));
const require=createRequire(import.meta.url),{chromium}=require(playwright);
const {initialColorsEqualSettled}=await import(pathToFileURL(path.join(repo,'tools/gui-native-family/ui/color-stability.mjs')).href);
assert.equal(fs.realpathSync(scratch),scratch);assert.ok(scratch.includes('/_temp/')&&fs.statSync(scratch).uid===process.getuid());assert.equal(path.dirname(output),scratch);assert.ok(!fs.existsSync(output));fs.mkdirSync(output,{mode:0o700});
const report={schema:1,status:'RUNNING_NONQUALIFYING_DEBUG',scope:inputs.scope,inputsSHA256:hash(inputsRaw),sourceBefore,dependencyRows,servedIdentities,variants:[],requests:[],failures:[],cleanup:[]};
const check=(ok,message)=>{if(!ok)report.failures.push(message);};
let activeContext,activeServer,activeProfile,current='setup';
try{
 for(const variant of['baseline','candidate']){
  const rows=[],profile=fs.mkdtempSync(path.join(scratch,'d-')),ownership={variant,profile,contextClosed:false,profileRemoved:false,serverStopped:false};report.cleanup.push(ownership);activeProfile=profile;
  const css=variant==='baseline'?beforeCSS:candidateCSS;let base;
  const server=http.createServer((request,response)=>{
   const url=new URL(request.url,'http://fixture.invalid');report.requests.push({variant,state:current,method:request.method,path:url.pathname});
   if(request.method!=='GET'){check(false,current+': action request');response.writeHead(405);response.end();return;}
   try{
    let raw,type;
    if(url.pathname==='/qa/axe.js'){raw=axeBuffer;type='text/javascript; charset=utf-8';}
    else if(url.pathname==='/favicon.ico'){response.writeHead(204);response.end();return;}
    else if(url.pathname==='/static/css/account-center-native.css'){raw=css;type='text/css';}
    else if(url.pathname.startsWith('/static/')){const n=decodeURIComponent(url.pathname.slice(8));assert.ok(n&&!path.isAbsolute(n)&&!n.includes('\\')&&!n.split('/').includes('..'));raw=asset('static/'+n);type=n.endsWith('.css')?'text/css':n.endsWith('.js')?'text/javascript; charset=utf-8':n.endsWith('.woff2')?'font/woff2':'application/octet-stream';}
    else if(url.pathname==='/sw.js'){raw=asset('services/server/internal/web/assets/meetups-worker.js');type='text/javascript; charset=utf-8';}
    else{const m=/^\/preview\/([a-z-]+)\/$/.exec(url.pathname);assert.ok(m&&states.has(m[1]));const state=states.get(m[1]);raw=htmlBuffers.get(state.name);assert.ok(raw);type='text/html; charset=utf-8';for(const[n,v]of Object.entries(state.renderer_headers)){assert.ok(!/^set-cookie$/i.test(n));response.setHeader(n,v);}const mode=Object.keys(state.renderer_headers).find(n=>n.toLowerCase()==='content-security-policy')||Object.keys(state.renderer_headers).find(n=>n.toLowerCase()==='content-security-policy-report-only');assert.ok(mode);response.setHeader('Content-Security-Policy',state.renderer_headers[mode]);}
    response.setHeader('Content-Type',type);if(!response.hasHeader('Cache-Control'))response.setHeader('Cache-Control','private, no-store');response.setHeader('X-Content-Type-Options','nosniff');response.end(raw);
   }catch(error){check(false,current+': unadmitted path '+url.pathname);response.writeHead(404);response.end();}
  });activeServer=server;
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});base='http://127.0.0.1:'+server.address().port;
  const context=await chromium.launchPersistentContext(profile,{executablePath:chrome,headless:true,viewport:{width:1280,height:720},locale:'ro-RO',javaScriptEnabled:true});activeContext=context;
  await context.route('**/*',route=>{const local=new URL(route.request().url()).origin===base;check(local,current+': external request');return local?route.continue():route.abort();});
  await context.routeWebSocket(/.*/,socket=>{check(false,current+': WebSocket');void socket.close();});
  const page=context.pages()[0]||await context.newPage();page.on('pageerror',()=>check(false,current+': page error'));page.on('console',m=>{if(m.type()==='error'||/Content Security Policy|violates the following.*directive|Refused to .*directive|CSP/i.test(m.text()))check(false,current+': console/CSP error');});page.on('requestfailed',()=>check(false,current+': failed request'));
  for(const state of states.values()){
   current=variant+':'+state.name;const label=current;await page.goto(base+'/preview/'+state.name+'/',{waitUntil:'networkidle'});await page.evaluate(()=>document.fonts.ready);
   const keyboard=await keyboardChecks(page,state,label);await page.addScriptTag({url:base+'/qa/axe.js'});await page.evaluate(()=>{for(const d of document.querySelectorAll('details'))d.open=true;});
   const steady=await settleAndColors(page);check(initialColorsEqualSettled(steady.before,steady.after)&&!steady.remainingAnimations,label+': color settling');
   const audits=[];
   for(const mode of['all-open','header-closed','header-keyboard-open']){
    if(mode==='header-closed')await page.evaluate(()=>{for(const e of document.querySelectorAll('header details'))e.open=false;});
    if(mode==='header-keyboard-open'){const summary=page.locator('header details.nav-menu.nav-end > summary');await summary.focus();await page.keyboard.press('Enter');check(await summary.evaluate(e=>e.parentElement.open),label+': keyboard-open audit');}
    if(mode!=='all-open')await settleAndColors(page);const axe=await audit(page),screenshot=variant+'-'+state.name+'-'+mode+'.png';
    const geometry=await page.evaluate(()=>{const h=document.querySelector('header'),p=document.querySelector('header .nav-panel'),c=document.querySelector('.card-danger > .muted'),row=e=>{if(!e)return null;const r=e.getBoundingClientRect(),s=getComputedStyle(e);return{x:r.x,y:r.y,width:r.width,height:r.height,position:s.position,background:s.backgroundColor};};return{scroll:{x:scrollX,y:scrollY},header:row(h),panel:row(p),dangerParagraph:row(c),overflow:document.documentElement.scrollWidth-innerWidth};});
    await page.screenshot({path:path.join(output,screenshot),fullPage:false});audits.push({mode,axe,geometry,screenshot,screenshotSHA256:hash(regular(path.join(output,screenshot)))});
   }
   rows.push({name:state.name,keyboard,steady,audits});
  }
  await context.close();activeContext=null;ownership.contextClosed=true;await new Promise(resolve=>server.close(resolve));activeServer=null;ownership.serverStopped=!server.listening;fs.rmSync(profile,{recursive:true,force:false});ownership.profileRemoved=!fs.existsSync(profile);activeProfile=null;
  report.variants.push({name:variant,CSS_sha256:hash(css),states:rows});
 }
 const bad=v=>v.states.flatMap(st=>st.audits.filter(a=>a.axe.incomplete.length).map(a=>({state:st.name,mode:a.mode,ids:a.axe.incomplete.map(x=>x.id),nodes:a.axe.incomplete.reduce((n,x)=>n+x.nodes.length,0)})));
 assert.deepEqual(bad(report.variants[0]),inputs.baseline_expected_bad,'baseline must reproduce original15 incomplete audits/54nodes');
 check(report.variants.length===2&&report.variants.every(v=>v.states.length===8&&v.states.every(s=>s.audits.length===3)),'complete48audits');
 check(report.variants.every(v=>v.states.every(s=>s.audits.every(a=>!a.axe.violations.length))),'actual violation');check(bad(report.variants[1]).length===0,'candidate still incomplete');
}catch(error){report.failures.push(String(error));}
finally{
 if(activeContext){try{await activeContext.close();report.cleanup.at(-1).contextClosed=true;activeContext=null;}catch(error){check(false,'owned context close failed');}}
 if(activeServer){if(activeServer.listening)await new Promise(resolve=>activeServer.close(resolve));report.cleanup.at(-1).serverStopped=!activeServer.listening;}
 if(activeProfile&&report.cleanup.at(-1).contextClosed){try{fs.rmSync(activeProfile,{recursive:true,force:false});report.cleanup.at(-1).profileRemoved=!fs.existsSync(activeProfile);}catch(error){check(false,'owned profile cleanup failed');}}
 try{report.sourceAfter=fence();assert.deepEqual(report.sourceAfter,sourceBefore);}catch(error){check(false,'source changed during debug');}
 try{
  // Final admitted registry fence: memory and original external bytes must
  // still equal the identities used by both variants; drift fails closed.
  for(const row of externalBuffers){const admitted=servedIdentities.find(r=>r.kind===row.kind);assert.equal(hash(row.raw),admitted.sha256);assert.deepEqual(regular(row.path),row.raw);}
  for(const[name,raw]of assetCache)assert.equal(hash(raw),servedIdentities.find(r=>r.kind==='GitMasset'&&r.path===name).sha256);
  report.servedRegistryUnchanged=true;
 }catch(error){report.servedRegistryUnchanged=false;check(false,'admitted served input registry changed');}
 check(report.requests.every(r=>r.method==='GET'),'action request');check(report.cleanup.length===2&&report.cleanup.every(r=>r.contextClosed&&r.profileRemoved&&r.serverStopped),'owned cleanup incomplete');
 report.status=report.failures.length?'DEBUG_FAILED_NO_QUALIFICATION':'PAIRED_DEBUG_EXPECTATIONS_MET_NOT_QUALIFICATION';fs.writeFileSync(path.join(output,'result.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({status:report.status,variants:report.variants.length,audits:report.variants.reduce((n,v)=>n+v.states.reduce((n,s)=>n+s.audits.length,0),0),failures:report.failures,resultSHA256:hash(regular(path.join(output,'result.json')))}));if(report.failures.length)process.exitCode=1;
}
