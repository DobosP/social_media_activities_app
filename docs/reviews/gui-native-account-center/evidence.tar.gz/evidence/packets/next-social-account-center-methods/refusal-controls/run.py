#!/usr/bin/env python3
"""Fourteen synthetic negative-admission controls; never product qualification."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import stat
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
PACKET = HERE.parent
METHOD = PACKET / "files/tools/gui-native-account-center"
METHOD_REVIEW = "349c71b57db77a97f4565c86d12c7c490be787a754e881d5340bd8b41d7e7596"
METHOD_HASHES = {
    "qualify.py": "41eff00431eeae4212eb83f11434ac080c6fe5e3d2e45c2de0dac901d3b1f97f",
    "desktop-qa.mjs": "d22bbc4c27b4a0427d1af7c52d6804042c7223298ddfbe72394ea1d73b197fc4",
    "export_test.go.txt": "3ee2024b740899073bc2ec723b5fb3d45b3a5da7d98492cdba1f6ed022dd69dc",
    "source-bindings.json": "063f745826c0d6fbc3a3776bd8968c18b0636b413beec007eda91e46380ab18b",
}
SOURCE = "1" * 40  # Explicitly synthetic; no Git repository exists in a fixture.
CLOSING = "2" * 40


def need(ok, message):
    if not ok:
        raise ValueError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def regular(path, limit=256 << 20):
    need(path.is_absolute() and path.resolve() == path, "unalias absolute input")
    before = path.lstat()
    need(stat.S_ISREG(before.st_mode) and before.st_nlink == 1 and before.st_size <= limit, "bounded single-link file")
    with path.open("rb") as stream:
        raw = stream.read(limit + 1)
        after = os.fstat(stream.fileno())
    keys = ("st_dev", "st_ino", "st_mode", "st_uid", "st_gid", "st_size", "st_mtime_ns", "st_ctime_ns", "st_nlink")
    need(len(raw) == before.st_size <= limit and all(getattr(before, key) == getattr(after, key) for key in keys), "input changed")
    return raw


def scalars(value):
    if isinstance(value, str): return {value}
    if isinstance(value, dict): return set().union(*(scalars(item) for item in value.values()), set())
    if isinstance(value, list): return set().union(*(scalars(item) for item in value), set())
    return set()


def write(path, raw, executable=False):
    with path.open("xb") as stream:
        stream.write(raw)
    path.chmod(0o700 if executable else 0o600)


def command(argv, cwd, output, name):
    stdout, stderr = output / (name + ".stdout"), output / (name + ".stderr")
    with stdout.open("xb") as out, stderr.open("xb") as err:
        child = subprocess.Popen([str(item) for item in argv], cwd=cwd, stdout=out, stderr=err,
                                 env={"PATH": os.defpath, "LANG": "C.UTF-8", "LC_ALL": "C.UTF-8"}, start_new_session=True)
        timeout = False
        try:
            code = child.wait(timeout=15)
        except subprocess.TimeoutExpired:
            timeout = True
            os.killpg(child.pid, signal.SIGTERM)
            try:
                child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait(timeout=5)
            code = child.returncode
        except BaseException:
            os.killpg(child.pid, signal.SIGTERM)
            try:
                child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait(timeout=5)
            raise
    return {"argv": [str(item) for item in argv], "cwd": str(cwd), "pid": child.pid,
            "owned_process_group": child.pid, "waited": True, "exit_code": code, "timed_out": timeout,
            "stdout": {"path": stdout.name, "sha256": digest(regular(stdout)), "bytes": stdout.stat().st_size},
            "stderr": {"path": stderr.name, "sha256": digest(regular(stderr)), "bytes": stderr.stat().st_size}}


def fixture(case, root, node, originals):
    base = root / case["id"].lower()
    repo = base / "repo"
    tools = repo / "tools/gui-native-account-center"
    tools.mkdir(parents=True)
    for name, raw in originals.items():
        if name != "source-bindings.json": write(tools / name, raw)
    helper = repo / "tools/gui-native-family/ui"
    helper.mkdir(parents=True)
    write(helper / "color-stability.mjs", b"globalThis.__accountRefusalSentinel('local-color-helper');\nexport function initialColorsEqualSettled(){throw new Error('not a real helper');}\n")
    deps = base / "deps"
    deps.mkdir()
    for name in ("go", "node", "chrome"):
        write(deps / name, ("#!/bin/sh\n# Negative "+name+" fixture sentinel; never executed.\nexit 91\n").encode(), executable=True)
    write(deps / "axe.js", b"throw new Error('negative fixture Axe sentinel; never executed');\n")
    playwright = deps / "playwright"
    playwright.mkdir()
    write(playwright / "package.json", b'{"name":"negative-account-refusal-fixture","version":"0.0.0","main":"index.cjs","private":true}\n')
    write(playwright / "index.cjs", b"globalThis.__accountRefusalSentinel('caller-playwright');\nthrow new Error('not real Playwright');\n")
    for name in ("cache", "modcache", "scratch"):
        (base / name).mkdir()
    actual_node = node if case["entry"] == "node" else deps / "node"
    paths = {"go": deps / "go", "node": actual_node, "chrome": deps / "chrome",
             "axe_file": deps / "axe.js", "playwright_package": playwright / "package.json"}
    admitted = {name: digest(regular(path)) for name, path in paths.items()}
    config = json.loads(originals["source-bindings.json"])
    config.update(control_fixture={"negative_only": True, "not_actual_source": True,
                                   "never_product_or_accepted_binding": True, "case": case["id"]},
                  producer_source=SOURCE, date_publication_source=CLOSING, dependency_sha256=dict(admitted))
    if case["kind"] != "unbound":
        # Deliberately get only as far as the mismatching hash. All actual
        # source/result/review identities stay null and no Git exists here.
        config["status"] = "BOUND_REVIEWED_COMMITTED_METHODS"
    if case["kind"] == "hash":
        config["dependency_sha256"][case["dependency"]] = "0" * 64
    write(tools / "source-bindings.json", (json.dumps(config, indent=2) + "\n").encode())
    metadata = {"negative_only": True, "no_Git_DB_or_workspace": True, "source_hint": SOURCE,
                "method_rows": [{"path": name, "sha256": digest(raw)} for name, raw in originals.items() if name != "source-bindings.json"],
                "synthetic_binding_sha256": digest(regular(tools / "source-bindings.json")),
                "hashes_before_single_planned_mismatch": admitted}
    write(base / "NEGATIVE_FIXTURE_ONLY.json", (json.dumps(metadata, indent=2) + "\n").encode())
    return base, repo, tools, playwright, paths, metadata


def cases():
    rows = [{"id": "PYTHON_UNBOUND_FULL", "entry": "python", "kind": "unbound"},
            {"id": "PYTHON_UNBOUND_CHECK_BRIDGE", "entry": "python", "kind": "unbound", "bridge": True},
            {"id": "DESKTOP_UNBOUND_DIRECT", "entry": "node", "kind": "unbound"}]
    for dependency in ("go", "node", "chrome", "axe_file", "playwright_package"):
        for entry in ("python", "node"):
            rows.append({"id": ("PYTHON" if entry == "python" else "DESKTOP") + "_MISMATCH_" + dependency.upper(),
                         "entry": entry, "kind": "hash", "dependency": dependency})
    rows.append({"id": "DESKTOP_ACTUAL_NODE_MISMATCH", "entry": "node", "kind": "node-identity"})
    need(len(rows) == 14, "finite fourteen controls only")
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--node", type=Path, required=True)
    parser.add_argument("--scratch", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--admission", type=Path, required=True)
    parser.add_argument("--admission-sha256", required=True)
    args = parser.parse_args()
    need(Path(__file__).resolve() == HERE / "run.py", "literal control source")
    method_review = regular(PACKET / "v2-method-source-review.json")
    review = json.loads(method_review)
    need(digest(method_review) == METHOD_REVIEW and review["findings"] == []
         and review["status"] == "V2_PRELIMINARY_METHOD_REPAIR_ACCEPTED_PENDING_FINAL_BINDINGS_AND_CONTROLS", "independent exact349c source admission")
    originals = {name: regular(METHOD / name) for name in METHOD_HASHES}
    need(all(digest(raw) == METHOD_HASHES[name] for name, raw in originals.items()), "four exact reviewed V2 images including still-disabled real bindings")
    source_files = {name: regular(HERE / name) for name in ("run.py", "python-observer.py", "node-observer.cjs")}
    admission_raw = regular(args.admission)
    admission = json.loads(admission_raw)
    status = admission.get("verdict", admission.get("status", ""))
    need(re.fullmatch("[0-9a-f]{64}", args.admission_sha256) and digest(admission_raw) == args.admission_sha256
         and isinstance(status, str) and "ACCEPT" in status and "NOT_ACCEPTED" not in status and admission.get("findings") == []
         and {METHOD_REVIEW, *[digest(raw) for raw in source_files.values()]}.issubset(scalars(admission)), "independent exact control-source approval before fixtures/children/output")
    need(args.node.is_absolute() and args.node.resolve() == args.node and os.access(args.node, os.X_OK), "explicit canonical installed Node")
    node_digest = digest(regular(args.node))
    python = Path(sys.executable).resolve()
    python_digest = digest(regular(python))
    need(args.scratch.is_absolute() and args.scratch.resolve() == args.scratch and args.scratch.is_dir()
         and args.scratch.stat().st_uid == os.getuid() and "_temp" in args.scratch.parts, "existing owned task scratch")
    need(args.output.parent == args.scratch and args.output.resolve() == args.output and not os.path.lexists(args.output), "fresh literal control output")
    declared = json.loads(regular(PACKET / "CONTROL_PLAN.json"))
    matrix = cases()
    need([row["id"] for row in matrix] == [row["id"] for row in declared["cases"]], "exact accepted fourteen declared cases")
    disk_before = dict(zip(("total", "used", "free"), shutil.disk_usage(args.scratch)))
    args.output.mkdir(mode=0o700)
    temporary = Path(tempfile.mkdtemp(prefix="ac-refusal-", dir=args.scratch))
    report = {"schema": 1, "status": "RUNNING_NEGATIVE_CONTROLS_ONLY", "method_review_sha256": METHOD_REVIEW,
              "control_source_admission_sha256": args.admission_sha256, "control_source": {name: digest(raw) for name, raw in source_files.items()},
              "method_images": METHOD_HASHES, "runtime_executables": {"python": {"path": str(python), "sha256": python_digest}, "node": {"path": str(args.node), "sha256": node_digest}},
              "cases": [], "failures": [], "disk_before": disk_before,
              "fixture": {"path": str(temporary), "owned_exclusive": True, "removed": False},
              "scope": "Synthetic negative refusals only. No product qualification, actual account input, Git/DB/workspace copy, real Go/Chrome/Playwright, browser, benchmark or provider run."}
    try:
        for case in matrix:
            base, repo, tools, playwright, paths, metadata = fixture(case, temporary, args.node, originals)
            trace_path = args.output / (case["id"] + ".trace.json")
            common = ["--repo", repo, "--producer-source", SOURCE]
            if case["entry"] == "python":
                options = common + (["--check-bridge"] if case.get("bridge") else [
                    "--scratch", base / "scratch", "--go", paths["go"], "--node", paths["node"], "--cache", base / "cache", "--modcache", base / "modcache",
                    "--playwright-package", playwright, "--axe-file", paths["axe_file"], "--chrome", paths["chrome"], "--pg-run", base / "NOT_A_REAL_PG_RUN"])
                argv = [python, "-I", "-B", HERE / "python-observer.py", "--trace", trace_path, "--method", tools / "qualify.py", "--", *options]
                expected = "unbound draft refuses before output, child command or dependency import" if case["kind"] == "unbound" else "all exact reviewed Go/Node/Chrome/Axe/Playwright input identities required before process/output"
            else:
                node_argument = base / "deps/node" if case["kind"] == "node-identity" else args.node
                argv = [args.node, "--require", HERE / "node-observer.cjs", tools / "desktop-qa.mjs", *common,
                        "--fixtures", base / "scratch", "--output", base / "scratch/desktop-output", "--baseline-proof", base / "NOT_A_REAL_BASELINE",
                        "--playwright-package", playwright, "--axe-file", paths["axe_file"], "--chrome", paths["chrome"],
                        "--go", paths["go"], "--node", node_argument, "--control-trace", trace_path]
                expected = ("BOUND_REVIEWED_COMMITTED_METHODS" if case["kind"] == "unbound" else
                            "explicit Node must be the actual executing interpreter" if case["kind"] == "node-identity" else
                            "all five reviewed inputs must match before any child/module/output")
            row = command(argv, base, args.output, case["id"])
            trace_raw = regular(trace_path)
            trace = json.loads(trace_raw)
            unchanged = all(regular(tools / name) == raw for name, raw in originals.items() if name != "source-bindings.json") and digest(regular(tools / "source-bindings.json")) == metadata["synthetic_binding_sha256"]
            no_effect = trace["forbidden"] == [] and trace.get("sentinels", []) == [] and list((base / "scratch").iterdir()) == []
            passed = row["waited"] and row["exit_code"] == 1 and not row["timed_out"] and expected in regular(args.output / row["stderr"]["path"]).decode() and no_effect and unchanged
            report["cases"].append({"id": case["id"], "pass": passed, "expected_original_guard": expected, "command": row,
                                    "trace": {"path": trace_path.name, "sha256": digest(trace_raw), "permitted_read_events": len(trace["reads"]), "forbidden_events": len(trace["forbidden"]), "sentinel_imports": len(trace.get("sentinels", []))},
                                    "zero_forbidden_effects": no_effect, "method_copy_unchanged": unchanged, "negative_fixture": metadata})
            if not passed: report["failures"].append(case["id"] + ": exact original refusal/zero-forbidden-effect proof failed")
        need(len(report["cases"]) == 14, "all controls actually completed")
    except BaseException as error:
        report["failures"].append(type(error).__name__ + ": " + str(error))
        raise
    finally:
        # No owning source/setup/cache is eligible. Every fixture child was
        # waited. Refuse cleanup if an unexpected symlink or foreign inode
        # appears; keep exact evidence for review instead of following it.
        try:
            need(temporary.parent == args.scratch and temporary.name.startswith("ac-refusal-")
                 and temporary.resolve() == temporary and temporary.stat().st_uid == os.getuid(), "exact owned fixture namespace")
            for path in temporary.rglob("*"):
                need(not path.is_symlink() and path.lstat().st_uid == os.getuid(), "unexpected fixture symlink/owner; retain")
            shutil.rmtree(temporary)
            report["fixture"]["removed"] = not temporary.exists()
        except BaseException as error:
            report["failures"].append("owned fixture cleanup: " + str(error))
        report["original_method_images_unchanged"] = all(regular(METHOD / name) == raw for name, raw in originals.items())
        if not report["original_method_images_unchanged"]: report["failures"].append("original method source drift")
        report["status"] = "PASS_FOURTEEN_SYNTHETIC_NEGATIVE_REFUSALS_ONLY" if len(report["cases"]) == 14 and not report["failures"] and report["fixture"]["removed"] else "FAIL_NEGATIVE_CONTROLS_ONLY"
        raw = (json.dumps(report, indent=2) + "\n").encode()
        write(args.output / "result.json", raw)
        print(json.dumps({"status": report["status"], "cases": len(report["cases"]), "result_sha256": digest(raw), "fixture_removed": report["fixture"]["removed"]}))
    return 0 if not report["failures"] else 1


if __name__ == "__main__":
    sys.exit(main())
