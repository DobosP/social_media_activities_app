#!/usr/bin/env python3
"""Control-only runpy observer. Guard exceptions propagate; no production input."""
import argparse
import decimal
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import runpy
import shutil
import signal
import stat
import subprocess
import sys
import tarfile
import tempfile
import uuid


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--trace", type=Path, required=True)
    parser.add_argument("--method", type=Path, required=True)
    parser.add_argument("method_args", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    if not args.method_args or args.method_args[0] != "--":
        raise ValueError("explicit method-argument separator required")
    # This observer's descriptor is opened before the hook. After installation
    # only os.write on that descriptor may retain the observer's own trace.
    descriptor = os.open(args.trace, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    trace = {"schema": 1, "control_only": True, "reads": [], "forbidden": [],
             "method_started": False, "guard_errors_swallowed": False}
    sys.dont_write_bytecode = True
    write_flags = os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND
    denied = {"subprocess.Popen", "os.system", "os.posix_spawn", "os.posix_spawnp",
              "os.exec", "os.fork", "os.forkpty", "os.mkdir", "os.remove",
              "os.rmdir", "os.rename", "os.link", "os.symlink", "os.truncate",
              "os.chmod", "os.chown", "os.utime"}

    def audit(event, values):
        if event == "open":
            name, mode, flags = values
            if flags & write_flags or isinstance(mode, str) and any(c in mode for c in "wax+"):
                trace["forbidden"].append({"event": event, "path": str(name), "mode": mode, "flags": flags})
                raise RuntimeError("CONTROL_BLOCKED_WRITE_BEFORE_EXECUTION")
            trace["reads"].append({"event": event, "path": str(name)})
        elif event in denied:
            trace["forbidden"].append({"event": event, "arguments": [str(value) for value in values]})
            raise RuntimeError("CONTROL_BLOCKED_SIDE_EFFECT_BEFORE_EXECUTION")

    sys.addaudithook(audit)
    sys.argv = [str(args.method), *args.method_args[1:]]
    try:
        trace["method_started"] = True
        # Exact copied source, original __main__, real argv. Do not catch,
        # replace, turn off, or turn a refused guard into a successful return.
        runpy.run_path(str(args.method), run_name="__main__")
    finally:
        raw = (json.dumps(trace, separators=(",", ":")) + "\n").encode()
        position = 0
        while position < len(raw):
            position += os.write(descriptor, raw[position:])
        os.close(descriptor)


if __name__ == "__main__":
    main()
