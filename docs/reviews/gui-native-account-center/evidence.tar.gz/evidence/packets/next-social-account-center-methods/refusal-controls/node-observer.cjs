'use strict';
// Control-only preload, before the exact copied ESM entry. Original guard
// exceptions remain fatal; uncaughtExceptionMonitor never handles the error.
const fs=require('node:fs'),child=require('node:child_process'),Module=require('node:module');
const index=process.argv.indexOf('--control-trace');
if(index<0||!process.argv[index+1])throw new Error('explicit control trace argv required');
const tracePath=process.argv[index+1],fd=fs.openSync(tracePath,'wx',0o600);
const write=fs.writeSync.bind(fs),close=fs.closeSync.bind(fs);
const trace={schema:1,control_only:true,reads:[],forbidden:[],sentinels:[],guardErrorsSwallowed:false};
const deny=(event,args)=>{trace.forbidden.push({event,arguments:args.map(value=>typeof value==='string'?value:typeof value)});throw new Error('CONTROL_BLOCKED_SIDE_EFFECT_BEFORE_EXECUTION');};
for(const name of['spawn','spawnSync','exec','execSync','execFile','execFileSync','fork']){
 child[name]=function(...args){return deny('child_process.'+name,args);};
}
for(const name of['mkdir','mkdirSync','mkdtemp','mkdtempSync','writeFile','writeFileSync','appendFile','appendFileSync','createWriteStream','rm','rmSync','rmdir','rmdirSync','unlink','unlinkSync','rename','renameSync','link','linkSync','symlink','symlinkSync','truncate','truncateSync','chmod','chmodSync','chown','chownSync','utimes','utimesSync','copyFile','copyFileSync','cp','cpSync']){
 fs[name]=function(...args){return deny('fs.'+name,args);};
}
const open=fs.openSync.bind(fs),read=fs.readFileSync.bind(fs);
fs.openSync=function(file,flags,...args){
 const writable=typeof flags==='number'?(flags&(fs.constants.O_WRONLY|fs.constants.O_RDWR|fs.constants.O_CREAT|fs.constants.O_TRUNC|fs.constants.O_APPEND)):/[wax+]/.test(flags);
 if(writable)return deny('fs.openSync.write',[file,flags]);trace.reads.push({event:'fs.openSync',path:String(file)});return open(file,flags,...args);
};
fs.readFileSync=function(file,...args){trace.reads.push({event:'fs.readFileSync',path:String(file)});return read(file,...args);};
for(const name of['mkdir','mkdtemp','writeFile','appendFile','rm','rmdir','unlink','rename','link','symlink','truncate','chmod','chown','utimes','copyFile','cp']){
 fs.promises[name]=function(...args){return deny('fs.promises.'+name,args);};
}
const promiseOpen=fs.promises.open.bind(fs.promises),asyncOpen=fs.open.bind(fs);
const writing=flags=>typeof flags==='number'?(flags&(fs.constants.O_WRONLY|fs.constants.O_RDWR|fs.constants.O_CREAT|fs.constants.O_TRUNC|fs.constants.O_APPEND)):/[wax+]/.test(flags);
fs.promises.open=function(file,flags,...args){if(writing(flags))return deny('fs.promises.open.write',[file,flags]);trace.reads.push({event:'fs.promises.open',path:String(file)});return promiseOpen(file,flags,...args);};
fs.open=function(file,flags,...args){if(writing(flags))return deny('fs.open.write',[file,flags]);trace.reads.push({event:'fs.open',path:String(file)});return asyncOpen(file,flags,...args);};
const load=Module._load;
Module._load=function(request,parent,isMain){
 if(request.startsWith('node:')||Module.builtinModules.includes(request))return load.call(this,request,parent,isMain);
 if(isMain&&request===process.argv[1])return load.call(this,request,parent,isMain);
 trace.forbidden.push({event:'Module._load.external',request});throw new Error('CONTROL_BLOCKED_EXTERNAL_REQUIRE');
};
globalThis.__accountRefusalSentinel=name=>{trace.sentinels.push(name);throw new Error('CONTROL_SENTINEL_MODULE_EXECUTED');};
Module.syncBuiltinESMExports();
process.on('uncaughtExceptionMonitor',error=>{trace.error={name:error.name,message:error.message};});
process.on('exit',()=>{
 const raw=Buffer.from(JSON.stringify(trace)+'\n');let offset=0;
 while(offset<raw.length)offset+=write(fd,raw,offset,raw.length-offset);close(fd);
});
