Fourteen account-method negative admission controls — SOURCE ONLY

This runner has NOT been parsed, imported or executed by its author. Independent source review must precede any control execution. The actual accepted V2 methods remain exact349c source; no production method source, real binding, original old helper, owning checkout or product runtime is edited.

run.py requires the exact independent349c method review and exact four V2 image hashes. It additionally requires a separate accepted control-source review JSON/path/SHA containing all three control-code hashes and349c before creating output, fixtures or children. The real source-bindings image remains disabled/null.

The runner creates one exclusive tiny _temp namespace containing14 finite synthetic fixture directories, tools files, sentinel files and empty cache/scratch dirs only. No Git, actual workspace, node_modules, DB, source export, account capture, baseline archive or authentic account input is copied/read. Every fixture has NEGATIVE_FIXTURE_ONLY.json and control_fixture metadata. Hash-mismatch fixtures use the method's bound-status spelling only to reach the negative guard; all actual source/PG/review values remain null, source/closing are synthetic111/222, there is no Git and hooks refuse every candidate child before execution. These are never accepted production/source bindings.

Python controls use exact copied qualify.py under an isolated -I -B runpy observer. Its audit hook records reads and blocks every candidate subprocess/mkdir/write/remove before execution. The trace FD is opened by the observer before the hook and written directly afterward. Original guard exceptions propagate untouched and remain child exit1 with original stderr. It does not monkeypatch or suppress any method guard.

Standalone Node controls use actual installed Node and a builtin-only preload. It synchronizes patched builtin child-process exports, logs/refuses candidate children and filesystem creation/writes, and blocks external CJS loads. The exact copied desktop source is the admitted target, not an external dependency. A sentinel local color helper and fake Playwright entry call a monitored sentinel if ESM/CJS execution is reached. Global monitor does not catch uncaught exceptions; original guard errors stay fatal. Direct cases hash and pass the actual running Node; the Python driver's Node, Go and Chrome inputs are inert shell sentinels. Other dependency files are synthetic. No real Go, Chrome, Playwright, browser or model executes.

The14 cases are the exact outer CONTROL_PLAN: Python unbound full and bridge, standalone Node unbound, five individual dependency mismatches in each entry, and a direct Node interpreter mismatch. Each requires waited exit1, its original refusal text, zero candidate forbidden events/sentinel imports/output, immutable copied source and unchanged synthetic binding. The parent control runner returns0 only if all14 negative controls pass. A safety-hook refusal is a control failure, not a guard pass.

Timeouts stop and wait only the owned child process group. Fixture cleanup follows all waits, checks exact ownership and refuses unexpected symlinks/foreign owners. It removes only the exclusive ac-refusal-* namespace; compact14stdout/stderr/trace files plus result.json remain in the separately specified output. No new environment variable names are introduced: trace paths are argv; child environment uses only existing PATH/LANG/LC_ALL.

After independent source review, Root may run using the actual installed Node, an existing task-owned _temp scratch and a fresh output child:

python3 -I -B /home/dobo/work/_temp/feat__gui-app-migration-a/social-family/next-social-account-center-methods/refusal-controls/run.py --node /absolute/installed/node --scratch /absolute/owned/_temp/control-scratch --output /absolute/owned/_temp/control-scratch/first-14-controls --admission /absolute/accepted-control-source-review.json --admission-sha256 FULL_SHA256

Root must retain actual exit/streams, then request independent actual control review. Source approval and these negative controls establish neither positive source admission nor account/PG/UI/benchmark acceptance.
