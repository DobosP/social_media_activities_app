"""Read only one completed exact-R primary UI run; never import/run product code.

Invocation after Root terminal only:
python3 -I THIS.py RUN ACTUAL_M2_SHA ACTUAL_RESULT_SHA ROOT_TERMINAL_JSON
Prints compact evidence/metrics JSON to stdout; caller retains stdout/stderr.
"""
import collections
from decimal import Decimal
import hashlib
import json
import pathlib
import re
import statistics
import struct
import subprocess
import sys
import tarfile

R = '02ac07258cca866180ef93aeeb6a17ecb07baae1'
PG_SHA = '856b0b3beb1d3b5d9cd784c067b27dd67e3ccca876f94607361abf920829962e'
PG_REVIEW = '82b01e1a3487d46f86af31cd6b76b3959c216b58c21ff99dcace2836ac4c584b'
BASE_SHA = 'bc10a80ae1a9b0f404e9434f2a0065d941a0cb4a336d5ea06eb39032da09c7ea'
BASE_MANIFEST = '2787ff123c6b333d5aeed9650c22cdab92b8e2a76f189085a4eb52c5f3bc21d4'
BASE_UI = '/home/dobo/work/_temp/ni-ui/run-0afd29b79fec-5cec58a3-f1b8-4e1a-b683-d959e6b9ca59'
STATES = ['overview-basic-en', 'overview-guardian-ro', 'overview-ward-connections-en', 'overview-escaped-ro', 'settings-no-token-en', 'settings-token-ro', 'settings-expired-record-en', 'settings-revoke-error-ro']
CODE = {'qualify.py': '41eff00431eeae4212eb83f11434ac080c6fe5e3d2e45c2de0dac901d3b1f97f', 'desktop-qa.mjs': 'd22bbc4c27b4a0427d1af7c52d6804042c7223298ddfbe72394ea1d73b197fc4', 'export_test.go.txt': '3ee2024b740899073bc2ec723b5fb3d45b3a5da7d98492cdba1f6ed022dd69dc'}
NATIVE = {'services/server/internal/web/account_center_native.go': '91368882d286d052e14fa586abfe2e6ce30f555c4605a81967c861ca40c62e3f', 'services/server/internal/web/pages/account-center.gohtml': '6370bd3f0a800fe86811e986f004dc8023683464ad53b16707da9e3e1c273446', 'services/server/internal/web/account_center_native_test.go': 'f3f85548d60abf767fd860faa10f9698ae8f9e363653dc142a52ff8715638cf1', 'static/css/account-center-native.css': 'a403375bbc41d376bd5e9568614694bc932be51af50b0004792e029e5d75c7cf'}


def raw(path):
    path = pathlib.Path(path)
    assert path.is_absolute() and path.resolve() == path and path.is_file() and not path.is_symlink()
    return path.read_bytes()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def file_sha(path):
    path = pathlib.Path(path)
    assert path.resolve() == path and path.is_file() and not path.is_symlink()
    result = hashlib.sha256()
    with path.open('rb') as stream:
        while chunk := stream.read(1 << 20):
            result.update(chunk)
    return result.hexdigest()


def load(path):
    return json.loads(raw(path))


def scalars(value):
    if isinstance(value, str):
        return [value]
    if isinstance(value, dict):
        return [s for v in value.values() for s in scalars(v)]
    if isinstance(value, list):
        return [s for v in value for s in scalars(v)]
    return []


def accepted(spec, required):
    value = load(spec['path'])
    assert file_sha(spec['path']) == spec['sha256'] and value[spec['field']] == spec['expected']
    assert spec['expected'].startswith('ACCEPT') and value['findings'] == []
    assert set(required) <= set(scalars(value))
    return value


def main():
    run = pathlib.Path(sys.argv[1]).resolve(strict=True)
    method_sha, result_sha = sys.argv[2:4]
    terminal_path = pathlib.Path(sys.argv[4]).resolve(strict=True)
    assert re.fullmatch('[a-f0-9]{40}', method_sha) and re.fullmatch('[a-f0-9]{64}', result_sha)
    report = load(run / 'result.json')
    assert file_sha(run / 'result.json') == result_sha and report['status'] == 'FAIL' and report['failures'] == ['benchmark failed; retain exact streams']
    terminal = load(terminal_path)
    assert terminal['waited_exit'] == 1
    terminal_values = scalars(terminal)
    for stream in terminal['streams']:
        assert file_sha(stream['path']) == stream['sha256'] and len(raw(stream['path'])) == stream['bytes']
        for line in raw(stream['path']).splitlines():
            try:
                terminal_values += scalars(json.loads(line))
            except (ValueError, UnicodeDecodeError):
                pass
    assert result_sha in terminal_values and str(run) in terminal_values
    repo = pathlib.Path('/home/dobo/work/_worktrees/social_media_activities_app/feat__gui-app-migration-a')
    git = lambda *args: subprocess.check_output(['git', '-C', str(repo), *args])
    assert git('rev-parse', 'HEAD').decode().strip() == method_sha and not git('status', '--porcelain', '--untracked-files=all')
    assert report['PG_producer_source'] == R and report['UI_method_source'] == method_sha
    methods = {'tools/gui-native-account-center/' + n for n in (*CODE, 'README.md', 'source-bindings.json')}
    allowed = methods | {'STATUS.md', 'docs/execplans/gui-native-account-center.md'}
    changed = git('diff', '--name-only', '--no-renames', R, method_sha).decode().splitlines()
    assert set(changed) <= allowed
    binding = load(repo / 'tools/gui-native-account-center/source-bindings.json')
    assert binding['status'] == 'BOUND_REVIEWED_COMMITTED_METHODS' and binding['producer_source'] == R
    assert binding['complete7_result_sha256'] == PG_SHA
    assert binding['complete7_review']['sha256'] == binding['native_account_source_review']['sha256'] == PG_REVIEW
    accepted(binding['complete7_review'], [R, PG_SHA, *NATIVE.values()])
    accepted(binding['native_account_source_review'], list(NATIVE.values()))
    accepted(binding['method_source_review'], list(CODE.values()))
    for n, h in CODE.items():
        assert file_sha(repo / 'tools/gui-native-account-center' / n) == h
    for n, h in NATIVE.items():
        assert file_sha(repo / n) == digest(git('show', R + ':' + n)) == h
    for row in binding['unchanged_overlay_helpers']:
        assert file_sha(repo / row['path']) == digest(git('show', R + ':' + row['path'])) == row['sha256']
    assert len(binding['unchanged_overlay_helpers']) == 5
    for row in report['committed_method']:
        assert row['path'] in methods and raw(repo / row['path']) == git('show', method_sha + ':' + row['path'])
        assert file_sha(repo / row['path']) == row['sha256'] and len(raw(repo / row['path'])) == row['bytes']
    assert {r['path'] for r in report['committed_method']} == methods
    dependencies = report['admitted_dependencies_before_output_or_process']
    assert dependencies == report['explicit_dependencies'] and len(dependencies) == 5
    assert {r['name']: r['sha256'] for r in dependencies} == binding['dependency_sha256']
    for row in dependencies:
        assert file_sha(row['path']) == row['sha256']
    dep = {r['name']: r['path'] for r in dependencies}
    pg = report['qualified_PG']
    assert pg['source'] == R and pg['result_sha256'] == PG_SHA and pg['new_account_capture'].startswith('NONE')
    artifacts = {r['path']: r for r in report['artifacts']}
    assert len(artifacts) == len(report['artifacts'])
    actual_files = {p.relative_to(run).as_posix() for p in run.rglob('*') if p.is_file() and p.name not in ('result.json', 'status.json')}
    assert set(artifacts) == actual_files and not any(p.is_symlink() for p in run.rglob('*'))
    for n, row in artifacts.items():
        assert not pathlib.Path(n).is_absolute() and '..' not in pathlib.Path(n).parts
        assert file_sha(run / n) == row['sha256'] and len(raw(run / n)) == row['bytes']
    assert len(report['commands']) == 3
    for command in report['commands']:
        assert command['exit_code'] == (1 if command is report['commands'][-1] else 0) and command['timed_out'] is False and command['pid'] == command['owned_process_group']
        for name in ('stdout', 'stderr'):
            assert file_sha(run / command[name]) == command[name + '_sha256']
        assert not raw(run / command['stderr'])
    overlay = run / 'overlay.json'
    export_command, desktop_command, bench_command = report['commands']
    assert export_command['argv'] == [dep['go'], 'test', '-mod=readonly', '-overlay=' + str(overlay), '-count=1', '-v', './internal/web', '-run', '^TestSocialAccountCenterQAExport$', '-args', '-account-center-ui-producer-source', R, '-account-center-ui-qa-output-dir', str(run / 'fixtures')]
    expected_bench = [dep['go'], 'test', '-mod=readonly', '-overlay=' + str(overlay), '-run', '^$', '-bench', '^BenchmarkSocialAccountCenterBodyRender$', '-benchmem', '-benchtime=100x', '-count=3', '-cpu=1', './internal/web', '-args', '-account-center-ui-producer-source', R]
    assert bench_command['argv'] == expected_bench
    assert desktop_command['argv'][0] == dep['node'] and desktop_command['argv'][1] == str(repo / 'tools/gui-native-account-center/desktop-qa.mjs')
    virtual = load(overlay)['Replace']
    assert len(virtual) == 6 and all(not pathlib.Path(k).exists() for k in virtual)
    assert set(virtual.values()) == {str(repo / 'tools/gui-native-account-center/export_test.go.txt')} | {str(repo / r['path']) for r in binding['unchanged_overlay_helpers']}
    export_text = raw(run / export_command['stdout']).decode()
    assert len(re.findall('^=== RUN   TestSocialAccountCenterQAExport$', export_text, re.M)) == 1
    assert '--- PASS: TestSocialAccountCenterQAExport (' in export_text and not re.search('--- (?:FAIL|SKIP):|DATA RACE|\\(cached\\)', export_text)
    manifest = load(run / 'fixtures/fixtures.json')
    desktop = load(run / 'desktop/desktop-results.json')
    assert file_sha(run / 'fixtures/fixtures.json') == report['fixture_manifest_sha256'] == desktop['fixtureManifestSHA256']
    assert file_sha(run / 'desktop/desktop-results.json') == report['desktop_report_sha256']
    assert manifest['PG_producer_source'] == desktop['PGProducerSource'] == R and manifest['UI_method_source'] == method_sha
    assert manifest['source_unchanged'] and desktop['sourceUnchanged'] and manifest['sources_before'] == manifest['sources_after'] == desktop['sourcesBefore'] == desktop['sourcesAfter']
    names = set(git('ls-files', '-z').decode().rstrip('\0').split('\0'))
    assert {r['path'] for r in manifest['sources_after']} == (names - allowed) | methods
    source_rows = {r['path']: r for r in manifest['sources_after']}
    blob_specs = {}
    for line in git('ls-tree', '-r', '-z', method_sha).split(b'\0'):
        if line:
            meta, n = line.split(b'\t', 1)
            mode, kind, oid = meta.split()
            assert kind == b'blob'
            blob_specs[n.decode()] = oid.decode()
    process = subprocess.Popen(['git', '-C', str(repo), 'cat-file', '--batch'], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    for n, row in source_rows.items():
        process.stdin.write((blob_specs[n] + '\n').encode()); process.stdin.flush()
        header = process.stdout.readline().split(); blob = process.stdout.read(int(header[2])); assert process.stdout.read(1) == b'\n'
        assert raw(repo / n) == blob and len(blob) == row['bytes'] and digest(blob) == row['sha256']
    process.stdin.close(); assert process.wait() == 0
    assert report['source_bridge'] == desktop['gitBridgeBefore'] == desktop['gitBridgeAfter']
    assert report['source_bridge']['producer_source'] == R and report['source_bridge']['ui_head'] == method_sha and report['source_bridge']['UI_only_changed_paths'] == changed
    assert report['git_after'] == {'head': method_sha, 'porcelain_empty': True}
    assert [s['name'] for s in manifest['states']] == STATES
    normalization = manifest['normalization']
    assert normalization == report['normalization'] == desktop['normalization'] and normalization['kind'] == 'render-nonce-only'
    assert normalization['replacement'] == 'synthetic-account-center-ui-nonce'
    norm = {r['name']: r for r in normalization['states']}
    by_state = {s['name']: s for s in manifest['states']}
    for name, state in by_state.items():
        html = raw(run / 'fixtures' / (name + '.html'))
        assert len(html) == state['bytes'] and digest(html) == state['sha256'] == norm[name]['normalized_html_sha256']
        assert norm[name]['attribute_replacements'] == 2 and norm[name]['csp_replacements'] == 1
        assert html.count(b'nonce="synthetic-account-center-ui-nonce"') == 2 and b'PRIVATE-' not in html
    base = repo / 'docs/reviews/gui-native-notification-inbox-dates'
    assert file_sha(base / 'evidence.tar.gz') == BASE_SHA and file_sha(base / 'archive-manifest.json') == BASE_MANIFEST
    outer = load(base / 'archive-manifest.json'); members = {}; body_rows = []
    with tarfile.open(base / 'evidence.tar.gz', 'r:gz') as archive:
        physical = archive.getmembers(); assert [m.name for m in physical] == [r['member'] for r in outer['members']]
        for member, row in zip(physical, outer['members']):
            assert member.isfile() and (member.size, member.mode, member.uid, member.gid) == (row['bytes'], row['mode'], row['uid'], row['gid'])
            assert int(Decimal(member.pax_headers['mtime']) * 10**9) == row['mtime_ns']
            value = archive.extractfile(member).read(); assert digest(value) == row['sha256']
            if row['original'].startswith(BASE_UI + '/fixtures/'):
                assert row['original'] not in members; members[row['original']] = (value, row)
    previous = json.loads(members[BASE_UI + '/fixtures/fixtures.json'][0])
    prior = previous['previous_body_equality'] + [dict(kind='notification-inbox', name=r['name'], path='notification-inbox/' + r['name'] + '.html', bytes=r['bytes'], sha256=r['sha256']) for r in previous['states']]
    candidates = manifest['previous_body_candidates']; assert len(candidates) == len(prior) == 37
    proof = report['previous_body_equality']; assert load(run / 'prior-body-equality.json') == proof and proof['literal_byte_equal'] and proof['count'] == 37
    assert proof['archive_sha256'] == BASE_SHA and proof['archive_manifest_sha256'] == BASE_MANIFEST
    for current, accepted_row, row in zip(candidates, prior, proof['rows']):
        assert (current['kind'], current['name']) == (accepted_row['kind'], accepted_row['name'])
        original = BASE_UI + '/fixtures/' + (current['name'] + '.html' if current['kind'] == 'notification-inbox' else accepted_row['path'])
        expected, source_row = members[original]; value = raw(run / 'fixtures' / current['path'])
        assert value == expected and digest(value) == current['sha256'] == accepted_row['sha256'] and len(value) == current['bytes'] == accepted_row['bytes']
        assert row == dict(current, equal=True, baseline_member=source_row['member'], baseline_original=original)
        body_rows.append({'kind': current['kind'], 'name': current['name'], 'bytes': len(value), 'sha256': digest(value)})
    assert desktop['previousBodyEquality'] == proof['rows'] and desktop['status'] == 'pass' and desktop['failures'] == []
    for k in ('requestFailures', 'pageErrors', 'consoleErrors', 'cspConsole', 'webSockets'):
        assert desktop[k] == []
    assert desktop['viewport'] == {'width': 1280, 'height': 720}
    screens = set(); axe_counts = collections.Counter(); keyboard_count = form_count = 0; state_metrics = []
    clean = lambda s: re.sub(r'\s+', ' ', s or '').strip()
    for no_js, rows in ((False, desktop['states']), (True, desktop['noJavaScriptStates'])):
        assert [s['name'] for s in rows] == STATES
        for state in rows:
            source = by_state[state['name']]; expected = source['expected']; metrics = state['metrics']
            assert state['javaScriptEnabled'] == (not no_js) and state['fixtureSHA256'] == source['sha256'] and state['htmlBytes'] == source['bytes']
            assert state['syntheticSourceSHA256'] == source['synthetic_source_sha256']
            assert 0 < state['htmlGzipLevel9'] < state['htmlBytes']
            assert metrics['native'] and metrics['heading'] == clean(expected['title']) and metrics['documentTitle'] == expected['title'] + ' · ' + expected['site']
            for k in ('language', 'theme', 'text', 'motion', 'canonical'):
                assert metrics[k] == source[k]
            assert metrics['fontsStatus'] == 'loaded' and metrics['overflow'] <= 0 and metrics['actorLabel'] == clean(expected['actor_label'])
            assert metrics['tabs'] == [dict(r, label=clean(r['label']), active=r['current']) for r in expected['tabs']]
            assert metrics['groups'] == [{'heading': clean(g['heading']), 'links': [dict(r, label=clean(r['label'])) for r in g['links']]} for g in expected['groups']]
            assert metrics['cardCount'] == (6 if expected['settings'] else 3)
            assert metrics['messages'] == list(map(clean, expected['messages'])) and metrics['signed'] == ('' if expected['settings'] else clean(expected['signed']))
            assert len(metrics['avatar']) == int(expected['avatar'])
            if expected['avatar']:
                assert metrics['avatar'] == [{'src': expected['avatar_uri'], 'width': '26', 'height': '26', 'alt': ''}]
            token = {'record': expected['has_token_record'], 'heading': clean(expected['api_heading']), 'text': clean(expected['token_text']), 'revoke': {'action': '/settings/api-token/revoke/', 'label': clean(expected['revoke_label'])} if expected['has_token_record'] else None} if expected['settings'] else None
            assert metrics['token'] == token
            danger = {'heading': clean(expected['account_heading']), 'links': [{'label': clean(expected['export_label']), 'href': '/account/export/'}, {'label': clean(expected['delete_label']), 'href': '/account/delete/'}]} if expected['settings'] else None
            assert metrics['danger'] == danger
            for k in ('duplicateIDs', 'unresolved', 'unlabelled', 'eventAttributes'):
                assert metrics[k] == []
            for k in ('executableInline', 'styleElements', 'inlineStyles', 'activePayload', 'privateText', 'unreadPills'):
                assert not metrics[k]
            assert metrics['nonceAttributes'] == [normalization['replacement']] * 2 and metrics['owner'] == expected['owner']
            assert metrics['stylesheetSources'] == ['/static/css/base.css', '/static/css/account-center-native.css'] and metrics['scriptSources'] == expected['script_sources']
            actions = ['/logout/', '/logout/', '/i18n/setlang/'] + (['/i18n/setlang/'] + (['/settings/api-token/revoke/'] if expected['has_token_record'] else []) if expected['settings'] else [])
            assert sorted(r['action'] for r in metrics['forms']) == sorted(actions)
            for form in metrics['forms']:
                wanted = [['csrfmiddlewaretoken', source['synthetic_csrf']]]
                if form['action'] == '/i18n/setlang/': wanted += [['next', expected['path']], ['language', source['language']]]
                assert form['method'] == 'post' and form['csrf'] == [source['synthetic_csrf']] and form['data'] == wanted and len(form['fields']) == len(wanted)
                assert [[r['name'], r['value']] for r in form['fields']] == wanted
                form_count += 1
            destinations = ['A:' + r['href'] for r in expected['tabs']]
            if expected['settings']: destinations += ['SELECT:language', 'BUTTON:/i18n/setlang/']
            destinations += ['A:' + r['href'] for g in expected['groups'] for r in g['links']]
            if expected['settings']: destinations += (['BUTTON:/settings/api-token/revoke/'] if expected['has_token_record'] else []) + ['A:/account/export/', 'A:/account/delete/']
            destinations += ['BUTTON:/logout/']
            assert [r['destination'] for r in state['keyboard'][:-1]] == destinations and set(state['keyboard'][-1]) == {'firstAccount'}
            for row in state['keyboard']:
                row = row.get('firstAccount', row); assert row['active'] and row['focusVisible'] and row['outline'] != 'none' and float(row['width'].removesuffix('px')) > 0
                keyboard_count += 1
            if no_js: assert state['audits'] == []
            else:
                assert state['steadyState']['before'] == state['steadyState']['after'] and state['steadyState']['initialColorsEqualSettled'] and state['steadyState']['remainingAnimations'] == 0
                assert [a['mode'] for a in state['audits']] == ['all-open', 'header-closed', 'header-keyboard-open']
                for audit in state['audits']:
                    assert audit['axe']['version'] == '4.14.0' and audit['axe']['violations'] == audit['axe']['incomplete'] == []
                    assert len(audit['axe']['passes']) == len(set(audit['axe']['passes']))
                    axe_counts.update(audit['axe']['passes']); screens.add(audit['screenshot'])
                    assert file_sha(run / 'desktop' / audit['screenshot']) == audit['screenshotSHA256']
                    assert struct.unpack('>II', raw(run / 'desktop' / audit['screenshot'])[16:24]) == (1280, 720)
                screens.add(state['screenshot']); assert file_sha(run / 'desktop' / state['screenshot']) == state['screenshotSHA256']
                assert struct.unpack('>II', raw(run / 'desktop' / state['screenshot'])[16:24])[0] == 1280
            required = ['/static/css/base.css', '/static/css/account-center-native.css', '/static/fonts/bricolage-grotesque-latin-wght-normal.woff2', '/static/fonts/bricolage-grotesque-latin-ext-wght-normal.woff2'] + ([] if no_js else expected['script_sources'] + ['/qa/axe.js'])
            assert [a['expected']['path'] for a in state['assets']] == required
            for asset in state['assets']:
                expect = asset['expected']; path = pathlib.Path(dep['axe_file']) if expect['path'] == '/qa/axe.js' else repo / expect['path'].lstrip('/')
                assert file_sha(path) == expect['sha256'] and len(raw(path)) == expect['bytes'] and asset['actual']
                for row in asset['actual']: assert row['path'] == expect['path'] and row['sha256'] == expect['sha256'] and row['bytes'] == expect['bytes'] and row['status'] == 200
            state_metrics.append({'name': state['name'], 'noJS': no_js, 'html_bytes': state['htmlBytes'], 'gzip9_bytes': state['htmlGzipLevel9'], 'forms': len(metrics['forms']), 'keyboard_witnesses': len(state['keyboard']), 'audits': len(state['audits'])})
    assert len(screens) == 32 and all(r['method'] == 'GET' and r['local'] for r in desktop['requests'])
    paths = {'/preview/' + n + '/' for n in STATES} | {'/qa/axe.js', '/sw.js', '/favicon.ico', '/static/css/base.css', '/static/css/account-center-native.css', '/static/fonts/bricolage-grotesque-latin-wght-normal.woff2', '/static/fonts/bricolage-grotesque-latin-ext-wght-normal.woff2', '/static/js/hovercard.js', '/static/js/site.js'}
    assert all(r['path'] in paths for r in desktop['requests'])
    for mock in desktop['mockEndpoints']:
        assert mock['path'] == '/sw.js' and mock['sha256'] == file_sha(repo / 'services/server/internal/web/assets/meetups-worker.js')
    for response in desktop['assetResponses']:
        path = pathlib.Path(dep['axe_file']) if response['path'] == '/qa/axe.js' else repo / response['path'].lstrip('/')
        assert response['status'] == 200 and file_sha(path) == response['sha256'] and len(raw(path)) == response['bytes']
    assert collections.Counter(r['state'] for r in desktop['fixturePolicyEnforcement']) == collections.Counter({n: 2 for n in STATES})
    assert all(r['enforcedSamePolicyForIsolatedFixture'] for r in desktop['fixturePolicyEnforcement'])
    for row in desktop['fixturePolicyEnforcement']:
        assert row['actualRendererHeader'] in by_state[row['state']]['renderer_headers']
        assert row['actualRendererHeader'].lower() in ('content-security-policy', 'content-security-policy-report-only')
    assert desktop['ownership']['serverStopped'] and len(desktop['ownership']['profiles']) == 2
    for row in desktop['ownership']['profiles']: assert row['closed'] and row['removed'] and not pathlib.Path(row['path']).exists()
    assert report['owned_temp']['removed'] and not pathlib.Path(report['owned_temp']['path']).exists()
    assert report['benchmark_requested'] and report['benchmark'] == {'status': 'REQUESTED_NOT_ADMITTED'}
    bench_raw = raw(run / bench_command['stdout']); bench = bench_raw.decode()
    samples = collections.defaultdict(list)
    for line in bench.splitlines():
        if not re.match('^BenchmarkSocialAccountCenterBodyRender/', line): continue
        fields = line.split()
        if len(fields) == 1: continue
        match = re.fullmatch('BenchmarkSocialAccountCenterBodyRender/(' + '|'.join(STATES) + ')/(classic|native)(?:-1)?', fields[0]); assert match and fields[1] == '100'
        metrics = {unit: Decimal(value) for value, unit in zip(fields[2::2], fields[3::2])}
        assert set(metrics) == {'ns/op', 'B/op', 'allocs/op', 'html-B/op', 'gzip9-B/op'}
        samples[match.groups()].append({k: float(v) for k, v in metrics.items()})
    assert set(samples) == {(n, 'native') for n in STATES} and all(len(rows) == 3 for rows in samples.values())
    failed = re.findall(r'^--- FAIL: (BenchmarkSocialAccountCenterBodyRender\S*)', bench, re.M)
    assert collections.Counter(failed) == collections.Counter(['BenchmarkSocialAccountCenterBodyRender'] + ['BenchmarkSocialAccountCenterBodyRender/' + n for n in STATES] + ['BenchmarkSocialAccountCenterBodyRender/' + n + '/classic' for n in STATES])
    errors = re.findall(r"context-key 'PRIVATE-extra' .* is not a valid identifier", bench)
    assert len(errors) == 8 and '\nFAIL\n' in bench and not re.search(r'--- SKIP:|DATA RACE|\(cached\)', bench)
    logs = re.findall('fixed synthetic AccountView state=([a-z-]+) input-sha256=([a-f0-9]{64}); no genuine token/session/export input', bench)
    assert {n for n, h in logs} == set(STATES) and all(by_state[n]['synthetic_source_sha256'] == h for n, h in logs)
    assert file_sha(run / 'result.json') == result_sha and not git('status', '--porcelain', '--untracked-files=all') and git('rev-parse', 'HEAD').decode().strip() == method_sha
    print(json.dumps({'schema': 1, 'status': 'CONFIRMED_PRIMARY_UI_PASS_OVERALL_BENCHMARK_FAILURE_NO_COMPARISON', 'source': R, 'UI_method_source': method_sha, 'result_sha256': result_sha, 'desktop_result_sha256': report['desktop_report_sha256'], 'Root_terminal_sha256': file_sha(terminal_path), 'native_UI_input_hashes': NATIVE, 'committed_source_rows': len(source_rows), 'artifact_rows_rehashed': len(artifacts), 'commands': len(report['commands']), 'states': state_metrics, 'Axe_audits': sum(r['audits'] for r in state_metrics), 'Axe_pass_predicates': sum(axe_counts.values()), 'Axe_rule_occurrences': dict(axe_counts), 'keyboard_witnesses': keyboard_count, 'observed_forms': form_count, 'screenshots': len(screens), 'requests': len(desktop['requests']), 'asset_responses': len(desktop['assetResponses']), 'physical_baseline_bodies': body_rows, 'baseline_archive_members': len(outer['members']), 'owned_cleanup': desktop['ownership'], 'temporary_HOME': report['owned_temp'], 'benchmark_stdout_sha256': digest(bench_raw), 'benchmark_native_rows_only': sum(map(len, samples.values())), 'benchmark_classic_rows': 0, 'benchmark_failed_classic_groups': len(errors), 'benchmark_failed_root_and_parent_and_leaf_frames': len(failed), 'benchmark_native_samples_NOT_COMPARATIVE': [{'name': n, 'samples': samples[n, 'native']} for n in STATES], 'fixed_source_log_records': len(logs), 'benchmark_failure_cause': 'Pongo2 direct classic ExecuteWriter rejects the common synthetic context key PRIVATE-extra before any timed classic sample; native24 rows do not form a matched48 benchmark. Fixed synthetic sentinel only; no genuine credential or account evidence.', 'scope': 'Desktop8JS8noJS/24strictAxe/all37literalbaseline and actualcleanup evidence passed; overall attempt remainsFAIL. No matchedbenchmark,comparativeefficiency,keeper,feature,milestone or production acceptance. No product reruns or source mutation.', 'findings': []}, indent=2))


if __name__ == '__main__':
    main()
