#!/usr/bin/env python3
"""Read-only old display marker privacy; never import or execute product helpers."""
from collections import Counter
from datetime import datetime
import hashlib
import json
from pathlib import Path
import re
import sys
from urllib.parse import urlsplit


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    run = Path(sys.argv[1]).resolve(strict=True)
    raw = (run / 'result.json').read_bytes()
    result = json.loads(raw)
    assert result['source'] == 'a8f713f74885acfc51f6985bc8c6a366950029b3'
    assert result['method_pass'] is True and result['errors'] == []
    artifact = next(row for row in result['artifact_rows'] if row['path'] == 'proof/app-test2json.stdout')
    stream = (run / artifact['path']).read_bytes()
    assert len(stream) == artifact['bytes'] and digest(stream) == artifact['sha256']
    events = [json.loads(line) for line in stream.splitlines()]
    root = 'TestNativeNotificationInboxRegisteredHTTPAndCurrentAuthority'
    leaves = ['registered-self-newest-first-100-and-read-only-get', 'csrf-origin-head-and-existing-method-admission', 'mark-all-beyond-100-self-only-idempotent-and-fetch', 'current-active-account-and-existing-cohort-admission', 'upstream-failure-preserves-state-and-response', 'registered-display-whitelist-and-existing-spa-source']
    runs = [e['Test'] for e in events if e.get('Action') == 'run' and e.get('Test')]
    passes = [e['Test'] for e in events if e.get('Action') == 'pass' and e.get('Test')]
    assert Counter(runs) == Counter(passes)
    assert all(runs.count(name) == passes.count(name) == 1 for name in [root] + [root + '/' + leaf for leaf in leaves])
    text = ''.join(e.get('Output', '') for e in events if e.get('Test') == root and e.get('Action') == 'output')
    markers = re.findall(r'NATIVE_NOTIFICATION_INBOX_V1 ([^\r\n]+)', text)
    assert len(markers) == 1
    projection = markers[0].encode()
    value = json.loads(projection)
    assert set(value) == {'schema', 'variants', 'capture'} and value['schema'] == 1
    assert value['capture'] == 'same registered-cookie GET callback; display whitelist only; no actor/IDs/credentials/render environment'
    assert [v['language'] for v in value['variants']] == ['en', 'ro']
    for variant in value['variants']:
        assert set(variant) == {'language', 'projection'} and set(variant['projection']) == {'items'}
        rows = variant['projection']['items']
        assert len(rows) == 100
        stamps = []
        for row in rows:
            assert set(row) == {'title', 'body', 'why', 'url', 'created_at', 'read_at'}
            assert all(type(row[name]) is str and len(row[name].encode()) <= 16384 for name in ['title', 'body', 'why', 'url', 'created_at'])
            assert row['read_at'] is None or row['read_at'] is True
            stamp = datetime.fromisoformat(row['created_at'].replace('Z', '+00:00'))
            assert stamp.tzinfo is not None
            stamps.append(stamp)
            href = row['url']
            if href:
                parsed = urlsplit(href)
                assert not any(char in href for char in ('\r', '\n', '\\')) and parsed.username is None
                assert not re.search(r'%(?![0-9A-Fa-f]{2})', href)
                assert href.startswith('/') and not href.startswith('//') or parsed.scheme in ('http', 'https')
        assert all(a >= b for a, b in zip(stamps, stamps[1:]))
    assert value['variants'][0]['projection'] == value['variants'][1]['projection']
    assert len(projection) == 42260 and digest(projection) == '672d58c74b44a1426e80a705ee7ba6e97842f5578aea1b96cb483ee8056543d0'
    account = 'TestNativeAccountCenterAssembledHTTPPreservesExistingActionsAndAuthority'
    account_events = [e for e in events if e.get('Test', '') == account or e.get('Test', '').startswith(account + '/')]
    account_runs = [e['Test'] for e in account_events if e.get('Action') == 'run']
    account_passes = [e['Test'] for e in account_events if e.get('Action') == 'pass']
    assert len(account_runs) == len(account_passes) == len(set(account_runs)) == 9 and Counter(account_runs) == Counter(account_passes)
    account_text = ''.join(e.get('Output', '') for e in account_events if e.get('Action') == 'output')
    assert all(re.fullmatch(r'\s*(?:=== (?:RUN|NAME)\s+TestNativeAccountCenter\S*|--- PASS: TestNativeAccountCenter\S* \([0-9.]+s\))\n?', line) for line in account_text.splitlines(keepends=True))
    assert (run / 'result.json').read_bytes() == raw and (run / artifact['path']).read_bytes() == stream
    items = value['variants'][0]['projection']['items']
    print(json.dumps({'schema': 1, 'status': 'PASS_CURRENT_COMPLETE_APP_ACCOUNT_NO_CAPTURE_AND_OLD_DISPLAY_WHITELIST', 'source': result['source'], 'result_sha256': digest(raw), 'app_raw_event_sha256': digest(stream), 'actual_account_root_and_eight_groups_once': True, 'actual_account_output': 'Generic Go runner framing only; no body/credential/export capture or new marker', 'actual_account_output_sha256': digest(account_text.encode()), 'retained_old_inbox_root_and_six_groups_once': True, 'old_display_projection_bytes': len(projection), 'old_display_projection_sha256': digest(projection), 'EN_RO_ordered_rows_equal': True, 'rows_per_language': len(items), 'nil_read_presence': sum(row['read_at'] is None for row in items), 'true_read_presence': sum(row['read_at'] is True for row in items), 'strict_admitted_nonempty_links': sum(bool(row['url']) for row in items), 'private_extra_fields': 0, 'projection_bytes_copied_to_review_output': False, 'findings': [], 'scope': 'Read-only terminal evidence inspection, no producer/helper import or product/DB/Docker/browser/benchmark execution.'}, indent=2))


if __name__ == '__main__':
    main()
