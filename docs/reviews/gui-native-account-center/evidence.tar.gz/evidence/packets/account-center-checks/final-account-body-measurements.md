# Account body measurements: exact R / M3

Actual result `949ebfe97d0f66fc858af87948a8feb6212c12af4790cabdbb62227108416ad8`; raw benchmark `7952230485a5af44510fdbfa49d05ad6cc71acc0e4cafb138645816509e46147`.

Each cell is classic / native. Medians use three warmed100-iteration samples per engine,CPU1. ns/op measures elapsed body rendering; native validation/projection/copy is included. HTML differs. These are descriptive scoped results,with no HTTP,DB,CPU-profile or general speedup claim. The detailed JSON audit retains every sample,median,min,max and span/median for all five metrics.

| State | Median ns/op | Median B/op | Median allocs/op | HTML B/op | gzip9 B/op | ns/op min–max classic / native | ns span/median % classic / native |
|---|---:|---:|---:|---:|---:|---|---:|
| overview-basic-en | 234,949 / 390,616 | 83,628 / 64,802 | 1,179 / 1,698 | 9,918 / 5,726 | 2,816 / 1,968 | 157,993–268,652 / 371,709–392,155 | 47.10 / 5.23 |
| overview-guardian-ro | 267,301 / 399,837 | 84,020 / 65,570 | 1,193 / 1,723 | 10,166 / 5,946 | 3,031 / 2,127 | 237,791–279,511 / 386,595–403,384 | 15.61 / 4.20 |
| overview-ward-connections-en | 273,205 / 414,740 | 84,940 / 67,314 | 1,235 / 1,803 | 10,080 / 5,888 | 2,854 / 2,005 | 261,465–283,616 / 402,305–419,048 | 8.11 / 4.04 |
| overview-escaped-ro | 278,162 / 408,457 | 85,788 / 65,722 | 1,199 / 1,717 | 10,348 / 6,131 | 3,082 / 2,173 | 242,332–285,093 / 389,777–410,057 | 15.37 / 4.97 |
| settings-no-token-en | 272,355 / 406,726 | 77,050 / 65,642 | 1,176 / 1,726 | 10,735 / 6,510 | 2,995 / 2,159 | 259,033–275,240 / 386,132–415,409 | 5.95 / 7.20 |
| settings-token-ro | 322,389 / 442,193 | 89,588 / 76,595 | 1,315 / 1,880 | 11,478 / 7,214 | 3,355 / 2,470 | 315,884–327,895 / 433,776–454,523 | 3.73 / 4.69 |
| settings-expired-record-en | 309,955 / 419,525 | 88,460 / 74,242 | 1,273 / 1,799 | 11,128 / 6,886 | 3,088 / 2,258 | 298,153–314,529 / 418,853–437,120 | 5.28 / 4.35 |
| settings-revoke-error-ro | 300,634 / 421,011 | 88,924 / 73,259 | 1,268 / 1,770 | 11,298 / 6,971 | 3,203 / 2,267 | 270,418–302,481 / 411,628–428,478 | 10.67 / 4.00 |

Native median elapsed is35.35–66.26% higher and allocations39.59–46.77% higher across these eight states. Allocated bytes are14.50–23.39% lower,HTML37.15–42.27% smaller,and gzip26.38–30.11% smaller. Classic basicEN has47.10% sample span/median; native spans4.00–7.20%. Three samples per group do not establish population-wide timing effects.

All eight fixed source digests are actual separate UI-export witnesses. This successful nonverbose benchmark emits zero parent hash-log records. Fixed shared inputs are proved by exact accepted exporter1aea source,the common constructor/merged context for both engines,executed source-stability assertions and packagePASS. No raw benchmark input-hash log is invented.

M2 remains an overall failed attempt with24native/0classic timing rows. Its data is excluded from these medians. The earlier strict Axe failure also remains failed.
