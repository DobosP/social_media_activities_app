# Social account center V2 — provisional functional source contract

Valid until: the date optimization and next account-center source are independently accepted and rebound — then treat this source proposal as history.

Published snapshot: `cb68b6d04fb6aac38b16c4e2936559bd0b426f44`; qualified native reference: `496056a6a528d01d544abbf77e18877b60d629bd`. Future closing SHA, native input manifest and accepted baseline keeper/body bindings remain **unbound**. The future baseline must close all37 identities:8family+10group-create+7group-detail+6preferences+6inbox. This proposal has not verified those body streams. Concurrent date-only changes are outside this contract; each account witness is checked against published Git bytes.

Scope is native presentation for existing `/you/` and `/settings/`, preserving the admitted producer, current backend actions, old templates/assets/tests, schema/dependencies/authcore provenance and SPA selection. This is source analysis, not implementation, qualification, policy or acceptance. No provider/flags activation, service rewrite, account purge-policy change, new fresh-auth factor, government identity, legal parenthood, real-child authority or mobile/device testing follows.

## Exact producer

`App.serveHTTP` → registered web router → `Server.page` → `view` → `AccountView` → current Pongo renderer when SPA is off. `view` calls `AccountView` before its older `accounts.Self` fallback. Both pages are handled there: **neither calls Self**. Preserve Self/progression/avatar-style services and their tests; do not add those queries or private fields by treating the fallback as this producer.

`platform.Actor` contains ID; PublicID, Username, DisplayName, AgeBand, Cohort, Role; IdentityVerified, IsActive, IsStaff, IsSuperuser. `accountUserMap` supplies exactly id,pk,public_id,username,display_name,age_band,cohort,role,is_active,is_authenticated,is_identity_verified,is_moderator,is_admin,requires_parental_consent,get_age_band_display,get_cohort_display. Authenticated means positive ID and active; moderator/admin use Actor methods; parental-consent display flag is AgeBand under_16. AccountView adds `user.is_guardian`.

Common fields are `user`, `is_guardian`, `has_guardians`, `connections_enabled`. The first flag is EXISTS active guardianrelationship rows with guardian_id=self; has_guardians is EXISTS active rows with ward_id=self. These are source display flags, not expiry/capability/parental-legal rulings. Connections visibility is Social!=nil && ConnectionCohorts[Actor.Cohort], without a new participation check. Destination services remain authoritative.

`you` adds no other page fields. Signed-in label uses display_name then username. AccountView supplies **no unread_notifications**, and Renderer defaults do not query it. Current registered account pages therefore have no unread pill producer, even though templates accept a truthy caller-supplied count. Home's unread producer is separate; do not invent an account query or claim a registered populated count.

`settings` selects only `created` from authtoken_token for self. A found row supplies `api_token_created` as time.Time; no row omits it; other errors propagate. No token key is selected. A creation timestamp is token-presence metadata, not current TTL validity: an expired stored row can still show the revoke control. It also supplies languages [[en,English],[ro,Română]] and current_language from existing `language(request)`. That helper chooses valid en/ro django_language cookie, otherwise first recognized Accept-Language prefix in source order, then en; it does not q-sort.

Normal `Server.page` GET/HEAD continues existing notice consumption, CSRF seeding, canonical/site defaults and existing generated avatar lookup. Preserve those reads and common shell behavior. The revoke-error `accountRender` path has the distinct context specified below; do not apply GET enrichment to it. GET does not issue/revoke tokens, download export, erase accounts or grant participation.

## Finite links and forms

Shared account tabs: Overview→/you/, Profile→/profile/, Interests→/interests/, Display→/display/, Privacy & data→/my-privacy/, Donations→/my-donations/, Guardians→/guardianship/ only when has_guardians, then Settings→/settings/. The active overview/settings source tab retains is-active and aria-current=page. Pongo uses registered name my_guardians for /guardianship/.

`you` has the source title/heading Account & settings, signed-in escaped label, and three ordered groups:

- Profile & preferences: profile,interests,topic_preferences,access_preferences,display_preferences,verify_age,notifications,messages,connections only when connections_enabled,saved_searches,notification_preferences.
- Privacy & safety: my_privacy,safety_record,activity_log,wards only when user.is_guardian,my_guardians only when has_guardians.
- Giving: my_donations,donate,campaigns,transparency.

It has an explicit POST /logout/ form containing csrfmiddlewaretoken and submit button.

`settings` retains its Settings title/heading and four ordered cards: language; preferences (display,notification,access,interests,topics,saved searches); privacy/safety (privacy,verify-age,safety record,activity log plus conditional wards/guardians); giving (my donations,transparency). The language form is POST /i18n/setlang/, hidden CSRF and next=request.path, language select with en/ro/current selection and Save button. Preserve the separate common footer language form and its no-JS control.

API access has two finite states: absent metadata shows the source no-device text and no revoke form; present metadata shows the source issued-date/device text using frozen `djangoDate` format `j M Y`, then POST /settings/api-token/revoke/ containing CSRF only. No token create, rotate, value, TTL or session control is implied. The account card keeps **GET** /account/export/ download and **GET** /account/delete/ preview links. Settings also has explicit POST logout.

## Admission, actions and responses

- Current ActorFrom requires ID>0 and IsActive. Anonymous/inactive private page entry redirects302 to /login/?next=QueryEscape(RequestURI). App session lookup/current active Actor reload can reject earlier with403/503. Invalid Authorization Token branch returns401. Pending/unassigned but active account access does not imply participation eligibility. Preserve the layered outcomes.
- Both page route tables declare GET; HEAD follows GET page production, including existing reads/CSRF seeding/render. There is no application HEAD stripping helper; actual net/http wire suppresses HEAD body, while direct recorders may retain writes. POST page entry rejects405 Allow GET. Other verbs follow current ServeMux rejection. Do not add a hand-written method policy.
- Browser actions retain ParseForm, active Actor and shared CSRF admission. Origin, or Referer fallback, must equal configured public origin; matching52-character cookie/header uses constant-time comparison. Form CSRF is forwarded only when CSRF headers are absent. App session mutation admission and web action checks both remain; token API admission is distinct.
- Browser revoke directly calls Accounts.RevokeAPIAccess(self.ID): DELETE authtoken_token WHERE user_id=self. It is idempotent for no row; success302 /settings/. It neither revokes web sessions nor affects another user. Preserve direct service semantics, no extra transaction/audit/factor. API DELETE /api/auth/token/ authenticates a token and returns204; it is not the browser form transport.
- Revoke NotFound/pgxNoRows errors map404/no-store. Other failures render current settings200 with escaped generic socialActionError text; ordinary DB failure says temporarily unavailable. A failed settings re-producer maps503/no-store; failed renderer maps500 Page unavailable. Preserve message/context behavior rather than printing database or response contents.
- Dedicated POST /logout/ checks CSRF, then RevokeSession. Failure503 Logout unavailable does not successfully clear cookies; success ClearCookies +303 /. Do not activate GET logout.
- Export is self-only GET /account/export/, ignores query target IDs, calls Accounts.Export(self=true), downloads my-data-<PublicID>.json with no-store. HEAD reaches AccountDownload but rejects non-GET403; preserve this edge. Existing schema5 can contain sensitive own evidence but only token-issued bool/time metadata, never token key. Export body is excluded from UI evidence; its policy stays unchanged.
- Account deletion remains a GET preview link. Current preview counts self-owned/scoped objects without erasing. Existing separate POST erasure transaction and cookie clearing are outside this UI slice. Never make the account-card link submit, auto-confirm, or claim a universal purge/legal-compliance policy.
- App begins no-store and security headers, but successful Renderer HTML deliberately overwrites Cache-Control with private,no-cache and adds Vary Cookie plus current nonce CSP/report-only-or-enforced choice. JSON failures, export and private SPA _data remain no-store. Do not claim HTML is no-store or tighten cache/CSP policy incidentally. Generic platform statuses remain400/403/404/503; safety rate errors429 and renderer errors500 remain distinct.

## Existing gaps and SPA boundary

`routeURL(set_language)` emits /i18n/setlang/, but native routes/methods tables and services register no handler. An admitted POST currently reaches404; bad session-CSRF can403 first. Form presence tests prove no successful save. Root intends a **separate bounded functional language-action repair**, with exact routing/CSRF/redirect/cookie/locale contract and independent source review before implementation. No repair is silently included here.

SPA is selected through Config.ReactUI→web.Config.SPA, including private _data=1 JSON. Keep this route/payload/shell branch unchanged. It has intentional current differences from Pongo: Wards nav link is unconditional; it asks routeURL(guardianship), which falls back to # because only my_guardians is registered; settings shares the full three-group account nav rather than its shorter Pongo cards. Do not silently harmonize these or widen authority in a presentation migration.

## Future proof and capture limits

First independently review this source contract and rebind actual closing/native inputs and all37 prior body identities after date optimization acceptance. A future presentation proposal should use cached embedded GoHTML and typed finite state with existing shell/route/copy helpers. Preserve all old tests/assertions, old Pongo templates/assets, service/schema/dependency/authcore bytes; any additive native registration or exact closed source-reader bridge needs demonstrated necessity.

Meaningful pure vectors cover finite names/fallbacks, flags and link order, token absent/present/expired-row metadata, EN/RO/date/copy, same-document field/action/CSRF snapshots, escaped text, malformed projection and independent concurrent rendering. Registered App evidence must cover active/anonymous/inactive/current-session/token failures; GET/HEAD/method/Origin/CSRF; self-only revoke success/failure/no-other-user/no-session change; logout failure/success; export exclusion/HEAD403; erasure GET no mutation; unchanged SPA. Preserve existing query caps, old regression roots and the complete affected profile on the exact source; do not claim old unit roots alone qualify the new route.

UI should use fictional labels, fixed synthetic dates and synthetic CSRF only, with no actual token/session/cookie/nonce/password/Authorization values or raw export/evidence/erasure payload persisted, logged, captured or printed on failure. Registered credential observations remain memory-only with boolean/count diagnostics. Browser inspection is read-only: no logout/revoke/export/delete submission or click. Desktop/no-JS/strict whole-document Axe/real keyboard/FormData and all37 body comparisons remain future evidence, not a claim here. Any matched body measurement must be fixed synthetic rendering only, never account mutation/export/HTTP performance or general speedup.

Read-only source/Git/hash inspection only was performed. No product code, formatter/compiler/Go parser, DB/API/browser, test/benchmark, runtime or owning-repo write was performed for this contract.

## V2 refinement: normal GET versus HTML revoke-error context

Independent preliminary review `fb8f15d86ac9d2b9ab731ed0d4522d518fed6af13706495dfa01e344229f91f1` accepts the49 source facts and requests this explicit distinction. Original V1 contractca1a27a8/witness3cb59af3/hash-list73c25693 and the preliminary review remain byte-exact in `history-v1`. All49 witness records and source hashes are unchanged. Closing source/native inputs and the37-body baseline binding remain null.

On browser revoke failure, `AccountAction` calls `accountRender(w,r,a,"settings",socialActionError(err),nil)`. It passes the original **POST** request for `/settings/api-token/revoke/`; it does not redirect or call `Server.page`. `accountRender` invokes only the existing `AccountView` settings reads, supplies its explicit error message/tag and seeds/preserves CSRF when Auth exists, then calls Renderer directly. Renderer defaults therefore keep `request.path` and relative `canonical_url` as `/settings/api-token/revoke/`, and the settings language form's hidden `next` retains that action path. The normal settings template/tabs still render; do not normalize the request, canonical or language next to `/settings/`.

The direct error render uses the exact Renderer default site name **Social Activities**, rather than `Config.SiteName` or the normal page fallback Activities. Neither global `avatar_uri` nor `user.avatar_uri` is added by the existing error path. It performs no `Server.page` common `accounts.Avatar` lookup and no `consumePostNotice`; pending notice state is not consumed in this branch. Keep the source's absent-avatar/default shell presentation rather than silently adding the GET avatar query. Authentication/CSRF/permissions and the original self-only token deletion service are unchanged.

Future finite fixture contracts must separate these contexts:

| Fixture | Request and handler | Canonical / language next | Site and avatar | Message/read effects |
| --- | --- | --- | --- | --- |
| Normal settings GET | GET `/settings/` through `Server.page` | Config.PublicURL + `/settings/` / `/settings/` | Config.SiteName, or Activities if empty; existing common generated avatar is populated | Existing post-notice consumption and common avatar lookup, in addition to settings producer reads |
| HTML revoke-error | POST `/settings/api-token/revoke/` through `accountRender` | Relative `/settings/api-token/revoke/` / `/settings/api-token/revoke/` | Renderer default Social Activities; global/user avatar_uri absent | Explicit escaped generic error/tag; settings producer and CSRF only, with no post-notice consumption or extra common avatar query |

Use a fictional nondefault Config.SiteName and PublicURL in the normal GET fixture so the difference is observable; use fixed synthetic CSRF, labels and token creation dates only. A revoke-error fixture should retain a token-present metadata snapshot and its revoke form when the simulated deletion fails without changing stored state. Test any absent-token variant from its own producer snapshot, without inventing a token value. Registered failure injection must preserve the original POST request context and prove no extra enrichment queries/notice consumption; it must not route the expected error through GET or mask a producer failure as a successful HTML render. If settings reconstruction itself fails, the existing503 error remains separate. No product/SQL/policy/permission change or credential capture is authorized by these fixture contracts.
