#!/usr/bin/env python3
"""DISABLED account keeper source skeleton. Final profile not yet released."""
import argparse
from decimal import Decimal
import hashlib
import io
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import tarfile

ROOT=Path('/home/dobo/work/_temp/feat__gui-app-migration-a/social-family')
HERE=ROOT/'account-center-custody-prep'
REPO=Path('/home/dobo/work/_worktrees/social_media_activities_app/feat__gui-app-migration-a')
UI_ROOT=Path('/home/dobo/work/_temp/ac-ui')
STAT_KEYS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
EARLIEST={}
EARLIEST_LINKS={}
EARLIEST_DIRS={}
MAX_FILE=64<<20
MAX_PAYLOAD=128<<20
FORBIDDEN={'data','pgdata','pg_wal','pg_xact','cache','node_modules','.git','binaries','source','host-tmp','test-tmp','__pycache__'}
COLLECTION_RELEASED=False

def need(ok, message):
    if not ok:
        raise ValueError(message)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def hex64(value):
    return isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value) is not None

def safe_member(name):
    need(isinstance(name, str) and name and not Path(name).is_absolute() and '..' not in Path(name).parts
         and '\\' not in name and name != '.' and Path(name).as_posix() == name, 'safe canonical relative member required')
    return name

def read(path):
    path = Path(path)
    need(path.is_absolute() and path.resolve() == path, 'canonical unaliased input required')
    before = path.lstat()
    need(stat.S_ISREG(before.st_mode) and 0 <= before.st_size <= MAX_FILE, 'bounded regular nonsymlink input required')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        opened = os.fstat(fd)
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            raw = stream.read(MAX_FILE + 1)
        after = os.fstat(fd)
    finally:
        os.close(fd)
    before_stat = tuple(getattr(before, key) for key in STAT_KEYS)
    need(len(raw) == before.st_size and before_stat == tuple(getattr(opened, key) for key in STAT_KEYS)
         == tuple(getattr(after, key) for key in STAT_KEYS), 'input changed before/during read')
    snapshot = (raw, before_stat)
    need(path not in EARLIEST or EARLIEST[path] == snapshot, 'input differs from earliest bytes/fullstat')
    EARLIEST.setdefault(path, snapshot)
    return raw, before

def bound(path, digest):
    need(hex64(digest), 'explicit SHA-256 required')
    raw, info = read(path)
    need(sha(raw) == digest, 'bound input digest differs')
    return raw, info

def read_git_link(path):
    need(path.is_absolute() and path.parent.resolve() == path.parent and path.is_relative_to(REPO),
         'literal internal Git symlink input')
    before = path.lstat(); target = os.readlink(path).encode(); after = path.lstat()
    fingerprint = tuple(getattr(before, key) for key in STAT_KEYS)
    need(stat.S_ISLNK(before.st_mode) and path.resolve().is_relative_to(REPO)
         and fingerprint == tuple(getattr(after, key) for key in STAT_KEYS), 'Git symlink identity changed')
    snapshot = (target, fingerprint)
    need(path not in EARLIEST_LINKS or EARLIEST_LINKS[path] == snapshot, 'Git link differs from earliest bytes/fullstat')
    EARLIEST_LINKS.setdefault(path, snapshot)
    return target, before

def read_directory(path):
    need(path.is_absolute() and (path.is_relative_to(ROOT) or path.is_relative_to(UI_ROOT))
         and path.resolve() == path and not path.is_relative_to(HERE)
         and path not in HERE.parents and not any(part in FORBIDDEN for part in path.parts),
         'literal safe evidence directory; method/output/private trees cannot be censused')
    before = path.lstat()
    need(stat.S_ISDIR(before.st_mode), 'safe directory input required')
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        opened = os.fstat(fd); names = sorted(os.listdir(fd))
        need(len(names) <= 16384, 'bounded safe directory membership required')
        entries = []
        for name in names:
            info = os.stat(name, dir_fd=fd, follow_symlinks=False)
            need(stat.S_ISREG(info.st_mode) or stat.S_ISDIR(info.st_mode), 'safe evidence directory special entry refused')
            entries.append({'name': name, 'kind': 'directory' if stat.S_ISDIR(info.st_mode) else 'file'})
        after = os.fstat(fd)
    finally:
        os.close(fd)
    fingerprint = tuple(getattr(before, key) for key in STAT_KEYS)
    need(fingerprint == tuple(getattr(opened, key) for key in STAT_KEYS)
         == tuple(getattr(after, key) for key in STAT_KEYS), 'directory identity changed during census')
    snapshot = (tuple((row['name'], row['kind']) for row in entries), fingerprint)
    need(path not in EARLIEST_DIRS or EARLIEST_DIRS[path] == snapshot,
         'directory differs from earliest membership/fullstat')
    EARLIEST_DIRS.setdefault(path, snapshot)
    return entries, before

def observer_fence(view):
    need(set(view) == {'label', 'uid_map', 'gid_map'} and isinstance(view['label'], str) and view['label'],
         'one explicitly chosen observer view required')
    # These fixed proc metadata files are not payloads/ordinary st_size files.
    need(Path('/proc/self/uid_map').read_text() == view['uid_map']
         and Path('/proc/self/gid_map').read_text() == view['gid_map'], 'observer UID/GID mapping changed')

def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args], env={'PATH': os.defpath, 'LANG': 'C.UTF-8'})

def git_blob(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()

def git_objects(source):
    return {row.split(b'\t', 1)[1].decode(): row.split(b'\t', 1)[0].split()[2].decode()
            for row in git('ls-tree', '-r', '-z', source).split(b'\0') if row}

def write_payload(output, payload):
    need(not os.path.lexists(output) and output.parent == HERE and output.is_absolute()
         and output.resolve() == output and HERE.resolve() == HERE and HERE.stat().st_uid == os.getuid(),
         'exclusive fresh direct-child owned output')
    need(all(len(row[0]) <= MAX_FILE for row in payload.values()) and sum(len(row[0]) for row in payload.values()) <= MAX_PAYLOAD, 'bounded compact payload')
    output.mkdir(mode=0o700)
    archive_path = output / 'evidence.tar.gz'; manifest = []
    with tarfile.open(archive_path, mode='x:gz', format=tarfile.PAX_FORMAT) as archive:
        for member, (raw, info, path) in sorted(payload.items()):
            safe_member(member)
            entry = tarfile.TarInfo(member); entry.size = len(raw); entry.mode = stat.S_IMODE(info.st_mode)
            entry.uid = info.st_uid; entry.gid = info.st_gid; entry.mtime = info.st_mtime_ns // 10 ** 9
            entry.pax_headers = {'mtime': str(entry.mtime) + '.' + str(info.st_mtime_ns % 10 ** 9).zfill(9)}
            archive.addfile(entry, io.BytesIO(raw))
            manifest.append({'member': member, 'original': str(path), 'bytes': len(raw), 'sha256': sha(raw),
                             'mode': entry.mode, 'uid': entry.uid, 'gid': entry.gid, 'mtime_ns': info.st_mtime_ns})
    with tarfile.open(archive_path, mode='r:gz') as archive:
        entries = archive.getmembers()
        need([entry.name for entry in entries] == [row['member'] for row in manifest], 'complete archive member readback')
        for entry, row in zip(entries, manifest):
            need(entry.isfile() and entry.size == row['bytes'] and entry.mode == row['mode']
                 and entry.uid == row['uid'] and entry.gid == row['gid']
                 and int(Decimal(entry.pax_headers['mtime']) * 10 ** 9) == row['mtime_ns']
                 and sha(archive.extractfile(entry).read()) == row['sha256'], 'payload bytes/full portable metadata readback')
    return archive_path, manifest


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binding',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    need(Path(__file__).resolve()==HERE/'collect.disabled.py' and args.binding.parent==HERE,
         'literal owned disabled draft and binding required')
    binding=json.loads(read(args.binding)[0])
    # No source/attempt/selection inventory, controls, baseline read or output
    # may occur before actual primary UI reviews and final source release.
    need(COLLECTION_RELEASED and binding.get('status')=='BOUND_FINAL_ACCOUNT_CUSTODY',
         'DISABLED: actual repaired UI/measurement/selection and independent collector source review required')
    # Deliberately not a metadata-only release switch: final account semantic,
    # source/attempt/exclusion/alias fences must be implemented and reviewed
    # after those actuals exist. The copied writer is never called in this draft.
    raise ValueError('Account final semantic adapter not released; no collection authorized')


if __name__=='__main__':
    main()
