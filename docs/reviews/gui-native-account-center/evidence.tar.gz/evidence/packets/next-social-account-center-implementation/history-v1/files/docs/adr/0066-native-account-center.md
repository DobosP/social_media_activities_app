# ADR-0066: Native account overview and settings presentation

Date: 2026-10-20
Status: SOURCE ONLY — scratch proposal; not applied or qualified; closing source and37-body keeper binding pending.

## Scope and source

Replace only existing Pongo presentation for `/you/` and `/settings/` with a
cached escaped GoHTML view and scoped additive CSS. The existing `AccountView`
producer, services, SQL, auth/session admission, schema, dependencies, old assets,
Pongo templates and original assertions stay unchanged. Exact two-template
Renderer dispatch leaves SPA and every other renderer branch intact. Final
application waits for independently accepted date closure/source/baseline rebind;
provisional source0afd and V2 contractfdef are not a predicted closing commit.

The typed page projects the trusted current Actor/self map, source guardian and
connection flags, finite link order and token-row creation metadata. It adds no
unread query, Self fallback, token value/validity claim, legal parent identity or
participation authority. Language, logout, revoke, export and erasure-preview
spellings stay source-defined. `/i18n/setlang/` remains an admitted404 gap pending
Root's separate functional repair; form presence is not successful-save evidence.

Normal GET/HEAD retains Server.page notice/CSRF/canonical/site/avatar enrichment.
Revoke error keeps the original POST `/settings/api-token/revoke/` path for
canonical/request/language-next, Renderer default Social Activities, no normal
avatar query or notice consumption, and generic escaped failure copy. Failed
settings reconstruction remains503. API access shows stored creation metadata,
even an expired row; browser revocation stays self-only/idempotent and does not
remove web sessions. Export remains self GET/no-store, HEAD403; account erasure
remains a GET preview link. HTML remains private,no-cache; private SPA/JSON/export
remain no-store. No cache, CSP, method, role, CSRF/Origin or policy change follows.

## Strict source custody and tests proposed

Only three existing Go files change: renderer dispatch, a strict newest source
entry in the original walker, and a closed exact prior-source bridge for retained
inbox custody controls. Full SHA/length/unique-literal before/after relations and
inverse proof preserve all32/31/27 historic rows and138 current physical inputs.
No old test predicate, guard, fixture, registry or reference template is removed.
The older preference layout/transport fixture tables exclude you/settings, so
no test-only reference-render adapter is needed or added.

The original four new source images remain byte-exact. Five pure test roots
cover finite links/flags/metadata/contexts, escaping/read-only actions, malformed
projection and concurrent state isolation. A sixth new web root covers exact
source inverses/rehashed/truncated/old/duplicate mutations. One new assembled-App
root has eight groups covering real password-cookie GET/HEAD, current/session/
token admission, methods/CSRF/Origin/Referer, stored-expired metadata, self-only
revocation and errors, logout, exportHEAD/preview and explicit SPA boundaries.
Error tests make the common avatar table unavailable to prove direct error
rendering does not add the GET query; signed notice checks keep GET/error effects
distinct. These are authored assertions, not execution or acceptance receipts.
Credentials, rendered bodies, nonce/CSRF/session/token values and private exports
remain memory-only with generic failure diagnostics; no capture/export marker is
introduced. Fixed fictional fixtures alone may enter future UI evidence.

## Pending qualification and limits

No parser, formatter, compiler, test, PG, browser, benchmark, gate or owning edit
was run for this packet. Independent exact whole-patch source review is required
after the final date closing/37-body/native-input rebind. Root then applies,
formats with refreshed source relations, compiles/vets and runs meaningful
focused checks, commits and qualifies the unchanged complete affected profile
with original inventories/caps/timeouts/cleanup. All actual failed attempts must
remain distinct. Separate synthetic desktop/no-JS/Axe/keyboard/forms/all37-body
and matched fixed-data body measurement methods remain to be reviewed and run.
No performance, full21/current-image/main/GUI milestone/production/provider/
government/legal-parent/real-child activation or new authority is claimed.
