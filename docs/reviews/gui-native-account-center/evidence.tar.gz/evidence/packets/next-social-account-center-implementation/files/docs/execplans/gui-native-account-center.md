# Native account center — bounded execution plan

Valid until: closing/source bytes change — rebind and independently review before application.

Status: SOURCE ONLY; no product or method execution. Actual basebdb5cc8,
contractV3 006f1c6954cd; qualified native/UI0afd and canonicalbc10/all37 bodies
are concretely bound. Root exact four-new-Go formatting receiptd365 is recorded.

1. Verify exact closingbdb, all49 unchanged account-source witnesses and canonical
   bc10/all37 physical bodies/metadata, qualification34cc/UI8eb/measurement555.
   Preserve V1/V2 source/reviews and Root exact formatting receipt as history.
2. Independently review the complete source patch, two-template-only dispatch,
   typed projection, strict source inverse bridges and all original assertions.
   Language404 repair is separate; no producer/SQL/auth/policy changes are allowed.
3. Root applies only independently accepted postformat images, compiles/vets and
   runs focused pure/custody/App checks with credential-safe diagnostics.
   Five pure roots,one custody root andone App root/eight groups are declarations,
   not observed pass counts. Repair failures before committing the exact source.
4. Qualify complete affected packages with existing inventory/case/query/resource/
   timeout/cleanup authorities; count actual roots/named cases and stopped services.
   Do not replace complete qualification with focused tests or invent a pass.
5. Review separate synthetic GET overview/settings/token absent/present/expired
   metadata and POST revoke-error fixtures. Preserve GET canonical/site/avatar/
   notice versus error action-path/defaultsite/absent-avatar/notice distinctions.
6. Run desktop1280x720 JS/no-JS, strict whole-document Axe, keyboard/FormData/current
   asset checks and all37 previous-body equality on the exact accepted source.
   Use only fictional labels/dates/fixed synthetic CSRF; no actual credential,
   export/erasure payload, logged body or live revoke/logout/export/delete action.
7. Measure only fixed synthetic matched rendering, including native projection/
   copying work. Keep elapsed/HTML/gzip/allocation results and variability honest;
   no mutation/HTTP/SQL/general efficiency claim. Methods require source review.
8. Independently review actual qualification/UI/measurement/custody/feature records,
   retain compact source/failures/reproduction, then separately authorize exact
   rolling retention. Root alone promotes reviewed canonical/docs and publishes
   the feature branch. No main/milestone/production/provider/real-child authority.
