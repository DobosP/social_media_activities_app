# ADR ledger — claimed numbers

Claim the next free number **here, in the same commit as the ADR file**, so two parallel worktrees
never mint the same number. Next free number: **0063** (0057–0060 already claimed on existing refs; 0061 claimed here) (0041–0049 reserved 2026-10-05 for the audit fix sessions: G2 0041/0043–0046, G3 0042/0047–0049; 0055 claimed on branch `feat/policy8-local-poc`). Template: [`0000-template.md`](0000-template.md).
ADRs are append-only: a reversal is a new ADR that flips the old one's `Status:` to `superseded-by ADR-NNNN`.
On conflict: `STATUS.md` > newest-dated ADR > every other doc.

| # | Slug | Status | Date |
|---|---|---|---|
| 0001 | [launch-hosting-hetzner-single-box](0001-launch-hosting-hetzner-single-box.md) | accepted | 2026-06-19 |
| 0002 | [cohort-connections-policy](0002-cohort-connections-policy.md) | accepted | 2026-05-30 |
| 0003 | [no-celery-postgres-deferredtask](0003-no-celery-postgres-deferredtask.md) | accepted | 2026-06-23 |
| 0004 | [media-screening-hash-blocklist-first](0004-media-screening-hash-blocklist-first.md) | accepted (its "no video" line superseded by ADR-0026) | 2026-06-13 |
| 0005 | [dependency-pinning-policy](0005-dependency-pinning-policy.md) | accepted | 2026-05-27 |
| 0006 | [e2ee-messaging-access-control-over-scanning](0006-e2ee-messaging-access-control-over-scanning.md) | accepted | 2026-05-29 |
| 0007 | [mobile-photo-activity-cards](0007-mobile-photo-activity-cards.md) | accepted | 2026-07-03 |
| 0008 | [api-v1-pagination-and-deferred-task-kinds](0008-api-v1-pagination-and-deferred-task-kinds.md) | accepted | 2026-07-04 |
| 0009 ⚠ | [csp-enforcement-prep](0009-csp-enforcement-prep.md) | superseded-by ADR-0010 | 2026-07-04 |
| 0009 ⚠ | [query-retention-and-audit-checkpoints](0009-query-retention-and-audit-checkpoints.md) | accepted | 2026-07-04 |
| 0010 | [csp-style-hardening-and-report-digest](0010-csp-style-hardening-and-report-digest.md) | superseded-by ADR-0014 | 2026-07-04 |
| 0011 | [readiness-and-structured-request-logs](0011-readiness-and-structured-request-logs.md) | accepted | 2026-07-04 |
| 0012 | [media-presigned-egress](0012-media-presigned-egress.md) | accepted | 2026-07-04 |
| 0013 | [graceful-readiness-drain](0013-graceful-readiness-drain.md) | accepted | 2026-07-04 |
| 0014 | [bounded-csp-report-ingestion](0014-bounded-csp-report-ingestion.md) | accepted | 2026-07-04 |
| 0015 | [browser-security-headers](0015-browser-security-headers.md) | accepted | 2026-07-04 |
| 0016 | [react-spa-frontend-migration](0016-react-spa-frontend-migration.md) | accepted | 2026-07-06 |
| 0017 | [roedu-seed-after-migrate](0017-roedu-seed-after-migrate.md) | accepted | 2026-07-07 |
| 0018 | [public-listing-request-field](0018-public-listing-request-field.md) | accepted | 2026-07-07 |
| 0019 | [places-v2-and-ia-redesign](0019-places-v2-and-ia-redesign.md) | accepted (owner direction) | 2026-07-07 |
| 0020 | [multi-type-activities-wizard-live-filters](0020-multi-type-activities-wizard-live-filters.md) | accepted (owner feedback on ADR-0019) | 2026-07-07 |
| 0021 | [map-quality-filters-labels-aggregation](0021-map-quality-filters-labels-aggregation.md) | accepted | 2026-07-07 |
| 0022 | [resource-bounded-asgi-browser-runtime](0022-resource-bounded-asgi-browser-runtime.md) | accepted | 2026-07-11 |
| 0023 | [roedu-event-lifecycle-snapshot-reconciliation](0023-roedu-event-lifecycle-snapshot-reconciliation.md) | accepted | 2026-07-12 |
| 0024 | [canonical-roedu-social-app-pack](0024-canonical-roedu-social-app-pack.md) | accepted | 2026-07-12 |
| 0025 | [agent-and-search-engine-access-surface](0025-agent-and-search-engine-access-surface.md) | accepted | 2026-07-12 |
| 0026 | [private-thread-video-and-sota-image-compression](0026-private-thread-video-and-sota-image-compression.md) | accepted (supersedes the "no video" line of ADR-0004) | 2026-07-13 |
| 0027 | [avatar-styles-uniqueness-registry](0027-avatar-styles-uniqueness-registry.md) | accepted (owner-approved) | 2026-07-13 |
| 0028 | [tiered-profile-visibility](0028-tiered-profile-visibility.md) | accepted (owner-approved tier matrix) | 2026-07-13 |
| 0029 | [plural-sentiment-reactions](0029-plural-sentiment-reactions.md) | accepted (owner decisions) | 2026-07-14 |
| 0030 | [refusal-visibility-and-tick-isolation](0030-refusal-visibility-and-tick-isolation.md) | accepted; one owner decision open (§4 refused-`venues` narrowing) | 2026-08-18 |
| 0031 | [go-public-serving-foundation](0031-go-public-serving-foundation.md) | scope superseded by 0032 | 2026-10-04 |
| 0032 | [complete-native-go-backend](0032-complete-native-go-backend.md) | accepted; landing authorized 2026-10-04, code review pending (ADR-0040) | 2026-10-04 |
| 0033 | [manual-github-actions](0033-manual-github-actions.md) | accepted; explicit owner request | 2026-10-04 |
| 0034 | [native-config-error-observability](0034-native-config-error-observability.md) | implemented; landing per ADR-0040; human review gates first deployment | 2026-10-04 |
| 0035 | [guarded-permissions-private-schema](0035-guarded-permissions-private-schema.md) | proposed; landing per ADR-0040; human auth/privacy review gates first deployment | 2026-10-04 |
| 0036 | [fresh-participation-authority](0036-fresh-participation-authority.md) | proposed; locally qualified, landing per ADR-0040; human review gates first deployment | 2026-10-04 |
| 0037 | [postgresql-shared-rate-budgets](0037-postgresql-shared-rate-budgets.md) | proposed for integration review | 2026-10-04 |
| 0038 | [native-verification-toolchain](0038-native-verification-toolchain.md) | proposed; native qualified, reference retirement blocked; landing per ADR-0040; human review gates first deployment | 2026-10-05 |
| 0039 | [native-source-login-failure-counter](0039-native-source-login-failure-counter.md) | proposed; source restoration qualified, landing per ADR-0040; human auth/privacy review gates first deployment | 2026-10-05 |
| 0040 | [landing-and-deployment-review-gates](0040-landing-and-deployment-review-gates.md) | accepted; owner decision 2026-10-05 | 2026-10-05 |
| 0041 | [report-eligibility-predicate](0041-report-eligibility-predicate.md) | accepted; owner decisions 2026-10-05; human safety review gates first deployment | 2026-10-05 |
| 0043 | [direct-only-block-veto](0043-direct-only-block-veto.md) | accepted; owner decision 2026-10-05 (narrows SAFETY rule 2 to direct chats); human safety review gates first deployment | 2026-10-05 |
| 0044 | [media-fingerprint-minimisation](0044-media-fingerprint-minimisation.md) | accepted; reference parity (audit GO-MEDIA-01/02); human privacy review gates first deployment | 2026-10-05 |
| 0045 | [guardian-authority](0045-guardian-authority.md) | accepted; owner decisions 2026-10-05; human safety review gates first deployment | 2026-10-05 |
| 0046 | [membership-logistics-scope](0046-membership-logistics-scope.md) | accepted; owner decisions 2026-10-05; human privacy review gates first deployment | 2026-10-05 |
| 0050 | [original-public-gui-fixtures](0050-original-public-gui-fixtures.md) | targeted managed tests passed; landing/group review pending | 2026-10-10 |
| 0051 | [public-original-template-load-tracing](0051-public-original-template-load-tracing.md) | targeted tests/formatter passed; broader landing/group review pending | 2026-10-10 |
| 0052 | [released-public-golden-tooling-bridge](0052-released-public-golden-tooling-bridge.md) | focused managed checks and bounded actual review passed; no formal oracle/group acceptance | 2026-10-10 |
| 0053 | [filesystem-original-renderer-boundary](0053-filesystem-original-renderer-boundary.md) | focused managed checks/partial actual review passed; no default production switch | 2026-10-10 |
| 0054 | [public-external-script-nonce-binding](0054-public-external-script-nonce-binding.md) | focused managed83/DATA checks passed; wider qualification pending | 2026-10-10 |
| 0056 | [gui-preparation-scope-and-portable-mode-binding](0056-gui-preparation-scope-and-portable-mode-binding.md) | proposed; owner decision Q2 2026-10-11; 794573c output change awaits privacy/independent review | 2026-10-11 |
| 0061 | [native-family-pages](0061-native-family-pages.md) | implemented; independently qualified affected PG6/desktop8+2, feature branch only | 2026-10-19 |
| 0062 | [native-group-create](0062-native-group-create.md) | independently feature-qualified PG1f8c974 + presentationd05343b | 2026-10-19 |
| 0063 | [native-group-detail](0063-native-group-detail.md) | independently feature-qualified affectedPG6/desktop7+7; feature branch only | 2026-10-19 |
| 0064 | [native-notification-preferences](0064-native-notification-preferences.md) | independently feature-qualified affectedPG6/desktop6+6; feature branch only | 2026-10-20 |
| 0065 | [native-notification-inbox](0065-native-notification-inbox.md) | original496 feature-qualified/custody retained; date0afd independently qualified affectedPG7/450roots1353named, UI6+6/all37 exact, matched body costs lower/HTML larger; date keeperbc10/feature6611 and exact retention3eef/postcheck4122 accepted; feature branch only | 2026-10-20 |

| 0066 | [native-account-center](0066-native-account-center.md) | SOURCE ONLY over closingbdb; bound native37 keeper, repaired exact readers/fixture isolation and Root formatted new-Go; final source review/application/all execution pending | 2026-10-20 |

⚠ **0009 is claimed twice** — this ledger exists so it does not happen again. Both files stay:
`0009-csp-enforcement-prep.md` (superseded by ADR-0010) and
`0009-query-retention-and-audit-checkpoints.md` (accepted). Cite the slug, not the bare number.
