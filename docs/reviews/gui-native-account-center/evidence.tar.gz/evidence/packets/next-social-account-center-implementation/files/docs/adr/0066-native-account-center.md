# ADR-0066: Native account overview and settings presentation

Date: 2026-10-20
Status: SOURCE ONLY — exact closingbdb and37-body keeper bound; Root mechanical formatting incorporated; final source review, application and qualification pending.

## Scope and source

Replace only existing Pongo presentation for `/you/` and `/settings/` with a
cached escaped GoHTML view and scoped additive CSS. The existing `AccountView`
producer, services, SQL, auth/session admission, schema, dependencies, old assets,
Pongo templates and original assertions stay unchanged. Exact two-template
Renderer dispatch leaves SPA and every other renderer branch intact. Base is
actual closingbdb5cc82a30c2b3307c87d56fdc92fc55948ecff; native producer/UI method
remain qualified0afd. ContractV3 006f1c6954cd binds all49 unchanged source witnesses,
source-manifest2230/5c1a07b0 and accepted canonicalbc10/1689 members with all37
physical bodies. Keeper2d0a/feature6611/publicationba3c and full34cc/UI8eb/555
measurements establish the baseline only; this account source is unqualified.

The typed page projects the trusted current Actor/self map, source guardian and
connection flags, finite link order and token-row creation metadata. It adds no
unread query, Self fallback, token value/validity claim, legal parent identity or
participation authority. Language, logout, revoke, export and erasure-preview
spellings stay source-defined. `/i18n/setlang/` remains an admitted404 gap pending
Root's separate functional repair; form presence is not successful-save evidence.

Normal GET/HEAD retains Server.page notice/CSRF/canonical/site/avatar enrichment.
Revoke error keeps the original POST `/settings/api-token/revoke/` path for
canonical/request/language-next, Renderer default Social Activities, no normal
avatar query or notice consumption, and generic escaped failure copy. Failed
settings reconstruction remains503. API access shows stored creation metadata,
even an expired row; browser revocation stays self-only/idempotent and does not
remove web sessions. Export remains self GET/no-store, HEAD403; account erasure
remains a GET preview link. HTML remains private,no-cache; private SPA/JSON/export
remain no-store. No cache, CSP, method, role, CSRF/Origin or policy change follows.

## Strict source custody and tests proposed

Only four existing Go files change: renderer dispatch, strict newest source
entries in the original walker and live preference binding, and a closed exact
prior-source bridge for retained inbox custody controls. Full SHA/length/unique-literal before/after relations and
inverse proof preserve all32/31/27 historic rows and138 current physical inputs.
No old test predicate, guard, fixture, registry or reference template is removed.
The older preference layout/transport fixture tables exclude you/settings, so
no test-only reference-render adapter is needed or added.

Original new GoHTML/CSS images remain byte-exact; four new Go images use only
Root mechanical formatting outputs, receiptd365f013. Complete compact V2 and
review26c938ab/observation36e73ff6 remain in history-v2. Five pure test roots
cover finite links/flags/metadata/contexts, escaping/read-only actions, malformed
projection and concurrent state isolation. A sixth new web root covers exact
source inverses/rehashed/truncated/old/duplicate mutations. One new assembled-App
root has eight groups covering real password-cookie GET/HEAD, current/session/
token admission, methods/CSRF/Origin/Referer, stored-expired metadata, self-only
revocation and errors, logout, exportHEAD/preview and explicit SPA boundaries.
Error tests keep fixture relations shadowing public while making the actual
avatar generation column unavailable; a local DELETE refusal plus unavailable
settings created column exercises failed reconstruction. Signed notice checks
keep GET/error effects distinct. These are authored assertions, not execution or acceptance receipts.
Credentials, rendered bodies, nonce/CSRF/session/token values and private exports
remain memory-only with generic failure diagnostics; no capture/export marker is
introduced. Fixed fictional fixtures alone may enter future UI evidence.

## Pending qualification and limits

No parser, formatter, compiler, test, PG, browser, benchmark, gate or owning edit
was run by this author. Root separately ran gofmt-e on four NEW Go images; only
those exact outputs are incorporated, with all existing reader/hash relations
unchanged. No compile or test result follows. Independent exact whole-patch
postformat/contract review is required on this actual bound closing. Root then
applies, compiles/vets and runs meaningful
focused checks, commits and qualifies the unchanged complete affected profile
with original inventories/caps/timeouts/cleanup. All actual failed attempts must
remain distinct. Separate synthetic desktop/no-JS/Axe/keyboard/forms/all37-body
and matched fixed-data body measurement methods remain to be reviewed and run.
No performance, full21/current-image/main/GUI milestone/production/provider/
government/legal-parent/real-child activation or new authority is claimed.
