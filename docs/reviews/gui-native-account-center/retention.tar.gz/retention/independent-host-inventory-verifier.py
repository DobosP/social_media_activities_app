"""Read-only HOST verification of the one fixed retention inventory; no remover."""
import collections
import gzip
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import tarfile

H = Path('/home/dobo/work/_temp/feat__gui-app-migration-a/social-family/account-center-retention')
F = H.parent
REPO = Path('/home/dobo/work/_worktrees/social_media_activities_app/feat__gui-app-migration-a')
OLD = F / 'notification-inbox-date-pg-qa/run-0afd29b79fec-0d124589-48a8-45be-a6b7-b93476bc129c'
PREVIOUS = F / 'account-center-pg-qa/run-a8f713f74885-7c56c571-615c-40bc-9163-4e6e9e9afecf'
LATEST = F / 'account-center-pg-qa/run-02ac07258cca-7ad9ada4-a7d6-4780-bc94-4d29b542f972'
K = ('st_dev', 'st_ino', 'st_mode', 'st_uid', 'st_gid', 'st_size', 'st_mtime_ns', 'st_ctime_ns', 'st_nlink')
sha = lambda b: hashlib.sha256(b).hexdigest()
load = lambda p: json.loads(p.read_bytes())
I = json.loads(gzip.decompress((H / 'inventory.json.gz').read_bytes()))
L = json.loads(gzip.decompress((H / 'latest-snapshot.json.gz').read_bytes()))
S = load(H / 'inventory-summary.json')
O = load(H / 'host-observer.json')
assert O == I['observer'] and O['uid'] == O['euid'] == os.getuid() == 1000
assert O['gid'] == O['egid'] == os.getgid() == 1000
assert O['uid_map'] == Path('/proc/self/uid_map').read_text() and O['gid_map'] == Path('/proc/self/gid_map').read_text()
assert O['user_namespace'] == os.readlink('/proc/self/ns/user')
assert sha((H / 'inventory.json.gz').read_bytes()) == S['inventory']['sha256'] == '42c8923d04738912cff8a2dc7d9ac497339c10abdb2fd44dac25cfabfa7929bc'
assert sha((H / 'latest-snapshot.json.gz').read_bytes()) == S['latest_snapshot']['sha256'] == '4791125487ed712f628f5dda36b2730d79881a85da329db72cac56eb3ec7b322'
assert len(gzip.decompress((H / 'inventory.json.gz').read_bytes())) == S['inventory']['uncompressed_bytes']
assert len(gzip.decompress((H / 'latest-snapshot.json.gz').read_bytes())) == S['latest_snapshot']['uncompressed_bytes']
registry = {}


def check(row, target=False):
    path = Path(row['path'])
    assert path.is_absolute() and path.resolve() == path and not path.is_symlink()
    before = path.lstat()
    assert {k: getattr(before, k) for k in K} == row['stat']
    if target:
        assert before.st_uid == os.getuid()
    if row['kind'] == 'directory':
        assert stat.S_ISDIR(before.st_mode) and sorted(p.name for p in path.iterdir()) == row['entries']
    else:
        assert row['kind'] == 'file' and stat.S_ISREG(before.st_mode) and before.st_nlink == 1
        result = hashlib.sha256()
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
        try:
            assert {k: getattr(os.fstat(fd), k) for k in K} == row['stat']
            while chunk := os.read(fd, 1 << 20):
                result.update(chunk)
            assert {k: getattr(os.fstat(fd), k) for k in K} == row['stat']
        finally:
            os.close(fd)
        assert result.hexdigest() == row['sha256'] and before.st_size == row['bytes'] and before.st_blocks * 512 == row['allocated_bytes']
    assert {k: getattr(path.lstat(), k) for k in K} == row['stat']
    if row['path'] in registry:
        assert registry[row['path']] == row
    registry[row['path']] = row


fixed_dirs = [run / leaf for run in (OLD, PREVIOUS) for leaf in ('source', 'binaries')]
fixed_file = PREVIOUS / 'proof/command-006.stdout'
assert [g['root'] for g in I['target_groups']] == list(map(str, fixed_dirs + [fixed_file])) == S['target_roots']
targets = []
for group in I['target_groups']:
    root = Path(group['root'])
    rows = group['rows']
    index = {r['path']: r for r in rows}
    assert len(index) == len(rows) and str(root) in index
    assert group['type'] == ('whole_owned_generated_tree' if root in fixed_dirs else 'literal_duplicate_Git_stdout')
    for row in rows:
        path = Path(row['path'])
        assert path == root or path.is_relative_to(root)
        check(row, True)
        if row['kind'] == 'directory':
            assert {str(path / n) for n in row['entries']} <= set(index)
    if root == fixed_file:
        assert len(rows) == 1 and rows[0]['kind'] == 'file'
    targets += rows
assert len({r['path'] for r in targets}) == len(targets)
files = [r for r in targets if r['kind'] == 'file']
directories = [r for r in targets if r['kind'] == 'directory']
assert len(files) == S['target_files'] == 4500 and len(directories) == S['target_directories'] == 489
assert sum(r['bytes'] for r in files) == S['target_logical_bytes'] == 667239108
assert sum(r['allocated_bytes'] for r in files) == S['target_allocated_bytes'] == 676671488
protected = []
for key, countkey in [('preserved_old_and_latest_runs', 'protected_run_rows'), ('preserved_latest_UI', 'protected_UI_rows'), ('preserved_old_canonical', 'protected_canonical_rows'), ('preserved_account_packets_and_all_UI', 'protected_packet_rows')]:
    assert len(I[key]) == S[countkey]
    for row in I[key]:
        path = Path(row['path'])
        assert not any(path == p or path.is_relative_to(p) for p in fixed_dirs + [fixed_file])
        check(row)
    protected += I[key]
assert L['rows'] == [r for r in I['preserved_old_and_latest_runs'] if Path(r['path']) == LATEST or Path(r['path']).is_relative_to(LATEST)]
assert L['UI_rows'] == I['preserved_latest_UI'] and L['ALL695_native_PG_artifacts_including_Gitstdout_protected'] and L['excluded_latest_stdout'] is None
probe = O['foreign_protected_probe']
check(probe)
assert probe['path'] == str(LATEST / 'socket/pg-cleanup.json') and probe['stat']['st_uid'] == probe['stat']['st_gid'] == 999
selected = load(F / 'account-center-keeper/prepared-selection.json')
old_probe = [r for r in selected['foreign_owned_payload_rows'] if r['path'] == probe['path']][0]
assert all(old_probe['stat'][k] == probe['stat'][k] for k in K if k not in ('st_uid', 'st_gid'))
assert O['keeper_observer_probe_ownership'] == {'st_uid': 65534, 'st_gid': 65534} and not O['ownership_normalized']
git = lambda *a: subprocess.check_output(['git', '--no-optional-locks', '-C', str(REPO), *a])
assert git('rev-parse', 'HEAD').decode().strip() == S['source_sha'] and git('rev-parse', 'HEAD^{tree}').decode().strip() == S['source_tree']
assert not git('status', '--porcelain', '--untracked-files=all')
for join in I['source_Git_joins']:
    manifest_path = Path(join['source_manifest'])
    manifest = load(manifest_path)
    assert sha(manifest_path.read_bytes()) == join['source_manifest_sha256'] and len(manifest) == join['regular_files']
    root = manifest_path.parent / 'source'
    rows = {Path(r['path']).relative_to(root).as_posix(): r for r in registry.values() if r['kind'] == 'file' and Path(r['path']).is_relative_to(root)}
    objects = {}
    for line in git('ls-tree', '-r', '-z', join['commit']).split(b'\0'):
        if line:
            meta, name = line.split(b'\t', 1)
            mode, kind, oid = meta.split()
            assert kind == b'blob' and mode in (b'100644', b'100755')
            objects[name.decode()] = (int(mode, 8) & 0o777, oid.decode())
    assert set(objects) == set(rows) == {r['path'] for r in manifest}
    process = subprocess.Popen(['git', '--no-optional-locks', '-C', str(REPO), 'cat-file', '--batch'], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    for row in manifest:
        current = rows[row['path']]
        mode, oid = objects[row['path']]
        assert current['bytes'] == row['bytes'] and current['sha256'] == row['sha256'] and stat.S_IMODE(current['stat']['st_mode']) == row['mode'] == mode
        process.stdin.write((oid + '\n').encode()); process.stdin.flush()
        header = process.stdout.readline().split(); data = process.stdout.read(int(header[2]))
        assert header[:2] == [oid.encode(), b'blob'] and process.stdout.read(1) == b'\n' and sha(data) == row['sha256'] and len(data) == row['bytes']
    process.stdin.close()
    assert process.wait() == 0
assert len(I['binary_provenance']) == 18
for row in I['binary_provenance']:
    current = registry[row['path']]
    value = load(Path(row['run']) / 'result.json')
    command = row['actual_build_command']
    assert value['method_pass'] and value['errors'] == [] and command in value['commands'] and command['exit'] == 0
    assert command['argv'][command['argv'].index('-o') + 1] == row['path']
    assert current['sha256'] == row['original_recorded_sha256'] == row['observed_current_sha256']
archive = I['duplicate_archive_provenance'][0]
assert archive['path'] == str(fixed_file) and len(I['duplicate_archive_provenance']) == 1
value = load(PREVIOUS / 'result.json')
assert archive['command'] in value['commands'] and archive['command']['exit'] == 0
assert registry[str(fixed_file)]['sha256'] == value['git_archive']['sha256'] == '907428a29eb83d7a37e2aa72e46034ae1c690724290e96cb14c8b31721f5b8b9'
assert not (OLD / 'proof/command-006.stdout').exists()
assert I['already_pruned0afd_archive']['status'] == 'NONE_ALREADY_PRUNED_NOT_A_NEW_TARGET'
prior = load(REPO / 'docs/reviews/gui-native-notification-inbox-dates/retention-result.json')
assert I['already_pruned0afd_archive']['original_deleted_row'] in prior['deleted']
value = load(LATEST / 'result.json')
assert len(value['artifact_rows']) == 695
for row in value['artifact_rows']:
    current = registry[str(LATEST / row['path'])]
    assert current['sha256'] == row['sha256'] and current['bytes'] == row['bytes']
assert len(I['owned_roles']) == len({r['cid'] for r in I['owned_roles']}) == len({r['name'] for r in I['owned_roles']}) == 45
for row in I['owned_roles']:
    run = Path(row['run'])
    created = load(run / 'proof' / (row['role'] + '-created.json'))
    assert created['id'] == row['cid'] and created['name'] == row['name'] and created['labels']['io.dobolabs.gui.owner'] in row['name']
    assert sha((run / (row['role'] + '.cid')).read_bytes()) == row['CID_file_sha256']
assert not git('status', '--porcelain', '--untracked-files=all')
print(json.dumps({'schema': 1, 'status': 'PASS_INDEPENDENT_HOST_INVENTORY_BOUNDARIES_ONLY_NOT_DRYRUN_OR_DELETION', 'source_sha': S['source_sha'], 'source_tree': S['source_tree'], 'inventory_sha256': S['inventory']['sha256'], 'latest_snapshot_sha256': S['latest_snapshot']['sha256'], 'target_files': len(files), 'target_directories': len(directories), 'target_logical_bytes': sum(r['bytes'] for r in files), 'target_allocated_bytes': sum(r['allocated_bytes'] for r in files), 'target_roots': S['target_roots'], 'unique_physical_rows_rehashed': len(registry), 'protected_run_rows': S['protected_run_rows'], 'protected_UI_rows': S['protected_UI_rows'], 'protected_packet_rows': S['protected_packet_rows'], 'protected_canonical_rows': S['protected_canonical_rows'], 'source_join_counts': [j['regular_files'] for j in I['source_Git_joins']], 'successful_original_binary_provenance': len(I['binary_provenance']), 'CID_history_rows': len(I['owned_roles']), 'latest_R_all695_including_Gitstdout_protected': True, 'old0afd_stdout_already_pruned_never_targeted': True, 'HOST999_and_keeper65534_probe_views_distinct_no_normalization': True, 'all_original_bytes_and_metadata_still_present': True, 'findings': []}, indent=2))
