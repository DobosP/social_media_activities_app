#!/usr/bin/env python3
"""Read-only HOST duplicate-source proof; never export, replay or remove anything."""
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import tarfile

HERE = Path('/home/dobo/work/_temp/feat__gui-app-migration-a/social-family/account-center-retention')
TARGET = HERE.parent/'account-center-pg-qa/run-a8f713f74885-7c56c571-615c-40bc-9163-4e6e9e9afecf/proof/command-006.stdout'
INVENTORY_SHA = '42c8923d04738912cff8a2dc7d9ac497339c10abdb2fd44dac25cfabfa7929bc'
KEYS = ('st_dev', 'st_ino', 'st_mode', 'st_uid', 'st_gid', 'st_size', 'st_mtime_ns', 'st_ctime_ns', 'st_nlink')


def need(value, message):
    if not value:
        raise RuntimeError(message)


def main():
    need(Path(__file__).resolve() == HERE / 'verify-archive-content.py', 'exact proof source required')
    inv_path=HERE/'inventory.json.gz';before=inv_path.lstat()
    need(inv_path.resolve()==inv_path and stat.S_ISREG(before.st_mode) and before.st_size<=64<<20,'bounded literal inventory')
    fd=os.open(inv_path,os.O_RDONLY|os.O_NOFOLLOW)
    try:
        need({k:getattr(os.fstat(fd),k) for k in KEYS}=={k:getattr(before,k) for k in KEYS},'inventory changed before open')
        with os.fdopen(fd,'rb',closefd=False) as stream:raw=stream.read((64<<20)+1)
        need(len(raw)==before.st_size and {k:getattr(os.fstat(fd),k) for k in KEYS}=={k:getattr(before,k) for k in KEYS},'inventory changed during read')
    finally:os.close(fd)
    need(hashlib.sha256(raw).hexdigest()==INVENTORY_SHA,'exact HOST inventory digest')
    with gzip.GzipFile(fileobj=io.BytesIO(raw)) as stream:decoded=stream.read((128<<20)+1)
    need(len(decoded)<=128<<20,'bounded decoded inventory')
    inventory=json.loads(decoded)
    need(len(inventory['duplicate_archive_provenance'])==1 and inventory['duplicate_archive_provenance'][0]['path']==str(TARGET),
         'only the one exact a8 duplicate;latestR archive never a target')
    probe = Path(inventory['observer']['foreign_protected_probe']['path'])
    need(probe.stat().st_uid == probe.stat().st_gid == 999, 'same HOST observer required')
    records = []
    groups = inventory['target_groups']
    for item in inventory['duplicate_archive_provenance']:
        path = Path(item['path']); need(path.resolve() == path, 'canonical archive input required')
        original = next(group['rows'][0] for group in groups if group['root'] == str(path))
        run = path.parents[1]
        join = next(row for row in inventory['source_Git_joins'] if row['source_manifest'] == str(run / 'source-manifest.json'))
        manifest_path = run / 'source-manifest.json'
        expected_manifest = next(row for row in inventory['preserved_old_and_latest_runs'] if row['path'] == str(manifest_path))
        need(manifest_path.resolve() == manifest_path and {key: getattr(manifest_path.lstat(), key) for key in KEYS} == expected_manifest['stat'], 'source manifest metadata differs')
        manifest_raw = manifest_path.read_bytes()
        need(hashlib.sha256(manifest_raw).hexdigest() == join['source_manifest_sha256'] == expected_manifest['sha256'], 'source manifest hash differs')
        manifest = json.loads(manifest_raw)
        by_path = {row['path']: row for row in manifest}
        need(len(by_path) == len(manifest) and not any('link' in row for row in manifest), 'unique regular source manifest required')
        before = path.lstat()
        need(stat.S_ISREG(before.st_mode) and {key: getattr(before, key) for key in KEYS} == original['stat'], 'archive bytes/stat beforeimage differs')
        descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
        seen = set()
        try:
            with os.fdopen(descriptor, 'rb', closefd=False) as stream:
                with tarfile.open(fileobj=stream, mode='r:gz') as archive:
                    for member in archive:
                        name = member.name.rstrip('/')
                        need(name and not name.startswith('/') and '..' not in Path(name).parts, 'unsafe archive member')
                        if member.isdir():
                            continue
                        need(member.isfile() and name in by_path and name not in seen, 'unexpected/duplicate archive object')
                        seen.add(name); expected = by_path[name]
                        need(member.size == expected['bytes'] and member.mode & ~0o022 == expected['mode'], 'original source size/mode differs')
                        digest = hashlib.sha256()
                        data = archive.extractfile(member)
                        while True:
                            block = data.read(1 << 20)
                            if not block:
                                break
                            digest.update(block)
                        need(digest.hexdigest() == expected['sha256'], 'original source member hash differs')
                    comment = archive.pax_headers.get('comment')
                    need(comment in (None, join['commit']), 'archive commit comment differs')
            after = os.fstat(descriptor)
        finally:
            os.close(descriptor)
        need(seen == set(by_path) and {key: getattr(after, key) for key in KEYS} == original['stat']
             and {key: getattr(path.lstat(), key) for key in KEYS} == original['stat'], 'archive completeness/final metadata differs')
        records.append({'path': str(path), 'observed_archive_sha256': original['sha256'], 'archive_bytes': original['bytes'],
                        'source_commit': join['commit'], 'source_manifest_sha256': join['source_manifest_sha256'],
                        'regular_source_members': len(seen), 'all_member_bytes_modes_match_Git_verified_source_manifest': True,
                        'archive_comment': comment, 'command_ledger_available': item['command'] is not None,
                        'scope': 'One successful a8 archive content proof only; original successful command/build hashes are retained. LatestR archive remains protected.'})
    target = HERE / 'archive-content-custody.json'
    need(not target.exists(), 'proof output already exists')
    value = {'schema': 1, 'status': 'HOST_READ_ONLY_EXACT_A8_ARCHIVE_CONTENT_MATCHES_NOT_RETENTION',
             'rows': records, 'accepted_account_keeper_archive': 'e31b656ba310cb09639a6ab7e1a2a2dc8d305e17ae7a1f30ce3c8bc5ca3bee26', 'deletion_performed': False}
    target.write_text(json.dumps(value, indent=2) + '\n')
    print(json.dumps({'rows': len(records), 'member_counts': [row['regular_source_members'] for row in records],
                      'proof_sha256': hashlib.sha256(target.read_bytes()).hexdigest()}))


if __name__ == '__main__':
    main()
