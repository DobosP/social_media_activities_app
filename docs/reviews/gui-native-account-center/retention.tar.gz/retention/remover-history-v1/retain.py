#!/usr/bin/env python3
"""Exact review-bound HOST account rolling retention; no recursive removal."""
import argparse
from decimal import Decimal
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import time
import tarfile
import uuid

BASE = Path('/home/dobo/work/_temp/feat__gui-app-migration-a/social-family')
HERE = BASE / 'account-center-retention'
REPO = Path('/home/dobo/work/_worktrees/social_media_activities_app/feat__gui-app-migration-a')
OLD = BASE / 'notification-inbox-date-pg-qa/run-0afd29b79fec-0d124589-48a8-45be-a6b7-b93476bc129c'
PREVIOUS = BASE / 'account-center-pg-qa/run-a8f713f74885-7c56c571-615c-40bc-9163-4e6e9e9afecf'
LATEST = BASE / 'account-center-pg-qa/run-02ac07258cca-7ad9ada4-a7d6-4780-bc94-4d29b542f972'
CURRENT_UI = Path('/home/dobo/work/_temp/ac-ui/run-02ac07258cca-d0c13ae7-7bc6-4d06-bcc2-f919042eea6a')
DATE_KEEPER = REPO / 'docs/reviews/gui-native-notification-inbox-dates'
ACCOUNT_KEEPER = BASE / 'account-center-keeper'
CANDIDATE = ACCOUNT_KEEPER / 'candidate-75edf1a'
SOURCE = '75edf1a051e95441248f58dbfed9e610cc4a00b6'
TREE = 'e0b844fff50626b120752affc54d2e21cf32d2e6'
OLD_SOURCE = '0afd29b79fecf69bfb88847a8412d4bb2e02a787'
PREVIOUS_SOURCE = 'a8f713f74885acfc51f6985bc8c6a366950029b3'
NATIVE_SOURCE = '02ac07258cca866180ef93aeeb6a17ecb07baae1'
PLAN_SHA = '2ec96b7f43067b874fb0a7d741523ba1b579ae1461266cb97f808ad356eedb6f'
INVENTORY_SHA = '42c8923d04738912cff8a2dc7d9ac497339c10abdb2fd44dac25cfabfa7929bc'
LATEST_SHA = '4791125487ed712f628f5dda36b2730d79881a85da329db72cac56eb3ec7b322'
PG_SHA = '856b0b3beb1d3b5d9cd784c067b27dd67e3ccca876f94607361abf920829962e'
PREVIOUS_PG_SHA = 'dab389ac8492b0db6bfcaca26fcd84ce535a8f14a0def7445b31d4819ab3fa2e'
OLD_PG_SHA = '1ba8e2499b7fe93b979e835c0e3d7533f731b08581d2e40a9b0519f780d8a647'
UI_SHA = '949ebfe97d0f66fc858af87948a8feb6212c12af4790cabdbb62227108416ad8'
LANES = {'web','app','accounts','recommendations','social','messaging','notifications'}
TARGET_DIRS = tuple(run / leaf for run in (OLD, PREVIOUS) for leaf in ('source','binaries'))
TARGET_FILES = (PREVIOUS/'proof/command-006.stdout',)
PARENTS = {OLD,PREVIOUS,PREVIOUS/'proof'}
STAT_KEYS = ('dev','ino','mode','uid','gid','bytes','mtime_ns','ctime_ns','nlink')
OBS_KEYS = ('st_dev','st_ino','st_mode','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns','st_nlink')
PORTABLE = ('bytes','sha256','mode','uid','gid','mtime_ns')
# Generic prior date-retention helpers below remain literal byte reuse.


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def hex64(value):
    return isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value) is not None


def literal(value):
    need(isinstance(value, str) and not value.startswith('/') and '\\' not in value
         and all(x not in ('', '.', '..') for x in value.split('/')), 'literal relative path')
    return value


def parent_fd(path):
    need(path.is_absolute() and path == Path(os.path.normpath(path)), 'literal absolute path')
    fd = os.open('/', os.O_RDONLY | os.O_DIRECTORY)
    try:
        for part in path.parts[1:-1]:
            following = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            os.close(fd); fd = following
        return fd
    except BaseException:
        os.close(fd); raise


def meta(info):
    return dict(dev=info.st_dev, ino=info.st_ino, mode=stat.S_IMODE(info.st_mode), uid=info.st_uid,
                gid=info.st_gid, bytes=info.st_size, mtime_ns=info.st_mtime_ns,
                ctime_ns=info.st_ctime_ns, nlink=info.st_nlink)


def same(info, row, directory=False, removing=False):
    need(stat.S_ISDIR(info.st_mode) if directory else stat.S_ISREG(info.st_mode), 'original regular type')
    keys = ('dev', 'ino', 'mode', 'uid', 'gid') if directory and removing else STAT_KEYS
    need(all(meta(info)[k] == row[k] for k in keys), 'original inode/full metadata changed')
    if not directory:
        need(info.st_nlink == 1, 'hardlink refused')


def current(path, collect=False):
    need(path.is_absolute() and path.resolve() == path, 'canonical input path')
    parent = parent_fd(path); fd = None
    try:
        before = os.stat(path.name, dir_fd=parent, follow_symlinks=False)
        need(stat.S_ISREG(before.st_mode) or stat.S_ISDIR(before.st_mode), 'no symlink/special file')
        if stat.S_ISDIR(before.st_mode):
            fd = os.open(path.name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent)
            need(meta(os.fstat(fd)) == meta(before), 'directory swapped before open')
            entries = sorted(os.listdir(fd)); need(meta(os.fstat(fd)) == meta(before), 'directory changed during read')
            return dict(path=str(path), file=False, **meta(before), sha256=None, git_blob=None, entries=entries)
        need(before.st_nlink == 1, 'single-link regular file')
        fd = os.open(path.name, os.O_RDONLY | os.O_NOFOLLOW, dir_fd=parent)
        need(meta(os.fstat(fd)) == meta(before), 'file swapped before open')
        digest = hashlib.sha256(); blob = hashlib.sha1(('blob ' + str(before.st_size) + '\0').encode())
        size = 0; chunks = []
        while True:
            block = os.read(fd, 1 << 20)
            if not block:
                break
            size += len(block); digest.update(block); blob.update(block)
            if collect:
                need(size <= 64 << 20, 'bounded metadata/keeper input'); chunks.append(block)
        need(meta(os.fstat(fd)) == meta(before) and size == before.st_size, 'file changed during read')
        row = dict(path=str(path), file=True, **meta(before), sha256=digest.hexdigest(), git_blob=blob.hexdigest(), entries=None)
        return (b''.join(chunks), row) if collect else row
    finally:
        if fd is not None:
            os.close(fd)
        os.close(parent)


def snapshot(root):
    return [current(path) for path in [root] + sorted(root.rglob('*'))]


class Inputs:
    """Keep first validated raw bytes/stat; never validate one read then consume another."""
    def __init__(self):
        self.rows = {}
    def read(self, path, digest=None):
        if path not in self.rows:
            self.rows[path] = current(path, collect=True)
        raw, row = self.rows[path]
        if digest is not None:
            need(hex64(digest) and sha(raw) == digest, 'explicit bound input differs: ' + str(path))
        return raw
    def json(self, path, digest=None):
        return json.loads(self.read(path, digest))
    def fence(self):
        for path, (raw, row) in self.rows.items():
            now, info = current(path, collect=True)
            need(now == raw and info == row, 'first-read input drift: ' + str(path))


def scalars(value):
    if isinstance(value, str):
        return {value}
    if isinstance(value, dict):
        return set().union(*(scalars(x) for x in value.values()), set())
    if isinstance(value, list):
        return set().union(*(scalars(x) for x in value), set())
    return set()


def accepted(inputs, spec, digests, source=None):
    need(set(spec) == {'path', 'sha256', 'field', 'expected'}, 'explicit independent review binding')
    path = Path(spec['path']); need(path.is_relative_to(BASE) or path.is_relative_to(REPO / 'docs/reviews'), 'owned/canonical review')
    value = inputs.json(path, spec['sha256']); expected = spec['expected']
    need(spec['field'] in ('status', 'verdict') and isinstance(expected, str)
         and (expected.startswith('ACCEPT') or 'ACCEPTED' in expected) and 'NOT_ACCEPTED' not in expected
         and value.get(spec['field']) == expected and value.get('findings') == [], 'actual independently accepted review')
    need(all(x in scalars(value) for x in list(digests) + ([] if source is None else [source])), 'review must contain actual bound source/digest scalars')
    return value


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args], env={'PATH': os.defpath, 'LANG': 'C.UTF-8'})


def unpack(inputs, path, digest):
    raw = inputs.read(path, digest)
    with gzip.GzipFile(fileobj=io.BytesIO(raw), mode='rb') as stream:
        decoded = stream.read((128 << 20) + 1)
    need(len(decoded) <= 128 << 20, 'bounded portable manifest')
    return decoded, json.loads(decoded)


def expected_row(row):
    need(row['kind'] in ('file','directory') and set(row['stat']) == set(OBS_KEYS), 'exact HOST inventory row')
    s = row['stat']; file = row['kind'] == 'file'
    need(stat.S_ISREG(s['st_mode']) if file else stat.S_ISDIR(s['st_mode']), 'original type bits')
    value = dict(path=row['path'], file=file, dev=s['st_dev'], ino=s['st_ino'],
                 mode=stat.S_IMODE(s['st_mode']), uid=s['st_uid'], gid=s['st_gid'],
                 bytes=s['st_size'], mtime_ns=s['st_mtime_ns'], ctime_ns=s['st_ctime_ns'], nlink=s['st_nlink'],
                 sha256=row['sha256'] if file else None, entries=None if file else row['entries'])
    if file:
        need(row['bytes'] == value['bytes'] and s['st_nlink'] == 1 and hex64(row['sha256']), 'single-link fixed regular row')
    return value


def compare_snapshot(row, removed=()):
    path = Path(row['path']); wanted = expected_row(row); now = current(path)
    if not wanted['file'] and removed and path in PARENTS:
        same(path.lstat(), wanted, directory=True, removing=True)
        need(now['entries'] == [name for name in wanted['entries'] if str(path/name) not in set(removed)],
             'only literal planned child entries may disappear')
    else:
        need(all(now[key] == value for key,value in wanted.items()), 'exact HOST bytes/fullstat/membership changed: '+str(path))
    return now


def protect(rows, removed=()):
    for row in rows:
        compare_snapshot(row, removed)


def source_fence():
    need(git('rev-parse','HEAD').decode().strip()==SOURCE and git('rev-parse','HEAD^{tree}').decode().strip()==TREE
         and not git('status','--porcelain','--untracked-files=all'),'exact clean collected M3 before promotion')
    for old in (OLD_SOURCE,PREVIOUS_SOURCE,NATIVE_SOURCE):git('merge-base','--is-ancestor',old,SOURCE)


def host_view(inputs, plan):
    observer=inputs.json(HERE/'host-observer.json',plan['host_observer_sha256'])
    need(Path('/proc/self/uid_map').read_text()==observer['uid_map'] and Path('/proc/self/gid_map').read_text()==observer['gid_map']
         and os.readlink('/proc/self/ns/user')==observer['user_namespace'] and os.getuid()==os.geteuid()==observer['uid']
         and os.getgid()==os.getegid()==observer['gid'],'same recorded HOST view required')
    compare_snapshot(observer['foreign_protected_probe'])
    need(observer['foreign_protected_probe']['stat']['st_uid']==observer['foreign_protected_probe']['stat']['st_gid']==999
         and observer['ownership_normalized'] is False,'HOST999 actual ownership; never translate archive metadata')
    return observer


def keeper(inputs,spec,account=False):
    # Accepted keeper+feature receipts are custody authority; do not rerun old
    # product qualification or reinterpret accepted archived inner statuses.
    need(set(spec)=={'path','archive_sha256','manifest_sha256','selection_path','selection_sha256','result_sha256','reviews'},'exact keeper authority spec')
    root=CANDIDATE if account else DATE_KEEPER
    selection_path=ACCOUNT_KEEPER/'prepared-selection.json' if account else DATE_KEEPER/'selection.json'
    expected=('e31b656ba310cb09639a6ab7e1a2a2dc8d305e17ae7a1f30ce3c8bc5ca3bee26',
              '6a0c5c50e3c8e77f46a36becc9617f2120476716350354b447716ee29089af8f',
              'bf9ed59146817e287f7c975046a63f1cda79017b68f538e83e3a28299be2adaa',
              'fc046c45c91e3101edb50162e8447bb3f01138e8ee5fb75e2ca369676651a292') if account else (
              'bc10a80ae1a9b0f404e9434f2a0065d941a0cb4a336d5ea06eb39032da09c7ea',
              '2787ff123c6b333d5aeed9650c22cdab92b8e2a76f189085a4eb52c5f3bc21d4',
              '982a51b039310e3df32c124fd44a2f4758685865ba697f2fa185f363c2a7809f',
              '9d005b48c274481e21f509a6d9e15550ce237f397c3de23bef987a01ab13126e')
    need(spec['path']==str(root) and spec['selection_path']==str(selection_path)
         and tuple(spec[k] for k in ('archive_sha256','manifest_sha256','selection_sha256','result_sha256'))==expected,
         'exact accepted date/account archive/manifest/result/selection identities')
    raw=inputs.read(root/'evidence.tar.gz',spec['archive_sha256']);outer=inputs.json(root/'archive-manifest.json',spec['manifest_sha256'])
    selection=inputs.json(selection_path,spec['selection_sha256'])
    receipt=inputs.json(root/('result.json' if account else 'collection-result.json'),spec['result_sha256'])
    need(outer['archive_sha256']==spec['archive_sha256'] and outer['complete_bytes_mode_UID_GID_nsmtime_roundtrip'] is True
         and receipt['status']=='COLLECTED_PENDING_INDEPENDENT_KEEPER_AND_FEATURE_REVIEW'
         and receipt['archive']=={'sha256':spec['archive_sha256'],'bytes':len(raw),'members':len(outer['members'])}
         and len(outer['members'])==(2587 if account else 1689)
         and receipt['source_sha']==selection['source_sha']==(SOURCE if account else OLD_SOURCE),
         'exact accepted custody envelope; preserve pending inner result')
    if account:need(receipt['native_source']==NATIVE_SOURCE and selection['native_source']==NATIVE_SOURCE,'accepted current native source')
    need(set(spec['reviews'])=={'keeper','feature'},'separate actual keeper AND feature authority')
    k,f=spec['reviews']['keeper'],spec['reviews']['feature']
    need(k['path']!=f['path'] and hex64(k['sha256']) and hex64(f['sha256']) and k['sha256']!=f['sha256'],'distinct keeper/feature paths AND hashes')
    authority={'keeper':(ACCOUNT_KEEPER/'keeper-review.json','279909705896aa2ca5acbf51cc056df5b47288fa7b95ec0be4c2513134b7549a'),
               'feature':(ACCOUNT_KEEPER/'acceptance.json','2c3806753662f6a483117446b0d0d3fc9ec2f69f4bc11c0f27341ae50f01806a')} if account else {
              'keeper':(DATE_KEEPER/'keeper-review.json','2d0af9fb0abe7446d63549237be12e18ef4df5a184bcd386abf7c9240d9d365a'),
              'feature':(DATE_KEEPER/'acceptance.json','6611a306c2e9659a492d2abbc2cb507c81f7b45a1bbecfa3c53946bfe65a6444')}
    for role,(path,digest) in authority.items():
        ref=spec['reviews'][role];need(ref['path']==str(path) and ref['sha256']==digest,'literal accepted keeper/feature receipt')
        required=[spec['archive_sha256']]+([spec['manifest_sha256'],spec['selection_sha256'],spec['result_sha256']] if role=='keeper' else [])
        accepted(inputs,ref,required,SOURCE if account else OLD_SOURCE)
    index={}
    for row in outer['members']:index.setdefault(row['original'],[]).append(row)
    return {'root':root,'index':index,'selection':selection,'snapshot':snapshot(root)}


def keeper_fence(value):
    for row in value['snapshot']:
        now=current(Path(row['path']));need(now==row,'protected keeper directory/bytes/fullstat changed')


def custody_row(row,index):
    wanted=expected_row(row)
    need(any(all(wanted[key]==record[key] for key in PORTABLE) for record in index.get(row['path'],[])),
         'same-view original proof/result/CID/source manifest portable custody')


def source_export(inputs,run,commit,all_rows):
    manifest=inputs.json(run/'source-manifest.json');by={row['path']:row for row in manifest}
    need(len(by)==len(manifest),'unique source manifest')
    files={str(Path(row['path']).relative_to(run/'source')):row for row in all_rows if row['kind']=='file'}
    tree={}
    for item in git('ls-tree','-r','-z',commit).split(b'\0'):
        if item:
            head,name=item.split(b'\t',1);tree[name.decode()]=tuple(head.decode().split())
    need(set(tree)==set(by)==set(files),'complete original Git/source manifest membership')
    git('merge-base','--is-ancestor',commit,SOURCE)
    for name,row in files.items():
        now=compare_snapshot(row);wanted=by[literal(name)]
        need(now['bytes']==wanted['bytes'] and now['sha256']==wanted['sha256']
             and now['mode']==wanted['mode']
             and tree[name]==(('100755' if now['mode'] & 0o111 else '100644'),'blob',now['git_blob']),
             'all source bytes/modes/Gitblob provenance exact')


def live_absence(cids,names,targets):
    fmt='{\"id\":{{json .ID}},\"names\":{{json .Names}},\"state\":{{json .State}}}'
    raw=subprocess.check_output(['docker','container','ls','-a','--no-trunc','--format',fmt])
    rows=[json.loads(line) for line in raw.splitlines()]
    for row in rows:
        need(row['id'] not in cids and not (set(row['names'].split(',')) & names),'an original CID/name is still present')
        if row['state']!='running':continue
        mounts=json.loads(subprocess.check_output(['docker','container','inspect',row['id'],'--format','{{json .Mounts}}']))
        for mount in mounts:
            if mount.get('Type')=='bind':
                path=Path(mount['Source'])
                need(not any(path==target or path.is_relative_to(target) or target.is_relative_to(path) for target in targets),
                     'running bind overlaps an exact owned target')
    return {'successful_daemon_inventory':True,'original_CIDs_and_names_absent':len(cids),
            'no_running_bind_overlap':True,'containers_checked':len(rows),'minimal_inventory_sha256':sha(raw)}

def roles_and_shutdown(inputs,inventory,results):
    roles=inventory['owned_roles'];need(len(roles)==45 and len({r['cid'] for r in roles})==len({r['name'] for r in roles})==45,'exact45 original owned roles')
    expected={'db',*LANES,*('reference-'+n for n in LANES)}
    for run in (OLD,PREVIOUS,LATEST):
        own=[r for r in roles if r['run']==str(run)]
        need({r['role'] for r in own}==expected and {p.stem for p in run.glob('*.cid')}==expected,'closed original CID namespace')
        for row in own:
            need(re.fullmatch('[a-f0-9]{64}',row['cid']) and inputs.read(run/(row['role']+'.cid'),row['CID_file_sha256']).decode().strip()==row['cid'],'original CID file')
            created=inputs.json(run/'proof'/(row['role']+'-created.json'))
            need(created['id']==row['cid'] and created['name']==row['name'] and created['labels']['io.dobolabs.gui.owner'] in row['name'],'owned CID/name/create proof')
        cleanup=inputs.json(run/'socket/pg-cleanup.json');value=results[run]
        need(cleanup['stop_exit']==0 and cleanup['status_exit']==3 and cleanup['pid_probe_exit']==1 and cleanup['pid_and_socket_files_absent']==1
             and not list((run/'socket').glob('.s.PGSQL.*')) and value['method_pass'] is True and value['errors']==[]
             and set(value['cleanup'])==expected and value['pg_cleanup']==cleanup and set(value['retired_databases'])==LANES
             and all(x['stopped'] and x['id_absent'] and x['name_absent'] for x in value['cleanup'].values())
             and all(x['checkpoint_completed'] and x['name_and_oid_absent'] for x in value['retired_databases'].values()),
             'recorded all45role/21DB/privatePG shutdown; no product rerun')
    return {r['cid'] for r in roles},{r['name'].removeprefix('/') for r in roles}


def fresh(binding,inputs):
    stamp=binding['issued_unix_ns'];need(type(stamp)is int and 0<=time.time_ns()-stamp<=3600*10**9,'fresh preceding-hour binding')
    nonce=uuid.UUID(binding['execution_nonce']);need(str(nonce)==binding['execution_nonce'] and nonce.version==4,'literal fresh UUID4')
    need(not os.path.lexists(HERE/('used-'+binding['execution_nonce']+'.json')),'one-use execution nonce already consumed')
    reviews=list(binding['retention_reviews'].values())+[r for spec in binding['keepers'].values() for r in spec['reviews'].values()]
    if binding['dry_run_review'] is not None:reviews.append(binding['dry_run_review'])
    need(all(stamp>=Path(r['path']).stat().st_mtime_ns for r in reviews),'fresh binding follows actual reviews')
    inputs.fence()


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--binding',type=Path,required=True)
    parser.add_argument('--receipt',type=Path,required=True);parser.add_argument('--execute',action='store_true');args=parser.parse_args()
    need(Path(__file__).resolve()==HERE/'retain.py' and args.binding.parent==HERE and args.receipt.parent==HERE
         and args.receipt.resolve()==args.receipt and not os.path.lexists(args.receipt),'fresh literal task-owned binding/receipt')
    result={'schema':1,'status':'REFUSED_BEFORE_DELETION','executed':False,'deleted':[],'removed_directories':[],'logical_bytes_deleted':0};inputs=Inputs()
    try:
        binding=inputs.json(args.binding)
        need(binding.get('schema')==1 and binding.get('status')=='BOUND_ACCEPTED_ACCOUNT_KEEPER_REVIEWED_EXACT_RETENTION',
             'pending keeper/source/plan review binding refuses before bulk verification/deletion')
        need(set(binding)=={'schema','status','source_sha','source_tree','method_sha256','builder_sha256','archive_verifier_sha256',
             'plan_sha256','inventory_sha256','latest_snapshot_sha256','retention_reviews','keepers','issued_unix_ns','execution_nonce','dry_run_receipt','dry_run_review'},
             'exact final account retention binding schema')
        need(binding['source_sha']==SOURCE and binding['source_tree']==TREE and binding['plan_sha256']==PLAN_SHA
             and binding['inventory_sha256']==INVENTORY_SHA and binding['latest_snapshot_sha256']==LATEST_SHA,'exact reviewed source/scope/inventories')
        inputs.read(HERE/'retain.py',binding['method_sha256']);inputs.read(HERE/'build-proposal.py',binding['builder_sha256'])
        inputs.read(HERE/'verify-archive-content.py',binding['archive_verifier_sha256'])
        plan=inputs.json(HERE/'plan.json',PLAN_SHA);_,inventory=unpack(inputs,HERE/'inventory.json.gz',INVENTORY_SHA)
        _,latest=unpack(inputs,HERE/'latest-snapshot.json.gz',LATEST_SHA)
        need(plan['source_sha']==SOURCE and plan['source_tree']==TREE and plan['native_source']==NATIVE_SOURCE
             and plan['physical_deletion_performed'] is False and plan['inventory_sha256']==INVENTORY_SHA
             and plan['latest_snapshot_sha256']==LATEST_SHA and plan['builder_sha256']==binding['builder_sha256']
             and plan['archive_verifier_sha256']==binding['archive_verifier_sha256']
             and latest['source_sha']==SOURCE and latest['native_source']==NATIVE_SOURCE and latest['latest_run']==str(LATEST)
             and latest['latest_UI']==str(CURRENT_UI) and latest['ALL695_native_PG_artifacts_including_Gitstdout_protected'] is True
             and latest['excluded_latest_stdout'] is None,'literal HOST source/latest protection plan')
        observer=host_view(inputs,plan);source_fence()
        accepted(inputs,plan['actual_independent_inventory_review'],[INVENTORY_SHA,LATEST_SHA],SOURCE)
        need(set(binding['retention_reviews'])=={'root','peer'},'Root AND independent peer source/actualplan reviews')
        root,peer=binding['retention_reviews']['root'],binding['retention_reviews']['peer']
        need(isinstance(root.get('path'),str) and isinstance(peer.get('path'),str) and Path(root['path'])!=Path(peer['path'])
             and hex64(root.get('sha256')) and hex64(peer.get('sha256')) and root['sha256']!=peer['sha256'],
             'distinct Root/peer PATH AND SHA before accepted calls')
        for ref in (root,peer):accepted(inputs,ref,[binding['method_sha256'],binding['builder_sha256'],binding['archive_verifier_sha256'],PLAN_SHA,INVENTORY_SHA,LATEST_SHA],SOURCE)
        need(set(binding['keepers'])=={'date','account'},'accepted immutable date baseline AND account successor custody')
        keepers={name:keeper(inputs,spec,name=='account') for name,spec in binding['keepers'].items()};fresh(binding,inputs)
        groups=inventory['target_groups'];need([Path(g['root']) for g in groups]==list(TARGET_DIRS+TARGET_FILES)
             and plan['target_roots']==[str(p) for p in TARGET_DIRS+TARGET_FILES],'literal four generated roots plus one a8stdout,no expansion')
        targets=[r for g in groups for r in g['rows'] if r['kind']=='file'];directories=[r for g in groups for r in g['rows'] if r['kind']=='directory']
        need(len({r['path'] for r in targets})==len(targets)==plan['files_to_remove']==4500
             and len({r['path'] for r in directories})==len(directories)==plan['directories_to_remove']==489
             and sum(r['bytes'] for r in targets)==plan['logical_bytes_to_remove']==667239108,'exact actual finite HOST totals')
        for group in groups:
            r=Path(group['root']);need({str(p) for p in [r]+sorted(r.rglob('*'))}=={x['path'] for x in group['rows']} if r in TARGET_DIRS
                  else len(group['rows'])==1 and group['rows'][0]['path']==str(r),'complete closed target membership')
            for row in group['rows']:
                path=Path(row['path'])
                need((r in TARGET_DIRS and (path==r or path.is_relative_to(r)) or r in TARGET_FILES and path==r)
                     and row['stat']['st_uid']==os.getuid() and not path.is_relative_to(LATEST)
                     and not path.is_relative_to(ACCOUNT_KEEPER) and not path.is_relative_to(CURRENT_UI)
                     and not path.is_relative_to(DATE_KEEPER),'only exact owned superseded generated/duplicate targets')
                compare_snapshot(row)
        results={OLD:inputs.json(OLD/'result.json',OLD_PG_SHA),PREVIOUS:inputs.json(PREVIOUS/'result.json',PREVIOUS_PG_SHA),
                 LATEST:inputs.json(LATEST/'result.json',PG_SHA)}
        need(results[OLD]['source']==OLD_SOURCE and results[PREVIOUS]['source']==PREVIOUS_SOURCE
             and results[LATEST]['source']==NATIVE_SOURCE,'original successful PG source identities')
        for run,source in ((OLD,OLD_SOURCE),(PREVIOUS,PREVIOUS_SOURCE)):
            source_export(inputs,run,source,next(g['rows'] for g in groups if g['root']==str(run/'source')))
        source_export(inputs,LATEST,NATIVE_SOURCE,[r for r in latest['rows'] if r['kind']=='file' and Path(r['path']).is_relative_to(LATEST/'source')])
        for record in inventory['binary_provenance']:
            row=next(r for r in targets if r['path']==record['path']);run=Path(record['run']);need(run in (OLD,PREVIOUS),'only old successful binaries')
            name=Path(row['path']).name;v=results[run]
            saved=(v['reference_bootstrap_binary'] if name=='reference-bootstrap' else v['notifications_reference_bootstrap_binary'] if name=='reference-notifications-bootstrap' else v['lanes'][name.removesuffix('.test')]['binary'])
            command=record['actual_build_command']
            need(record['provenance']=='ORIGINAL_SUCCESSFUL_BUILD_AND_RECORDED_BINARY_SHA_MATCH_CURRENT'
                 and record['observed_current_sha256']==record['original_recorded_sha256']==row['sha256']==saved['sha256']
                 and command in v['commands'] and command['exit']==0 and '-o' in command['argv']
                 and command['argv'][command['argv'].index('-o')+1]==row['path'],'every original successful build/output/hash receipt')
            for key in ('stdout','stderr'):inputs.read(run/literal(command[key]['path']),command[key]['sha256'])
        latest_index={r['path']:r for r in latest['rows'] if r['kind']=='file'}
        need(len(results[LATEST]['artifact_rows'])==695,'all latestR artifact inventory')
        for record in results[LATEST]['artifact_rows']:
            row=latest_index.get(str(LATEST/literal(record['path'])))
            need(row is not None and row['bytes']==record['bytes'] and row['sha256']==record['sha256'],'ALL695latestRproofs INCLUDINGGitstdout protected')
        for row in latest['rows']:
            path=Path(row['path'])
            if row['kind']!='file' or path.parent!=LATEST/'binaries':continue
            name=path.name;v=results[LATEST]
            saved=(v['reference_bootstrap_binary'] if name=='reference-bootstrap' else v['notifications_reference_bootstrap_binary'] if name=='reference-notifications-bootstrap' else v['lanes'][name.removesuffix('.test')]['binary'])
            need(saved['sha256']==row['sha256'],'latestR binaries match successful execution hashes')
        already=inventory['already_pruned0afd_archive'];prior=inputs.json(DATE_KEEPER/'retention-result.json',already['previous_receipt_sha256'])
        need(already['status']=='NONE_ALREADY_PRUNED_NOT_A_NEW_TARGET' and already['path']==str(OLD/'proof/command-006.stdout')
             and already['original_deleted_row'] in prior['deleted'] and not os.path.lexists(already['path']),'0afd stdout already pruned,never count or delete twice')
        exclusion=[r for r in keepers['account']['selection']['exclusions'] if r['path']==str(TARGET_FILES[0])]
        archive_row=next(r for r in targets if r['path']==str(TARGET_FILES[0]))
        need(len(exclusion)==1 and exclusion[0]['kind']=='duplicate-Git-archive-stdout' and exclusion[0]['sha256']==archive_row['sha256']
             and exclusion[0]['bytes']==archive_row['bytes'] and exclusion[0]['stat']==archive_row['stat'],'exact accepted a8archive custody ledger/full9stat')
        commands=[c for c in results[PREVIOUS]['commands'] if c['argv']==['git','-C',str(REPO),'archive','--format=tar.gz',PREVIOUS_SOURCE]]
        need(len(commands)==1 and commands[0]['exit']==0 and commands[0]['stdout']['path']=='proof/command-006.stdout'
             and commands[0]['stdout']['sha256']==archive_row['sha256'] and commands[0]['stdout']['bytes']==archive_row['bytes'],'original exacta8 archive command receipt')
        latest_archive=LATEST/'proof/command-006.stdout'
        latest_ledger=[r for r in keepers['account']['selection']['exclusions'] if r['path']==str(latest_archive)]
        latest_archive_row=latest_index[str(latest_archive)]
        need(len(latest_ledger)==1 and latest_ledger[0]['sha256']==latest_archive_row['sha256']
             and latest_ledger[0]['bytes']==latest_archive_row['bytes'] and latest_ledger[0]['stat']==latest_archive_row['stat'],
             'latestR archive remains physical with accepted exact ledger; never a deletion target')
        for row in inventory['preserved_old_and_latest_runs']:
            path=Path(row['path'])
            if row['kind']=='file' and path!=latest_archive:
                for run,name in ((OLD,'date'),(PREVIOUS,'account'),(LATEST,'account')):
                    if path.parent in (run,run/'proof'):custody_row(row,keepers[name]['index'])
        inputs.json(CURRENT_UI/'result.json',UI_SHA);cids,names=roles_and_shutdown(inputs,inventory,results)
        protect(inventory['preserved_old_and_latest_runs']);protect(latest['UI_rows']);protect(inventory['preserved_old_canonical'])
        protect(inventory['preserved_account_packets_and_all_UI'])
        for value in keepers.values():keeper_fence(value)
        content=inputs.json(HERE/'archive-content-custody.json',plan['archive_content_custody_sha256'])
        need(content['status']=='HOST_READ_ONLY_EXACT_A8_ARCHIVE_CONTENT_MATCHES_NOT_RETENTION' and len(content['rows'])==1
             and content['rows'][0]['path']==str(TARGET_FILES[0]) and content['rows'][0]['all_member_bytes_modes_match_Git_verified_source_manifest'] is True
             and content['rows'][0]['observed_archive_sha256']==archive_row['sha256'] and content['rows'][0]['archive_bytes']==archive_row['bytes'],
             'actual onea8 duplicate archive wholemember/Git content proof')
        if args.execute:
            need(binding['dry_run_receipt'] is not None and binding['dry_run_review'] is not None,'successful independently reviewed exactHOSTdryrun before execute')
            spec=binding['dry_run_receipt'];dry=inputs.json(Path(spec['path']),spec['sha256'])
            need(Path(spec['path']).parent==HERE and Path(binding['dry_run_review']['path']).parent==HERE,'task-owned dryrun/peerreview')
            need(dry['status']=='VERIFIED_NOT_EXECUTED' and dry['executed'] is False and dry['deleted']==[]
                 and all(dry[key]==value for key,value in [('method_sha256',binding['method_sha256']),('plan_sha256',PLAN_SHA),('inventory_sha256',INVENTORY_SHA),
                    ('latest_snapshot_sha256',LATEST_SHA),('accepted_candidate_sha256',binding['keepers']['account']['archive_sha256'])]),'same exact method/custody/scope dryrun')
            accepted(inputs,binding['dry_run_review'],[spec['sha256'],binding['method_sha256'],PLAN_SHA,INVENTORY_SHA,LATEST_SHA],SOURCE)
        else:need(binding['dry_run_receipt'] is binding['dry_run_review'] is None,'dryrun cannot carry stale execution approval')
        source_fence();host_view(inputs,plan);fresh(binding,inputs)
        result.update(status='VERIFIED_NOT_EXECUTED',method_sha256=binding['method_sha256'],plan_sha256=PLAN_SHA,inventory_sha256=INVENTORY_SHA,
            latest_snapshot_sha256=LATEST_SHA,accepted_candidate_sha256=binding['keepers']['account']['archive_sha256'],source_sha=SOURCE,source_tree=TREE,
            HOST_observer=observer,target_files=len(targets),target_directories=len(directories),target_logical_bytes=667239108,
            live_absence=live_absence(cids,names,[Path(r['path']) for r in targets+directories]))
        if args.execute:
            source_fence();host_view(inputs,plan);fresh(binding,inputs)
            result['immediate_live_absence']=live_absence(cids,names,[Path(r['path']) for r in targets+directories])
            marker=HERE/('used-'+binding['execution_nonce']+'.json')
            with marker.open('x') as stream:json.dump({'binding_sha256':sha(inputs.read(args.binding))},stream)
            result.update(executed=True,status='PARTIAL_EXACT_ACCOUNT_RETENTION_RETAIN_RECEIPT')
            for row in targets:
                need(0<=time.time_ns()-binding['issued_unix_ns']<=3600*10**9,'binding expired during removal')
                path=Path(row['path']);compare_snapshot(row);parent=parent_fd(path)
                try:
                    same(os.stat(path.name,dir_fd=parent,follow_symlinks=False),expected_row(row))
                    os.unlink(path.name,dir_fd=parent)
                finally:os.close(parent)
                result['deleted'].append({'path':row['path'],'bytes':row['bytes'],'sha256':row['sha256']});result['logical_bytes_deleted']+=row['bytes']
            for row in sorted(directories,key=lambda r:(len(Path(r['path']).parts),r['path']),reverse=True):
                path=Path(row['path']);wanted=expected_row(row);now=current(path)
                same(path.lstat(),wanted,directory=True,removing=True);need(not now['entries'],'only empty exact planned directory')
                parent=parent_fd(path)
                try:
                    same(os.stat(path.name,dir_fd=parent,follow_symlinks=False),wanted,directory=True,removing=True);os.rmdir(path.name,dir_fd=parent)
                finally:os.close(parent)
                result['removed_directories'].append(row['path'])
            need(all(not os.path.lexists(r['path']) for r in targets+directories),'all exact targets absent')
            removed={r['path'] for r in targets+directories}
            protect(inventory['preserved_old_and_latest_runs'],removed);protect(latest['UI_rows']);protect(inventory['preserved_old_canonical'])
            protect(inventory['preserved_account_packets_and_all_UI'])
            for value in keepers.values():keeper_fence(value)
            source_fence();host_view(inputs,plan);inputs.fence();result['status']='COMPLETE_EXACT_SOCIAL_ACCOUNT_ROLLING_RETENTION'
    except BaseException as error:
        result['error']=type(error).__name__+': '+str(error);raise
    finally:
        result['raw_deleted_paths_unavailable']=bool(result['deleted'])
        result['retained_history_semantics']='Only exact superseded0afd+a8 generated source/binaries and onea8 duplicateGitstdout may be absent. ALLlatestR695proofs including47.5MBGitstdout/latestRsource/bin,M3Git/dependencies,current/historicalUI,logs/source manifests/packets/branches/baselines/keepers/caches/otherowners remain.0afdstdout was alreadypruned,never newdeletion. Portable keeper ownership remains in original observer view.'
        with args.receipt.open('x') as stream:json.dump(result,stream,separators=(',',':'));stream.write('\n')
        print(json.dumps({'status':result['status'],'deleted':len(result['deleted']),'directories':len(result['removed_directories']),'logical_bytes_deleted':result['logical_bytes_deleted']}))


if __name__=='__main__':
    import signal
    def interrupted(signum,frame):raise RuntimeError('interrupted exact retention; retain partial receipt')
    signal.signal(signal.SIGINT,interrupted);signal.signal(signal.SIGTERM,interrupted)
    main()
