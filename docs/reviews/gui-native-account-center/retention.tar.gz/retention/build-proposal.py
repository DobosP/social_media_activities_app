#!/usr/bin/env python3
"""Read-only HOST-view inventory; writes only this new retention proposal. No remover."""
import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess

FAMILY = Path('/home/dobo/work/_temp/feat__gui-app-migration-a/social-family')
HERE = FAMILY / 'account-center-retention'
REPO = Path('/home/dobo/work/_worktrees/social_media_activities_app/feat__gui-app-migration-a')
OLD = FAMILY / 'notification-inbox-date-pg-qa/run-0afd29b79fec-0d124589-48a8-45be-a6b7-b93476bc129c'
PREVIOUS = FAMILY / 'account-center-pg-qa/run-a8f713f74885-7c56c571-615c-40bc-9163-4e6e9e9afecf'
LATEST = FAMILY / 'account-center-pg-qa/run-02ac07258cca-7ad9ada4-a7d6-4780-bc94-4d29b542f972'
LATEST_UI = Path('/home/dobo/work/_temp/ac-ui/run-02ac07258cca-d0c13ae7-7bc6-4d06-bcc2-f919042eea6a')
DATE_UI = Path('/home/dobo/work/_temp/ni-ui/run-0afd29b79fec-5cec58a3-f1b8-4e1a-b683-d959e6b9ca59')
CANONICAL = REPO / 'docs/reviews/gui-native-notification-inbox-dates'
ACCOUNT_KEEPER = FAMILY / 'account-center-keeper'
CANDIDATE = ACCOUNT_KEEPER / 'candidate-75edf1a'
SOURCE = '75edf1a051e95441248f58dbfed9e610cc4a00b6'
TREE = 'e0b844fff50626b120752affc54d2e21cf32d2e6'
OLD_SOURCE = '0afd29b79fecf69bfb88847a8412d4bb2e02a787'
PREVIOUS_SOURCE = 'a8f713f74885acfc51f6985bc8c6a366950029b3'
NATIVE_SOURCE = '02ac07258cca866180ef93aeeb6a17ecb07baae1'
TARGET_DIRS = tuple(run / leaf for run in (OLD, PREVIOUS) for leaf in ('source', 'binaries'))
TARGET_FILES = (PREVIOUS / 'proof/command-006.stdout',)
KEYS = ('st_dev', 'st_ino', 'st_mode', 'st_uid', 'st_gid', 'st_size', 'st_mtime_ns', 'st_ctime_ns', 'st_nlink')
REGISTRY = {}


def need(value, message):
    if not value:
        raise RuntimeError(message)


def meta(info):
    return {key: getattr(info, key) for key in KEYS}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(path):
    need(path.is_absolute() and path.resolve() == path, 'canonical nonsymlink path required')


def observe(path, target=False):
    canonical(path)
    before = path.lstat()
    need(stat.S_ISREG(before.st_mode) or stat.S_ISDIR(before.st_mode), 'special/link object refused')
    if target:
        need(before.st_uid == os.getuid(), 'delete target ownership must be current HOST owner')
    row = {'path': str(path), 'kind': 'file' if stat.S_ISREG(before.st_mode) else 'directory', 'stat': meta(before)}
    if stat.S_ISREG(before.st_mode):
        need(before.st_nlink == 1, 'single-link regular input required')
        digest = hashlib.sha256()
        descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
        try:
            opened = os.fstat(descriptor)
            need(meta(before) == meta(opened), 'input changed before open')
            while True:
                block = os.read(descriptor, 1 << 20)
                if not block:
                    break
                digest.update(block)
            after = os.fstat(descriptor)
        finally:
            os.close(descriptor)
        need(meta(before) == meta(after) == meta(path.lstat()), 'input changed during hash')
        row.update(bytes=before.st_size, sha256=digest.hexdigest(), allocated_bytes=before.st_blocks * 512)
    else:
        row['entries'] = sorted(child.name for child in path.iterdir())
        need(meta(before) == meta(path.lstat()), 'directory changed during enumeration')
    need(path not in REGISTRY or REGISTRY[path] == row, 'earliest HOST bytes/stat/membership changed')
    REGISTRY.setdefault(path, row)
    return row


def walk(root, target=False, excluded=()):
    rows = []
    def descend(path):
        if path in excluded:
            return
        row = observe(path, target)
        rows.append(row)
        if row['kind'] == 'directory':
            for name in row['entries']:
                descend(path / name)
    descend(root)
    return rows


def read_json(path):
    row = observe(path)
    raw = path.read_bytes()
    need(sha(raw) == row['sha256'], 'JSON changed after earliest read')
    return json.loads(raw)


def git(*args):
    return subprocess.check_output(['git', '--no-optional-locks', '-C', str(REPO), *args])


def fence():
    need(git('rev-parse', 'HEAD').decode().strip() == SOURCE and git('rev-parse', 'HEAD^{tree}').decode().strip() == TREE
         and not git('status', '--porcelain', '--untracked-files=all'), 'exact clean final account methodM3 required')
    for ancestor in (OLD_SOURCE, PREVIOUS_SOURCE, NATIVE_SOURCE):
        git('merge-base', '--is-ancestor', ancestor, SOURCE)


def verify_source(run, commit, rows):
    raw_manifest = read_json(run / 'source-manifest.json')
    manifest = {row['path']: row for row in raw_manifest}
    need(len(manifest) == len(raw_manifest) and not any('link' in row for row in raw_manifest), 'unique regular source manifest required')
    files = {Path(row['path']).relative_to(run / 'source').as_posix(): row for row in rows if row['kind'] == 'file'}
    need(set(files) == set(manifest), 'entire generated source file set must match original manifest')
    tree = {}
    for entry in git('ls-tree', '-r', '-z', commit).split(b'\0'):
        if not entry:
            continue
        head, name = entry.split(b'\t', 1)
        mode, kind, oid = head.split()
        need(kind == b'blob' and mode in (b'100644', b'100755'), 'source Git object type refused')
        tree[name.decode()] = (int(mode, 8) & 0o777, oid.decode())
    need(set(tree) == set(manifest), 'original Git tracked source set differs')
    process = subprocess.Popen(['git', '--no-optional-locks', '-C', str(REPO), 'cat-file', '--batch'], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    try:
        for name, row in manifest.items():
            original = files[name]
            mode, oid = tree[name]
            need(original['sha256'] == row['sha256'] and original['bytes'] == row['bytes']
                 and stat.S_IMODE(original['stat']['st_mode']) == row['mode'] == mode, 'source manifest metadata differs')
            process.stdin.write((oid + '\n').encode()); process.stdin.flush()
            header = process.stdout.readline().decode().split()
            need(header[:2] == [oid, 'blob'] and int(header[2]) == row['bytes'], 'original Git blob receipt differs')
            remaining = int(header[2]); digest = hashlib.sha256()
            while remaining:
                block = process.stdout.read(min(1 << 20, remaining)); need(block, 'short Git blob')
                digest.update(block); remaining -= len(block)
            need(process.stdout.read(1) == b'\n' and digest.hexdigest() == row['sha256'], 'Git blob content differs')
        process.stdin.close(); need(process.wait() == 0, 'Git blob reader failed')
    finally:
        if process.poll() is None:
            process.terminate(); process.wait()
    return {'commit': commit, 'source_manifest': str(run / 'source-manifest.json'),
            'source_manifest_sha256': observe(run / 'source-manifest.json')['sha256'],
            'regular_files': len(manifest), 'whole_source_matches_original_Git_and_manifest': True}


def write_json(path, value):
    need(not path.exists(), 'proposal output already exists')
    path.write_text(json.dumps(value, indent=2) + '\n')


def write_gzip(path, value):
    need(not path.exists(), 'proposal output already exists')
    raw = (json.dumps(value, sort_keys=True, separators=(',', ':')) + '\n').encode()
    path.write_bytes(gzip.compress(raw, compresslevel=9, mtime=0))
    return {'path': str(path), 'sha256': sha(path.read_bytes()), 'uncompressed_bytes': len(raw)}


def main():
    need(Path(__file__).resolve()==HERE/'build-proposal.py','literal read-only account builder')
    need(HERE.resolve()==HERE and HERE.stat().st_uid==os.getuid(),'owned literal proposal directory')
    need(not any(os.path.lexists(HERE/name) for name in ('host-observer.json','inventory.json.gz','latest-snapshot.json.gz','inventory-summary.json')),
         'exclusive fresh inventory outputs; never overwrite a prior inventory')
    fence();disk=shutil.disk_usage(FAMILY)
    # HOST view is established before any target enumeration/hashing. The
    # accepted keeper observer is preserved verbatim; never translate its UID.
    probe=LATEST/'socket/pg-cleanup.json';host_probe=observe(probe)
    need(host_probe['stat']['st_uid']==host_probe['stat']['st_gid']==999,'HOST999 required before inventory; no ownership normalization')
    selection=read_json(ACCOUNT_KEEPER/'prepared-selection.json')
    original=[r for r in selection['foreign_owned_payload_rows'] if r['path']==str(probe)]
    need(len(original)==1 and all(original[0]['stat'][k]==host_probe['stat'][k] for k in KEYS if k not in ('st_uid','st_gid')),
         'keeper-to-HOST probe nonownership identity must remain exact')
    observer={'view':'HOST_REQUIRED_ESCALATED_READ_ONLY','uid':os.getuid(),'gid':os.getgid(),
        'euid':os.geteuid(),'egid':os.getegid(),'uid_map':Path('/proc/self/uid_map').read_text(),
        'gid_map':Path('/proc/self/gid_map').read_text(),'user_namespace':os.readlink('/proc/self/ns/user'),
        'foreign_protected_probe':host_probe,'keeper_observer':selection['observer'],
        'keeper_observer_probe_ownership':{k:original[0]['stat'][k] for k in ('st_uid','st_gid')},
        'all_nonownership_probe_fields_equal':True,'ownership_normalized':False}
    for name,digest in (('keeper-review.json','279909705896aa2ca5acbf51cc056df5b47288fa7b95ec0be4c2513134b7549a'),
                        ('acceptance.json','2c3806753662f6a483117446b0d0d3fc9ec2f69f4bc11c0f27341ae50f01806a')):
        value=read_json(ACCOUNT_KEEPER/name)
        need(observe(ACCOUNT_KEEPER/name)['sha256']==digest and value['status'].startswith('ACCEPT') and value['findings']==[],
             'actual independently accepted account keeper AND feature required before inventory')
    need(observe(CANDIDATE/'evidence.tar.gz')['sha256']=='e31b656ba310cb09639a6ab7e1a2a2dc8d305e17ae7a1f30ce3c8bc5ca3bee26'
         and observe(CANDIDATE/'result.json')['sha256']=='fc046c45c91e3101edb50162e8447bb3f01138e8ee5fb75e2ca369676651a292'
         and observe(CANDIDATE/'archive-manifest.json')['sha256']=='6a0c5c50e3c8e77f46a36becc9617f2120476716350354b447716ee29089af8f',
         'exact accepted successor immutable candidate')
    target_groups=[{'root':str(root),'type':'whole_owned_generated_tree','rows':walk(root,True)} for root in TARGET_DIRS]
    target_groups += [{'root':str(path),'type':'literal_duplicate_Git_stdout','rows':[observe(path,True)]} for path in TARGET_FILES]
    targets=[row for group in target_groups for row in group['rows']]
    need(len({r['path'] for r in targets})==len(targets),'target overlap refused')
    results={run:read_json(run/'result.json') for run in (OLD,PREVIOUS,LATEST)}
    for run,source in ((OLD,OLD_SOURCE),(PREVIOUS,PREVIOUS_SOURCE),(LATEST,NATIVE_SOURCE)):
        value=results[run]
        need(value['source']==source and value['method_pass'] is True and value['errors']==[],'all three native runs are successful distinct sources')
    source_joins=[verify_source(run,source,next(g['rows'] for g in target_groups if g['root']==str(run/'source')))
                  for run,source in ((OLD,OLD_SOURCE),(PREVIOUS,PREVIOUS_SOURCE))]
    provenance=[]
    for run in (OLD,PREVIOUS):
        value=results[run]
        binary_rows=[r for g in target_groups if g['root']==str(run/'binaries') for r in g['rows'] if r['kind']=='file']
        expected_names={lane+'.test' for lane in value['lanes']}|{'reference-bootstrap','reference-notifications-bootstrap'}
        need({Path(r['path']).name for r in binary_rows}==expected_names,'exact nine successful compiled binaries')
        for row in binary_rows:
            name=Path(row['path']).name
            if name.endswith('.test'):
                expected=value['lanes'][name.removesuffix('.test')]['binary']['sha256'];proof='proof/'+name.removesuffix('.test')+'-compile.stdout'
            else:
                expected=value['notifications_reference_bootstrap_binary' if name=='reference-notifications-bootstrap' else 'reference_bootstrap_binary']['sha256']
                proof='proof/'+('notifications-reference-bootstrap-compile.stdout' if name=='reference-notifications-bootstrap' else 'reference-bootstrap-compile.stdout')
            commands=[c for c in value['commands'] if c['stdout']['path']==proof]
            need(len(commands)==1 and commands[0]['exit']==0 and expected==row['sha256']
                 and '-o' in commands[0]['argv'] and commands[0]['argv'][commands[0]['argv'].index('-o')+1]==row['path'],
                 'each target binary matches its original successful build/output/hash')
            provenance.append({'path':row['path'],'run':str(run),'observed_current_sha256':row['sha256'],'bytes':row['bytes'],
                'provenance':'ORIGINAL_SUCCESSFUL_BUILD_AND_RECORDED_BINARY_SHA_MATCH_CURRENT',
                'original_recorded_sha256':expected,'actual_build_command':commands[0]})
    value=results[PREVIOUS];path=TARGET_FILES[0];archive=observe(path,True)
    commands=[c for c in value['commands'] if c['argv']==['git','-C',str(REPO),'archive','--format=tar.gz',PREVIOUS_SOURCE]]
    need(len(commands)==1 and commands[0]['exit']==0 and commands[0]['stdout']['path']=='proof/command-006.stdout'
         and commands[0]['stdout']['sha256']==value['git_archive']['sha256']==archive['sha256']
         and commands[0]['stdout']['bytes']==value['git_archive']['bytes']==archive['bytes'],'only exact successful a8 duplicate archive')
    exclusions=[x for x in selection['exclusions'] if x['path']==str(path)]
    need(len(exclusions)==1 and exclusions[0]['kind']=='duplicate-Git-archive-stdout'
         and exclusions[0]['sha256']==archive['sha256'] and exclusions[0]['bytes']==archive['bytes']
         and all(exclusions[0]['stat'][k]==archive['stat'][k] for k in KEYS),'exact a8 archive metadata in accepted account custody')
    archive_joins=[{'path':str(path),'provenance':'SUCCESSFUL_EXACT_FULL_GIT_COMMAND_AND_ACCEPTED_ACCOUNT_EXCLUSION',
                    'source_commit':PREVIOUS_SOURCE,'command':commands[0]}]
    preserved=[]
    for run in (OLD,PREVIOUS,LATEST):preserved+=walk(run,excluded=TARGET_DIRS+TARGET_FILES)
    latest_source=[r for r in preserved if Path(r['path'])==LATEST/'source' or Path(r['path']).is_relative_to(LATEST/'source')]
    source_joins.append(verify_source(LATEST,NATIVE_SOURCE,latest_source))
    latest_index={r['path']:r for r in preserved if r['kind']=='file' and Path(r['path']).is_relative_to(LATEST)}
    need(len(results[LATEST]['artifact_rows'])==695,'all695 latestR physical proof inputs')
    for row in results[LATEST]['artifact_rows']:
        current=latest_index.get(str(LATEST/row['path']))
        need(current is not None and current['sha256']==row['sha256'] and current['bytes']==row['bytes'],
             'every latestR proof,INCLUDING47.5MBGitstdout,must remain protected physical bytes')
    for row in preserved:
        p=Path(row['path'])
        if row['kind']!='file' or p.parent!=LATEST/'binaries':continue
        name=p.name;v=results[LATEST]
        expected=(v['lanes'][name.removesuffix('.test')]['binary']['sha256'] if name.endswith('.test') else
                  v['notifications_reference_bootstrap_binary' if name=='reference-notifications-bootstrap' else 'reference_bootstrap_binary']['sha256'])
        need(row['sha256']==expected,'protected latestR successful execution binary hash')
    profile=read_json(ACCOUNT_KEEPER/'profile.json')
    protected_roots={Path(x) for x in profile['packet_roots']}|{Path(x['path']) for x in profile['UI_runs']}|{ACCOUNT_KEEPER,DATE_UI}
    packet_rows={}
    for root in sorted(protected_roots):
        for row in walk(root):
            need(row['path'] not in packet_rows or packet_rows[row['path']]==row,'protected path alias differs')
            packet_rows[row['path']]=row
    preserved_ui=walk(LATEST_UI);source_reference=walk(CANONICAL)
    roles=[]
    for run in (OLD,PREVIOUS,LATEST):
        for path in sorted(run.glob('*.cid')):
            row=observe(path);cid=path.read_text().strip();role=path.stem
            need(len(cid)==64 and all(c in '0123456789abcdef' for c in cid),'literal original CID')
            created=read_json(run/'proof'/(role+'-created.json'))
            need(created['id']==cid and created['labels']['io.dobolabs.gui.owner'] in created['name'],'original role/CID/name/owner join')
            roles.append({'run':str(run),'role':role,'cid':cid,'name':created['name'],'CID_file_sha256':row['sha256']})
    need(len(roles)==45 and len({r['cid'] for r in roles})==len({r['name'] for r in roles})==45,'exact45 successful historical/current roles')
    old_stdout=OLD/'proof/command-006.stdout';need(not os.path.lexists(old_stdout),'0afd stdout already pruned; never count/delete again')
    previous_retention=read_json(CANONICAL/'retention-result.json');prior=[r for r in previous_retention['deleted'] if r['path']==str(old_stdout)]
    need(len(prior)==1 and previous_retention['status']=='COMPLETE_EXACT_SOCIAL_DATE_ROLLING_RETENTION','exact prior already-pruned date archive receipt')
    for path in tuple(REGISTRY):observe(path,target=any(path==root or path.is_relative_to(root) for root in TARGET_DIRS) or path in TARGET_FILES)
    fence()
    inventory={'schema':1,'status':'HOST_FINITE_INVENTORY_ONLY_NO_REMOVAL','observer':observer,'target_groups':target_groups,
        'preserved_old_and_latest_runs':preserved,'preserved_latest_UI':preserved_ui,'preserved_old_canonical':source_reference,
        'preserved_account_packets_and_all_UI':list(packet_rows.values()),'source_Git_joins':source_joins,'binary_provenance':provenance,
        'duplicate_archive_provenance':archive_joins,'owned_roles':roles,
        'already_pruned0afd_archive':{'status':'NONE_ALREADY_PRUNED_NOT_A_NEW_TARGET','path':str(old_stdout),
            'previous_receipt_sha256':observe(CANONICAL/'retention-result.json')['sha256'],'original_deleted_row':prior[0]}}
    latest={'schema':1,'status':'HOST_LATEST_PROTECTED_SETUP_SNAPSHOT_ONLY','source_sha':SOURCE,'native_source':NATIVE_SOURCE,
        'latest_run':str(LATEST),'rows':[r for r in preserved if Path(r['path'])==LATEST or Path(r['path']).is_relative_to(LATEST)],
        'latest_UI':str(LATEST_UI),'UI_rows':preserved_ui,'ALL695_native_PG_artifacts_including_Gitstdout_protected':True,'excluded_latest_stdout':None}
    write_json(HERE/'host-observer.json',observer);inv=write_gzip(HERE/'inventory.json.gz',inventory);snap=write_gzip(HERE/'latest-snapshot.json.gz',latest)
    files=[r for r in targets if r['kind']=='file'];directories=[r for r in targets if r['kind']=='directory']
    summary={'schema':1,'status':'READ_ONLY_HOST_PROPOSAL_INVENTORY_COMPLETE_NOT_RETENTION','observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'source_sha':SOURCE,'source_tree':TREE,'native_source':NATIVE_SOURCE,'disk_before':{'total':disk.total,'used':disk.used,'available':disk.free},
        'inventory':inv,'latest_snapshot':snap,'target_files':len(files),'target_directories':len(directories),
        'target_logical_bytes':sum(r['bytes'] for r in files),'target_allocated_bytes':sum(r['allocated_bytes'] for r in files),
        'target_roots':[str(p) for p in TARGET_DIRS+TARGET_FILES],'protected_run_rows':len(preserved),'protected_UI_rows':len(preserved_ui),
        'protected_canonical_rows':len(source_reference),'protected_packet_rows':len(packet_rows),'source_joins':source_joins,'owned_CID_roles':len(roles),
        'accepted_account_keeper_archive':'e31b656ba310cb09639a6ab7e1a2a2dc8d305e17ae7a1f30ce3c8bc5ca3bee26',
        'keeper_review_sha256':'279909705896aa2ca5acbf51cc056df5b47288fa7b95ec0be4c2513134b7549a',
        'feature_review_sha256':'2c3806753662f6a483117446b0d0d3fc9ec2f69f4bc11c0f27341ae50f01806a',
        'physical_deletion_performed':False,'execution_source':None,'limits':'Read-only inventory,not dryrun or removal. Exact source/actualplan/Root+peer review and freshbinding required before any deletion.'}
    write_json(HERE/'inventory-summary.json',summary)
    print(json.dumps({k:summary[k] for k in ('status','target_files','target_directories','target_logical_bytes','target_allocated_bytes','protected_run_rows','protected_UI_rows','protected_packet_rows','owned_CID_roles')}))


if __name__=='__main__':
    main()
