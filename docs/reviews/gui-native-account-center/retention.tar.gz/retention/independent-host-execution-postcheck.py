"""Read-only HOST postcheck of the one reviewed exact retention execution."""
import collections
import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import uuid

H = Path('/home/dobo/work/_temp/feat__gui-app-migration-a/social-family/account-center-retention')
REPO = Path('/home/dobo/work/_worktrees/social_media_activities_app/feat__gui-app-migration-a')
sha = lambda b: hashlib.sha256(b).hexdigest()
load = lambda p: json.loads(p.read_bytes())
I = json.loads(gzip.decompress((H / 'inventory.json.gz').read_bytes()))
L = json.loads(gzip.decompress((H / 'latest-snapshot.json.gz').read_bytes()))
O = load(H / 'host-observer.json')
E = load(H / 'execution-receipt.json')
B = load(H / 'binding-execute.json')
T = load(H / 'root-execution-terminal.json')
launch = load(H / 'root-execution-launch.json')
K = ('st_dev', 'st_ino', 'st_mode', 'st_uid', 'st_gid', 'st_size', 'st_mtime_ns', 'st_ctime_ns', 'st_nlink')
assert sha((H / 'execution-receipt.json').read_bytes()) == '502be224d205310f4af4183d55f9c8314ff183f3d88886cb5d152ba5f760fc24'
assert sha((H / 'inventory.json.gz').read_bytes()) == E['inventory_sha256'] == '42c8923d04738912cff8a2dc7d9ac497339c10abdb2fd44dac25cfabfa7929bc'
assert sha((H / 'latest-snapshot.json.gz').read_bytes()) == E['latest_snapshot_sha256'] == '4791125487ed712f628f5dda36b2730d79881a85da329db72cac56eb3ec7b322'
assert E['status'] == 'COMPLETE_EXACT_SOCIAL_ACCOUNT_ROLLING_RETENTION' and E['executed'] and E['raw_deleted_paths_unavailable']
targets = [r for g in I['target_groups'] for r in g['rows']]
files = [r for r in targets if r['kind'] == 'file']
directories = [r for r in targets if r['kind'] == 'directory']
expected = {r['path']: {'path': r['path'], 'bytes': r['bytes'], 'sha256': r['sha256']} for r in files}
assert {r['path']: r for r in E['deleted']} == expected and len(E['deleted']) == len(expected) == 4500
assert set(E['removed_directories']) == {r['path'] for r in directories} and len(E['removed_directories']) == len(directories) == 489
assert E['logical_bytes_deleted'] == sum(r['bytes'] for r in E['deleted']) == 667239108
assert all(not os.path.lexists(r['path']) for r in targets)
removed = {r['path'] for r in targets}
roots = [Path(g['root']) for g in I['target_groups']]
OLD = roots[0].parent
PREVIOUS = roots[2].parent
parents = {OLD, PREVIOUS, PREVIOUS / 'proof'}
registry = {}
changed_parents = []


def check(row):
    path = Path(row['path'])
    assert path.is_absolute() and path.resolve() == path and not path.is_symlink()
    before = path.lstat()
    wanted = row['stat']
    relaxed = row['kind'] == 'directory' and path in parents
    keys = ('st_dev', 'st_ino', 'st_mode', 'st_uid', 'st_gid') if relaxed else K
    assert all(getattr(before, k) == wanted[k] for k in keys)
    if row['kind'] == 'directory':
        assert stat.S_ISDIR(before.st_mode)
        entries = sorted(p.name for p in path.iterdir())
        allowed = [name for name in row['entries'] if str(path / name) not in removed]
        assert entries == (allowed if relaxed else row['entries'])
        if relaxed:
            changed_parents.append({'path': str(path), 'lost_entries': sorted(set(row['entries']) - set(entries))})
    else:
        assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
        result = hashlib.sha256()
        try:
            assert {k: getattr(os.fstat(fd), k) for k in K} == wanted
            while chunk := os.read(fd, 1 << 20):
                result.update(chunk)
            assert {k: getattr(os.fstat(fd), k) for k in K} == wanted
        finally:
            os.close(fd)
        assert result.hexdigest() == row['sha256'] and before.st_size == row['bytes'] and before.st_blocks * 512 == row['allocated_bytes']
    assert all(getattr(path.lstat(), k) == wanted[k] for k in keys)
    if row['path'] in registry:
        assert registry[row['path']] == row
    registry[row['path']] = row


assert O['uid'] == O['euid'] == os.getuid() == 1000 and O['gid'] == O['egid'] == os.getgid() == 1000
assert O['uid_map'] == Path('/proc/self/uid_map').read_text() and O['gid_map'] == Path('/proc/self/gid_map').read_text()
assert O['user_namespace'] == os.readlink('/proc/self/ns/user') and E['HOST_observer'] == O
for key in ('preserved_old_and_latest_runs', 'preserved_latest_UI', 'preserved_old_canonical', 'preserved_account_packets_and_all_UI'):
    for row in I[key]:
        check(row)
probe = O['foreign_protected_probe']
check(probe)
assert probe['stat']['st_uid'] == probe['stat']['st_gid'] == 999 and not O['ownership_normalized']
assert len(changed_parents) == 3
for row in changed_parents:
    assert row['lost_entries'] == (['command-006.stdout'] if Path(row['path']) == PREVIOUS / 'proof' else ['binaries', 'source'])
latest = Path(L['latest_run'])
result = load(latest / 'result.json')
assert len(result['artifact_rows']) == 695
for row in result['artifact_rows']:
    now = registry[str(latest / row['path'])]
    assert now['bytes'] == row['bytes'] and now['sha256'] == row['sha256']
latest_binaries = [r for r in registry.values() if r['kind'] == 'file' and Path(r['path']).parent == latest / 'binaries']
assert len(latest_binaries) == 9
for row in latest_binaries:
    name = Path(row['path']).name
    expected_sha = result['lanes'][name.removesuffix('.test')]['binary']['sha256'] if name.endswith('.test') else result['notifications_reference_bootstrap_binary' if name == 'reference-notifications-bootstrap' else 'reference_bootstrap_binary']['sha256']
    assert row['sha256'] == expected_sha
old_stdout = OLD / 'proof/command-006.stdout'
assert not os.path.lexists(old_stdout) and str(old_stdout) not in expected
assert I['already_pruned0afd_archive']['status'] == 'NONE_ALREADY_PRUNED_NOT_A_NEW_TARGET'
assert T['waited_exit'] == 0 and not T['timed_out'] and '--execute' in T['argv']
assert T['argv'] == launch['argv'] and T['launch_sha256'] == sha((H / 'root-execution-launch.json').read_bytes())
assert T['receipt_sha256'] == sha((H / 'execution-receipt.json').read_bytes())
assert launch['binding_sha256'] == sha((H / 'binding-execute.json').read_bytes())
assert sha((H / 'execution.stdout').read_bytes()) == T['stdout_sha256'] and sha((H / 'execution.stderr').read_bytes()) == T['stderr_sha256']
assert not (H / 'execution.stderr').read_bytes()
assert load(H / 'execution.stdout') == {'status': E['status'], 'deleted': 4500, 'directories': 489, 'logical_bytes_deleted': 667239108}
assert B['method_sha256'] == E['method_sha256'] == sha((H / 'retain.py').read_bytes()) == '49bc9c7141d8bc1189e521fe1bc1e0a7037140497f3a63d336e26dfd21d691de'
assert B['plan_sha256'] == E['plan_sha256'] == sha((H / 'plan.json').read_bytes())
assert B['dry_run_receipt']['sha256'] == '2fcbb9cd0746b250433e7e316895ffe3eb26bc9a5451396bd62a6f3acc501be0'
assert B['dry_run_review']['sha256'] == '963d53efba4accce208741c6b510f8f5f0ec3037bf2d6d4ced574b6678d842a8'
for spec in list(B['retention_reviews'].values()) + [B['dry_run_review']] + [r for k in B['keepers'].values() for r in k['reviews'].values()]:
    path = Path(spec['path']); review = load(path)
    assert sha(path.read_bytes()) == spec['sha256'] and review[spec['field']] == spec['expected'] and review['findings'] == []
    assert B['issued_unix_ns'] >= path.stat().st_mtime_ns
nonce = uuid.UUID(B['execution_nonce'])
assert nonce.version == 4 and str(nonce) == B['execution_nonce']
assert B['execution_nonce'] != load(H / 'binding-dry-run.json')['execution_nonce']
marker_path = H / ('used-' + str(nonce) + '.json')
assert load(marker_path) == {'binding_sha256': sha((H / 'binding-execute.json').read_bytes())}
start = int(datetime.datetime.fromisoformat(launch['started_utc']).timestamp() * 10**9)
end = int(datetime.datetime.fromisoformat(T['terminal_utc']).timestamp() * 10**9)
assert 0 <= start - B['issued_unix_ns'] <= end - B['issued_unix_ns'] <= 3600 * 10**9
for key in ('live_absence', 'immediate_live_absence'):
    assert E[key]['successful_daemon_inventory'] and E[key]['original_CIDs_and_names_absent'] == 45 and E[key]['no_running_bind_overlap']
cids = {r['cid'] for r in I['owned_roles']}
names = {r['name'].removeprefix('/') for r in I['owned_roles']}
fmt = '{"id":{{json .ID}},"names":{{json .Names}},"state":{{json .State}}}'
raw = subprocess.check_output(['docker', 'container', 'ls', '-a', '--no-trunc', '--format', fmt], timeout=30)
containers = [json.loads(line) for line in raw.splitlines()]
running = binds = 0
for row in containers:
    assert row['id'] not in cids and not (set(row['names'].split(',')) & names)
    if row['state'] != 'running':
        continue
    running += 1
    mounts = json.loads(subprocess.check_output(['docker', 'container', 'inspect', row['id'], '--format', '{{json .Mounts}}'], timeout=30))
    for mount in mounts:
        if mount.get('Type') == 'bind':
            binds += 1
            p = Path(mount['Source'])
            assert not any(p == t or p.is_relative_to(t) or t.is_relative_to(p) for t in roots)
git = lambda *a: subprocess.check_output(['git', '--no-optional-locks', '-C', str(REPO), *a])
assert git('rev-parse', 'HEAD').decode().strip() == E['source_sha'] and git('rev-parse', 'HEAD^{tree}').decode().strip() == E['source_tree']
assert not git('status', '--porcelain', '--untracked-files=all')
assert all(not os.path.lexists(r['path']) for r in targets)
disk = shutil.disk_usage(H.parent)
print(json.dumps({'schema': 1, 'status': 'PASS_INDEPENDENT_ACTUAL_HOST_RETENTION_POSTCHECK_EXACT_ABSENCE_PROTECTION_AND_RECEIPTS', 'execution_receipt_sha256': sha((H / 'execution-receipt.json').read_bytes()), 'method_sha256': E['method_sha256'], 'plan_sha256': E['plan_sha256'], 'inventory_sha256': E['inventory_sha256'], 'latest_snapshot_sha256': E['latest_snapshot_sha256'], 'source_sha': E['source_sha'], 'source_tree': E['source_tree'], 'deleted_files': len(E['deleted']), 'removed_directories': len(E['removed_directories']), 'logical_bytes_deleted': E['logical_bytes_deleted'], 'all4989exact_target_objects_physically_absent': True, 'all_deleted_raw_paths_unavailable': True, 'old0afd_stdout_already_pruned_not_counted': True, 'protected_run_rows': len(I['preserved_old_and_latest_runs']), 'protected_UI_rows': len(I['preserved_latest_UI']), 'protected_packet_rows': len(I['preserved_account_packets_and_all_UI']), 'protected_canonical_rows': len(I['preserved_old_canonical']), 'unique_protected_physical_rows_rehashed': len(registry), 'only_allowed_parent_entry_losses': changed_parents, 'latest_R_all695_proofs_including_Gitstdout_rehashed': True, 'latest_R_successful_binaries_retained': len(latest_binaries), 'latest_R_source_and_allUI_packets_keepers_unchanged': True, 'HOST999_probe_and_UIDmapping_unchanged': True, 'fresh_distinct_nonce_and_exact_oneuse_marker': True, 'marker_sha256': sha(marker_path.read_bytes()), 'recorded_and_fresh_live45CID_name_absence': True, 'postcheck_containers': len(containers), 'postcheck_running': running, 'postcheck_bind_mounts': binds, 'postcheck_minimal_daemon_sha256': sha(raw), 'disk_after': {'total': disk.total, 'used': disk.used, 'available': disk.free}, 'findings': []}, indent=2))
