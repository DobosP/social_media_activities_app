from pathlib import Path
import os,json,gzip,hashlib,stat,subprocess,time
H=Path('/home/dobo/work/_temp/feat__gui-app-migration-a/social-family/notification-inbox-date-retention')
R=Path('/home/dobo/work/_worktrees/social_media_activities_app/feat__gui-app-migration-a')
S='0afd29b79fecf69bfb88847a8412d4bb2e02a787'
def digest(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def load(n):return json.loads((gzip.decompress((H/n).read_bytes()) if n.endswith('.gz') else (H/n).read_bytes()))
def check(x,m):
 if not x:raise AssertionError(m)
check(Path('/proc/self/uid_map').read_text()=='         0          0 4294967295\n','HOST uid map')
check(Path('/proc/self/gid_map').read_text()=='         0          0 4294967295\n','HOST gid map')
check(os.readlink('/proc/self/ns/user')=='user:[4026531837]' and os.getuid()==os.getgid()==1000,'HOST namespace')
i=load('inventory.json.gz'); l=load('latest-snapshot.json.gz'); e=load('execution-receipt.json'); b=load('binding-execute.json'); d=load('binding-dry-run.json')
check(digest(H/'execution-receipt.json')=='3eef88c1be04e94b6196f4e753179c671e8f757cdb2e20e19acd118563da8308','actual receipt')
check(e['status']=='COMPLETE_EXACT_SOCIAL_DATE_ROLLING_RETENTION' and e['executed'] is True and 'error' not in e,'complete status')
files=[r for g in i['target_groups'] for r in g['rows'] if r['kind']=='file']; dirs=[r for g in i['target_groups'] for r in g['rows'] if r['kind']=='directory']; removed={r['path'] for r in files+dirs}
check(len(files)==4464 and len(dirs)==487 and sum(r['bytes'] for r in files)==703582358,'finite totals')
check(e['deleted']==[{k:r[k] for k in ('path','bytes','sha256')} for r in files],'exact ordered deleted rows')
check(e['removed_directories']==[r['path'] for r in sorted(dirs,key=lambda r:(len(Path(r['path']).parts),r['path']),reverse=True)],'exact ordered removed dirs')
check(e['logical_bytes_deleted']==703582358 and all(not os.path.lexists(p) for p in removed),'all4951 absent')
check({k for k in b if b[k]!=d[k]}=={'issued_unix_ns','execution_nonce','dry_run_receipt','dry_run_review'},'execution binding only approved changes')
marker=H/('used-'+b['execution_nonce']+'.json');check(json.loads(marker.read_text())=={'binding_sha256':digest(H/'binding-execute.json')},'nonce marker')
check(b['issued_unix_ns']<=marker.stat().st_mtime_ns<=(H/'execution-receipt.json').stat().st_mtime_ns,'nonce chronology')
rows={}
for r in i['preserved_old_and_latest_runs']+l['rows']+l['UI_rows']+i['preserved_old_canonical']:
 if r['path'] in rows:check(rows[r['path']]==r,'identical duplicate protected row')
 rows[r['path']]=r
mutations=[];counts={'files':0,'directories':0};foreign=[]
for p,r in rows.items():
 check(p not in removed,'protected/target disjoint')
 path=Path(p);s=path.lstat();now={k:getattr(s,k) for k in r['stat']}
 if r['kind']=='file':
  check(stat.S_ISREG(s.st_mode) and now==r['stat'] and s.st_size==r['bytes'] and digest(path)==r['sha256'],'protected file '+p)
  if 'allocated_bytes' in r:check(s.st_blocks*512==r['allocated_bytes'],'protected allocated bytes')
  counts['files']+=1
  if s.st_uid==999 or s.st_gid==999:foreign.append(p)
 else:
  check(stat.S_ISDIR(s.st_mode),'protected directory type')
  gone=[name for name in r['entries'] if str(path/name) in removed]
  check(sorted(os.listdir(path))==[name for name in r['entries'] if name not in gone],'protected directory entries '+p)
  if gone:
   check(all(now[k]==r['stat'][k] for k in ('st_dev','st_ino','st_mode','st_uid','st_gid')),'planned parent identity')
   direct_dirs=sum(str(path/name) in {v['path'] for v in dirs} for name in gone)
   check(now['st_nlink']==r['stat']['st_nlink']-direct_dirs,'planned parent link count')
   check(now['st_mtime_ns']>=r['stat']['st_mtime_ns'] and now['st_ctime_ns']>=r['stat']['st_ctime_ns'],'planned parent monotonic times')
   mutations.append({'path':p,'removed_entries':gone,'directory_links_removed':direct_dirs})
  else:check(now==r['stat'],'untouched protected directory '+p)
  counts['directories']+=1
check(counts=={'files':4464,'directories':267} and len(mutations)==4,'protected totals and exactly4parent transitions')
check(len(foreign)==6,'all6 HOST foreign ownership rows retained999')
run_failed=next(Path(g['root']).parent for g in i['target_groups'] if 'run-ea9fe7e38032-' in g['root'] and g['root'].endswith('/source'))
check(not os.path.lexists(run_failed/'result.json'),'failed EA9 result remains absent')
for row in i['binary_provenance']:
 if '/run-ea9fe7e38032-' in row['path']:
  check(row['provenance']=='OBSERVED_POST_FAILURE_BINARY_BYTES_ONLY_NO_EXECUTION_HASH_RECEIPT' and row['original_recorded_sha256'] is None and row['actual_build_command'] is None,'failed provenance never reclassified')
for g in i['source_Git_joins']:
 subprocess.run(['git','-C',str(R),'merge-base','--is-ancestor',g['commit'],S],check=True,capture_output=True)
check(subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD']).decode().strip()==S,'source SHA')
check(subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD^{tree}']).decode().strip()==b['source_tree'],'source tree')
check(subprocess.check_output(['git','-C',str(R),'status','--porcelain'])==b'','source clean')
for spec in b['keepers'].values():
 base=Path(spec['path'])
 for name,key in [('evidence.tar.gz','archive_sha256'),('archive-manifest.json','manifest_sha256')]:check(digest(base/name)==spec[key],'keeper archive/manifest hash')
 if spec['result_sha256']:check(digest(base/'result.json')==spec['result_sha256'],'keeper result')
 check(digest(Path(spec['selection_path']))==spec['selection_sha256'],'keeper selection')
 for ref in spec['reviews'].values():check(digest(ref['path'])==ref['sha256'],'keeper review hash')
cids={r['cid'] for r in i['owned_roles']};names={r['name'].removeprefix('/') for r in i['owned_roles']}
fmt='{"id":{{json .ID}},"names":{{json .Names}},"state":{{json .State}}}'
raw=subprocess.check_output(['docker','container','ls','-a','--no-trunc','--format',fmt]);live=[json.loads(r) for r in raw.splitlines()];running=0
scopes=[Path(g['root']) for g in i['target_groups']]
for row in live:
 check(row['id'] not in cids and not(set(row['names'].split(',')) & names),'oldCID/name live')
 if row['state']=='running':
  running+=1
  for m in json.loads(subprocess.check_output(['docker','container','inspect',row['id'],'--format','{{json .Mounts}}'])):
   if m.get('Type')=='bind':
    p=Path(m['Source']).resolve()
    check(not any(p==v or p.is_relative_to(v) or v.is_relative_to(p) for v in scopes),'running bind overlap')
for run in {Path(r['run']) for r in i['owned_roles']}:
 cleanup=json.loads((run/'socket/pg-cleanup.json').read_text());check(cleanup['stop_exit']==0 and cleanup['status_exit']==3 and cleanup['pid_probe_exit']==1 and cleanup['pid_and_socket_files_absent']==1,'PG cleanup')
 check(not list((run/'socket').glob('.s.PGSQL.*')) and not (run/'socket/postmaster.pid').exists(),'PG files absent')
out={'status':'INDEPENDENT_ACTUAL_HOST_EXACT_DATE_RETENTION_POSTCHECK_PASS','observed_unix_ns':time.time_ns(),'receipt_sha256':digest(H/'execution-receipt.json'),'binding_sha256':digest(H/'binding-execute.json'),'source_sha':S,'all4951planned_paths_absent':True,'deleted_files':len(files),'removed_directories':len(dirs),'logical_bytes_deleted':703582358,'protected_files_full9stat_hash':counts['files'],'protected_directories_checked':counts['directories'],'only4planned_parent_transitions':mutations,'HOST_foreign_protected_files_owner999':len(foreign),'source_clean_and_historical_commits_reachable':True,'failed_EA9_result_still_absent_and_execution_hashes_not_reconstructed':True,'original_CIDs_names_absent':len(cids),'Docker_inventory_successful':True,'Docker_containers_checked':len(live),'Docker_running_mounts_checked':running,'Docker_inventory_sha256':hashlib.sha256(raw).hexdigest(),'running_target_bind_overlap':False,'keeper_and_canonical_hashes_unchanged':True,'retainer_or_product_runtime_repeated':False,'findings':[]}
(H/'independent-execution-host-observation.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
