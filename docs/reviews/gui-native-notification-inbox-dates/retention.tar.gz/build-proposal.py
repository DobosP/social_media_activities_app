#!/usr/bin/env python3
"""Read-only HOST-view inventory; writes only this new retention proposal. No remover."""
import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess

FAMILY = Path('/home/dobo/work/_temp/feat__gui-app-migration-a/social-family')
HERE = FAMILY / 'notification-inbox-date-retention'
REPO = Path('/home/dobo/work/_worktrees/social_media_activities_app/feat__gui-app-migration-a')
OLD = FAMILY / 'notification-inbox-pg-qa/run-496056a6a528-9681bb2d-06e5-4b23-9b62-8ab6f4ce3b80'
FAILED = FAMILY / 'notification-inbox-date-pg-qa/run-ea9fe7e38032-244baefa-64b7-4ca8-a35a-0f52ffb06ab6'
LATEST = FAMILY / 'notification-inbox-date-pg-qa/run-0afd29b79fec-0d124589-48a8-45be-a6b7-b93476bc129c'
LATEST_UI = Path('/home/dobo/work/_temp/ni-ui/run-0afd29b79fec-5cec58a3-f1b8-4e1a-b683-d959e6b9ca59')
CANONICAL = REPO / 'docs/reviews/gui-native-notification-inbox'
SOURCE = '0afd29b79fecf69bfb88847a8412d4bb2e02a787'
TREE = 'd7cc1a7e5171daebc2e6150e121c0651e2c192d7'
OLD_SOURCE = '496056a6a528d01d544abbf77e18877b60d629bd'
FAILED_SOURCE = 'ea9fe7e38032b367d329687c54187f0020349abd'
TARGET_DIRS = tuple(run / leaf for run in (OLD, FAILED) for leaf in ('source', 'binaries'))
TARGET_FILES = (FAILED / 'proof/command-006.stdout', LATEST / 'proof/command-006.stdout')
KEYS = ('st_dev', 'st_ino', 'st_mode', 'st_uid', 'st_gid', 'st_size', 'st_mtime_ns', 'st_ctime_ns', 'st_nlink')
REGISTRY = {}


def need(value, message):
    if not value:
        raise RuntimeError(message)


def meta(info):
    return {key: getattr(info, key) for key in KEYS}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(path):
    need(path.is_absolute() and path.resolve() == path, 'canonical nonsymlink path required')


def observe(path, target=False):
    canonical(path)
    before = path.lstat()
    need(stat.S_ISREG(before.st_mode) or stat.S_ISDIR(before.st_mode), 'special/link object refused')
    if target:
        need(before.st_uid == os.getuid(), 'delete target ownership must be current HOST owner')
    row = {'path': str(path), 'kind': 'file' if stat.S_ISREG(before.st_mode) else 'directory', 'stat': meta(before)}
    if stat.S_ISREG(before.st_mode):
        need(before.st_nlink == 1, 'single-link regular input required')
        digest = hashlib.sha256()
        descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
        try:
            opened = os.fstat(descriptor)
            need(meta(before) == meta(opened), 'input changed before open')
            while True:
                block = os.read(descriptor, 1 << 20)
                if not block:
                    break
                digest.update(block)
            after = os.fstat(descriptor)
        finally:
            os.close(descriptor)
        need(meta(before) == meta(after) == meta(path.lstat()), 'input changed during hash')
        row.update(bytes=before.st_size, sha256=digest.hexdigest(), allocated_bytes=before.st_blocks * 512)
    else:
        row['entries'] = sorted(child.name for child in path.iterdir())
        need(meta(before) == meta(path.lstat()), 'directory changed during enumeration')
    need(path not in REGISTRY or REGISTRY[path] == row, 'earliest HOST bytes/stat/membership changed')
    REGISTRY.setdefault(path, row)
    return row


def walk(root, target=False, excluded=()):
    rows = []
    def descend(path):
        if path in excluded:
            return
        row = observe(path, target)
        rows.append(row)
        if row['kind'] == 'directory':
            for name in row['entries']:
                descend(path / name)
    descend(root)
    return rows


def read_json(path):
    row = observe(path)
    raw = path.read_bytes()
    need(sha(raw) == row['sha256'], 'JSON changed after earliest read')
    return json.loads(raw)


def git(*args):
    return subprocess.check_output(['git', '--no-optional-locks', '-C', str(REPO), *args])


def fence():
    need(git('rev-parse', 'HEAD').decode().strip() == SOURCE and git('rev-parse', 'HEAD^{tree}').decode().strip() == TREE
         and not git('status', '--porcelain'), 'exact clean0afd source required')
    for ancestor in (OLD_SOURCE, FAILED_SOURCE):
        git('merge-base', '--is-ancestor', ancestor, SOURCE)


def verify_source(run, commit, rows):
    raw_manifest = read_json(run / 'source-manifest.json')
    manifest = {row['path']: row for row in raw_manifest}
    need(len(manifest) == len(raw_manifest) and not any('link' in row for row in raw_manifest), 'unique regular source manifest required')
    files = {Path(row['path']).relative_to(run / 'source').as_posix(): row for row in rows if row['kind'] == 'file'}
    need(set(files) == set(manifest), 'entire generated source file set must match original manifest')
    tree = {}
    for entry in git('ls-tree', '-r', '-z', commit).split(b'\0'):
        if not entry:
            continue
        head, name = entry.split(b'\t', 1)
        mode, kind, oid = head.split()
        need(kind == b'blob' and mode in (b'100644', b'100755'), 'source Git object type refused')
        tree[name.decode()] = (int(mode, 8) & 0o777, oid.decode())
    need(set(tree) == set(manifest), 'original Git tracked source set differs')
    process = subprocess.Popen(['git', '--no-optional-locks', '-C', str(REPO), 'cat-file', '--batch'], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    try:
        for name, row in manifest.items():
            original = files[name]
            mode, oid = tree[name]
            need(original['sha256'] == row['sha256'] and original['bytes'] == row['bytes']
                 and stat.S_IMODE(original['stat']['st_mode']) == row['mode'] == mode, 'source manifest metadata differs')
            process.stdin.write((oid + '\n').encode()); process.stdin.flush()
            header = process.stdout.readline().decode().split()
            need(header[:2] == [oid, 'blob'] and int(header[2]) == row['bytes'], 'original Git blob receipt differs')
            remaining = int(header[2]); digest = hashlib.sha256()
            while remaining:
                block = process.stdout.read(min(1 << 20, remaining)); need(block, 'short Git blob')
                digest.update(block); remaining -= len(block)
            need(process.stdout.read(1) == b'\n' and digest.hexdigest() == row['sha256'], 'Git blob content differs')
        process.stdin.close(); need(process.wait() == 0, 'Git blob reader failed')
    finally:
        if process.poll() is None:
            process.terminate(); process.wait()
    return {'commit': commit, 'source_manifest': str(run / 'source-manifest.json'),
            'source_manifest_sha256': observe(run / 'source-manifest.json')['sha256'],
            'regular_files': len(manifest), 'whole_source_matches_original_Git_and_manifest': True}


def write_json(path, value):
    need(not path.exists(), 'proposal output already exists')
    path.write_text(json.dumps(value, indent=2) + '\n')


def write_gzip(path, value):
    need(not path.exists(), 'proposal output already exists')
    raw = (json.dumps(value, sort_keys=True, separators=(',', ':')) + '\n').encode()
    path.write_bytes(gzip.compress(raw, compresslevel=9, mtime=0))
    return {'path': str(path), 'sha256': sha(path.read_bytes()), 'uncompressed_bytes': len(raw)}


def main():
    need(Path(__file__).resolve() == HERE / 'build-proposal.py', 'exact proposal source required')
    fence()
    disk = shutil.disk_usage(FAMILY)
    probe = LATEST / 'socket/pg-cleanup.json'
    host_probe = observe(probe)
    need(host_probe['stat']['st_uid'] == host_probe['stat']['st_gid'] == 999, 'HOST ownership view999 required; never normalize namespace ownership')
    sandbox = read_json(HERE / 'default-observer.json')
    prior = sandbox['probe']['stat']
    need(all(prior[key] == host_probe['stat'][key] for key in prior if key not in ('st_uid', 'st_gid')),
         'observer probe has nonownership drift')
    observer = {'view': 'HOST_REQUIRED_ESCALATED_READ_ONLY', 'uid': os.getuid(), 'gid': os.getgid(),
                'euid': os.geteuid(), 'egid': os.getegid(), 'uid_map': Path('/proc/self/uid_map').read_text(),
                'gid_map': Path('/proc/self/gid_map').read_text(), 'user_namespace': os.readlink('/proc/self/ns/user'),
                'foreign_protected_probe': host_probe, 'default_observer_probe_ownership': {key: prior[key] for key in ('st_uid', 'st_gid')},
                'all_nonownership_probe_fields_equal': True, 'ownership_normalized': False}
    target_groups = []
    for root in TARGET_DIRS:
        target_groups.append({'root': str(root), 'type': 'whole_owned_generated_tree', 'rows': walk(root, True)})
    for path in TARGET_FILES:
        target_groups.append({'root': str(path), 'type': 'literal_duplicate_Git_stdout', 'rows': [observe(path, True)]})
    targets = [row for group in target_groups for row in group['rows']]
    need(len({row['path'] for row in targets}) == len(targets), 'target overlap refused')
    source_joins = []
    for run, commit in ((OLD, OLD_SOURCE), (FAILED, FAILED_SOURCE)):
        source_joins.append(verify_source(run, commit, next(group['rows'] for group in target_groups if group['root'] == str(run / 'source'))))
    old_result = read_json(OLD / 'result.json')
    latest_result = read_json(LATEST / 'result.json')
    need(old_result['source'] == OLD_SOURCE and old_result['method_pass'] and old_result['errors'] == []
         and latest_result['source'] == SOURCE and latest_result['method_pass'] and latest_result['errors'] == [], 'successful old/latest qualification binding differs')
    need(not os.path.lexists(FAILED / 'result.json'), 'failedEA9 must not gain a result')
    failure_review = read_json(FAMILY / 'notification-inbox-date-checks/first-full-failure-review.json')
    need(failure_review['verdict'] == 'ACCEPT_FAILURE_CAUSE_RAW_SEVEN_SUITE_AND_CLEANUP_AUDIT_ONLY' and failure_review['findings'] == [], 'failed source review required')
    provenance = []
    for run, label in ((OLD, 'accepted496'), (FAILED, 'failedEA9')):
        binary_rows = [row for group in target_groups if group['root'] == str(run / 'binaries') for row in group['rows'] if row['kind'] == 'file']
        for row in binary_rows:
            name = Path(row['path']).name
            record = {'path': row['path'], 'observed_current_sha256': row['sha256'], 'bytes': row['bytes']}
            if label == 'accepted496':
                if name.endswith('.test'):
                    lane = name.removesuffix('.test'); expected = old_result['lanes'][lane]['binary']['sha256']; proof = 'proof/' + lane + '-compile.stdout'
                else:
                    expected = old_result['notifications_reference_bootstrap_binary' if name == 'reference-notifications-bootstrap' else 'reference_bootstrap_binary']['sha256']
                    proof = 'proof/' + ('notifications-reference-bootstrap-compile.stdout' if name == 'reference-notifications-bootstrap' else 'reference-bootstrap-compile.stdout')
                commands = [c for c in old_result['commands'] if c['stdout']['path'] == proof]
                need(len(commands) == 1 and commands[0]['exit'] == 0 and expected == row['sha256'], 'accepted old binary/build receipt differs')
                record.update(provenance='ORIGINAL_SUCCESSFUL_BUILD_AND_RECORDED_BINARY_SHA_MATCH_CURRENT', original_recorded_sha256=expected, actual_build_command=commands[0])
            else:
                record.update(provenance='OBSERVED_POST_FAILURE_BINARY_BYTES_ONLY_NO_EXECUTION_HASH_RECEIPT',
                              original_recorded_sha256=None, actual_build_command=None,
                              note='EA9 has no result.json/retained command ledger. Native PASS/CID path evidence remains failed overall; current binary hash is not fabricated as its execution hash.')
            provenance.append(record)
    archive_joins = []
    for path, result, expected_sha, expected_bytes in ((TARGET_FILES[0], None, 'c3d36a1fd8089a945f8b7f5af4eb4031765abc9eb0a4e13ae53a5eec646676a4', 70430720),
                                                       (TARGET_FILES[1], latest_result, '48b74396f6c2fe01d907fdfca30ebcba29fba6f6a01949fb9126b5ffe3cff820', 41496094)):
        row = observe(path, True); need(row['sha256'] == expected_sha and row['bytes'] == expected_bytes, 'literal archive duplicate differs')
        if result is not None:
            commands = [c for c in result['commands'] if c['stdout']['path'] == 'proof/command-006.stdout']
            need(len(commands) == 1 and commands[0]['exit'] == 0 and commands[0]['stdout']['sha256'] == expected_sha
                 and commands[0]['argv'] == ['git', '-C', str(REPO), 'archive', '--format=tar.gz', SOURCE], 'current archive command ledger differs')
            archive_joins.append({'path': str(path), 'provenance': 'SUCCESSFUL_EXACT_FULL_GIT_COMMAND_LEDGER', 'command': commands[0]})
        else:
            archive_joins.append({'path': str(path), 'provenance': 'OBSERVED_FAILED_RUN_RAW_ARCHIVE_BOUND_BY_F33D_NO_COMMAND_LEDGER',
                                  'command': None, 'source_commit': FAILED_SOURCE, 'source_manifest_verified': True})
    preserved = []
    for run in (OLD, FAILED, LATEST):
        preserved += walk(run, excluded=TARGET_DIRS + TARGET_FILES)
    latest_source = [row for row in preserved if row['path'] == str(LATEST / 'source') or Path(row['path']).is_relative_to(LATEST / 'source')]
    source_joins.append(verify_source(LATEST, SOURCE, latest_source))
    for row in preserved:
        path = Path(row['path'])
        if row['kind'] != 'file' or path.parent != LATEST / 'binaries':
            continue
        name = path.name
        if name.endswith('.test'):
            expected = latest_result['lanes'][name.removesuffix('.test')]['binary']['sha256']
        else:
            expected = latest_result['notifications_reference_bootstrap_binary' if name == 'reference-notifications-bootstrap' else 'reference_bootstrap_binary']['sha256']
        need(row['sha256'] == expected, 'latest protected binary differs from accepted execution receipt')
    preserved_ui = walk(LATEST_UI)
    source_reference = walk(CANONICAL)
    roles = []
    for run in (OLD, FAILED, LATEST):
        for path in sorted(run.glob('*.cid')):
            cid = path.read_text().strip(); row = observe(path)
            need(len(cid) == 64 and all(c in '0123456789abcdef' for c in cid), 'CID spelling refused')
            role = path.stem; created = read_json(run / 'proof' / (role + '-created.json'))
            need(created['id'] == cid and created['labels']['io.dobolabs.gui.owner'] in created['name'], 'CID/name owner join differs')
            roles.append({'run': str(run), 'role': role, 'cid': cid, 'name': created['name'], 'CID_file_sha256': row['sha256']})
    need(len(roles) == 45 and len({r['cid'] for r in roles}) == 45 and len({r['name'] for r in roles}) == 45, 'exact45 owned historical/current roles required')
    old_deleted = OLD / 'proof/command-006.stdout'
    need(not os.path.lexists(old_deleted), '496 duplicate Git stdout was already pruned; never target/count twice')
    previous_retention = read_json(CANONICAL / 'retention-result.json')
    prior = [row for row in previous_retention['deleted'] if row['path'] == str(old_deleted)]
    need(len(prior) == 1 and previous_retention['status'] == 'COMPLETE_EXACT_SOCIAL_ROLLING_RETENTION', 'prior already-pruned archive receipt differs')
    for path in tuple(REGISTRY):
        observe(path, target=any(path == root or path.is_relative_to(root) for root in TARGET_DIRS) or path in TARGET_FILES)
    fence()
    inventory = {'schema': 1, 'status': 'HOST_FINITE_INVENTORY_ONLY_NO_REMOVAL', 'observer': observer,
                 'target_groups': target_groups, 'preserved_old_and_latest_runs': preserved,
                 'preserved_latest_UI': preserved_ui, 'preserved_old_canonical': source_reference,
                 'source_Git_joins': source_joins, 'binary_provenance': provenance, 'duplicate_archive_provenance': archive_joins,
                 'owned_roles': roles, 'already_pruned496_archive': {'status': 'NONE_ALREADY_PRUNED_NOT_A_NEW_TARGET', 'path': str(old_deleted), 'previous_receipt_sha256': observe(CANONICAL / 'retention-result.json')['sha256'], 'original_deleted_row': prior[0]}}
    latest = {'schema': 1, 'status': 'HOST_LATEST_PROTECTED_SETUP_SNAPSHOT_ONLY', 'source_sha': SOURCE,
              'latest_run': str(LATEST), 'rows': [row for row in preserved if row['path'] == str(LATEST) or Path(row['path']).is_relative_to(LATEST)],
              'latest_UI': str(LATEST_UI), 'UI_rows': preserved_ui, 'excluded_exact_duplicate_stdout': str(TARGET_FILES[1])}
    write_json(HERE / 'host-observer.json', observer)
    inv = write_gzip(HERE / 'inventory.json.gz', inventory)
    snap = write_gzip(HERE / 'latest-snapshot.json.gz', latest)
    files = [row for row in targets if row['kind'] == 'file']; directories = [row for row in targets if row['kind'] == 'directory']
    summary = {'schema': 1, 'status': 'READ_ONLY_HOST_PROPOSAL_INVENTORY_COMPLETE_NOT_RETENTION',
               'observed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'source_sha': SOURCE, 'source_tree': TREE,
               'disk_before': {'total': disk.total, 'used': disk.used, 'available': disk.free},
               'inventory': inv, 'latest_snapshot': snap, 'target_files': len(files), 'target_directories': len(directories),
               'target_logical_bytes': sum(row['bytes'] for row in files), 'target_allocated_bytes': sum(row['allocated_bytes'] for row in files),
               'target_roots': [str(p) for p in TARGET_DIRS + TARGET_FILES],
               'protected_run_rows': len(preserved), 'protected_UI_rows': len(preserved_ui), 'protected_canonical_rows': len(source_reference),
               'source_joins': source_joins, 'owned_CID_roles': len(roles), 'new_keeper_binding': None,
               'execution_source': None, 'physical_deletion_performed': False,
               'limits': 'Read-only builder, not a remover/verifier/dryrun. New date keeper acceptance/schema remains unknown. No execution is possible from this proposal.'}
    write_json(HERE / 'inventory-summary.json', summary)
    print(json.dumps({key: summary[key] for key in ('status', 'target_files', 'target_directories', 'target_logical_bytes', 'target_allocated_bytes', 'protected_run_rows', 'protected_UI_rows', 'protected_canonical_rows', 'owned_CID_roles')}))


if __name__ == '__main__':
    main()
