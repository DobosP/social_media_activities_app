#!/usr/bin/env python3
"""Read-only HOST duplicate-source proof; never export, replay or remove anything."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import stat
import tarfile

HERE = Path('/home/dobo/work/_temp/feat__gui-app-migration-a/social-family/notification-inbox-date-retention')
KEYS = ('st_dev', 'st_ino', 'st_mode', 'st_uid', 'st_gid', 'st_size', 'st_mtime_ns', 'st_ctime_ns', 'st_nlink')


def need(value, message):
    if not value:
        raise RuntimeError(message)


def main():
    need(Path(__file__).resolve() == HERE / 'verify-archive-content.py', 'exact proof source required')
    inventory = json.loads(gzip.decompress((HERE / 'inventory.json.gz').read_bytes()))
    probe = Path(inventory['observer']['foreign_protected_probe']['path'])
    need(probe.stat().st_uid == probe.stat().st_gid == 999, 'same HOST observer required')
    records = []
    groups = inventory['target_groups']
    for item in inventory['duplicate_archive_provenance']:
        path = Path(item['path']); need(path.resolve() == path, 'canonical archive input required')
        original = next(group['rows'][0] for group in groups if group['root'] == str(path))
        run = path.parents[1]
        join = next(row for row in inventory['source_Git_joins'] if row['source_manifest'] == str(run / 'source-manifest.json'))
        manifest_path = run / 'source-manifest.json'
        expected_manifest = next(row for row in inventory['preserved_old_and_latest_runs'] if row['path'] == str(manifest_path))
        need(manifest_path.resolve() == manifest_path and {key: getattr(manifest_path.lstat(), key) for key in KEYS} == expected_manifest['stat'], 'source manifest metadata differs')
        manifest_raw = manifest_path.read_bytes()
        need(hashlib.sha256(manifest_raw).hexdigest() == join['source_manifest_sha256'] == expected_manifest['sha256'], 'source manifest hash differs')
        manifest = json.loads(manifest_raw)
        by_path = {row['path']: row for row in manifest}
        need(len(by_path) == len(manifest) and not any('link' in row for row in manifest), 'unique regular source manifest required')
        before = path.lstat()
        need(stat.S_ISREG(before.st_mode) and {key: getattr(before, key) for key in KEYS} == original['stat'], 'archive bytes/stat beforeimage differs')
        descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
        seen = set()
        try:
            with os.fdopen(descriptor, 'rb', closefd=False) as stream:
                with tarfile.open(fileobj=stream, mode='r:' if run.name.startswith('run-ea9') else 'r:gz') as archive:
                    for member in archive:
                        name = member.name.rstrip('/')
                        need(name and not name.startswith('/') and '..' not in Path(name).parts, 'unsafe archive member')
                        if member.isdir():
                            continue
                        need(member.isfile() and name in by_path and name not in seen, 'unexpected/duplicate archive object')
                        seen.add(name); expected = by_path[name]
                        need(member.size == expected['bytes'] and member.mode & ~0o022 == expected['mode'], 'original source size/mode differs')
                        digest = hashlib.sha256()
                        data = archive.extractfile(member)
                        while True:
                            block = data.read(1 << 20)
                            if not block:
                                break
                            digest.update(block)
                        need(digest.hexdigest() == expected['sha256'], 'original source member hash differs')
                    comment = archive.pax_headers.get('comment')
                    need(comment in (None, join['commit']), 'archive commit comment differs')
            after = os.fstat(descriptor)
        finally:
            os.close(descriptor)
        need(seen == set(by_path) and {key: getattr(after, key) for key in KEYS} == original['stat']
             and {key: getattr(path.lstat(), key) for key in KEYS} == original['stat'], 'archive completeness/final metadata differs')
        records.append({'path': str(path), 'observed_archive_sha256': original['sha256'], 'archive_bytes': original['bytes'],
                        'source_commit': join['commit'], 'source_manifest_sha256': join['source_manifest_sha256'],
                        'regular_source_members': len(seen), 'all_member_bytes_modes_match_Git_verified_source_manifest': True,
                        'archive_comment': comment, 'command_ledger_available': item['command'] is not None,
                        'scope': 'Content/custody proof only. Missing EA9 command/execution hashes are not reconstructed.'})
    target = HERE / 'archive-content-custody.json'
    need(not target.exists(), 'proof output already exists')
    value = {'schema': 1, 'status': 'HOST_READ_ONLY_EXACT_TWO_ARCHIVE_CONTENT_MATCHES_NOT_RETENTION',
             'rows': records, 'new_keeper_acceptance': None, 'deletion_performed': False}
    target.write_text(json.dumps(value, indent=2) + '\n')
    print(json.dumps({'rows': len(records), 'member_counts': [row['regular_source_members'] for row in records],
                      'proof_sha256': hashlib.sha256(target.read_bytes()).hexdigest()}))


if __name__ == '__main__':
    main()
