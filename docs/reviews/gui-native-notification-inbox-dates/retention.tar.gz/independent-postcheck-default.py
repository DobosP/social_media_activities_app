from pathlib import Path
from decimal import Decimal
import os,json,hashlib,tarfile,stat,time
H=Path('/home/dobo/work/_temp/feat__gui-app-migration-a/social-family/notification-inbox-date-retention');K=H.parent/'notification-inbox-date-keeper';R=Path('/home/dobo/work/_worktrees/social_media_activities_app/feat__gui-app-migration-a')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def need(x,m):
 if not x:raise AssertionError(m)
s=json.loads((K/'prepared-selection.json').read_text());need(Path('/proc/self/uid_map').read_text()==s['observer']['uid_map'] and Path('/proc/self/gid_map').read_text()==s['observer']['gid_map'],'default observer')
for r in s['rows']+list(s['collector_source_files'].values()):
 p=Path(r['path']);st=p.lstat();need(stat.S_ISREG(st.st_mode) and {k:getattr(st,k) for k in r['stat']}==r['stat'] and st.st_size==r['bytes'] and sha(p)==r['sha256'],'selected/repro full8stat '+str(p))
for r in s['source_frame']:
 p=R/r['path'];st=p.lstat();need(stat.S_ISREG(st.st_mode) and {k:getattr(st,k) for k in r['stat']}==r['stat'] and st.st_size==r['bytes'] and sha(p)==r['sha256'],'source full8stat '+str(p))
counts={}
for base,n,expected,wanted in [(K/'candidate-0afd','new0afd',1689,'bc10a80ae1a9b0f404e9434f2a0065d941a0cb4a336d5ea06eb39032da09c7ea'),(R/'docs/reviews/gui-native-notification-inbox','original496',2695,'e007db95293927d330e574efeb4938e52edd2309b520f07895ce0c5fa77b5eb5')]:
 m=json.loads((base/'archive-manifest.json').read_text());rows=m['members'] if isinstance(m,dict) else m;need(sha(base/'evidence.tar.gz')==wanted,'archive sha')
 with tarfile.open(base/'evidence.tar.gz','r:gz') as t:
  members=t.getmembers();need(len(members)==len(rows)==expected and len({v.name for v in members})==expected,'archive exact unique count')
  index={v.name:v for v in members}
  for row in rows:
   ti=index[row['member']];need(ti.isfile() and not ti.issym() and not ti.islnk() and ti.size==row['bytes'] and ti.mode==row['mode'] and ti.uid==row['uid'] and ti.gid==row['gid'] and int(Decimal(ti.pax_headers['mtime'])*10**9)==row['mtime_ns'] and hashlib.sha256(t.extractfile(ti).read()).hexdigest()==row['sha256'],'archive complete bytes/PAX')
   if n=='new0afd':
    p=Path(row['original']);st=p.lstat();need(stat.S_ISREG(st.st_mode) and st.st_size==row['bytes'] and stat.S_IMODE(st.st_mode)==row['mode'] and st.st_uid==row['uid'] and st.st_gid==row['gid'] and st.st_mtime_ns==row['mtime_ns'] and sha(p)==row['sha256'],'new archived original remains exact')
 counts[n]=expected
need(all(Path(r['path']).lstat().st_uid==Path(r['path']).lstat().st_gid==65534 for r in s['foreign_owned_payload_rows']),'original observed foreign4 ownership65534 preserved')
need(s['failed_EA9']['command_metadata']=='LOST_NOT_RECONSTRUCTED','failure remains lost metadata')
obs={'status':'INDEPENDENT_POST_RETENTION_DEFAULT_VIEW_SOURCE_AND_KEEPER_PASS','observed_unix_ns':time.time_ns(),'selected1673_plus6repro_full8stat_hash_unchanged':True,'owning_source2230_full8stat_hash_unchanged':True,'complete_archive_members_bytes_and_PAX_reverified':counts,'all1689new_archived_originals_bytes_and_portable_metadata_unchanged':True,'four_foreign_payload_UID_GID65534_preserved':True,'ownership_normalization_performed':False,'directory_censuses_not_reexecuted_after_planned_parent_changes':True,'failed_EA9_command_metadata_still_lost_not_reconstructed':True,'collector_or_product_runtime_repeated':False,'findings':[]}
(H/'independent-execution-default-observation.json').write_text(json.dumps(obs,indent=2)+'\n');print(json.dumps(obs))
