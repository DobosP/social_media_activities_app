#!/usr/bin/env python3
"""Exact disabled-until-bound HOST Social date retention; no recursive removal."""
import argparse
from decimal import Decimal
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import time
import tarfile
import uuid

BASE = Path('/home/dobo/work/_temp/feat__gui-app-migration-a/social-family')
HERE = BASE / 'notification-inbox-date-retention'
REPO = Path('/home/dobo/work/_worktrees/social_media_activities_app/feat__gui-app-migration-a')
OLD = BASE / 'notification-inbox-pg-qa/run-496056a6a528-9681bb2d-06e5-4b23-9b62-8ab6f4ce3b80'
FAILED = BASE / 'notification-inbox-date-pg-qa/run-ea9fe7e38032-244baefa-64b7-4ca8-a35a-0f52ffb06ab6'
LATEST = BASE / 'notification-inbox-date-pg-qa/run-0afd29b79fec-0d124589-48a8-45be-a6b7-b93476bc129c'
CURRENT_UI = Path('/home/dobo/work/_temp/ni-ui/run-0afd29b79fec-5cec58a3-f1b8-4e1a-b683-d959e6b9ca59')
OLD_KEEPER = REPO / 'docs/reviews/gui-native-notification-inbox'
DATE_KEEPER = BASE / 'notification-inbox-date-keeper'
CANDIDATE = DATE_KEEPER / 'candidate-0afd'
SOURCE = '0afd29b79fecf69bfb88847a8412d4bb2e02a787'
TREE = 'd7cc1a7e5171daebc2e6150e121c0651e2c192d7'
OLD_SOURCE = '496056a6a528d01d544abbf77e18877b60d629bd'
FAILED_SOURCE = 'ea9fe7e38032b367d329687c54187f0020349abd'
PLAN_SHA = '370bdc1fe8ffe987b7cfe8485b5e654cdc03b29a24f0465c012cfa1a53f6671b'
INVENTORY_SHA = 'af3fa2b49e6e971e14002e5b3894a0cfe3281b12492d34c18873acf2b8f7a030'
LATEST_SHA = '54fc886f6308eb7b7823df1cfc5f8a65b612ad235695af5d5207bf03c2abb0bd'
PG_SHA = '1ba8e2499b7fe93b979e835c0e3d7533f731b08581d2e40a9b0519f780d8a647'
UI_SHA = '5a3fe1e513fe4ec9b49c3c60327c9e7d2d98be173aa7a041b72b9d683ad34f3e'
LANES = {'web','app','accounts','recommendations','social','messaging','notifications'}
TARGET_DIRS = tuple(run / leaf for run in (OLD, FAILED) for leaf in ('source','binaries'))
TARGET_FILES = (FAILED/'proof/command-006.stdout',LATEST/'proof/command-006.stdout')
PARENTS = {OLD,FAILED,FAILED/'proof',LATEST/'proof'}
STAT_KEYS = ('dev','ino','mode','uid','gid','bytes','mtime_ns','ctime_ns','nlink')
OBS_KEYS = ('st_dev','st_ino','st_mode','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns','st_nlink')
PORTABLE = ('bytes','sha256','mode','uid','gid','mtime_ns')
# The fourteen helpers below are byte-exact definitions from reviewed3e95.


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def hex64(value):
    return isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value) is not None


def literal(value):
    need(isinstance(value, str) and not value.startswith('/') and '\\' not in value
         and all(x not in ('', '.', '..') for x in value.split('/')), 'literal relative path')
    return value


def parent_fd(path):
    need(path.is_absolute() and path == Path(os.path.normpath(path)), 'literal absolute path')
    fd = os.open('/', os.O_RDONLY | os.O_DIRECTORY)
    try:
        for part in path.parts[1:-1]:
            following = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            os.close(fd); fd = following
        return fd
    except BaseException:
        os.close(fd); raise


def meta(info):
    return dict(dev=info.st_dev, ino=info.st_ino, mode=stat.S_IMODE(info.st_mode), uid=info.st_uid,
                gid=info.st_gid, bytes=info.st_size, mtime_ns=info.st_mtime_ns,
                ctime_ns=info.st_ctime_ns, nlink=info.st_nlink)


def same(info, row, directory=False, removing=False):
    need(stat.S_ISDIR(info.st_mode) if directory else stat.S_ISREG(info.st_mode), 'original regular type')
    keys = ('dev', 'ino', 'mode', 'uid', 'gid') if directory and removing else STAT_KEYS
    need(all(meta(info)[k] == row[k] for k in keys), 'original inode/full metadata changed')
    if not directory:
        need(info.st_nlink == 1, 'hardlink refused')


def current(path, collect=False):
    need(path.is_absolute() and path.resolve() == path, 'canonical input path')
    parent = parent_fd(path); fd = None
    try:
        before = os.stat(path.name, dir_fd=parent, follow_symlinks=False)
        need(stat.S_ISREG(before.st_mode) or stat.S_ISDIR(before.st_mode), 'no symlink/special file')
        if stat.S_ISDIR(before.st_mode):
            fd = os.open(path.name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent)
            need(meta(os.fstat(fd)) == meta(before), 'directory swapped before open')
            entries = sorted(os.listdir(fd)); need(meta(os.fstat(fd)) == meta(before), 'directory changed during read')
            return dict(path=str(path), file=False, **meta(before), sha256=None, git_blob=None, entries=entries)
        need(before.st_nlink == 1, 'single-link regular file')
        fd = os.open(path.name, os.O_RDONLY | os.O_NOFOLLOW, dir_fd=parent)
        need(meta(os.fstat(fd)) == meta(before), 'file swapped before open')
        digest = hashlib.sha256(); blob = hashlib.sha1(('blob ' + str(before.st_size) + '\0').encode())
        size = 0; chunks = []
        while True:
            block = os.read(fd, 1 << 20)
            if not block:
                break
            size += len(block); digest.update(block); blob.update(block)
            if collect:
                need(size <= 64 << 20, 'bounded metadata/keeper input'); chunks.append(block)
        need(meta(os.fstat(fd)) == meta(before) and size == before.st_size, 'file changed during read')
        row = dict(path=str(path), file=True, **meta(before), sha256=digest.hexdigest(), git_blob=blob.hexdigest(), entries=None)
        return (b''.join(chunks), row) if collect else row
    finally:
        if fd is not None:
            os.close(fd)
        os.close(parent)


def snapshot(root):
    return [current(path) for path in [root] + sorted(root.rglob('*'))]


class Inputs:
    """Keep first validated raw bytes/stat; never validate one read then consume another."""
    def __init__(self):
        self.rows = {}
    def read(self, path, digest=None):
        if path not in self.rows:
            self.rows[path] = current(path, collect=True)
        raw, row = self.rows[path]
        if digest is not None:
            need(hex64(digest) and sha(raw) == digest, 'explicit bound input differs: ' + str(path))
        return raw
    def json(self, path, digest=None):
        return json.loads(self.read(path, digest))
    def fence(self):
        for path, (raw, row) in self.rows.items():
            now, info = current(path, collect=True)
            need(now == raw and info == row, 'first-read input drift: ' + str(path))


def scalars(value):
    if isinstance(value, str):
        return {value}
    if isinstance(value, dict):
        return set().union(*(scalars(x) for x in value.values()), set())
    if isinstance(value, list):
        return set().union(*(scalars(x) for x in value), set())
    return set()


def accepted(inputs, spec, digests, source=None):
    need(set(spec) == {'path', 'sha256', 'field', 'expected'}, 'explicit independent review binding')
    path = Path(spec['path']); need(path.is_relative_to(BASE) or path.is_relative_to(REPO / 'docs/reviews'), 'owned/canonical review')
    value = inputs.json(path, spec['sha256']); expected = spec['expected']
    need(spec['field'] in ('status', 'verdict') and isinstance(expected, str)
         and (expected.startswith('ACCEPT') or 'ACCEPTED' in expected) and 'NOT_ACCEPTED' not in expected
         and value.get(spec['field']) == expected and value.get('findings') == [], 'actual independently accepted review')
    need(all(x in scalars(value) for x in list(digests) + ([] if source is None else [source])), 'review must contain actual bound source/digest scalars')
    return value


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args], env={'PATH': os.defpath, 'LANG': 'C.UTF-8'})


def unpack(inputs, path, digest):
    raw = inputs.read(path, digest)
    with gzip.GzipFile(fileobj=io.BytesIO(raw), mode='rb') as stream:
        decoded = stream.read((128 << 20) + 1)
    need(len(decoded) <= 128 << 20, 'bounded portable manifest')
    return decoded, json.loads(decoded)


def expected_row(row):
    need(row['kind'] in ('file','directory') and set(row['stat']) == set(OBS_KEYS), 'exact HOST inventory row')
    s = row['stat']; file = row['kind'] == 'file'
    need(stat.S_ISREG(s['st_mode']) if file else stat.S_ISDIR(s['st_mode']), 'original type bits')
    value = dict(path=row['path'], file=file, dev=s['st_dev'], ino=s['st_ino'],
                 mode=stat.S_IMODE(s['st_mode']), uid=s['st_uid'], gid=s['st_gid'],
                 bytes=s['st_size'], mtime_ns=s['st_mtime_ns'], ctime_ns=s['st_ctime_ns'], nlink=s['st_nlink'],
                 sha256=row['sha256'] if file else None, entries=None if file else row['entries'])
    if file:
        need(row['bytes'] == value['bytes'] and s['st_nlink'] == 1 and hex64(row['sha256']), 'single-link fixed regular row')
    return value


def compare_snapshot(row, removed=()):
    path = Path(row['path']); wanted = expected_row(row); now = current(path)
    if not wanted['file'] and removed and path in PARENTS:
        same(path.lstat(), wanted, directory=True, removing=True)
        need(now['entries'] == [name for name in wanted['entries'] if str(path/name) not in set(removed)],
             'only literal planned child entries may disappear')
    else:
        need(all(now[key] == value for key,value in wanted.items()), 'exact HOST bytes/fullstat/membership changed: '+str(path))
    return now


def protect(rows, removed=()):
    for row in rows:
        compare_snapshot(row, removed)


def source_fence():
    need(git('rev-parse','HEAD').decode().strip() == SOURCE
         and git('rev-parse','HEAD^{tree}').decode().strip() == TREE
         and not git('status','--porcelain','--untracked-files=all'), 'exact clean0afd before promotion')
    for old in (OLD_SOURCE,FAILED_SOURCE):
        git('merge-base','--is-ancestor',old,SOURCE)


def host_view(inputs, plan):
    observer = inputs.json(HERE/'host-observer.json',plan['host_observer_sha256'])
    need(Path('/proc/self/uid_map').read_text() == observer['uid_map']
         and Path('/proc/self/gid_map').read_text() == observer['gid_map']
         and os.readlink('/proc/self/ns/user') == observer['user_namespace']
         and os.getuid() == os.geteuid() == observer['uid']
         and os.getgid() == os.getegid() == observer['gid'], 'same recorded HOST observer required')
    probe = observer['foreign_protected_probe']; compare_snapshot(probe)
    need(probe['stat']['st_uid'] == probe['stat']['st_gid'] == 999, 'HOST foreign protected ownership must remain999; no translation')
    return observer


def keeper(inputs, spec, date=False):
    need(set(spec) == {'path','archive_sha256','manifest_sha256','selection_path','selection_sha256',
                       'result_sha256','exclusions_sha256','reviews'}, 'explicit complete keeper spec')
    root = CANDIDATE if date else OLD_KEEPER
    need(spec['path'] == str(root) and root.resolve() == root and root.stat().st_uid == os.getuid(), 'literal protected keeper')
    archive_raw = inputs.read(root/'evidence.tar.gz',spec['archive_sha256'])
    outer = inputs.json(root/'archive-manifest.json',spec['manifest_sha256'])
    selection_path = DATE_KEEPER/'prepared-selection.json' if date else OLD_KEEPER/'selection.json'
    need(spec['selection_path'] == str(selection_path), 'exact selection location')
    selection_raw = inputs.read(selection_path,spec['selection_sha256']); selection = json.loads(selection_raw)
    if date:
        need(spec['archive_sha256'] == 'bc10a80ae1a9b0f404e9434f2a0065d941a0cb4a336d5ea06eb39032da09c7ea'
             and spec['manifest_sha256'] == '2787ff123c6b333d5aeed9650c22cdab92b8e2a76f189085a4eb52c5f3bc21d4'
             and spec['result_sha256'] == '9d005b48c274481e21f509a6d9e15550ce237f397c3de23bef987a01ab13126e'
             and spec['selection_sha256'] == '982a51b039310e3df32c124fd44a2f4758685865ba697f2fa185f363c2a7809f'
             and spec['exclusions_sha256'] == '6900bbf52db7adf654c06927af5e520d0834d69b66273ba67ba1911277ac06d0',
             'exact actual collected date candidate')
        need(isinstance(outer,dict) and outer['archive_sha256'] == spec['archive_sha256']
             and outer['complete_bytes_mode_UID_GID_nsmtime_roundtrip'] is True, 'date object manifest schema')
        manifest = outer['members']; receipt = inputs.json(root/'result.json',spec['result_sha256'])
        need(receipt['schema'] == 1 and receipt['status'] == 'COLLECTED_PENDING_INDEPENDENT_KEEPER_AND_FEATURE_REVIEW'
             and receipt['source_sha'] == receipt['UI_method_source'] == SOURCE
             and receipt['archive'] == {'sha256':spec['archive_sha256'],'bytes':len(archive_raw),'members':len(manifest)}
             and receipt['baseline'] == {'archive_sha256':'e007db95293927d330e574efeb4938e52edd2309b520f07895ce0c5fa77b5eb5','reference_only':True,'all37_physical_bytes_equal':True}
             and receipt['observer'] == selection['observer'] and selection['source_sha'] == SOURCE,
             'actual positive date result/source/baseline/observer join')
        need(len(archive_raw) == 4114989 and len(manifest) == 1689
             and set(p.name for p in root.iterdir()) == {'evidence.tar.gz','archive-manifest.json','result.json'},
             'exact immutable three-file actual candidate')
        _, exclusions = unpack(inputs,DATE_KEEPER/'exclusions.json.gz',spec['exclusions_sha256'])
        need(exclusions['observer'] == selection['observer']
             and selection['exclusion_inventory']['sha256'] == spec['exclusions_sha256'], 'original portable exclusion observer')
    else:
        need(spec['archive_sha256'] == 'e007db95293927d330e574efeb4938e52edd2309b520f07895ce0c5fa77b5eb5'
             and spec['manifest_sha256'] == '6720016f22139a372003b81c2d4ce6f2fe2be01ffb04eda4d91c941f23fceead'
             and spec['selection_sha256'] == '8eb2204317187acf5d37c5dafc72e7352a5a5d5a57df2a552500f26007a272a8'
             and spec['result_sha256'] is None and spec['exclusions_sha256'] is None, 'accepted496 canonical keeper')
        manifest = outer; exclusions = None
    need(isinstance(manifest,list) and len({row['member'] for row in manifest}) == len(manifest), 'complete unique member list')
    need(set(spec['reviews']) == {'keeper','feature'}, 'actual keeper AND bounded feature review')
    need(spec['reviews']['keeper'].get('path') != spec['reviews']['feature'].get('path')
         and hex64(spec['reviews']['keeper'].get('sha256')) and hex64(spec['reviews']['feature'].get('sha256'))
         and spec['reviews']['keeper']['sha256'] != spec['reviews']['feature']['sha256'],
         'distinct actual keeper and feature receipt paths AND hashes')
    expected_reviews = ({
        'keeper': (DATE_KEEPER/'independent-keeper-review.json','2d0af9fb0abe7446d63549237be12e18ef4df5a184bcd386abf7c9240d9d365a'),
        'feature': (DATE_KEEPER/'independent-feature-review.json','6611a306c2e9659a492d2abbc2cb507c81f7b45a1bbecfa3c53946bfe65a6444'),
    } if date else {
        'keeper': (OLD_KEEPER/'keeper-review.json','205b60d81c51e277d4c0167fa24b40905e7f60ecd4dac3b0e8cb4a0207dd8427'),
        'feature': (OLD_KEEPER/'acceptance.json','38abd7473228855908d9e4a1e5bd85efccfd0346d27dd3e7a7e1402095fb4c8b'),
    })
    need(all(spec['reviews'][role]['path']==str(path) and spec['reviews'][role]['sha256']==digest
             for role,(path,digest) in expected_reviews.items()), 'exact already accepted keeper and feature receipts')
    source = SOURCE if date else OLD_SOURCE
    for role,review in spec['reviews'].items():
        required = [spec['archive_sha256']] + ([spec['manifest_sha256'],spec['selection_sha256']] if role == 'keeper' else [])
        if date and role == 'keeper': required.append(spec['result_sha256'])
        accepted(inputs,review,required,source)
    index={}; hashes=set(); total=0; selected_seen=False; exclusions_seen=not date
    with tarfile.open(fileobj=io.BytesIO(archive_raw),mode='r:gz') as archive:
        members=archive.getmembers()
        need([m.name for m in members] == [row['member'] for row in manifest], 'entire physical keeper member inventory')
        for member,row in zip(members,manifest):
            literal(member.name)
            need(member.isfile() and member.size == row['bytes'] and member.mode == row['mode']
                 and member.uid == row['uid'] and member.gid == row['gid']
                 and int(Decimal(member.pax_headers['mtime'])*10**9) == row['mtime_ns'], 'original portable metadata unchanged')
            total+=member.size;need(0 <= member.size <= 64<<20 and total <= 256<<20,'bounded full keeper readback')
            body=archive.extractfile(member).read();need(sha(body)==row['sha256'],'every keeper member byte hash')
            if member.name == 'selection.json': need(body==selection_raw,'outer and archived selection exact');selected_seen=True
            if date and member.name == 'excluded-beforeimages.json.gz':
                need(body==inputs.read(DATE_KEEPER/'exclusions.json.gz',spec['exclusions_sha256']),'exact archived exclusion beforeimages');exclusions_seen=True
            index.setdefault(row['original'],[]).append(row);hashes.add(row['sha256'])
    need(selected_seen and exclusions_seen,'required physical custody metadata members')
    if date:
        need({PG_SHA,UI_SHA,'34ccf92bb01861e208f729375e691a9448bb3aad3736dedbe025a4eee586d61c',
              '8eb0240e6ad6244ad18595ad298abd8b781051c471cd7a8a5147c6f29e521c3f',
              '555c309e70d8b1aeedf3a03db231133091a0e863b7c221b72c733417733fbfad'}.issubset(hashes),
             'actual current PG/UI/measurement accepted evidence in custody')
    return {'root':root,'index':index,'hashes':hashes,'selection':selection,'exclusions':exclusions,'snapshot':snapshot(root)}


def keeper_fence(value):
    for row in value['snapshot']:
        now=current(Path(row['path']));need(now==row,'protected keeper directory/bytes/fullstat changed')


def custody_row(row,index):
    wanted=expected_row(row)
    need(any(all(wanted[key]==record[key] for key in PORTABLE) for record in index.get(row['path'],[])),
         'same-view original proof/result/CID/source manifest portable custody')


def source_export(inputs,run,commit,all_rows):
    manifest=inputs.json(run/'source-manifest.json');by={row['path']:row for row in manifest}
    need(len(by)==len(manifest),'unique source manifest')
    files={str(Path(row['path']).relative_to(run/'source')):row for row in all_rows if row['kind']=='file'}
    tree={}
    for item in git('ls-tree','-r','-z',commit).split(b'\0'):
        if item:
            head,name=item.split(b'\t',1);tree[name.decode()]=tuple(head.decode().split())
    need(set(tree)==set(by)==set(files),'complete original Git/source manifest membership')
    git('merge-base','--is-ancestor',commit,SOURCE)
    for name,row in files.items():
        now=compare_snapshot(row);wanted=by[literal(name)]
        need(now['bytes']==wanted['bytes'] and now['sha256']==wanted['sha256']
             and now['mode']==wanted['mode']
             and tree[name]==(('100755' if now['mode'] & 0o111 else '100644'),'blob',now['git_blob']),
             'all source bytes/modes/Gitblob provenance exact')


def roles_and_shutdown(inputs,inventory,old_result,latest_result):
    roles=inventory['owned_roles'];need(len(roles)==45 and len({r['cid'] for r in roles})==len({r['name'] for r in roles})==45,'exact45 owned roles')
    for root in (OLD,FAILED,LATEST):
        own=[r for r in roles if r['run']==str(root)]
        expected={'db',*LANES,*('reference-'+n for n in LANES)}
        need({r['role'] for r in own}==expected and {p.stem for p in root.glob('*.cid')}==expected,'original exact role/CID namespace')
        for row in own:
            need(re.fullmatch('[a-f0-9]{64}',row['cid']) and inputs.read(root/(row['role']+'.cid'),row['CID_file_sha256']).decode().strip()==row['cid'],'owned CID file')
            created=inputs.json(root/'proof'/(row['role']+'-created.json'))
            need(created['id']==row['cid'] and created['name']==row['name']
                 and created['labels']['io.dobolabs.gui.owner'] in row['name'],'recorded original CID/name/owner join')
        cleanup=inputs.json(root/'socket/pg-cleanup.json')
        need(cleanup['stop_exit']==0 and cleanup['status_exit']==3 and cleanup['pid_probe_exit']==1
             and cleanup['pid_and_socket_files_absent']==1 and not list((root/'socket').glob('.s.PGSQL.*')),'private PG shutdown and files')
        value=old_result if root==OLD else latest_result if root==LATEST else None
        if value is not None:
            need(value['method_pass'] is True and value['errors']==[] and set(value['cleanup'])==expected
                 and value['pg_cleanup']==cleanup and set(value['retired_databases'])==LANES
                 and all(v['stopped'] and v['id_absent'] and v['name_absent'] for v in value['cleanup'].values())
                 and all(v['checkpoint_completed'] and v['name_and_oid_absent'] for v in value['retired_databases'].values()),
                 'actual accepted success lifecycle/retirements')
    return {r['cid'] for r in roles},{r['name'].removeprefix('/') for r in roles}


def live_absence(cids,names,targets):
    fmt='{\"id\":{{json .ID}},\"names\":{{json .Names}},\"state\":{{json .State}}}'
    raw=subprocess.check_output(['docker','container','ls','-a','--no-trunc','--format',fmt])
    rows=[json.loads(line) for line in raw.splitlines()]
    for row in rows:
        need(row['id'] not in cids and not (set(row['names'].split(',')) & names),'an original CID/name is still present')
        if row['state']!='running':continue
        mounts=json.loads(subprocess.check_output(['docker','container','inspect',row['id'],'--format','{{json .Mounts}}']))
        for mount in mounts:
            if mount.get('Type')=='bind':
                path=Path(mount['Source'])
                need(not any(path==target or path.is_relative_to(target) or target.is_relative_to(path) for target in targets),
                     'running bind overlaps an exact owned target')
    return {'successful_daemon_inventory':True,'original_CIDs_and_names_absent':len(cids),
            'no_running_bind_overlap':True,'containers_checked':len(rows),'minimal_inventory_sha256':sha(raw)}


def fresh(binding,inputs):
    stamp=binding['issued_unix_ns'];need(type(stamp)is int and 0<=time.time_ns()-stamp<=3600*10**9,'fresh preceding-hour binding')
    nonce=uuid.UUID(binding['execution_nonce']);need(str(nonce)==binding['execution_nonce'] and nonce.version==4,'literal fresh UUID4')
    need(not os.path.lexists(HERE/('used-'+binding['execution_nonce']+'.json')),'one-use execution nonce already consumed')
    reviews=list(binding['retention_reviews'].values())+list(binding['keepers']['date']['reviews'].values())
    if binding['dry_run_review'] is not None:reviews.append(binding['dry_run_review'])
    need(all(stamp>=Path(row['path']).stat().st_mtime_ns for row in reviews),'fresh binding follows actual reviews')
    inputs.fence()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binding',type=Path,required=True)
    parser.add_argument('--receipt',type=Path,required=True)
    parser.add_argument('--execute',action='store_true')
    args=parser.parse_args()
    need(Path(__file__).resolve()==HERE/'retain.py' and args.binding.parent==HERE and args.receipt.parent==HERE
         and args.receipt.resolve()==args.receipt and not os.path.lexists(args.receipt),'fresh literal task-owned binding/receipt')
    result={'schema':1,'status':'REFUSED_BEFORE_DELETION','executed':False,'deleted':[],'removed_directories':[],'logical_bytes_deleted':0}
    inputs=Inputs()
    try:
        binding=inputs.json(args.binding)
        need(binding.get('schema')==1 and binding.get('status')=='BOUND_ACCEPTED_DATE_KEEPER_REVIEWED_EXACT_RETENTION',
             'pending keeper/review binding refuses before bulk verification/deletion')
        need(set(binding)=={'schema','status','source_sha','source_tree','method_sha256','plan_sha256','inventory_sha256','latest_snapshot_sha256',
                            'retention_reviews','keepers','issued_unix_ns','execution_nonce','dry_run_receipt','dry_run_review'},'exact final binding schema')
        need(binding['source_sha']==SOURCE and binding['source_tree']==TREE and binding['plan_sha256']==PLAN_SHA
             and binding['inventory_sha256']==INVENTORY_SHA and binding['latest_snapshot_sha256']==LATEST_SHA,'exact reviewed source/scope/inventories')
        inputs.read(HERE/'retain.py',binding['method_sha256'])
        plan=inputs.json(HERE/'plan.json',PLAN_SHA)
        _,inventory=unpack(inputs,HERE/'inventory.json.gz',INVENTORY_SHA)
        _,latest=unpack(inputs,HERE/'latest-snapshot.json.gz',LATEST_SHA)
        need(plan['source_sha']==SOURCE and plan['source_tree']==TREE and plan['physical_deletion_performed'] is False
             and plan['inventory_sha256']==INVENTORY_SHA and plan['latest_snapshot_sha256']==LATEST_SHA
             and latest['source_sha']==SOURCE and latest['latest_run']==str(LATEST) and latest['latest_UI']==str(CURRENT_UI),'original370b inventory scope')
        observer=host_view(inputs,plan);source_fence()
        need(set(binding['retention_reviews'])=={'root','peer'},'Root AND independent peer source/plan reviews')
        root,peer=binding['retention_reviews']['root'],binding['retention_reviews']['peer']
        need(isinstance(root.get('path'),str) and isinstance(peer.get('path'),str) and Path(root['path'])!=Path(peer['path'])
             and hex64(root.get('sha256')) and hex64(peer.get('sha256')) and root['sha256']!=peer['sha256'],
             'distinct Root/peer PATH AND SHA before accepted calls')
        for ref in (root,peer):
            accepted(inputs,ref,[binding['method_sha256'],PLAN_SHA,INVENTORY_SHA,LATEST_SHA],SOURCE)
        need(set(binding['keepers'])=={'baseline496','date'},'accepted baseline AND successor custody')
        keepers={name:keeper(inputs,spec,name=='date') for name,spec in binding['keepers'].items()}
        fresh(binding,inputs)
        groups=inventory['target_groups']
        need([Path(g['root']) for g in groups]==list(TARGET_DIRS+TARGET_FILES),'literal six roots, no expansion')
        targets=[row for g in groups for row in g['rows'] if row['kind']=='file']
        directories=[row for g in groups for row in g['rows'] if row['kind']=='directory']
        need(len({r['path'] for r in targets})==len(targets)==4464
             and len({r['path'] for r in directories})==len(directories)==487
             and sum(r['bytes'] for r in targets)==703582358==plan['logical_bytes_to_remove'],'exact finite totals')
        for group in groups:
            root=Path(group['root'])
            need({str(p) for p in [root]+sorted(root.rglob('*'))}=={r['path'] for r in group['rows']} if root in TARGET_DIRS
                 else len(group['rows'])==1 and group['rows'][0]['path']==str(root),'complete closed target membership')
            for row in group['rows']:
                path=Path(row['path'])
                need((root in TARGET_DIRS and (path==root or path.is_relative_to(root)) or root in TARGET_FILES and path==root)
                     and row['stat']['st_uid']==os.getuid() and not path.is_relative_to(CANDIDATE)
                     and not path.is_relative_to(CURRENT_UI),'only literal owned targets, never keeper/UI')
                compare_snapshot(row)
        old_result=inputs.json(OLD/'result.json')
        current_result=inputs.json(LATEST/'result.json',PG_SHA)
        need(old_result['source']==OLD_SOURCE and current_result['source']==SOURCE and current_result['tree']==TREE,'actual successful source epochs')
        need(not os.path.lexists(FAILED/'result.json'),'EA9 failure must never gain reconstructed result')
        failed=inputs.json(BASE/'notification-inbox-date-checks/first-full-failure-review.json',
                           'f33df1580a7034a9bf3bdaa7c60f645098fb9759284b48ddb2225954d611b719')
        need(failed['verdict']=='ACCEPT_FAILURE_CAUSE_RAW_SEVEN_SUITE_AND_CLEANUP_AUDIT_ONLY' and failed['findings']==[],'first failure remains distinct')
        for run,commit in ((OLD,OLD_SOURCE),(FAILED,FAILED_SOURCE)):
            source_export(inputs,run,commit,next(g['rows'] for g in groups if g['root']==str(run/'source')))
        latest_source=[r for r in latest['rows'] if r['kind']=='file' and Path(r['path']).is_relative_to(LATEST/'source')]
        source_export(inputs,LATEST,SOURCE,latest_source)
        for record in inventory['binary_provenance']:
            row=next(r for r in targets if r['path']==record['path']);need(record['observed_current_sha256']==row['sha256'],'observed binary beforeimage')
            if Path(record['path']).is_relative_to(FAILED):
                need(record['provenance']=='OBSERVED_POST_FAILURE_BINARY_BYTES_ONLY_NO_EXECUTION_HASH_RECEIPT'
                     and record['original_recorded_sha256'] is record['actual_build_command'] is None,'no fabricated failed execution hash')
            else:
                command=record['actual_build_command']
                name=Path(row['path']).name
                saved=(old_result['reference_bootstrap_binary'] if name=='reference-bootstrap' else
                       old_result['notifications_reference_bootstrap_binary'] if name=='reference-notifications-bootstrap' else
                       old_result['lanes'][name.removesuffix('.test')]['binary'])
                need(record['original_recorded_sha256']==row['sha256'] and command in old_result['commands'] and command['exit']==0
                     and saved['sha256']==row['sha256'] and '-o' in command['argv']
                     and command['argv'][command['argv'].index('-o')+1]==row['path'],'original successful496 build/hash')
                for kind in ('stdout','stderr'):inputs.read(OLD/literal(command[kind]['path']),command[kind]['sha256'])
        for row in latest['rows']:
            path=Path(row['path'])
            if row['kind']!='file' or path.parent!=LATEST/'binaries':continue
            name=path.name
            saved=(current_result['reference_bootstrap_binary'] if name=='reference-bootstrap' else
                   current_result['notifications_reference_bootstrap_binary'] if name=='reference-notifications-bootstrap' else
                   current_result['lanes'][name.removesuffix('.test')]['binary'])
            need(saved['sha256']==row['sha256'],'latest protected binary execution SHA differs')
        already=inventory['already_pruned496_archive']
        prior=inputs.json(OLD_KEEPER/'retention-result.json',already['previous_receipt_sha256'])
        need(already['status']=='NONE_ALREADY_PRUNED_NOT_A_NEW_TARGET' and already['path']==str(OLD/'proof/command-006.stdout')
             and already['original_deleted_row'] in prior['deleted'] and not os.path.lexists(already['path']),'496 archive already pruned, never count twice')
        selection=keepers['date']['selection'];excluded=keepers['date']['exclusions']['exclusions']
        for row in [r for r in targets if Path(r['path']) in TARGET_FILES]:
            matches=[e for e in excluded if e['kind']=='duplicated-full-Git-archive-stdout' and e['path']==row['path']]
            need(len(matches)==1 and matches[0]['bytes']==row['bytes'] and matches[0]['sha256']==row['sha256']
                 and all(matches[0]['stat'][key]==row['stat'][key] for key in matches[0]['stat']),'accepted exact archive exclusion beforeimage')
        for root in (FAILED/'source',FAILED/'binaries'):
            group=next(e for e in excluded if e['path']==str(root));index={r['path']:r for r in group['rows']}
            own=next(g['rows'] for g in groups if g['root']==str(root))
            need(set(index)=={r['path'] for r in own},'all failed generated beforeimages in accepted custody')
            for row in own:
                priorrow=index[row['path']]
                need(all(priorrow['stat'][key]==row['stat'][key] for key in priorrow['stat']),'failed source/binary original stat')
                if row['kind']=='file':need(priorrow['sha256']==row['sha256'] and priorrow['bytes']==row['bytes'],'failed observed byte hash')
                else:need([entry['name'] for entry in priorrow['entries']]==row['entries'],'failed directory original membership custody')
        for row in inventory['preserved_old_and_latest_runs']:
            path=Path(row['path'])
            if row['kind']=='file':
                for run,name in ((OLD,'baseline496'),(FAILED,'date'),(LATEST,'date')):
                    if path.parent in (run,run/'proof'):custody_row(row,keepers[name]['index'])
        inputs.json(CURRENT_UI/'result.json',UI_SHA)
        cids,names=roles_and_shutdown(inputs,inventory,old_result,current_result)
        protect(inventory['preserved_old_and_latest_runs']);protect(latest['UI_rows']);protect(inventory['preserved_old_canonical'])
        for value in keepers.values():keeper_fence(value)
        content=inputs.json(HERE/'archive-content-custody.json',plan['archive_content_custody_sha256'])
        need(content['status']=='HOST_READ_ONLY_EXACT_TWO_ARCHIVE_CONTENT_MATCHES_NOT_RETENTION'
             and {r['path'] for r in content['rows']}=={str(p) for p in TARGET_FILES}
             and all(r['all_member_bytes_modes_match_Git_verified_source_manifest'] for r in content['rows']),'full duplicate member/Git content proof')
        for record in content['rows']:
            original=next(row for row in targets if row['path']==record['path'])
            need(record['observed_archive_sha256']==original['sha256'] and record['archive_bytes']==original['bytes'],
                 'physical member proof bound to exact literal archive bytes')
        if args.execute:
            need(binding['dry_run_receipt'] is not None and binding['dry_run_review'] is not None,'successful reviewed HOST dryrun before execute')
            dry_spec=binding['dry_run_receipt'];dry=inputs.json(Path(dry_spec['path']),dry_spec['sha256'])
            need(Path(dry_spec['path']).parent==HERE and Path(binding['dry_run_review']['path']).parent==HERE,
                 'task-owned dryrun and peer review')
            need(dry['status']=='VERIFIED_NOT_EXECUTED' and dry['executed'] is False and dry['deleted']==[]
                 and all(dry[key]==value for key,value in [('method_sha256',binding['method_sha256']),('plan_sha256',PLAN_SHA),
                     ('inventory_sha256',INVENTORY_SHA),('latest_snapshot_sha256',LATEST_SHA),
                     ('accepted_candidate_sha256',binding['keepers']['date']['archive_sha256'])]),'same exact dryrun method/custody/scope')
            accepted(inputs,binding['dry_run_review'],[dry_spec['sha256'],binding['method_sha256'],PLAN_SHA,INVENTORY_SHA,LATEST_SHA],SOURCE)
        else:need(binding['dry_run_receipt'] is binding['dry_run_review'] is None,'dryrun cannot smuggle stale execution approval')
        source_fence();host_view(inputs,plan);fresh(binding,inputs)
        result.update(status='VERIFIED_NOT_EXECUTED',method_sha256=binding['method_sha256'],plan_sha256=PLAN_SHA,
                      inventory_sha256=INVENTORY_SHA,latest_snapshot_sha256=LATEST_SHA,
                      accepted_candidate_sha256=binding['keepers']['date']['archive_sha256'],
                      source_sha=SOURCE,source_tree=TREE,HOST_observer=observer,
                      target_files=len(targets),target_directories=len(directories),target_logical_bytes=703582358,
                      live_absence=live_absence(cids,names,[Path(r['path']) for r in targets+directories]))
        if args.execute:
            source_fence();host_view(inputs,plan);fresh(binding,inputs)
            result['immediate_live_absence']=live_absence(cids,names,[Path(r['path']) for r in targets+directories])
            marker=HERE/('used-'+binding['execution_nonce']+'.json')
            with marker.open('x') as stream:json.dump({'binding_sha256':sha(inputs.read(args.binding))},stream)
            result.update(executed=True,status='PARTIAL_EXACT_DATE_RETENTION_RETAIN_RECEIPT')
            for row in targets:
                need(0<=time.time_ns()-binding['issued_unix_ns']<=3600*10**9,'binding expired during removal')
                path=Path(row['path']);compare_snapshot(row);parent=parent_fd(path)
                try:
                    same(os.stat(path.name,dir_fd=parent,follow_symlinks=False),expected_row(row))
                    os.unlink(path.name,dir_fd=parent)
                finally:os.close(parent)
                result['deleted'].append({'path':row['path'],'bytes':row['bytes'],'sha256':row['sha256']})
                result['logical_bytes_deleted']+=row['bytes']
            for row in sorted(directories,key=lambda r:(len(Path(r['path']).parts),r['path']),reverse=True):
                path=Path(row['path']);wanted=expected_row(row);now=current(path)
                same(path.lstat(),wanted,directory=True,removing=True);need(not now['entries'],'only empty exact planned directory')
                parent=parent_fd(path)
                try:
                    same(os.stat(path.name,dir_fd=parent,follow_symlinks=False),wanted,directory=True,removing=True)
                    os.rmdir(path.name,dir_fd=parent)
                finally:os.close(parent)
                result['removed_directories'].append(row['path'])
            need(all(not os.path.lexists(row['path']) for row in targets+directories),'all exact targets absent')
            removed={row['path'] for row in targets+directories}
            protect(inventory['preserved_old_and_latest_runs'],removed);protect(latest['UI_rows']);protect(inventory['preserved_old_canonical'])
            for value in keepers.values():keeper_fence(value)
            source_fence();host_view(inputs,plan);inputs.fence()
            result['status']='COMPLETE_EXACT_SOCIAL_DATE_ROLLING_RETENTION'
    except BaseException as error:
        result['error']=type(error).__name__+': '+str(error)
        raise
    finally:
        result['raw_deleted_paths_unavailable']=bool(result['deleted'])
        result['retained_history_semantics']='Only exact superseded496/failedEA9 generated source/binaries and two duplicate Git stdout files may be absent. Latest0afd setup, every historical/current UI/proof/log/source manifest/packet/branch/baseline/canonical keeper/cache remain. FailedEA9 binary execution hashes/command metadata are not reconstructed. Original portable archive ownership remains unchanged in its recorded observer view.'
        with args.receipt.open('x') as stream:json.dump(result,stream,separators=(',',':'));stream.write('\n')
        print(json.dumps({'status':result['status'],'deleted':len(result['deleted']),'directories':len(result['removed_directories']),'logical_bytes_deleted':result['logical_bytes_deleted']}))


if __name__=='__main__':
    import signal
    def interrupted(signum,frame):
        raise RuntimeError('interrupted exact retention; retain partial receipt')
    signal.signal(signal.SIGINT,interrupted);signal.signal(signal.SIGTERM,interrupted)
    main()
