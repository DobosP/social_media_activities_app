from pathlib import Path
from decimal import Decimal
import json,hashlib,tarfile,io,stat
P=Path(__file__).parent
K=P.parent/'notification-inbox-date-keeper'
U=Path('/home/dobo/work/_temp/ni-ui/run-0afd29b79fec-5cec58a3-f1b8-4e1a-b683-d959e6b9ca59')
B=Path('/home/dobo/work/_worktrees/social_media_activities_app/feat__gui-app-migration-a/docs/reviews/gui-native-notification-inbox')
registry={}
def digest(raw):return hashlib.sha256(raw).hexdigest()
def read(p):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and p.resolve()==p and s.st_size<=16*2**20
 raw=p.read_bytes();after=p.lstat()
 def identity(s):return tuple(getattr(s,k) for k in ('st_dev','st_ino','st_mode','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns'))
 assert identity(s)==identity(after)
 row=(identity(s),digest(raw));assert str(p) not in registry or registry[str(p)]==row
 registry[str(p)]=row;return raw
refs_raw=read(K/'baseline-references.json');assert digest(refs_raw)=='e93c0d94f24559277641f59bdd9ff88f499cc716b2140993d463aca303320a9f';refs=json.loads(refs_raw)
arc=read(B/'evidence.tar.gz');assert digest(arc)=='e007db95293927d330e574efeb4938e52edd2309b520f07895ce0c5fa77b5eb5'
mraw=read(B/'archive-manifest.json');assert digest(mraw)=='6720016f22139a372003b81c2d4ce6f2fe2be01ffb04eda4d91c941f23fceead'
manifest_rows=json.loads(mraw);assert isinstance(manifest_rows,list) and len(manifest_rows)==2695
manifest={r['member']:r for r in manifest_rows};assert len(manifest)==2695
raw=read(U/'result.json');assert digest(raw)=='5a3fe1e513fe4ec9b49c3c60327c9e7d2d98be173aa7a041b72b9d683ad34f3e'
report=json.loads(raw);assert report['status']=='PASS' and report['failures']==[] and report['PG_producer_source']==report['UI_method_source']=='0afd29b79fecf69bfb88847a8412d4bb2e02a787'
artifacts={r['path']:r for r in report['artifacts']};rows=[]
with tarfile.open(fileobj=io.BytesIO(arc),mode='r:gz') as archive:
 members=archive.getmembers();assert len(members)==2695 and len({m.name for m in members})==2695
 for old in refs['baseline_body_references']:
  name=old['member'];assert name.startswith('evidence/ui-final/fixtures/') and '..' not in Path(name).parts
  e=archive.getmember(name);m=manifest[name]
  assert e.isfile() and e.size==m['bytes']==old['bytes'] and e.mode==m['mode'] and e.uid==m['uid'] and e.gid==m['gid'] and int(Decimal(e.pax_headers['mtime'])*10**9)==m['mtime_ns']
  before=archive.extractfile(e).read();rel=name.removeprefix('evidence/ui-final/');current=read(U/rel);sha=digest(current)
  assert before==current and digest(before)==old['sha256']==sha and artifacts[rel]['sha256']==sha and artifacts[rel]['bytes']==len(current)
  rows.append(dict(path=rel,baseline_member=name,bytes=len(current),sha256=sha,equal=True))
assert len(rows)==len({r['path'] for r in rows})==37
for p in list(registry):read(Path(p))
proof=dict(schema=1,status='ROOT_ALL37_BODY_BYTES_EQUAL_ACCEPTED496_NO_ADDITIONAL_NORMALIZATION',source_sha=report['PG_producer_source'],UI_method_sha=report['UI_method_source'],UI_result_sha256=digest(raw),comparison_source_sha256=digest(Path(__file__).read_bytes()),baseline_archive_sha256=digest(arc),baseline_reference_sha256=digest(refs_raw),previous_31_from_committed_UI=len(report['previous_body_equality']),current_inbox_6=len([r for r in rows if '/' not in r['path'].removeprefix('fixtures/')]),total=37,all_registered_input_reads_rechecked=True,extra_normalization_applied=False,rows=rows)
with (P/'all37-body-comparison.json').open('x') as f:json.dump(proof,f,indent=2);f.write(chr(10))
print('37bodySHA',digest((P/'all37-body-comparison.json').read_bytes()))
