DATE FOLLOW-UP COMPACT EVIDENCE PLAN ONLY
Source ea9fe7e38032b367d329687c54187f0020349abd; published base cb68b6d.

Reference accepted canonical496/e007 (2,695 members) instead of duplicating its historical tree. baseline-references.json lists accepted custody/feature hashes and37 existing HTML identities. Those are old references, not a new body-comparison result.

Plan retains new complete-PG raw/proof/source-manifest and command/lifecycle/cleanup receipts, new primary UI/measurement/all37 comparison evidence, changed source/preflight/reviews and compact reproduction. Only exact duplicated git-archive stdout and generated source/binary/cache trees are proposed for archive exclusion; retain hashes/commands/manifests and preserve disk bytes until a separate reviewed retention.

New result/count/source-census/selection/review fields remain null until actual completed independent PG/UI/measurement/body reviews. Preserve all new failed/incomplete attempts or refuse. No collector exists or was executed by this proposal; no archive/acceptance/deletion is authorized. A different agent reviews eventual collector/selection and actual keeper. No owning repository changes.

Mixed actual496 regressions remain immutable references. Source call-count reduction is unmeasured; preserve stable resolver availability/outcome/tzdata limitation and report only actual warmed body timing/allocation/output scope.
