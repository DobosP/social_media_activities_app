SOCIAL INBOX PAGE-LOCAL DATE OPTIMIZATION — REBOUND SOURCE PROPOSAL
Valid until source/checkpoint/metadata inputs change; then history.
Basecb68b6d04fb6aac38b16c4e2936559bd0b426f44 is clean and published.
Current496 keeper/feature/retention accepted; old proposal is retained in history-v1.
Preliminary runtime/test reviewdf72 accepted; whole6path final review pending.
No owning application/compiler/tests/PG/browser/benchmark has occurred.

Exactly6 paths: owned notification_inbox_native.go, one NEW pure test and4docs.
Runtime/test images remain exact4f25eda8/e940f3a6 from the preliminary review.
Private per-page zero-value state lazily resolves Europe/Bucharest once, converts
one instant per row and formats "2 Jan 15:04" and RFC3339. Zero loads nothing.
No global state/cache, decoder/parser/auth/order100/href/shell/template/service/
SQL/schema/flags/dependency/gate/method change. Generic djangoDate remains frozen.
All305old Go test files and11helper/template/asset/method witnesses remain exact.

COMPATIBILITY LIMIT
Equivalence requires stable resolver outcome/availability AND tzdata during a
page render. On a persistent load failure each stamp keeps its own original
location/offset. A transient first failure also stays fallback for the rest of
that page; old per-field calls could recover within that page. This intentional
page-local outcome is not unconditional transient-failure parity. A new page
retries; no global success or failure is pinned across requests.

Four NEW pure roots cover helper parity, winter/summer/both DST transitions,
nonUTC offsets/subseconds/rollover/extended year, zero/persistent load failure,
100row once-per-page resolution, next-page retry and16 concurrent pages.
These source tests have been formatted but not compiled or executed.
Root forward/inverse6path roundtrip passes after an initial scratch patch-mode
construction refusal (retained); temporary six-file setup removed after verified
success. Source-image inverse restores the original complete native file.

AFTER FINAL REVIEW
Root applies, focused race/vet/source/docs checks, commits and runs the unchanged
complete affected7 PG protocol; then unchanged6JS6noJS/18strictAxe/31prior bodies,
matched actual-display body samples and independent equality of all6 current
inbox fixture bodies with accepted496 (37total). All old failures/performance
regressions remain history. Source200->1zone loads/500->200formats for100rows is
a hypothesis, not measured improvement or causal timing share. No CPU/HTTP/general
speedup/main/milestone/provider/production/realchild/legal authority claim follows.
