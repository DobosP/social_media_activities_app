from pathlib import Path
import shutil,json,hashlib,subprocess,csv,difflib,os,stat
P=Path(__file__).parent;R=Path('/home/dobo/work/_worktrees/social_media_activities_app/feat__gui-app-migration-a');BASE='cb68b6d04fb6aac38b16c4e2936559bd0b426f44'
assert subprocess.check_output(['git','-C',str(R),'rev-parse','HEAD']).decode().strip()==BASE
assert subprocess.check_output(['git','-C',str(R),'rev-parse','@{upstream}']).decode().strip()==BASE
assert not subprocess.check_output(['git','-C',str(R),'status','--porcelain'])
H=P/'history-v1';
if not H.exists(): H.mkdir()
old_files=[p for p in P.iterdir() if p.is_file() and p.name!='rebind-proposal.py']
if not (H/'source.patch').exists():
 for p in old_files:shutil.copy2(p,H/p.name)
 for name in ('before','files'):shutil.copytree(P/name,H/name)
assert hashlib.sha256((H/'source.patch').read_bytes()).hexdigest()=='0d396ff98f66594a6dad537eb05e810a4cdfd6bee356cbbde938ece295105e0b'
paths=[r['path'] for r in csv.DictReader((P/'manifest.tsv').open(),delimiter='\t')]
meta=[n for n in paths if n.endswith('.md')]
assert len(meta)==4
for n in meta:shutil.copy2(R/n,P/'before'/n)
compat='Equivalence requires stable resolver outcome/availability and tzdata during a page render. A transient first failure stays in per-row source offsets for the rest of that page; the old helper could recover on a later per-field call. The next page retries. This intentional page-local outcome is not unconditional transient-failure parity.'
for n in meta:
 s=(R/n).read_text()
 if n=='STATUS.md':
  a='\nSeparate inbox date optimization (ADR-0065), source proposal after publishedcb68b6d: one lazy page-local Bucharest resolution and fixed paired formats; four NEW pure roots. '+compat+' Existing496 qualification/measurements remain historical; no new runtime or speedup claim.\n'
  point=s.index('\n- **GitHub Actions');s=s[:point]+a+s[point:]
 elif n=='docs/adr/0065-native-notification-inbox.md':
  s+='''

## Page-local date resolution follow-up — source proposal

The current496 feature and compact retention are independently accepted and
published by closingcb68b6d. The original twelve warmed body measurements retain
all elapsed/allocation-byte/HTML regressions. This separate runtime-source change
resolves Europe/Bucharest lazily once per page, converts each timestamp once and
formats the exact fixed display/RFC3339 pair. Generic djangoDate, producer,
self/newest100/mark-all/permissions, timestamp validation, original tests, markup,
assets and qualification methods remain unchanged.

'''+compat+'''

The new four pure test roots cover the frozen helper's output for winter/summer,
DST transitions, offsets/subseconds/rollover/zero, deterministic persistent load
failure, fresh-page retry and independent concurrent pages. Source formatting
and exact text inverses are recorded; compilation/tests/full affected7/UI/Axe,
all31 previous plus6 current inbox body identities and matched measurements
remain to be run on the committed source. Source-level reductions from200 to1
zone loads and500 to200 Format calls at100 rows are hypotheses, not measured
causal shares or performance results. No global cache, original assertion/gate
weakening, main/milestone/production/provider or real-child activation follows.
'''
 elif n=='docs/adr/README.md':
  old='independently feature-qualified exact496 affectedPG7/desktop6+6; compact custody and rolling retention; feature branch only'
  assert s.count(old)==1;s=s.replace(old,old+'; page-local date follow-up source proposal')
 else:
  s+='''

## Page-local date follow-up after publishedcb68b6d

Current496 canonical keeper/feature/retention publication is closed. A private
page-local lazy date formatter and four NEW pure test roots are proposed over
that actual closing source, with generic helper/305oldtests/markup/assets/methods
frozen. '''+compat+'''
No new compiler/runtime/measurement result follows from source formatting.
After independent whole-patch review, Root applies and runs focused unit/vet,
commits exact source, runs unchanged complete affected7, then unchanged desktop/
no-JS/strictAxe/31old bodies and matched actual-display body samples. Independently
compare all6 current inbox fixture bytes with accepted496 as well. Preserve all
existing regressions and failed histories. No activation/authority expansion.
'''
 (P/'files'/n).write_text(s)
# Refresh all five exact preimages; the native runtime beforeimage is unchanged.
for n in paths:
 q=R/n
 if q.exists():shutil.copy2(q,P/'before'/n)
rows=[]
for n in paths:
 b=(P/'before'/n).read_bytes() if (P/'before'/n).exists() else b'';a=(P/'files'/n).read_bytes()
 status='M' if (R/n).exists() else 'A';mode=stat.S_IMODE((R/n).stat().st_mode) if status=='M' else 0o644
 rows.append(dict(status=status,path=n,before_sha256=hashlib.sha256(b).hexdigest() if status=='M' else '-',before_bytes=len(b),after_sha256=hashlib.sha256(a).hexdigest(),after_bytes=len(a),mode=format(mode,'o')))
with (P/'manifest.tsv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t',lineterminator='\n');w.writeheader();w.writerows(rows)
def patch(inverse=False):
 out=[]
 for row in rows:
  n=row['path'];before=P/'before'/n;after=P/'files'/n;b=before.read_text().splitlines(keepends=True) if before.exists() else [];a=after.read_text().splitlines(keepends=True)
  if inverse:a,b=b,a
  out.append('diff --git a/'+n+' b/'+n+'\n')
  if row['status']=='A':out.append(('deleted file mode ' if inverse else 'new file mode ')+('100'+row['mode'].zfill(3))+'\n')
  fromname='a/'+n if not(row['status']=='A' and not inverse) else '/dev/null';toname='b/'+n if not(row['status']=='A' and inverse) else '/dev/null'
  out.extend(difflib.unified_diff(b,a,fromfile=fromname,tofile=toname))
 return ''.join(out)
(P/'source.patch').write_text(patch());(P/'inverse.patch').write_text(patch(True))
subprocess.run(['git','-C',str(R),'apply','--check',str(P/'source.patch')],check=True)
T=P/'roundtrip';T.mkdir()
for row in rows:
 if row['status']=='M':q=T/row['path'];q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(P/'before'/row['path'],q)
subprocess.run(['git','apply',str(P/'source.patch')],cwd=T,check=True)
for row in rows:assert (T/row['path']).read_bytes()==(P/'files'/row['path']).read_bytes()
subprocess.run(['git','apply',str(P/'inverse.patch')],cwd=T,check=True)
for row in rows:assert ((T/row['path']).read_bytes()==(P/'before'/row['path']).read_bytes()) if row['status']=='M' else not (T/row['path']).exists()
shutil.rmtree(T)
(P/'roundtrip-proof.txt').write_text('inverse_modified_beforeimages_exact=5\ninverse_new_test_absent=1\nforward_exact_afterimages=6\nowned_six_file_roundtrip_removed_after_verification=1\n')
for manifest in ('protected-tests.sha256','frozen-display-and-method-witnesses.sha256'):
 for line in (P/manifest).read_text().splitlines():
  digest,name=line.split('  ',1);assert hashlib.sha256((R/name).read_bytes()).hexdigest()==digest
for name in ('README.txt','SEMANTIC_PROOF.txt'):
 s=(P/name).read_text();s=s.replace('stable timezone data during a render','stable resolver outcome/availability and timezone data during a render').replace('stable Bucharest timezone data','stable resolver outcome/availability and Bucharest timezone data');s+='\nFINAL REBIND: base'+BASE+' is clean and published; original496 proposal and preliminary review remain exact in history-v1. Four metadata preimages/afterimages are refreshed without rewriting accepted496 facts. '+compat+' Whole6path independent approval and Root application/actual qualification remain pending.\n';(P/name).write_text(s)
review=H/'independent-preliminary-source-review.json';assert hashlib.sha256(review.read_bytes()).hexdigest()=='df72dd40b604174982076bcf5cb867dbad49d1d50cc1f3384b7212fa538ef10a'
guard=json.loads((P/'APPLY_GUARD.json').read_bytes());guard.update(status='REBOUND_SOURCE_PROPOSAL_PENDING_INDEPENDENT_WHOLE_PATCH_REVIEW',source_base=BASE,required_current_checkpoint_closing_source=BASE,metadata_paths_provisional=[],metadata_paths_rebound=meta,current_feature_published=True,preliminary_source_review_sha256=hashlib.sha256(review.read_bytes()).hexdigest(),explicit_compatibility_limit=compat)
(P/'APPLY_GUARD.json').write_text(json.dumps(guard,indent=2)+'\n')
proof=dict(schema=1,status='EXACT_SIX_PATH_SOURCE_REBOUND_UNAPPLIED',base=BASE,published=True,runtime_source_sha256=next(x['after_sha256'] for x in rows if x['path'].endswith('native.go')),new_test_sha256=next(x['after_sha256'] for x in rows if x['path'].endswith('dates_test.go')),unchanged_runtime_and_test_from_V1=True,protected_old_tests=305,frozen_other_witnesses=11,original_history_files=len(old_files)+11,compatibility=compat,forward_inverse_six_path_roundtrip=True,owning_writes_or_runtime=False)
(P/'rebind-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
names=sorted(str(p.relative_to(P)) for p in (P/'files').rglob('*') if p.is_file())+sorted(p.name for p in P.iterdir() if p.is_file() and p.name not in ('FILEHASHES.sha256','independent-preliminary-source-review.json'))
(P/'FILEHASHES.sha256').write_text(''.join(hashlib.sha256((P/n).read_bytes()).hexdigest()+'  '+n+'\n' for n in names))
print(json.dumps(dict(source_patch=hashlib.sha256((P/'source.patch').read_bytes()).hexdigest(),manifest=hashlib.sha256((P/'manifest.tsv').read_bytes()).hexdigest(),FILEHASHES=hashlib.sha256((P/'FILEHASHES.sha256').read_bytes()).hexdigest(),base=BASE,owning_clean=True)))
