SOCIAL INBOX DATE-ONLY FOLLOWUP — SOURCE PROPOSAL / APPLY BLOCKED
Valid until source/checkpoint/metadata inputs change; then history.
Base496056a6a528d01d544abbf77e18877b60d629bd. No owning writes or product runtime.
CURRENT496 CUSTODY + INDEPENDENT ACCEPTANCE + FEATURE PUBLICATION MUST CLOSE FIRST.
The actual closing source SHA is UNBOUND; all4 metadata beforeimages must be rebound
before root application. This entire proposal is outside current keeper packet roots.
Only compact source assessment8831a542 was saved in the existing current checks packet.

Exactly6 proposed paths: owned notification_inbox_native.go, one NEW pure test file,
append-only ADR0065 note, index/status source-only suffix/notice and plan appendix.
Runtime-source change is only the private typed date formatter plus its per-page
zero-value declaration and replacement of the sole paired djangoDate call.
Original decoder/parse/zero rejection/order100/auth/shell/URL/error/render paths recover
byte-exactly by the3 declared inverse transformations. No producer/service/SQL/schema/
flags/dependencies/authcore/markup/asset/original-test/gate/method changes are proposed.
All305 currently tracked Go test files are hash-bound and unedited;4 new pure roots
are authored. Their existence/syntax is not executed qualification.

SEMANTIC CLAIM TO VERIFY, NOT EXECUTED OUTPUT PROOF
With stable timezone data during a render, one lazy Europe/Bucharest resolution and
one stamp.In per row use exact layouts "2 Jan 15:04" and time.RFC3339.
Frozen j/M/H/i token outputs and c use the same Go formatting semantics:
English month abbreviations evenRO, unpadded day, exact seconds/offset/Z and omitted
fractions. Original generic djangoDate and tests stay byte-exact.
Zero returns empty before any load; parser/zero refusal remains in the existing
caller. Empty/invalidzero pages load0times. A failed load leaves EACH stamp in its
own source location/offset; never UTC/Local/fixed+2 or another row's fallback zone.
A new page starts a new formatter and retries; no global cache or pinned failure.
A timezone database changing between the old per-row calls cannot be reproduced by
one resolution; stable render-time tzdata is the explicit compatibility assumption.

Pure source tests cover frozen-helper parity: winter/summer, both DST transition
boundaries, nonUTC offsets, subsecond omission, day/year rollover and extended typed
year. Deterministic loader failure/zero/100-row once-per-page/new-page retry and16
independent concurrent pages guard state/fallback. There are no env mutations,
sleeps, database/network/benchmark hooks or mutable global test seams.

RETAINED CURRENT EVIDENCE / FUTURE WORK
Current496 native elapsed/allocated-byte/HTML regressions remain honest immutable
history; lower allocation count/gzip is separate. The new source suggests source-level
zone loads200->1 and Format calls500->200 for100rows, not measured speedup/causal share.
No new benchmark or performance result is authored. Future actual comparison must
retain all current and prior body identities, existing nonce-only normalization,
helper/original-source controls and full affected gates under their original caps.
No escaping shortcut/unsafeHTML, new datetime attribute or template engine rewrite.

ACTUAL SOURCE-ONLY CHECKS
Scratch Go formatter parsed/formatted only the2 proposed Go images; no remaining
format output. Exact runtime-source inverse recovers the complete originalbf0efd65.
Forward/inverse/whitespace/hash checks are source observations only. No compiler,
Go test/vet, PG/browser/UI/Axe/body comparison/benchmark or candidate runtime executed.
No new corpus count, actual final pass or improvement is predicted. Independent
review after current custody, actual closing-source/metadata rebind and root apply
remain required. No main/milestone/production/provider/government/realchild or legal,
clinical/privacy authority changes follow from date formatting.
