#!/usr/bin/env python3
"""Root-only post-source-review synthetic controls; never run by source author."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import uuid

HERE = Path('/home/dobo/work/_temp/feat__gui-app-migration-a/social-family/notification-inbox-date-keeper')


def main():
    if Path(__file__).resolve() != HERE / 'run_controls.py':
        raise ValueError('canonical reviewed control source required')
    sha = lambda raw: hashlib.sha256(raw).hexdigest()
    selection = json.loads((HERE / 'prepared-selection.json').read_bytes())
    view = selection['observer']
    if Path('/proc/self/uid_map').read_text() != view['uid_map'] or Path('/proc/self/gid_map').read_text() != view['gid_map']:
        raise ValueError('use the exact preparation observer view')
    with tempfile.TemporaryDirectory(prefix='controls-', dir=HERE) as scratch:
        process = subprocess.run([sys.executable, '-I', str(HERE / 'test_custody_core.py'), '--scratch', scratch,
                                  '--source', str(HERE / 'collect.py')], stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    if process.returncode != 0 or b'Ran 6 tests' not in process.stderr or b'\nOK\n' not in process.stderr:
        raise RuntimeError('synthetic reader controls failed; no collection authorized')
    output = HERE / ('must-not-exist-' + str(uuid.uuid4()))
    refused = subprocess.run([sys.executable, '-I', str(HERE / 'collect.py'), '--binding',
                              str(HERE / 'binding.example.json'), '--output', str(output)],
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    if refused.returncode != 1 or os.path.lexists(output) or b'complete explicit final binding required' not in refused.stderr:
        raise RuntimeError('pending binding did not refuse before output')
    for name, raw in [('controls.stdout', process.stdout), ('controls.stderr', process.stderr),
                      ('pending.stdout', refused.stdout), ('pending.stderr', refused.stderr)]:
        with (HERE / name).open('xb') as stream:
            stream.write(raw)
    value = {'schema': 1, 'status': 'PASS_CUSTODY_CONTROLS_NOT_COLLECTION_ACCEPTANCE',
             'collector_sha256': sha((HERE / 'collect.py').read_bytes()),
             'selection_sha256': sha((HERE / 'prepared-selection.json').read_bytes()),
             'exclusions_sha256': sha((HERE / 'exclusions.json.gz').read_bytes()),
             'observer': view, 'tests_run': 6, 'unit_exit': process.returncode,
             'pending_binding_refused_before_output': True, 'pending_exit': refused.returncode,
             'owned_synthetic_fixtures_removed': True,
             'streams': {name: sha((HERE / name).read_bytes()) for name in ('controls.stdout', 'controls.stderr', 'pending.stdout', 'pending.stderr')},
             'scope': 'Fixed text/metadata source-reader and pending-refusal controls only; no product/service/PG/browser/collection/deletion.'}
    target = HERE / 'controls-result.json'
    with target.open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')
    print(json.dumps({'status': value['status'], 'receipt_sha256': sha(target.read_bytes())}))


if __name__ == '__main__':
    main()
