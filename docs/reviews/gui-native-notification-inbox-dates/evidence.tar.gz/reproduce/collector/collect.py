#!/usr/bin/env python3
"""Final source-bound compact collector; execute only after independent review.

Pending bindings refuse before output. No service/product execution, extraction,
promotion, overwrite or deletion; actual keeper/feature review remains separate.
"""
import argparse
import base64
from collections import Counter
import gzip
from decimal import Decimal
import hashlib
import io
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import tarfile

ROOT = Path('/home/dobo/work/_temp/feat__gui-app-migration-a/social-family')
HERE = ROOT / 'notification-inbox-date-keeper'
REPO = Path('/home/dobo/work/_worktrees/social_media_activities_app/feat__gui-app-migration-a')
UI_ROOT = Path('/home/dobo/work/_temp/ni-ui')
CANDIDATE_SOURCE = '0afd29b79fecf69bfb88847a8412d4bb2e02a787'
QUALIFIED_SOURCE = CANDIDATE_SOURCE
COLLECTION_RELEASED = True
PLAN_SHA = 'a284bd36fe653e61540e6a6457249af2299b5468dae1afd5b4860ead1a5c5264'
BASELINE_REFS_SHA = 'e93c0d94f24559277641f59bdd9ff88f499cc716b2140993d463aca303320a9f'
BASELINE_SHA = 'e007db95293927d330e574efeb4938e52edd2309b520f07895ce0c5fa77b5eb5'
FAILED_RUN = ROOT / 'notification-inbox-date-pg-qa/run-ea9fe7e38032-244baefa-64b7-4ca8-a35a-0f52ffb06ab6'
FAILED_ARCHIVE = FAILED_RUN / 'proof/command-006.stdout'
FAILED_ARCHIVE_BYTES = 70430720
FAILED_ARCHIVE_SHA = 'c3d36a1fd8089a945f8b7f5af4eb4031765abc9eb0a4e13ae53a5eec646676a4'
FAILED_OBSERVATIONS = {
    'first-full-failure-review.json': 'f33df1580a7034a9bf3bdaa7c60f645098fb9759284b48ddb2225954d611b719',
    'first-full-raw-observation.json': '1f342edce73af1a869aa1b5ca9c22c28336fef1982a5e4f37d6be757780638d5',
    'first-full-lifecycle-observation.json': '3c3dbb24043a4c83281f1070d66bf93d2d32c88b097a6d9272f789e9c47c51c5',
    'first-full-live-cleanup-observation.json': '899c3f177ef98b9082bddfa0ee1a23ee69ccfad9d67e8df6f6f1d8989dd66839',
    'first-full-root-failure-observation.json': '810fb9e5904b54f4cc948ac8e6c46d6fd2a9737616450ae11b7713654b6a5cdb',
    'first-full-terminal-output.txt': '88b26668401cf53e5732d3c6ca4d5d4afe04ad5ee1dda52266d16a33c19a301f',
}
STAT_KEYS = ('st_dev', 'st_ino', 'st_mode', 'st_uid', 'st_gid', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
EARLIEST = {}
EARLIEST_LINKS = {}
EARLIEST_DIRS = {}
EARLIEST_REFERENCES = {}
MAX_FILE = 64 << 20
MAX_PAYLOAD = 128 << 20
FORBIDDEN = {'data', 'pg_wal', 'pg_xact', 'cache', 'node_modules', '.git', 'binaries', 'host-tmp', 'test-tmp', '__pycache__'}


def need(ok, message):
    if not ok:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def hex64(value):
    return isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value) is not None


def safe_member(name):
    need(isinstance(name, str) and name and not Path(name).is_absolute() and '..' not in Path(name).parts
         and '\\' not in name and name != '.' and Path(name).as_posix() == name, 'safe canonical relative member required')
    return name


def read(path):
    path = Path(path)
    need(path.is_absolute() and path.resolve() == path, 'canonical unaliased input required')
    before = path.lstat()
    need(stat.S_ISREG(before.st_mode) and 0 <= before.st_size <= MAX_FILE, 'bounded regular nonsymlink input required')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        opened = os.fstat(fd)
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            raw = stream.read(MAX_FILE + 1)
        after = os.fstat(fd)
    finally:
        os.close(fd)
    before_stat = tuple(getattr(before, key) for key in STAT_KEYS)
    need(len(raw) == before.st_size and before_stat == tuple(getattr(opened, key) for key in STAT_KEYS)
         == tuple(getattr(after, key) for key in STAT_KEYS), 'input changed before/during read')
    snapshot = (raw, before_stat)
    need(path not in EARLIEST or EARLIEST[path] == snapshot, 'input differs from earliest bytes/fullstat')
    EARLIEST.setdefault(path, snapshot)
    return raw, before


def bound(path, digest):
    need(hex64(digest), 'explicit SHA-256 required')
    raw, info = read(path)
    need(sha(raw) == digest, 'bound input digest differs')
    return raw, info


def recheck_all():
    # Includes reference-only baseline archive, metadata and independent reviews.
    for path in tuple(EARLIEST):
        read(path)
    for path in tuple(EARLIEST_LINKS):
        read_git_link(path)
    for path in tuple(EARLIEST_DIRS):
        read_directory(path)
    for row in tuple(EARLIEST_REFERENCES.values()):
        reference_check(row)


def read_git_link(path):
    need(path.is_absolute() and path.parent.resolve() == path.parent and path.is_relative_to(REPO),
         'literal internal Git symlink input')
    before = path.lstat(); target = os.readlink(path).encode(); after = path.lstat()
    fingerprint = tuple(getattr(before, key) for key in STAT_KEYS)
    need(stat.S_ISLNK(before.st_mode) and path.resolve().is_relative_to(REPO)
         and fingerprint == tuple(getattr(after, key) for key in STAT_KEYS), 'Git symlink identity changed')
    snapshot = (target, fingerprint)
    need(path not in EARLIEST_LINKS or EARLIEST_LINKS[path] == snapshot, 'Git link differs from earliest bytes/fullstat')
    EARLIEST_LINKS.setdefault(path, snapshot)
    return target, before


def read_directory(path):
    need(path.is_absolute() and (path.is_relative_to(ROOT) or path.is_relative_to(UI_ROOT))
         and path.resolve() == path and not path.is_relative_to(HERE)
         and path not in HERE.parents and not any(part in FORBIDDEN for part in path.parts),
         'literal safe evidence directory; method/output/private trees cannot be censused')
    before = path.lstat()
    need(stat.S_ISDIR(before.st_mode), 'safe directory input required')
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        opened = os.fstat(fd); names = sorted(os.listdir(fd))
        need(len(names) <= 16384, 'bounded safe directory membership required')
        entries = []
        for name in names:
            info = os.stat(name, dir_fd=fd, follow_symlinks=False)
            need(stat.S_ISREG(info.st_mode) or stat.S_ISDIR(info.st_mode), 'safe evidence directory special entry refused')
            entries.append({'name': name, 'kind': 'directory' if stat.S_ISDIR(info.st_mode) else 'file'})
        after = os.fstat(fd)
    finally:
        os.close(fd)
    fingerprint = tuple(getattr(before, key) for key in STAT_KEYS)
    need(fingerprint == tuple(getattr(opened, key) for key in STAT_KEYS)
         == tuple(getattr(after, key) for key in STAT_KEYS), 'directory identity changed during census')
    snapshot = (tuple((row['name'], row['kind']) for row in entries), fingerprint)
    need(path not in EARLIEST_DIRS or EARLIEST_DIRS[path] == snapshot,
         'directory differs from earliest membership/fullstat')
    EARLIEST_DIRS.setdefault(path, snapshot)
    return entries, before


def directory_fence(selection, review_rows):
    rows = selection['directory_censuses']
    by_path = {row['path']: row for row in rows}
    need(rows and len(by_path) == len(rows), 'unique frozen safe directory census required')
    allowed_files = {row['path'] for row in selection['rows'] + review_rows}
    allowed_files |= {row['path'] for row in selection['exclusions']
                      if row['kind'] == 'duplicated-full-Git-archive-stdout'}
    for row in rows:
        need(set(row) == {'path', 'role', 'traversal', 'stat', 'entries'}
             and row['traversal'] in ('shallow', 'complete-safe-tree'), 'exact frozen safe directory row')
        path = Path(row['path']); entries, info = read_directory(path)
        need(row['entries'] == entries and row['stat'] == {key: getattr(info, key) for key in STAT_KEYS},
             'frozen safe directory membership/8stat changed')
        if row['traversal'] == 'complete-safe-tree':
            for entry in entries:
                child = str(path / entry['name'])
                if entry['kind'] == 'directory':
                    need(child in by_path and by_path[child]['traversal'] == 'complete-safe-tree',
                         'complete safe artifact subtree directory missing')
                else:
                    need(child in allowed_files, 'unselected/unreviewed raw artifact file appeared')
    for census in selection['attempt_censuses']:
        parent = census['parent']
        need(parent in by_path and by_path[parent]['role'] == 'attempt-parent', 'parent fullstat census required')
        for entry in census['entries']:
            if entry['kind'] != 'attempt-directory':
                continue
            run = entry['path']; scope = entry['scope']
            need(scope in ('PG', 'UI', 'baseline-reference-UI') and run in by_path, 'recorded PG/UI run fullstat census required')
            if scope == 'PG':
                need(by_path[run]['role'] == 'attempt-root', 'PG run-root identity census required')
                need(all(str(Path(run) / item['name']) in allowed_files for item in by_path[run]['entries']
                         if item['kind'] == 'file'), 'all run-root CID/source-manifest/result files required')
                for name, role in (('proof', 'safe-proof'), ('socket', 'safe-socket')):
                    child = str(Path(run) / name)
                    need(child in by_path and by_path[child]['role'] == role
                         and by_path[child]['traversal'] == 'complete-safe-tree', 'complete proof/socket census required')
            elif scope == 'UI':
                need(by_path[run]['role'] == 'UI-root' and by_path[run]['traversal'] == 'complete-safe-tree',
                     'complete physical UI directory tree census required')
            else:
                need(Path(run).name in ('run-3e536f9e1c88-47e36b1f-f828-4a54-b775-de876c32e07f',
                                       'run-496056a6a528-7da60674-4319-40ce-9231-b40dad1d3e39')
                     and by_path[run]['role'] == 'baseline-reference-UI', 'exact old canonical UI namespace reference only')


def observer_fence(view):
    need(set(view) == {'label', 'uid_map', 'gid_map'} and isinstance(view['label'], str) and view['label'],
         'one explicitly chosen observer view required')
    # These fixed proc metadata files are not payloads/ordinary st_size files.
    need(Path('/proc/self/uid_map').read_text() == view['uid_map']
         and Path('/proc/self/gid_map').read_text() == view['gid_map'], 'observer UID/GID mapping changed')


def selected(row):
    need(set(row) == {'path', 'member', 'bytes', 'sha256', 'stat', 'role'}, 'exact frozen selection row')
    path = Path(row['path']); safe_member(row['member'])
    need(path.is_relative_to(ROOT) or path.is_relative_to(REPO) or path.is_relative_to(UI_ROOT),
         'explicit owned source/evidence input')
    need(not any(part in FORBIDDEN for part in path.parts) and path != FAILED_ARCHIVE,
         'private state/generated tree/opaque archive cannot be payload')
    need(path != REPO / 'docs/reviews/gui-native-notification-inbox/evidence.tar.gz',
         'canonical496 baseline archive remains reference-only')
    raw, info = bound(path, row['sha256'])
    need(len(raw) == row['bytes'] and row['stat'] == {key: getattr(info, key) for key in STAT_KEYS},
         'exact source observer bytes/fullstat required; no ownership normalization')
    return raw, info


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args], env={'PATH': os.defpath, 'LANG': 'C.UTF-8'})


def git_blob(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()


def git_objects(source):
    return {row.split(b'\t', 1)[1].decode(): row.split(b'\t', 1)[0].split()[2].decode()
            for row in git('ls-tree', '-r', '-z', source).split(b'\0') if row}


def source_fence(frame):
    need(QUALIFIED_SOURCE == CANDIDATE_SOURCE and git('rev-parse', 'HEAD').decode().strip() == QUALIFIED_SOURCE
         and not git('status', '--porcelain'), 'exact independently qualified clean source required')
    objects = git_objects(QUALIFIED_SOURCE); names = list(objects)
    need({row['path'] for row in frame} == set(names) and len(frame) == len(names), 'complete Git source frame required')
    for row in frame:
        name = safe_member(row['path']); path = REPO / name
        if row['kind'] == 'file':
            raw, info = bound(path, row['sha256'])
            need(len(raw) == row['bytes'] and git_blob(raw) == objects[name]
                 and row['stat'] == {key: getattr(info, key) for key in STAT_KEYS}, 'qualified current/Git file bytes/fullstat differ')
        else:
            need(row['kind'] == 'symlink', 'known Git file kind required')
            target, info = read_git_link(path)
            need(git_blob(target) == objects[name] and sha(target) == row['sha256']
                 and row['stat'] == {key: getattr(info, key) for key in STAT_KEYS}, 'exact internal Git symlink/fullstat required')


def failed_attempt_skeleton(selection):
    need(not os.path.lexists(FAILED_RUN / 'result.json'), 'EA9 failed result must stay absent; never reconstruct')
    for name, digest in FAILED_OBSERVATIONS.items():
        bound(ROOT / 'notification-inbox-date-checks' / name, digest)
    failure = json.loads(bound(ROOT / 'notification-inbox-date-checks/first-full-failure-review.json',
                               FAILED_OBSERVATIONS['first-full-failure-review.json'])[0])
    need(failure['overall_status'] == 'FAILED_EXIT1_NO_RESULT_JSON_NO_COMPLETE_QUALIFICATION_ACCEPTANCE'
         and failure['accepted_complete_qualification'] is False and failure['missing_result_reconstructed'] is False,
         'only failure/source/native/lifecycle audit is admitted')
    # Actual final freezing must close all EA9 root/proof/CID/raw/source-manifest
    # files and exact exclusion metadata/source-Git joins. Lost in-memory command
    # timestamps/argv/records are declared LOST, not reconstructed from source.
    need(selection['failed_EA9']['command_metadata'] == 'LOST_NOT_RECONSTRUCTED'
         and selection['failed_EA9']['raw_archive_exclusion']['path'] == str(FAILED_ARCHIVE)
         and selection['failed_EA9']['raw_archive_exclusion']['bytes'] == FAILED_ARCHIVE_BYTES
         and selection['failed_EA9']['raw_archive_exclusion']['sha256'] == FAILED_ARCHIVE_SHA,
         'literal opaque failure archive exclusion only')


def baseline_and_37(selection):
    refs = json.loads(bound(HERE / 'baseline-references.json', BASELINE_REFS_SHA)[0])
    base = Path(refs['canonical_root'])
    raw = bound(base / 'evidence.tar.gz', BASELINE_SHA)[0]
    manifest = json.loads(bound(base / 'archive-manifest.json', refs['reference_metadata']['archive-manifest.json'])[0])
    for name, digest in refs['reference_metadata'].items():
        bound(base / safe_member(name), digest)
    need(len(manifest) == refs['archive']['members'] == 2695, 'immutable baseline2695 member census')
    body_refs = {row['member']: row for row in refs['baseline_body_references']}
    comparisons = selection['all37_body_rows']
    need(len(body_refs) == len(comparisons) == 37 and {row['baseline_member'] for row in comparisons} == set(body_refs),
         'closed31prior+6inbox identity comparison required')
    by_member = {row['baseline_member']: row for row in comparisons}
    visited = set()
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as archive:
        entries = archive.getmembers()
        need([entry.name for entry in entries] == [row['member'] for row in manifest], 'baseline complete physical member inventory')
        for entry, row in zip(entries, manifest):
            safe_member(entry.name)
            need(entry.isfile() and entry.size == row['bytes'] and entry.mode == row['mode']
                 and entry.uid == row['uid'] and entry.gid == row['gid']
                 and int(Decimal(entry.pax_headers['mtime']) * 10 ** 9) == row['mtime_ns'], 'immutable baseline PAX metadata')
            old = archive.extractfile(entry).read()
            need(sha(old) == row['sha256'], 'immutable baseline member bytes differ')
            if entry.name in body_refs:
                visited.add(entry.name)
                ref = body_refs[entry.name]; comparison = by_member[entry.name]
                current = bound(Path(comparison['new_path']), comparison['new_sha256'])[0]
                need(len(old) == ref['bytes'] and sha(old) == ref['sha256'] and current == old
                     and comparison['exact_bytes_equal'] is True, 'physical original37 body equality required')
    need(visited == set(body_refs), 'every closed physical37 baseline identity visited')
    # Never stat old manifest['original'] paths: prior retention removed some.


def exact_attempts(censuses):
    for census in censuses:
        parent = Path(census['parent'])
        need(parent.is_absolute() and parent.resolve() == parent and parent.is_dir() and not parent.is_symlink(),
             'literal canonical attempt namespace')
        actual = sorted(parent.iterdir())
        need([str(path) for path in actual] == [row['path'] for row in census['entries']],
             'unknown complete/incomplete/non-run/symlink attempt entry')
        for path, row in zip(actual, census['entries']):
            need(not path.is_symlink() and path.resolve() == path, 'attempt alias/symlink refused')
            if row['kind'] == 'attempt-directory':
                need(path.is_dir() and path.name.startswith('run-'), 'literal recorded attempt directory')
            else:
                need(row['kind'] == 'owned-runner-lock' and path.name == 'runner.lock', 'unreviewed nondirectory attempt entry')
                raw, info = bound(path, row['sha256'])
                need(len(raw) == row['bytes'] and row['stat'] == {key: getattr(info, key) for key in STAT_KEYS},
                     'literal runner lock bytes/fullstat')
    # Do not census mutable source/review packet directories. Source rows are
    # finite hash/stat-bound; final review refs are a separate exact list.


PG_CURRENT = ROOT / 'notification-inbox-date-pg-qa/run-0afd29b79fec-0d124589-48a8-45be-a6b7-b93476bc129c'
UI_CURRENT = UI_ROOT / 'run-0afd29b79fec-5cec58a3-f1b8-4e1a-b683-d959e6b9ca59'
PG_RESULT_SHA = '1ba8e2499b7fe93b979e835c0e3d7533f731b08581d2e40a9b0519f780d8a647'
UI_RESULT_SHA = '5a3fe1e513fe4ec9b49c3c60327c9e7d2d98be173aa7a041b72b9d683ad34f3e'
BENCH_SHA = '5546b541c6f9d02d572ea2fe194e9a8e10669d28a2ede73a7c90294512863dde'
REVIEW_DIGESTS = {'final-full-pg-review.json': '34ccf92bb01861e208f729375e691a9448bb3aad3736dedbe025a4eee586d61c',
                  'final-ui-review.json': '8eb0240e6ad6244ad18595ad298abd8b781051c471cd7a8a5147c6f29e521c3f',
                  'measurement-review.json': '555c309e70d8b1aeedf3a03db231133091a0e863b7c221b72c733417733fbfad'}
EXCLUDED_ROOTS = tuple(run / name for run in (FAILED_RUN, PG_CURRENT)
                       for name in ('source', 'binaries', 'host-tmp', 'test-tmp'))


def reference_check(row):
    path = Path(row['path'])
    archive = path in (FAILED_ARCHIVE, PG_CURRENT / 'proof/command-006.stdout')
    need(archive or any(path.is_relative_to(root) for root in EXCLUDED_ROOTS), 'literal excluded reference scope')
    need(path.is_absolute() and path.parent.resolve() == path.parent, 'canonical excluded reference parent')
    before = path.lstat(); need(row['stat'] == {key: getattr(before, key) for key in STAT_KEYS}, 'reference fullstat changed')
    result = None
    if row['kind'] == 'directory':
        need(stat.S_ISDIR(before.st_mode) and not path.is_symlink(), 'reference directory type')
        entries = [{'name': child.name, 'kind': 'directory' if child.is_dir() else 'file'} for child in sorted(path.iterdir())]
        need(entries == row['entries'], 'excluded directory membership changed')
    else:
        need(row['kind'] == 'file' and stat.S_ISREG(before.st_mode) and path.resolve() == path
             and before.st_size == row['bytes'] <= (80 << 20 if archive else 512 << 20), 'bounded literal reference file')
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
        digest = hashlib.sha256(); blob = hashlib.sha1(b'blob ' + str(before.st_size).encode() + b'\0'); size = 0
        try:
            need(tuple(getattr(os.fstat(fd), key) for key in STAT_KEYS) == tuple(row['stat'][key] for key in STAT_KEYS), 'reference swapped before read')
            while True:
                block = os.read(fd, 1 << 20)
                if not block:
                    break
                digest.update(block); blob.update(block); size += len(block)
            need(tuple(getattr(os.fstat(fd), key) for key in STAT_KEYS) == tuple(row['stat'][key] for key in STAT_KEYS), 'reference changed during read')
        finally:
            os.close(fd)
        need(size == row['bytes'] and digest.hexdigest() == row['sha256'], 'reference hash/size changed')
        result = blob.hexdigest()
    need(row['stat'] == {key: getattr(path.lstat(), key) for key in STAT_KEYS}, 'reference metadata changed')
    need(path not in EARLIEST_REFERENCES or EARLIEST_REFERENCES[path] == row, 'reference differs from earliest record')
    EARLIEST_REFERENCES.setdefault(path, row)
    return result


def check_exclusions(selection, pg):
    descriptor = selection['exclusion_inventory']
    compressed = bound(Path(descriptor['path']), descriptor['sha256'])[0]
    with gzip.GzipFile(fileobj=io.BytesIO(compressed)) as stream:
        raw = stream.read((32 << 20) + 1)
    need(len(raw) == descriptor['decoded_bytes'] <= 32 << 20 and sha(raw) == descriptor['decoded_sha256'], 'bounded exact exclusion beforeimages')
    saved = json.loads(raw); need(saved['observer'] == selection['observer'], 'one exclusion observer view')
    need([{key: value for key, value in row.items() if key != 'rows'} for row in saved['exclusions']] == selection['exclusions'], 'exact frozen exclusion descriptors')
    need(len(saved['exclusions']) == 10 and len({row['path'] for row in saved['exclusions']}) == 10, 'exact2archive+8generated tree exclusions')
    need({row['path'] for row in saved['exclusions']} == {str(path) for path in EXCLUDED_ROOTS}
         | {str(FAILED_ARCHIVE), str(PG_CURRENT / 'proof/command-006.stdout')}, 'literal complete exclusion set')
    need(sum(item['bytes'] for row in saved['exclusions'] for item in row.get('rows', []) if item['kind'] == 'file') < 4 << 30, 'bounded generated-reference aggregate')
    for exclusion in saved['exclusions']:
        path = Path(exclusion['path'])
        expected_source = 'ea9fe7e38032b367d329687c54187f0020349abd' if exclusion['run'] == str(FAILED_RUN) else QUALIFIED_SOURCE
        need(exclusion['run'] in (str(FAILED_RUN), str(PG_CURRENT)) and exclusion['source_sha'] == expected_source,
             'exact failed/current source epochs for every exclusion')
        if exclusion['kind'] == 'duplicated-full-Git-archive-stdout':
            if path == FAILED_ARCHIVE:
                need(exclusion['bytes'] == FAILED_ARCHIVE_BYTES and exclusion['sha256'] == FAILED_ARCHIVE_SHA
                     and exclusion['actual_command_index'] is None and 'LOST_NOT_RECONSTRUCTED' in exclusion['command_provenance'],
                     'failed opaque archive is a reference, lost execution metadata is not reconstructed')
            else:
                matches = [(i, row) for i, row in enumerate(pg['commands']) if row['argv'] ==
                           ['git', '-C', str(REPO), 'archive', '--format=tar.gz', QUALIFIED_SOURCE]]
                need(len(matches) == 1 and exclusion['actual_command_index'] == matches[0][0]
                     and path == PG_CURRENT / matches[0][1]['stdout']['path']
                     and exclusion['bytes'] == matches[0][1]['stdout']['bytes']
                     and exclusion['sha256'] == matches[0][1]['stdout']['sha256'], 'unique actual archive command/stream exclusion join')
            reference_check({**{key: exclusion[key] for key in ('path', 'bytes', 'sha256', 'stat')}, 'kind': 'file'})
            continue
        need(path in EXCLUDED_ROOTS and exclusion['run'] == str(path.parent), 'literal generated tree only')
        rows = exclusion['rows']; need(len({row['path'] for row in rows}) == len(rows), 'unique generated beforeimages')
        need({str(item) for item in [path] + sorted(path.rglob('*'))} == {row['path'] for row in rows}, 'complete generated tree membership changed')
        objects = git_objects(exclusion['source_sha']) if path.name == 'source' else None
        manifest = json.loads(read(path.parent / 'source-manifest.json')[0]) if objects else None
        files = {}
        for row in rows:
            need(Path(row['path']).is_relative_to(path) and row['kind'] in ('file', 'directory'), 'finite regular generated beforeimage')
            blob = reference_check(row)
            if row['kind'] == 'file':
                relative = Path(row['path']).relative_to(path).as_posix(); files[relative] = row
                if objects:
                    need(relative in objects and blob == objects[relative], 'entire generated source/Git blob join')
        if objects:
            need(set(files) == set(objects) == {row['path'] for row in manifest}, 'entire clean Git/source manifest identity')
            for row in manifest:
                saved_row = files[row['path']]
                need(saved_row['bytes'] == row['bytes'] and saved_row['sha256'] == row['sha256']
                     and stat.S_IMODE(saved_row['stat']['st_mode']) == row['mode'], 'source manifest bytes/mode join')
        elif path.name == 'binaries':
            need(set(files) == {name + '.test' for name in pg['lanes']} | {'reference-bootstrap', 'reference-notifications-bootstrap'}, 'exact9 generated binary identities')
            if path.parent == PG_CURRENT:
                expected = {name + '.test': value['binary']['sha256'] for name, value in pg['lanes'].items()}
                expected.update({'reference-bootstrap': pg['reference_bootstrap_binary']['sha256'],
                                 'reference-notifications-bootstrap': pg['notifications_reference_bootstrap_binary']['sha256']})
                need(all(files[name]['sha256'] == digest for name, digest in expected.items()), 'actual qualifier post-build/post-native binary hash joins')
            else:
                need('Observed after failed run only' in exclusion['binary_hash_provenance'], 'failed binaries are postfailure observations only')
        else:
            need(not files, 'runtime temporary trees must be empty of files')


def strings(value):
    if isinstance(value, str):
        return {value}
    if isinstance(value, dict):
        return set().union(*(strings(item) for item in value.values()), set())
    if isinstance(value, list):
        return set().union(*(strings(item) for item in value), set())
    return set()


def actual_semantics(binding, selection):
    need(selection['source_sha'] == QUALIFIED_SOURCE and selection['observer'] == binding['observer'], 'actual source/one observer selection')
    rows = selection['rows']; need(len({row['path'] for row in rows}) == len(rows)
         and len({row['member'] for row in rows}) == len(rows), 'unique physical selected inputs and members')
    need(selection['counts']['selected_files'] == len(rows)
         and selection['counts']['selected_logical_bytes'] == sum(row['bytes'] for row in rows), 'actual selected counts/bytes')
    for row in rows:
        selected(row)
    pg = json.loads(bound(PG_CURRENT / 'result.json', PG_RESULT_SHA)[0])
    need(pg['source'] == QUALIFIED_SOURCE and pg['method_pass'] is True and not pg['errors']
         and len(pg['commands']) == 340 and len(pg['artifact_rows']) == 695 and len(pg['method_inputs']) == 8
         and set(pg['lanes']) == {'web', 'app', 'accounts', 'recommendations', 'social', 'messaging', 'notifications'}
         and sum(row['tests']['top_level'] for row in pg['lanes'].values()) == 450
         and sum(row['tests']['named_passes'] for row in pg['lanes'].values()) == 1353, 'exact independently accepted full7 result')
    need(all(row['state'] == 'PASS' and row['tests']['fail'] == row['tests']['skip'] == 0 for row in pg['lanes'].values())
         and len(pg['retired_databases']) == 7 and len(pg['cleanup']) == 15
         and all(row['stopped'] and row['id_absent'] and row['name_absent'] for row in pg['cleanup'].values())
         and all(row['checkpoint_completed'] and row['name_and_oid_absent'] for row in pg['retired_databases'].values())
         and pg['pg_cleanup']['stop_exit'] == 0 and pg['pg_cleanup']['status_exit'] == 3
         and pg['pg_cleanup']['pid_and_socket_files_absent'] == 1, 'complete actual lane retirement/15role/privatePG cleanup')
    expected_argv = ['git', '-C', str(REPO), 'archive', '--format=tar.gz', QUALIFIED_SOURCE]
    archives = [command for command in pg['commands'] if command['argv'] == expected_argv]
    need(len(archives) == 1 and archives[0]['exit'] == 0 and pg['git_archive']['format'] == 'tar.gz'
         and archives[0]['stdout']['sha256'] == pg['git_archive']['sha256'] == '48b74396f6c2fe01d907fdfca30ebcba29fba6f6a01949fb9126b5ffe3cff820'
         and archives[0]['stdout']['bytes'] == pg['git_archive']['bytes'] == 41496094, 'actual entire-SHA compressed command identity')
    for command in pg['commands']:
        need(isinstance(command['argv'], list) and type(command['exit']) is int and command['seconds'] >= 0
             and command['timeout'] > 0, 'complete original command metadata')
        for kind in ('stdout', 'stderr'):
            stream = command[kind]; path = PG_CURRENT / safe_member(stream['path'])
            if path == PG_CURRENT / 'proof/command-006.stdout':
                continue
            need(len(bound(path, stream['sha256'])[0]) == stream['bytes'], 'actual command stream bytes')
    for row in pg['artifact_rows']:
        path = PG_CURRENT / safe_member(row['path'])
        if path != PG_CURRENT / 'proof/command-006.stdout':
            need(len(bound(path, row['sha256'])[0]) == row['bytes'], 'complete nonduplicate raw proof bytes')
    for row in pg['method_inputs']:
        need(len(bound(REPO / safe_member(row['path']), row['sha256'])[0]) == row['bytes'], 'all8 actual method roles source-bound')
    check_exclusions(selection, pg)
    ui = json.loads(bound(UI_CURRENT / 'result.json', UI_RESULT_SHA)[0])
    need(ui['status'] == 'PASS' and not ui['failures'] and ui['PG_producer_source'] == ui['UI_method_source'] == QUALIFIED_SOURCE
         and ui['git_after'] == {'head': QUALIFIED_SOURCE, 'porcelain_empty': True}
         and len(ui['artifacts']) == 73 and len(ui['commands']) == 4
         and all(row['exit_code'] == 0 and row['timed_out'] is False for row in ui['commands'])
         and ui['owned_temp']['removed'] is True and not os.path.lexists(ui['owned_temp']['path']), 'actual source-bound UI/4waitedchildren/temp cleanup')
    physical = {path.relative_to(UI_CURRENT).as_posix() for path in UI_CURRENT.rglob('*') if path.is_file()}
    need(physical == {row['path'] for row in ui['artifacts']} | {'result.json', 'status.json'}, 'all75 physical current UI files')
    for row in ui['artifacts']:
        need(len(bound(UI_CURRENT / safe_member(row['path']), row['sha256'])[0]) == row['bytes'], 'all physical UI artifact bytes')
    desktop = json.loads(bound(UI_CURRENT / 'desktop/desktop-results.json', ui['desktop_report_sha256'])[0])
    need(desktop['status'] == 'pass' and not desktop['failures'] and desktop['sourceUnchanged'] is True
         and desktop['sourcesBefore'] == desktop['sourcesAfter'] and len(desktop['states']) == len(desktop['noJavaScriptStates']) == 6
         and desktop['ownership']['serverStopped'] and len(desktop['ownership']['profiles']) == 2
         and all(row['closed'] and row['removed'] and not os.path.lexists(row['path']) for row in desktop['ownership']['profiles']), 'actual6+6/safe source/browser cleanup')
    audits = [row for state in desktop['states'] for row in state['audits']]
    need(len(audits) == 18 and all(not row['axe']['violations'] and not row['axe']['incomplete'] for row in audits)
         and len(desktop['requests']) == 78 and len(desktop['assetResponses']) == 66
         and all(row['method'] == 'GET' for row in desktop['requests'])
         and all(not desktop[name] for name in ('requestFailures', 'pageErrors', 'consoleErrors', 'cspConsole', 'webSockets')), 'strict18Axe/78GET/66assets/noerror streams')
    capture = json.loads(bound(UI_CURRENT / 'capture.json', ui['capture_sha256'])[0])
    projection = base64.b64decode(capture['projection_base64'], validate=True)
    need(capture['source_sha'] == capture['ui_method_source'] == QUALIFIED_SOURCE and capture['result_sha256'] == PG_RESULT_SHA
         and sha(projection) == capture['projection_sha256'] == '672d58c74b44a1426e80a705ee7ba6e97842f5578aea1b96cb483ee8056543d0', 'exact same-forwarded-GET current/old display input')
    value = json.loads(projection)
    need(set(value) == {'capture', 'schema', 'variants'} and [row['language'] for row in value['variants']] == ['en', 'ro'], 'closed bilingual display envelope')
    for variant in value['variants']:
        need(set(variant) == {'language', 'projection'} and set(variant['projection']) == {'items'}
             and len(variant['projection']['items']) == 100
             and all(set(row) == {'title', 'body', 'why', 'url', 'created_at', 'read_at'} for row in variant['projection']['items']), 'six-key display-only whitelist')
    raw = bound(UI_CURRENT / 'benchmark.stdout', BENCH_SHA)[0]; text = raw.decode()
    lines = [line for line in text.splitlines() if line.startswith('BenchmarkSocialNotificationInboxBodyRender/')]
    bench = re.findall(r'^(BenchmarkSocialNotificationInboxBodyRender/\S+)\s+([0-9]+)\s+(.+)$', text, re.M)
    need(len(lines) == len(bench) == 12 and all(count == '100' for _, count, _ in bench)
         and Counter(re.sub(r'-[0-9]+$', '', name) for name, _, _ in bench)
         == Counter({'BenchmarkSocialNotificationInboxBodyRender/' + language + '/' + engine: 3
                     for language in ('en', 'ro') for engine in ('classic', 'native')}), 'complete actual12sample inventory')
    for _, _, metrics in bench:
        parts = metrics.split(); need(len(parts) == 10 and Counter(parts[1::2]) == Counter(['ns/op', 'B/op', 'allocs/op', 'html-B/op', 'gzip9-B/op'])
                                     and all(re.fullmatch(r'[0-9]+(?:\.[0-9]+)?', part) for part in parts[::2]), 'complete finite benchmark units')
    for name, digest in REVIEW_DIGESTS.items():
        review = json.loads(bound(ROOT / 'notification-inbox-date-checks' / name, digest)[0])
        need(review['source_sha'] == QUALIFIED_SOURCE and review['verdict'].startswith('ACCEPT_') and review['findings'] == [], 'exact independent actual accepted review')
    need(sha(read(ROOT / 'notification-inbox-date-checks/all37-body-comparison.json')[0])
         == '93af2b7b6249880e78b2d43823cdadb9aecefb73390a9957cf8c5d5879a7d218', 'actual independent-reviewed all37 comparison')
    return {'PG': {'roots': 450, 'named': 1353, 'lanes': 7, 'commands': 340, 'proof_artifacts': 695, 'source_rows': 2230, 'roles': 15, 'retired_databases': 7},
            'UI': {'states': 6, 'noJS': 6, 'audits': 18, 'physical_files': 75, 'previous_bodies': 31, 'all_body_comparisons': 37},
            'measurement': {'rows': 12, 'scope': 'Matched display-body only; current elapsed/allocated bytes lower, HTML larger, no causal CPU/HTTP/general speed claim.'}}


def write_payload(output, payload):
    need(not os.path.lexists(output) and output.parent == HERE and output.is_absolute()
         and output.resolve() == output and HERE.resolve() == HERE and HERE.stat().st_uid == os.getuid(),
         'exclusive fresh direct-child owned output')
    need(all(len(row[0]) <= MAX_FILE for row in payload.values()) and sum(len(row[0]) for row in payload.values()) <= MAX_PAYLOAD, 'bounded compact payload')
    output.mkdir(mode=0o700)
    archive_path = output / 'evidence.tar.gz'; manifest = []
    with tarfile.open(archive_path, mode='x:gz', format=tarfile.PAX_FORMAT) as archive:
        for member, (raw, info, path) in sorted(payload.items()):
            safe_member(member)
            entry = tarfile.TarInfo(member); entry.size = len(raw); entry.mode = stat.S_IMODE(info.st_mode)
            entry.uid = info.st_uid; entry.gid = info.st_gid; entry.mtime = info.st_mtime_ns // 10 ** 9
            entry.pax_headers = {'mtime': str(entry.mtime) + '.' + str(info.st_mtime_ns % 10 ** 9).zfill(9)}
            archive.addfile(entry, io.BytesIO(raw))
            manifest.append({'member': member, 'original': str(path), 'bytes': len(raw), 'sha256': sha(raw),
                             'mode': entry.mode, 'uid': entry.uid, 'gid': entry.gid, 'mtime_ns': info.st_mtime_ns})
    with tarfile.open(archive_path, mode='r:gz') as archive:
        entries = archive.getmembers()
        need([entry.name for entry in entries] == [row['member'] for row in manifest], 'complete archive member readback')
        for entry, row in zip(entries, manifest):
            need(entry.isfile() and entry.size == row['bytes'] and entry.mode == row['mode']
                 and entry.uid == row['uid'] and entry.gid == row['gid']
                 and int(Decimal(entry.pax_headers['mtime']) * 10 ** 9) == row['mtime_ns']
                 and sha(archive.extractfile(entry).read()) == row['sha256'], 'payload bytes/full portable metadata readback')
    return archive_path, manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binding', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    need(Path(__file__).resolve() == HERE / 'collect.py' and args.binding.parent == HERE,
         'canonical reviewed collector and literal binding required')
    binding = json.loads(read(args.binding)[0])
    # First pending refusal precedes selection/controls/reviews and all output.
    need(binding.get('schema') == 1 and binding.get('status') == 'BOUND_FINAL_INDEPENDENT_EVIDENCE',
         'complete explicit final binding required')
    need(COLLECTION_RELEASED and QUALIFIED_SOURCE == binding['source_sha'] == CANDIDATE_SOURCE,
         'exact independently qualified source release required')
    bound(HERE / 'collect.py', binding['collector_sha256'])
    bound(HERE / 'plan.json', PLAN_SHA)
    selection_raw = bound(HERE / 'prepared-selection.json', binding['selection_sha256'])[0]
    selection = json.loads(selection_raw)
    need(selection['exclusion_inventory']['sha256'] == binding['exclusions_sha256'], 'exact exclusion inventory binding')
    observer_fence(binding['observer'])
    review_spec = binding['collector_review']
    review_path = Path(review_spec['path'])
    need(review_path.parent == HERE and review_path != args.binding, 'separate task-owned independent collector review')
    review = json.loads(bound(review_path, review_spec['sha256'])[0])
    field = review_spec['field']; expected = review_spec['expected']
    need(field in ('verdict', 'status') and isinstance(expected, str) and expected.startswith('ACCEPT')
         and review.get(field) == expected and review.get('findings') == []
         and all(value in strings(review) for value in (QUALIFIED_SOURCE, binding['collector_sha256'],
             binding['selection_sha256'], binding['exclusions_sha256'])), 'actual independent final source/selection review required')
    controls = json.loads(bound(HERE / 'controls-result.json', binding['controls_sha256'])[0])
    need(controls['status'] == 'PASS_CUSTODY_CONTROLS_NOT_COLLECTION_ACCEPTANCE'
         and controls['collector_sha256'] == binding['collector_sha256']
         and controls['selection_sha256'] == binding['selection_sha256']
         and controls['exclusions_sha256'] == binding['exclusions_sha256']
         and controls['observer'] == binding['observer'] and controls['tests_run'] == 6 and controls['unit_exit'] == 0
         and controls['pending_binding_refused_before_output'] is True and controls['pending_exit'] == 1
         and controls['owned_synthetic_fixtures_removed'] is True, 'actual same-view custody controls required')
    for name, digest in controls['streams'].items():
        need(name in ('controls.stdout', 'controls.stderr', 'pending.stdout', 'pending.stderr'), 'exact control stream')
        bound(HERE / name, digest)
    counts = actual_semantics(binding, selection)
    foreign = [{'path': row['path'], 'role': row['role'], 'sha256': row['sha256'], 'stat': row['stat']}
               for row in selection['rows'] if row['stat']['st_uid'] != os.getuid()]
    allowed_foreign = {str(run / 'socket' / name) for run in (FAILED_RUN, PG_CURRENT) for name in ('ready.json', 'pg-cleanup.json')}
    need(foreign == selection['foreign_owned_payload_rows']
         and {row['path'] for row in foreign} <= allowed_foreign
         and all(row['role'] in ('exact-reviewed-PG-ready', 'exact-reviewed-PG-pg-cleanup') for row in foreign),
         'only exact already-reviewed foreign PG metadata paths/roles; no ownership normalization')
    source_fence(selection['source_frame']); exact_attempts(selection['attempt_censuses'])
    directory_fence(selection, [])
    failed_attempt_skeleton(selection); baseline_and_37(selection)
    payload = {}; physical = set()
    def add(path, member, digest=None):
        path = Path(path); safe_member(member)
        need(member not in payload and str(path) not in physical, 'unique physical input/member, select each once')
        raw, info = bound(path, digest) if digest else read(path)
        need(len(raw) <= MAX_FILE, 'bounded payload member')
        payload[member] = (raw, info, path); physical.add(str(path))
    for row in selection['rows']:
        selected(row); add(row['path'], row['member'], row['sha256'])
    for name, row in selection['collector_source_files'].items():
        need(Path(row['path']) == HERE / safe_member(name), 'literal final collector reproduction source')
        raw, info = bound(HERE / name, row['sha256'])
        need(len(raw) == row['bytes'] and row['stat'] == {key: getattr(info, key) for key in STAT_KEYS}, 'collector source earliest observer metadata')
        add(HERE / name, 'reproduce/collector/' + name, row['sha256'])
    for path, member, digest in ((HERE / 'prepared-selection.json', 'selection.json', binding['selection_sha256']),
             (HERE / 'exclusions.json.gz', 'excluded-beforeimages.json.gz', binding['exclusions_sha256']),
             (args.binding, 'reproduce/collector/final-binding.json', None),
             (review_path, 'evidence/collector-review.json', review_spec['sha256']),
             (HERE / 'controls-result.json', 'evidence/collector-controls/result.json', binding['controls_sha256']),
             (HERE / 'SOURCE_PROOF.final.json', 'reproduce/collector/SOURCE_PROOF.final.json', binding['source_proof_sha256'])):
        add(path, member, digest)
    for name, digest in controls['streams'].items():
        add(HERE / name, 'evidence/collector-controls/' + name, digest)
    need(sum(len(row[0]) for row in payload.values()) <= MAX_PAYLOAD and len(payload) <= 4096, 'bounded aggregate payload/member count')
    source_fence(selection['source_frame']); exact_attempts(selection['attempt_censuses'])
    directory_fence(selection, []); check_exclusions(selection, json.loads(read(PG_CURRENT / 'result.json')[0]))
    observer_fence(binding['observer']); recheck_all()
    archive, manifest = write_payload(args.output, payload)
    source_fence(selection['source_frame']); exact_attempts(selection['attempt_censuses'])
    directory_fence(selection, []); check_exclusions(selection, json.loads(read(PG_CURRENT / 'result.json')[0]))
    observer_fence(binding['observer']); recheck_all()
    need(archive.stat().st_size <= MAX_PAYLOAD, 'bounded compressed output')
    digest = hashlib.sha256()
    with archive.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            digest.update(block)
    archive_sha = digest.hexdigest()
    def write(name, value):
        with (args.output / name).open('x') as stream:
            stream.write(json.dumps(value, indent=2) + '\n')
    write('archive-manifest.json', {'archive_sha256': archive_sha,
          'complete_bytes_mode_UID_GID_nsmtime_roundtrip': True, 'members': manifest})
    write('result.json', {'schema': 1, 'status': 'COLLECTED_PENDING_INDEPENDENT_KEEPER_AND_FEATURE_REVIEW',
          'source_sha': QUALIFIED_SOURCE, 'UI_method_source': QUALIFIED_SOURCE, 'observer': binding['observer'],
          'actuals': counts, 'archive': {'sha256': archive_sha, 'bytes': archive.stat().st_size, 'members': len(manifest)},
          'baseline': {'archive_sha256': BASELINE_SHA, 'reference_only': True, 'all37_physical_bytes_equal': True},
          'history': 'EA9 all7native PASS but overallFAILexit1/noresult; LOST command metadata not reconstructed; first binary hashes only observed postfailure.',
          'exclusions': 'Literal duplicate Git stdout and generated source/bin/emptytmp beforeimages retained as metadata; raw bytes not copied or deleted.',
          'limits': ['No full21/current-image/main/milestone/production/provider/government/real-child activation.',
                     'Matched body elapsed/allocated bytes lower; HTML larger; no causal CPU/HTTP/general speedup claim.',
                     'No deletion or acceptance by collector. Independent actual keeper and bounded feature reviews remain required.']})
    print(json.dumps({'output': str(args.output), 'archive_sha256': archive_sha, 'members': len(manifest),
                      'result_sha256': sha(read(args.output / 'result.json')[0])}))


if __name__ == '__main__':
    main()
