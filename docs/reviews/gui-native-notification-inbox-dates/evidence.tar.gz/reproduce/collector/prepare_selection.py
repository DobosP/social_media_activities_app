#!/usr/bin/env python3
"""Read-only metadata/hash preparation; never imports/runs collector or services."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess

ROOT = Path('/home/dobo/work/_temp/feat__gui-app-migration-a/social-family')
HERE = ROOT / 'notification-inbox-date-keeper'
REPO = Path('/home/dobo/work/_worktrees/social_media_activities_app/feat__gui-app-migration-a')
SOURCE = '0afd29b79fecf69bfb88847a8412d4bb2e02a787'
PG_PARENT = ROOT / 'notification-inbox-date-pg-qa'
RUNS = [PG_PARENT / 'run-ea9fe7e38032-244baefa-64b7-4ca8-a35a-0f52ffb06ab6',
        PG_PARENT / 'run-0afd29b79fec-0d124589-48a8-45be-a6b7-b93476bc129c']
UI_PARENT = Path('/home/dobo/work/_temp/ni-ui')
UI = UI_PARENT / 'run-0afd29b79fec-5cec58a3-f1b8-4e1a-b683-d959e6b9ca59'
KEYS = ('st_dev', 'st_ino', 'st_mode', 'st_uid', 'st_gid', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
BAD = {'data', 'pg_wal', 'pg_xact', 'cache', 'node_modules', '.git', '__pycache__'}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def fingerprint(info):
    return {key: getattr(info, key) for key in KEYS}


def file_row(path, maximum=64 << 20):
    assert path.is_absolute() and path.resolve() == path
    before = path.lstat(); assert stat.S_ISREG(before.st_mode) and before.st_size <= maximum
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    digest = hashlib.sha256(); size = 0
    try:
        assert fingerprint(os.fstat(fd)) == fingerprint(before)
        while True:
            block = os.read(fd, 1 << 20)
            if not block:
                break
            size += len(block); digest.update(block)
        assert fingerprint(os.fstat(fd)) == fingerprint(before)
    finally:
        os.close(fd)
    assert size == before.st_size
    return {'path': str(path), 'bytes': size, 'sha256': digest.hexdigest(), 'stat': fingerprint(before)}


def directory_row(path, role, traversal):
    assert path.resolve() == path and path.is_dir() and not path.is_symlink()
    before = path.lstat(); entries = []
    for child in sorted(path.iterdir()):
        info = child.lstat(); assert stat.S_ISDIR(info.st_mode) or stat.S_ISREG(info.st_mode)
        entries.append({'name': child.name, 'kind': 'directory' if stat.S_ISDIR(info.st_mode) else 'file'})
    assert fingerprint(path.lstat()) == fingerprint(before)
    return {'path': str(path), 'role': role, 'traversal': traversal, 'stat': fingerprint(before), 'entries': entries}


def tree_rows(root):
    rows = []
    for path in [root] + sorted(root.rglob('*')):
        info = path.lstat(); assert not any(part in BAD for part in path.parts)
        if stat.S_ISDIR(info.st_mode):
            row = directory_row(path, 'excluded-generated-directory', 'shallow'); row['kind'] = 'directory'
        elif stat.S_ISREG(info.st_mode):
            row = file_row(path, 512 << 20); row['kind'] = 'file'
        else:
            assert stat.S_ISLNK(info.st_mode) and path.resolve().is_relative_to(root)
            raw = os.readlink(path).encode(); row = {'path': str(path), 'kind': 'symlink', 'bytes': len(raw),
                                                    'sha256': sha(raw), 'target': raw.decode(), 'stat': fingerprint(info)}
        rows.append(row)
    return rows


def main():
    git = lambda *a: subprocess.check_output(['git', '-C', str(REPO), *a])
    assert git('rev-parse', 'HEAD').decode().strip() == SOURCE and not git('status', '--porcelain')
    observer = {'label': 'functions.exec default sandbox observer; Root collection/live review must use this same view',
                'uid_map': Path('/proc/self/uid_map').read_text(), 'gid_map': Path('/proc/self/gid_map').read_text()}
    rows = {}; directories = {}; exclusions = []
    def add(path, member, role):
        assert not any(part in BAD for part in path.parts)
        row = file_row(path); row.update(member=member, role=role)
        if str(path) in rows:
            assert rows[str(path)]['sha256'] == row['sha256']
            return
        assert member not in {saved['member'] for saved in rows.values()}
        rows[str(path)] = row
    def safe_tree(root, prefix, role):
        for path in [root] + sorted(root.rglob('*')):
            assert not any(part in BAD for part in path.parts) and not path.is_symlink()
            if path.is_dir():
                directories[str(path)] = directory_row(path, role, 'complete-safe-tree')
            else:
                assert path.is_file()
                add(path, prefix + '/' + path.relative_to(root).as_posix(), role)
    for index, run in enumerate(RUNS):
        label = 'failed-EA9' if index == 0 else 'actual-0afd'
        source = 'ea9fe7e38032b367d329687c54187f0020349abd' if index == 0 else SOURCE
        archive_index = None
        if index == 1:
            result = json.loads((run / 'result.json').read_bytes())
            matching = [i for i, command in enumerate(result['commands']) if command['argv'] ==
                        ['git', '-C', str(REPO), 'archive', '--format=tar.gz', SOURCE]]
            assert len(matching) == 1; archive_index = matching[0]
        directories[str(run)] = directory_row(run, 'attempt-root', 'shallow')
        for path in sorted(run.iterdir()):
            if path.is_file():
                add(path, 'evidence/PG/' + label + '/' + path.name, label)
        for path in sorted((run / 'proof').iterdir()):
            assert path.is_file() and not path.is_symlink()
            if path.name == 'command-006.stdout':
                reference = file_row(path, 80 << 20)
                exclusions.append({'kind': 'duplicated-full-Git-archive-stdout', **reference, 'source_sha': source,
                                   'command_provenance': 'LOST_NOT_RECONSTRUCTED; exact opaque source identity fromf33d/810f' if index == 0
                                   else 'actual command located by full argv; exact entire clean-SHA archive transport',
                                   'actual_command_index': archive_index, 'run': str(run)})
            else:
                add(path, 'evidence/PG/' + label + '/proof/' + path.name, label)
        for name, role in [('proof', 'safe-proof'), ('socket', 'safe-socket')]:
            directories[str(run / name)] = directory_row(run / name, role, 'complete-safe-tree')
            if name == 'socket':
                assert {path.name for path in (run / name).iterdir()} == {'ready.json', 'pg-cleanup.json', 'stop-request'}
                for path in sorted((run / name).iterdir()):
                    add(path, 'evidence/PG/' + label + '/socket/' + path.name, 'exact-reviewed-PG-' + path.stem)
        for name in ('source', 'binaries', 'host-tmp', 'test-tmp'):
            path = run / name; beforeimage = tree_rows(path)
            if name in ('host-tmp', 'test-tmp'):
                assert not any(row['kind'] == 'file' for row in beforeimage)
            exclusions.append({'kind': 'generated-source-tree' if name == 'source' else
                               'generated-binaries' if name == 'binaries' else 'empty-runtime-temporary-tree',
                               'path': str(path), 'source_sha': source, 'run': str(run), 'rows': beforeimage,
                               'binary_hash_provenance': 'Observed after failed run only; no missing execution hash/times reconstructed' if index == 0
                               else 'Join actual result lane/bootstrap binary SHA records; no execution repeated'})
    safe_tree(UI, 'evidence/UI-current', 'UI-root')
    checks = ROOT / 'notification-inbox-date-checks'
    safe_tree(checks, 'evidence/checks', 'review-and-raw-checks')
    for name in ('next-social-notification-inbox-date-optimization', 'notification-inbox-date-assertion-repair', 'next-social-date-archive-repair'):
        safe_tree(ROOT / name, 'reproduce/source-history/' + name, 'source-history')
    for name in ('history-core-v1', 'history-core-v2'):
        # Own method root is intentionally not a directory census. Exact source
        # history rows are hash/fullstat-bound, future controls/reviews live here.
        for path in sorted((HERE / name).iterdir()):
            assert path.is_file() and not path.is_symlink()
            add(path, 'reproduce/collector-history/' + name + '/' + path.name, 'collector-history')
    for name in ('plan.json', 'proposed-selection.json', 'baseline-references.json', 'README.txt'):
        add(HERE / name, 'reproduce/original-plan/' + name, 'original-plan')
    add(HERE / 'excluded-provenance-review-plan.json', 'evidence/excluded-provenance-review-plan.json', 'independent-provenance-plan')
    current = json.loads((RUNS[1] / 'result.json').read_bytes())
    u = json.loads((UI / 'result.json').read_bytes())
    methods = {row['path'] for row in current['method_inputs']} | {row['path'] for row in u['committed_method']}
    methods |= {'tools/gui-native-notification-inbox/test_qualify_pg_archive.py',
                'services/server/internal/web/notification_inbox_native.go',
                'services/server/internal/web/notification_inbox_dates_test.go'}
    for name in sorted(methods):
        add(REPO / name, 'reproduce/current/' + name, 'current-source-method')
    frame = []
    for entry in git('ls-tree', '-r', '-z', SOURCE).split(b'\0'):
        if not entry:
            continue
        header, name = entry.split(b'\t', 1); mode, kind, oid = header.decode().split(); name = name.decode(); path = REPO / name
        if mode == '120000':
            info = path.lstat(); raw = os.readlink(path).encode()
            row = {'path': name, 'kind': 'symlink', 'bytes': len(raw), 'sha256': sha(raw), 'stat': fingerprint(info), 'git_blob': oid}
        else:
            row = file_row(path); row.update(path=name, kind='file', git_blob=oid)
        frame.append(row)
    # Parent namespaces include known old canonical UI references, never copied.
    attempts = []
    for parent in (PG_PARENT, UI_PARENT):
        entries = []
        directories[str(parent)] = directory_row(parent, 'attempt-parent', 'shallow')
        for path in sorted(parent.iterdir()):
            if path.name == 'runner.lock':
                row = file_row(path); row['kind'] = 'owned-runner-lock'; entries.append(row)
            else:
                assert path.is_dir() and not path.is_symlink() and path.name.startswith('run-')
                scope = 'PG' if path in RUNS else 'UI' if path == UI else 'baseline-reference-UI'
                assert scope != 'PG' or path in RUNS
                if scope == 'baseline-reference-UI':
                    assert path.name in ('run-3e536f9e1c88-47e36b1f-f828-4a54-b775-de876c32e07f',
                                         'run-496056a6a528-7da60674-4319-40ce-9231-b40dad1d3e39')
                    directories[str(path)] = directory_row(path, 'baseline-reference-UI', 'shallow')
                entries.append({'path': str(path), 'kind': 'attempt-directory', 'scope': scope})
        attempts.append({'parent': str(parent), 'entries': entries})
    comparison = json.loads((checks / 'all37-body-comparison.json').read_bytes())
    bodies = [{'baseline_member': row['baseline_member'], 'new_path': str(UI / row['path']), 'new_sha256': row['sha256'],
               'new_bytes': row['bytes'], 'exact_bytes_equal': row['equal']} for row in comparison['rows']]
    packed = (json.dumps({'schema': 1, 'observer': observer, 'exclusions': exclusions}, separators=(',', ':')) + '\n').encode()
    compressed = gzip.compress(packed, mtime=0); (HERE / 'exclusions.json.gz').write_bytes(compressed)
    selection = {'schema': 1, 'status': 'FROZEN_SOURCE_PROPOSAL_PENDING_INDEPENDENT_COLLECTOR_REVIEW',
                 'source_sha': SOURCE, 'observer': observer, 'source_frame': frame, 'rows': list(rows.values()),
                 'directory_censuses': list(directories.values()), 'attempt_censuses': attempts,
                 'exclusions': [{key: value for key, value in row.items() if key != 'rows'} for row in exclusions],
                 'exclusion_inventory': {'path': str(HERE / 'exclusions.json.gz'), 'sha256': sha(compressed),
                                         'decoded_bytes': len(packed), 'decoded_sha256': sha(packed)},
                 'all37_body_rows': bodies, 'failed_EA9': {'command_metadata': 'LOST_NOT_RECONSTRUCTED',
                     'raw_archive_exclusion': next(row for row in exclusions if row['path'] == str(RUNS[0] / 'proof/command-006.stdout'))},
                 'counts': {'selected_files': len(rows), 'selected_logical_bytes': sum(row['bytes'] for row in rows.values()),
                            'source_frame': len(frame), 'directory_censuses': len(directories), 'exclusions': len(exclusions)}}
    selection['collector_source_files'] = {name: file_row(HERE / name) for name in
                                            ('collect.py', 'prepare_selection.py', 'test_custody_core.py', 'run_controls.py', 'README.md', 'CONTROL_PLAN.md')}
    selection['foreign_owned_payload_rows'] = [{'path': row['path'], 'role': row['role'], 'sha256': row['sha256'], 'stat': row['stat']}
                                               for row in rows.values() if row['stat']['st_uid'] != os.getuid()]
    (HERE / 'prepared-selection.json').write_text(json.dumps(selection, indent=2) + '\n')
    print(json.dumps({'source_preparation_only': True, **selection['counts'], 'exclusion_inventory_bytes': len(compressed),
                      'selected_UIDs': sorted({row['stat']['st_uid'] for row in rows.values()}), 'collector_import_or_execution': False}))


if __name__ == '__main__':
    main()
