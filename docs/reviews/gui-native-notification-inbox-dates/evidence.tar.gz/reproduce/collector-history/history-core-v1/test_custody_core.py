#!/usr/bin/env python3
"""Unexecuted pure fixed-text controls for the disabled skeleton's reader."""
import argparse
import ast
import hashlib
import os
from pathlib import Path
import stat
import tempfile
import unittest

SCRATCH = None
SOURCE = None


def reader_namespace():
    tree = ast.parse(SOURCE.read_bytes(), filename=str(SOURCE))
    names = {'need', 'sha', 'read', 'read_git_link', 'recheck_all', 'safe_member'}
    functions = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in names]
    if len(functions) != len(names):
        raise ValueError('exact reviewed pure helper functions required')
    namespace = {'Path': Path, 'os': os, 'stat': stat, 'hashlib': hashlib,
                 'EARLIEST': {}, 'EARLIEST_LINKS': {}, 'MAX_FILE': 64 << 20,
                 'STAT_KEYS': ('st_dev', 'st_ino', 'st_mode', 'st_uid', 'st_gid', 'st_size', 'st_mtime_ns', 'st_ctime_ns')}
    exec(compile(ast.Module(body=functions, type_ignores=[]), str(SOURCE), 'exec'), namespace)
    return tree, namespace


class CustodyReaderControls(unittest.TestCase):
    def setUp(self):
        if SCRATCH is None or SOURCE is None:
            raise RuntimeError('explicit owned scratch and reviewed source required')

    def test_skeleton_literal_and_actual_binding_remain_disabled(self):
        tree, _ = reader_namespace()
        values = {node.targets[0].id: node.value.value for node in tree.body
                  if isinstance(node, ast.Assign) and len(node.targets) == 1
                  and isinstance(node.targets[0], ast.Name) and isinstance(node.value, ast.Constant)}
        self.assertIs(values['COLLECTION_RELEASED'], False)
        self.assertIsNone(values['QUALIFIED_SOURCE'])

    def test_earliest_stable_then_changed_bytes_refuse(self):
        _, ns = reader_namespace()
        with tempfile.TemporaryDirectory(dir=SCRATCH) as root:
            path = Path(root) / 'fixed.txt'; path.write_bytes(b'fixed control one')
            self.assertEqual(ns['read'](path)[0], b'fixed control one')
            ns['read'](path)
            path.write_bytes(b'fixed control two')
            with self.assertRaises(ValueError):
                ns['read'](path)

    def test_fullstat_changes_and_inode_replacement_refuse(self):
        for kind in ('mode', 'mtime', 'inode'):
            with self.subTest(kind=kind), tempfile.TemporaryDirectory(dir=SCRATCH) as root:
                _, ns = reader_namespace(); path = Path(root) / 'fixed.txt'; path.write_bytes(b'fixed control')
                ns['read'](path); before = path.stat()
                if kind == 'mode':
                    path.chmod(stat.S_IMODE(before.st_mode) ^ 0o100)
                elif kind == 'mtime':
                    os.utime(path, ns=(before.st_atime_ns, before.st_mtime_ns + 1000000))
                else:
                    replacement = Path(root) / 'replacement.txt'; replacement.write_bytes(path.read_bytes())
                    replacement.chmod(stat.S_IMODE(before.st_mode))
                    os.utime(replacement, ns=(before.st_atime_ns, before.st_mtime_ns)); replacement.replace(path)
                with self.assertRaises(ValueError):
                    ns['read'](path)

    def test_reference_only_input_is_rechecked_without_payload(self):
        _, ns = reader_namespace()
        with tempfile.TemporaryDirectory(dir=SCRATCH) as root:
            path = Path(root) / 'fixed-reference.txt'; path.write_bytes(b'fixed reference')
            ns['read'](path); ns['recheck_all']()
            # No payload/add call exists in this control: it is reference-only.
            path.write_bytes(b'changed fixture')
            with self.assertRaises(ValueError):
                ns['recheck_all']()

    def test_cap_alias_and_unsafe_member_refuse(self):
        _, ns = reader_namespace()
        with tempfile.TemporaryDirectory(dir=SCRATCH) as root:
            path = Path(root) / 'fixed.txt'; path.write_bytes(b'x' * 17); ns['MAX_FILE'] = 16
            with self.assertRaises(ValueError):
                ns['read'](path)
            alias = Path(root) / 'alias.txt'; alias.symlink_to(path)
            with self.assertRaises(ValueError):
                ns['read'](alias)
            with self.assertRaises(ValueError):
                ns['safe_member']('../outside')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--scratch', type=Path, required=True)
    parser.add_argument('--source', type=Path, default=Path(__file__).with_name('collect.py'))
    args = parser.parse_args(); SCRATCH, SOURCE = args.scratch, args.source
    if (not SCRATCH.is_absolute() or SCRATCH.resolve() != SCRATCH or not SCRATCH.is_dir()
            or SCRATCH.stat().st_uid != os.getuid() or '/_temp/' not in str(SCRATCH) + '/'):
        raise ValueError('explicit existing canonical owned scratch required')
    if not SOURCE.is_absolute() or SOURCE.resolve() != SOURCE or not SOURCE.is_file():
        raise ValueError('canonical reviewed skeleton source required')
    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(CustodyReaderControls))
    raise SystemExit(0 if result.wasSuccessful() else 1)
