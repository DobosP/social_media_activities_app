#!/usr/bin/env python3
"""Disabled source skeleton. Final actual admissions/selection need new review.

No product/service command, extraction, promotion, overwrite or deletion.
Neither an in-progress run nor a source-only proposal unlocks collection.
"""
import argparse
from decimal import Decimal
import hashlib
import io
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import tarfile

ROOT = Path('/home/dobo/work/_temp/feat__gui-app-migration-a/social-family')
HERE = ROOT / 'notification-inbox-date-keeper'
REPO = Path('/home/dobo/work/_worktrees/social_media_activities_app/feat__gui-app-migration-a')
CANDIDATE_SOURCE = '0afd29b79fecf69bfb88847a8412d4bb2e02a787'
QUALIFIED_SOURCE = None
COLLECTION_RELEASED = False
PLAN_SHA = 'a284bd36fe653e61540e6a6457249af2299b5468dae1afd5b4860ead1a5c5264'
BASELINE_REFS_SHA = 'e93c0d94f24559277641f59bdd9ff88f499cc716b2140993d463aca303320a9f'
BASELINE_SHA = 'e007db95293927d330e574efeb4938e52edd2309b520f07895ce0c5fa77b5eb5'
FAILED_RUN = ROOT / 'notification-inbox-date-pg-qa/run-ea9fe7e38032-244baefa-64b7-4ca8-a35a-0f52ffb06ab6'
FAILED_ARCHIVE = FAILED_RUN / 'proof/command-006.stdout'
FAILED_ARCHIVE_BYTES = 70430720
FAILED_ARCHIVE_SHA = 'c3d36a1fd8089a945f8b7f5af4eb4031765abc9eb0a4e13ae53a5eec646676a4'
FAILED_OBSERVATIONS = {
    'first-full-failure-review.json': 'f33df1580a7034a9bf3bdaa7c60f645098fb9759284b48ddb2225954d611b719',
    'first-full-raw-observation.json': '1f342edce73af1a869aa1b5ca9c22c28336fef1982a5e4f37d6be757780638d5',
    'first-full-lifecycle-observation.json': '3c3dbb24043a4c83281f1070d66bf93d2d32c88b097a6d9272f789e9c47c51c5',
    'first-full-live-cleanup-observation.json': '899c3f177ef98b9082bddfa0ee1a23ee69ccfad9d67e8df6f6f1d8989dd66839',
    'first-full-root-failure-observation.json': '810fb9e5904b54f4cc948ac8e6c46d6fd2a9737616450ae11b7713654b6a5cdb',
    'first-full-terminal-output.txt': '88b26668401cf53e5732d3c6ca4d5d4afe04ad5ee1dda52266d16a33c19a301f',
}
STAT_KEYS = ('st_dev', 'st_ino', 'st_mode', 'st_uid', 'st_gid', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
EARLIEST = {}
EARLIEST_LINKS = {}
MAX_FILE = 64 << 20
MAX_PAYLOAD = 128 << 20
FORBIDDEN = {'data', 'pg_wal', 'pg_xact', 'cache', 'node_modules', '.git', 'binaries', 'host-tmp', 'test-tmp', '__pycache__'}


def need(ok, message):
    if not ok:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def hex64(value):
    return isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value) is not None


def safe_member(name):
    need(isinstance(name, str) and name and not Path(name).is_absolute() and '..' not in Path(name).parts
         and '\\' not in name and name != '.' and Path(name).as_posix() == name, 'safe canonical relative member required')
    return name


def read(path):
    path = Path(path)
    need(path.is_absolute() and path.resolve() == path, 'canonical unaliased input required')
    before = path.lstat()
    need(stat.S_ISREG(before.st_mode) and 0 <= before.st_size <= MAX_FILE, 'bounded regular nonsymlink input required')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        opened = os.fstat(fd)
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            raw = stream.read(MAX_FILE + 1)
        after = os.fstat(fd)
    finally:
        os.close(fd)
    before_stat = tuple(getattr(before, key) for key in STAT_KEYS)
    need(len(raw) == before.st_size and before_stat == tuple(getattr(opened, key) for key in STAT_KEYS)
         == tuple(getattr(after, key) for key in STAT_KEYS), 'input changed before/during read')
    snapshot = (raw, before_stat)
    need(path not in EARLIEST or EARLIEST[path] == snapshot, 'input differs from earliest bytes/fullstat')
    EARLIEST.setdefault(path, snapshot)
    return raw, before


def bound(path, digest):
    need(hex64(digest), 'explicit SHA-256 required')
    raw, info = read(path)
    need(sha(raw) == digest, 'bound input digest differs')
    return raw, info


def recheck_all():
    # Includes reference-only baseline archive, metadata and independent reviews.
    for path in tuple(EARLIEST):
        read(path)
    for path in tuple(EARLIEST_LINKS):
        read_git_link(path)


def read_git_link(path):
    need(path.is_absolute() and path.parent.resolve() == path.parent and path.is_relative_to(REPO),
         'literal internal Git symlink input')
    before = path.lstat(); target = os.readlink(path).encode(); after = path.lstat()
    fingerprint = tuple(getattr(before, key) for key in STAT_KEYS)
    need(stat.S_ISLNK(before.st_mode) and path.resolve().is_relative_to(REPO)
         and fingerprint == tuple(getattr(after, key) for key in STAT_KEYS), 'Git symlink identity changed')
    snapshot = (target, fingerprint)
    need(path not in EARLIEST_LINKS or EARLIEST_LINKS[path] == snapshot, 'Git link differs from earliest bytes/fullstat')
    EARLIEST_LINKS.setdefault(path, snapshot)
    return target, before


def observer_fence(view):
    need(set(view) == {'label', 'uid_map', 'gid_map'} and isinstance(view['label'], str) and view['label'],
         'one explicitly chosen observer view required')
    # These fixed proc metadata files are not payloads/ordinary st_size files.
    need(Path('/proc/self/uid_map').read_text() == view['uid_map']
         and Path('/proc/self/gid_map').read_text() == view['gid_map'], 'observer UID/GID mapping changed')


def selected(row):
    need(set(row) == {'path', 'member', 'bytes', 'sha256', 'stat', 'role'}, 'exact frozen selection row')
    path = Path(row['path']); safe_member(row['member'])
    need(path.is_relative_to(ROOT) or path.is_relative_to(REPO), 'explicit owned source/evidence input')
    need(not any(part in FORBIDDEN for part in path.parts) and path != FAILED_ARCHIVE,
         'private state/generated tree/opaque archive cannot be payload')
    need(path != REPO / 'docs/reviews/gui-native-notification-inbox/evidence.tar.gz',
         'canonical496 baseline archive remains reference-only')
    raw, info = bound(path, row['sha256'])
    need(len(raw) == row['bytes'] and row['stat'] == {key: getattr(info, key) for key in STAT_KEYS},
         'exact source observer bytes/fullstat required; no ownership normalization')
    return raw, info


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args], env={'PATH': os.defpath, 'LANG': 'C.UTF-8'})


def source_fence(frame):
    need(QUALIFIED_SOURCE == CANDIDATE_SOURCE and git('rev-parse', 'HEAD').decode().strip() == QUALIFIED_SOURCE
         and not git('status', '--porcelain'), 'exact independently qualified clean source required')
    names = git('ls-tree', '-r', '--name-only', QUALIFIED_SOURCE).decode().splitlines()
    need({row['path'] for row in frame} == set(names) and len(frame) == len(names), 'complete Git source frame required')
    for row in frame:
        name = safe_member(row['path']); path = REPO / name
        blob = git('show', QUALIFIED_SOURCE + ':' + name)
        if row['kind'] == 'file':
            raw, info = bound(path, row['sha256'])
            need(len(raw) == row['bytes'] and raw == blob
                 and row['stat'] == {key: getattr(info, key) for key in STAT_KEYS}, 'qualified current/Git file bytes/fullstat differ')
        else:
            need(row['kind'] == 'symlink', 'known Git file kind required')
            target, info = read_git_link(path)
            need(target == blob and sha(blob) == row['sha256']
                 and row['stat'] == {key: getattr(info, key) for key in STAT_KEYS}, 'exact internal Git symlink/fullstat required')


def failed_attempt_skeleton(selection):
    need(not os.path.lexists(FAILED_RUN / 'result.json'), 'EA9 failed result must stay absent; never reconstruct')
    for name, digest in FAILED_OBSERVATIONS.items():
        bound(ROOT / 'notification-inbox-date-checks' / name, digest)
    failure = json.loads(bound(ROOT / 'notification-inbox-date-checks/first-full-failure-review.json',
                               FAILED_OBSERVATIONS['first-full-failure-review.json'])[0])
    need(failure['overall_status'] == 'FAILED_EXIT1_NO_RESULT_JSON_NO_COMPLETE_QUALIFICATION_ACCEPTANCE'
         and failure['accepted_complete_qualification'] is False and failure['missing_result_reconstructed'] is False,
         'only failure/source/native/lifecycle audit is admitted')
    # Actual final freezing must close all EA9 root/proof/CID/raw/source-manifest
    # files and exact exclusion metadata/source-Git joins. Lost in-memory command
    # timestamps/argv/records are declared LOST, not reconstructed from source.
    need(selection['failed_EA9']['command_metadata'] == 'LOST_NOT_RECONSTRUCTED'
         and selection['failed_EA9']['raw_archive_exclusion']['path'] == str(FAILED_ARCHIVE)
         and selection['failed_EA9']['raw_archive_exclusion']['bytes'] == FAILED_ARCHIVE_BYTES
         and selection['failed_EA9']['raw_archive_exclusion']['sha256'] == FAILED_ARCHIVE_SHA,
         'literal opaque failure archive exclusion only')


def baseline_and_37(selection):
    refs = json.loads(bound(HERE / 'baseline-references.json', BASELINE_REFS_SHA)[0])
    base = Path(refs['canonical_root'])
    raw = bound(base / 'evidence.tar.gz', BASELINE_SHA)[0]
    manifest = json.loads(bound(base / 'archive-manifest.json', refs['reference_metadata']['archive-manifest.json'])[0])
    for name, digest in refs['reference_metadata'].items():
        bound(base / safe_member(name), digest)
    need(len(manifest) == refs['archive']['members'] == 2695, 'immutable baseline2695 member census')
    body_refs = {row['member']: row for row in refs['baseline_body_references']}
    comparisons = selection['all37_body_rows']
    need(len(body_refs) == len(comparisons) == 37 and {row['baseline_member'] for row in comparisons} == set(body_refs),
         'closed31prior+6inbox identity comparison required')
    by_member = {row['baseline_member']: row for row in comparisons}
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as archive:
        entries = archive.getmembers()
        need([entry.name for entry in entries] == [row['member'] for row in manifest], 'baseline complete physical member inventory')
        for entry, row in zip(entries, manifest):
            safe_member(entry.name)
            need(entry.isfile() and entry.size == row['bytes'] and entry.mode == row['mode']
                 and entry.uid == row['uid'] and entry.gid == row['gid']
                 and int(Decimal(entry.pax_headers['mtime']) * 10 ** 9) == row['mtime_ns'], 'immutable baseline PAX metadata')
            old = archive.extractfile(entry).read()
            need(sha(old) == row['sha256'], 'immutable baseline member bytes differ')
            if entry.name in body_refs:
                ref = body_refs[entry.name]; comparison = by_member[entry.name]
                current = bound(Path(comparison['new_path']), comparison['new_sha256'])[0]
                need(len(old) == ref['bytes'] and sha(old) == ref['sha256'] and current == old
                     and comparison['exact_bytes_equal'] is True, 'physical original37 body equality required')
    # Never stat old manifest['original'] paths: prior retention removed some.


def exact_attempts(censuses):
    for census in censuses:
        parent = Path(census['parent'])
        need(parent.is_absolute() and parent.resolve() == parent and parent.is_dir() and not parent.is_symlink(),
             'literal canonical attempt namespace')
        actual = sorted(parent.iterdir())
        need([str(path) for path in actual] == [row['path'] for row in census['entries']],
             'unknown complete/incomplete/non-run/symlink attempt entry')
        for path, row in zip(actual, census['entries']):
            need(not path.is_symlink() and path.resolve() == path, 'attempt alias/symlink refused')
            if row['kind'] == 'attempt-directory':
                need(path.is_dir() and path.name.startswith('run-'), 'literal recorded attempt directory')
            else:
                need(row['kind'] == 'owned-runner-lock' and path.name == 'runner.lock', 'unreviewed nondirectory attempt entry')
                raw, info = bound(path, row['sha256'])
                need(len(raw) == row['bytes'] and row['stat'] == {key: getattr(info, key) for key in STAT_KEYS},
                     'literal runner lock bytes/fullstat')
    # Do not census mutable source/review packet directories. Source rows are
    # finite hash/stat-bound; final review refs are a separate exact list.


def actual_semantics_not_yet_bound(binding, selection):
    # Deliberately unimplemented fail-closed admission until actual final reviews:
    # full result+commands/raw packages/7 lanes/cleanup/source manifest; complete
    # physical UI/capture/benchmark and all37 comparisons; frozen exclusions and
    # source/history/method/4-controls; exact separate accepted review roles.
    raise ValueError('actual PG/UI/measurement/body/review/selection admission requires a new reviewed final source revision')


def write_payload(output, payload):
    need(not os.path.lexists(output) and output.parent == HERE and output.is_absolute()
         and output.resolve() == output, 'exclusive fresh direct-child output')
    need(sum(len(row[0]) for row in payload.values()) <= MAX_PAYLOAD, 'bounded compact payload')
    output.mkdir(mode=0o700)
    archive_path = output / 'evidence.tar.gz'; manifest = []
    with tarfile.open(archive_path, mode='x:gz', format=tarfile.PAX_FORMAT) as archive:
        for member, (raw, info, path) in sorted(payload.items()):
            safe_member(member)
            entry = tarfile.TarInfo(member); entry.size = len(raw); entry.mode = stat.S_IMODE(info.st_mode)
            entry.uid = info.st_uid; entry.gid = info.st_gid; entry.mtime = info.st_mtime_ns // 10 ** 9
            entry.pax_headers = {'mtime': str(entry.mtime) + '.' + str(info.st_mtime_ns % 10 ** 9).zfill(9)}
            archive.addfile(entry, io.BytesIO(raw))
            manifest.append({'member': member, 'original': str(path), 'bytes': len(raw), 'sha256': sha(raw),
                             'mode': entry.mode, 'uid': entry.uid, 'gid': entry.gid, 'mtime_ns': info.st_mtime_ns})
    with tarfile.open(archive_path, mode='r:gz') as archive:
        entries = archive.getmembers()
        need([entry.name for entry in entries] == [row['member'] for row in manifest], 'complete archive member readback')
        for entry, row in zip(entries, manifest):
            need(entry.isfile() and entry.size == row['bytes'] and entry.mode == row['mode']
                 and entry.uid == row['uid'] and entry.gid == row['gid']
                 and int(Decimal(entry.pax_headers['mtime']) * 10 ** 9) == row['mtime_ns']
                 and sha(archive.extractfile(entry).read()) == row['sha256'], 'payload bytes/full portable metadata readback')
    return archive_path, manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binding', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    # First refusal precedes reading any pending paths or creating any output.
    need(COLLECTION_RELEASED and QUALIFIED_SOURCE is not None,
         'source skeleton disabled pending actual qualification/final collector review')
    binding = json.loads(read(args.binding)[0])
    need(binding['status'] == 'BOUND_FINAL_INDEPENDENT_EVIDENCE', 'pending binding cannot collect')
    need(args.binding.parent == HERE, 'literal task-owned final binding')
    bound(HERE / 'plan.json', PLAN_SHA)
    selection = json.loads(bound(Path(binding['selection_path']), binding['selection_sha256'])[0])
    observer_fence(binding['observer'])
    actual_semantics_not_yet_bound(binding, selection)
    source_fence(selection['source_frame']); exact_attempts(selection['attempt_censuses'])
    failed_attempt_skeleton(selection); baseline_and_37(selection)
    payload = {}
    for row in selection['rows'] + binding['final_review_rows']:
        raw, info = selected(row); member = row['member']
        need(member not in payload, 'unique selected member; review records selected exactly once')
        payload[member] = (raw, info, Path(row['path']))
    source_fence(selection['source_frame']); exact_attempts(selection['attempt_censuses'])
    observer_fence(binding['observer']); recheck_all()
    archive, manifest = write_payload(args.output, payload)
    source_fence(selection['source_frame']); exact_attempts(selection['attempt_censuses'])
    observer_fence(binding['observer']); recheck_all()
    # Final result writer must be completed only with actual bound counts and
    # pending-independent-keeper status in the separately reviewed final revision.
    raise ValueError('source skeleton never emits acceptance or a projected result')


if __name__ == '__main__':
    main()
