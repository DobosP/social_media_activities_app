# Custody controls — source plan, unexecuted

After final source/selection review, Root runs isolated fixed-text standard-library controls in an explicit owned scratch directory. Never mutate genuine evidence for a negative test. This skeleton contains no executed control receipt.

1. Disabled/pending binding refuses before reading pending actual paths or creating output. A final-source incomplete review/selection binding must also refuse before output.
2. Same canonical regular bytes/stat pass; changed bytes, chmod, nanosecond mtime, UID/GID/view mapping, inode replacement, symlink/component alias, oversized payload and special-file inputs refuse. Preserve ordinary64MiB cap. Test with fixed synthetic data/sparse metadata only.
3. Earliest registry detects drift between validation/add/final reread, including a **reference-only baseline** before output and after archive readback. No success may silently adopt a later snapshot.
4. Unknown complete/incomplete/symlink/nondirectory attempt namespace entries refuse. Exact recorded runner.lock is separately hash/fullstat-bound; no broad file exception. Review files arriving after source preparation enter only the separate exact final-review roles, never auto-admitted directory globs.
5. FailedEA9 remains no-result/overallFAIL. Unknown stdout exclusions, changed exclusion paths/bytes/stat/hash/Git joins, private/generated-tree payloads, unreviewed command metadata reconstruction and missing raw proof/CID/source-manifest/cleanup each refuse.
6. All37 comparison identities are unique and closed; byte, metadata, member-name, missing/extra identity and new normalization mutations refuse. Check baseline manifest/PAX internally without statting deleted historical original source paths.
7. Independent review records require exact accepted state, empty findings and actual source/artifact digests. Wrong source/role/hash, duplicated review role/file, stale observation view, partialPG-as-full or missing raw command/lane/cleanup joins refuse.
8. Fresh exclusive output, duplicate/unsafe member, cap, truncation and PAX metadata/readback mismatches refuse. Root retains actual control/result/archive receipts and a separate independent keeper review before promotion; no deletion follows.
