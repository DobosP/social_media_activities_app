# Native notification inbox — collected candidate

Exact source `496056a6a528d01d544abbf77e18877b60d629bd`. Independent keeper/feature acceptance remains pending.

Complete affected-seven, actual desktop/no-JS, capture, benchmark and separate history are bound in result.json and selection.json. Benchmark is descriptive warmed body rendering only; no HTTP/DB/throughput/general-speedup claim.

Original failed histories remain failed. Aliases preserve original metadata and exact content, not independent tar bodies or accepted epoch identity. Excluded full Git archives retain original digest/tree/manifest history. No raw output was deleted by this collector.

Reproduce using [committed methods](../../../tools/gui-native-notification-inbox/README.md) and the exact clean qualified checkout; this archive is not a full source/dependency distribution. Canonical prior notification-preferences baseline keeper remains a pinned dependency.

No all21/current-image/main/milestone/production/mobile/provider/government or real-child activation.
