# Inbox compact custody preparation

Source only; actual final bindings/counts and independent collection-source review are required before prepare/collect. The example must refuse before output. No runtime, archive, deletion, feature acceptance or source-workspace copy is produced by this preparation. Current first campaigns are still running; any additional terminal campaign needs an explicit reviewed history extension. Canonical preference keeper29a9 retains prior immutable failures.
