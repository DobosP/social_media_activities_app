#!/usr/bin/env python3
"""Scratch-only explicit selection/collection; no product runtime, mutation or deletion."""
import argparse
import base64
import collections
from decimal import Decimal
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import tarfile

DRAFT = Path(__file__).absolute().parent
ROOT = Path('/home/dobo/work/_temp/feat__gui-app-migration-a/social-family')
UI_ROOT = Path('/home/dobo/work/_temp/ni-ui')
REPO = Path('/home/dobo/work/_worktrees/social_media_activities_app/feat__gui-app-migration-a')
MAXIMUM = 64 << 20
LANES = ('web', 'app', 'accounts', 'recommendations', 'social', 'messaging', 'notifications')
PREFIX = 'github.com/DobosP/social_media_activities_app/services/server/internal/'
STATES = ['empty-en','one-unread-ro','mixed-en','all-read-ro','escaped-ro','unsafe-links-en']
BANNED = {'node_modules','binaries','bin','go-cache','go-mod','source','profiles','proposed','before','go-tmp','__pycache__'}
PACKET_SUFFIXES = {'.json','.patch','.md','.py','.mjs','.txt','.stdout','.stderr','.jsonl','.diff','.css','.go','.gohtml','.html','.sh','.log','.js'}


def need(ok, message):
    if not ok: raise RuntimeError(message)


def sha(raw): return hashlib.sha256(raw).hexdigest()


def literal(value):
    need(isinstance(value,str) and not value.startswith('/') and '\\' not in value and
         all(p not in ('','.','..') for p in value.split('/')), 'Literal relative path required')
    return value


def metadata(info):
    return dict(mode=stat.S_IMODE(info.st_mode),uid=info.st_uid,gid=info.st_gid,mtime_ns=info.st_mtime_ns)


def read(path):
    need(path.is_absolute() and path.resolve()==path, 'Canonical unaliased input required: '+str(path))
    before=path.lstat();need(stat.S_ISREG(before.st_mode) and 0<=before.st_size<=MAXIMUM,'Bounded regular input required')
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
    try:
        opened=os.fstat(fd)
        with os.fdopen(fd,'rb',closefd=False) as stream: raw=stream.read(MAXIMUM+1)
        after=os.fstat(fd)
        keys=('st_dev','st_ino','st_mode','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
        need(all(getattr(before,k)==getattr(opened,k)==getattr(after,k) for k in keys) and len(raw)==after.st_size<=MAXIMUM,'Input changed during read')
        return raw,after
    finally: os.close(fd)


def record(path):
    need(any(path.is_relative_to(p) for p in (ROOT,UI_ROOT,REPO)), 'Foreign input root')
    raw,info=read(path)
    return dict(source=str(path),bytes=len(raw),sha256=sha(raw),**metadata(info))


def pinned(row):
    need(any(Path(row['source']).is_relative_to(p) for p in (ROOT,UI_ROOT,REPO)), 'Foreign pinned root')
    raw,info=read(Path(row['source']))
    need(len(raw)==row['bytes'] and sha(raw)==row['sha256'] and metadata(info)=={k:row[k] for k in metadata(info)},'Pinned bytes/stat differ: '+row['source'])
    return raw,info


def git(*args): return subprocess.check_output(['git','-C',str(REPO),*args])


def fence(config,source_rows):
    source=config['final_source'];need(git('rev-parse','HEAD').decode().strip()==source and not git('status','--porcelain'),'Exact clean final source required')
    need(git('rev-parse',source+'^{tree}').decode().strip()==config['final_tree'],'Final source tree changed')
    tree={}
    for entry in git('ls-tree','-r','-z',source).split(b'\0'):
        if entry:
            header,name=entry.split(b'\t',1);tree[name.decode()]=tuple(header.decode().split())
    need(len(source_rows)==len(tree)==config['source_rows_expected'] and len({r['path'] for r in source_rows})==len(tree),'Complete source manifest required')
    for row in source_rows:
        name=literal(row['path']);raw,info=read(REPO/name)
        blob=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
        mode='100755' if row['mode']&0o111 else '100644'
        need(len(raw)==row['bytes'] and sha(raw)==row['sha256'] and tree.get(name)==(mode,'blob',blob) and bool(info.st_mode&0o111)==bool(row['mode']&0o111),'Git/current/manifest differs: '+name)


def test_receipt(lane,listed,raw,stored):
    names=[s for s in listed.decode().splitlines() if re.fullmatch(r'(?:Test|Example|Fuzz)[A-Za-z0-9_]+',s)]
    need(names and len(names)==len(set(names)),'Complete unique root inventory required')
    events=[json.loads(line) for line in raw.splitlines()]
    need(events and all(e.get('Package')==PREFIX+lane for e in events) and not any(e.get('Action') in ('fail','skip') for e in events),'Wrong package/fail/skip')
    runs=[e['Test'] for e in events if e.get('Action')=='run'];passes=[e['Test'] for e in events if e.get('Action')=='pass' and e.get('Test')]
    need(collections.Counter(runs)==collections.Counter(passes) and all(v==1 for v in collections.Counter(runs).values()) and {n for n in runs if '/' not in n}==set(names) and len([e for e in events if e.get('Action')=='pass' and not e.get('Test')])==1,'All listed roots/named cases must pass once')
    need(stored['top_level']==len(names) and stored['named_passes']==len(passes) and stored['fail']==stored['skip']==0 and collections.Counter(stored['identities'])==collections.Counter(runs),'Stored test receipt mismatch')
    return len(names),len(passes)


class Selection:
    def __init__(self): self.files=[];self.aliases=[];self.excluded=[];self.members={};self.content={};self.native_epochs=[];self.used=set()
    def add(self,path,member,category,expected=None,alias=False):
        literal(member);need(member not in self.used,'Duplicate member');self.used.add(member)
        row=record(path)
        if expected is not None: need(row['bytes']==expected['bytes'] and row['sha256']==expected['sha256'],'Original artifact inventory changed')
        row.update(member=member,category=category)
        key=(row['bytes'],row['sha256'])
        if alias and key in self.content:
            target=self.content[key];raw,_=pinned(row);other,_=pinned(self.members[target]);need(raw==other,'Hash collision/alias mismatch')
            row['original_member']=row.pop('member');row['content_member']=target
            row['acceptance']='Historical exact content only; not accepted-run identity or equal source metadata.'
            self.aliases.append(row)
        else:
            self.files.append(row);self.members[member]=row
            if alias or path.suffix in ('.png','.html'):self.content.setdefault(key,member)
        return row
    def raw(self,member): return pinned(self.members[member])[0]
    def data(self,member): return json.loads(self.raw(member))
    def resolve(self,member):
        if member in self.members:return self.raw(member)
        matches=[a for a in self.aliases if a['original_member']==member];need(len(matches)==1,'Unresolved alias')
        return self.raw(matches[0]['content_member'])


def native(sel,label,binding,config):
    path=Path(binding['path']);need(path.parent==ROOT/'notification-inbox-pg-qa','Wrong native epoch path')
    item=sel.add(path/'result.json','evidence/'+label+'/result.json','native-result')
    need(item['sha256']==binding['result_sha256'],'Native result hash changed')
    x=sel.data('evidence/'+label+'/result.json');source=binding.get('source',config['final_source'])
    need(x['source']==source and x['method_pass'] is True and not x['errors'] and set(x['lanes'])==set(LANES),'Actual complete-seven success required')
    expected=config['final_native_observed_expected'] if label=='native-final' else {'commands':binding['expected_commands'],'artifact_rows':binding['expected_artifact_rows']}
    need(len(x['commands'])==expected['commands'] and len(x['artifact_rows'])==expected['artifact_rows'],'Original per-epoch native command/artifact inventory differs')
    roles={'db',*LANES,*('reference-'+n for n in LANES)}
    need(set(x['cleanup'])==roles and all(v.get('stopped') is True and v.get('id_absent') is True and v.get('name_absent') is True for v in x['cleanup'].values()),'Fifteen exact cleanup receipts required')
    pc=x['pg_cleanup'];need(pc['stop_exit']==0 and pc['status_exit']==3 and pc['owned_pid']>0 and pc['pid_probe_exit']==1 and pc['pid_and_socket_files_absent']==1 and x['pg_storage_initial']['tmpfs']['bytes']==1<<30,'Original fixed-cap shutdown receipts required')
    sel.add(path/'source-manifest.json','evidence/'+label+'/source-manifest.json','complete-source-manifest')
    for p in sorted(path.glob('*.cid')):sel.add(p,'evidence/'+label+'/'+p.name,'owned-resource-receipt')
    archives=[c['stdout']['path'] for c in x['commands'] if c['argv'][0]=='git' and 'archive' in c['argv']];need(len(archives)==1,'Exactly one Git archive stdout required')
    for row in x['artifact_rows']:
        name=literal(row['path']);need(name.startswith('proof/'),'Unexpected native proof path')
        if name in archives:
            sel.excluded.append(dict(source=str(path/name),**row,reason='Full binary Git archive stdout omitted; original recorded digest/tree/source manifest retained. No deletion.'))
        else:sel.add(path/name,'evidence/'+label+'/'+name,'native-raw-proof',row)
    counts=[]
    for lane in LANES:
        v=x['lanes'][lane];retired=x['retired_databases'][lane]
        need(v['state']=='PASS' and v['pg_before']==v['pg_after'] and v['pg_after']['fixtures']==0 and retired['checkpoint_completed'] is True and retired['name_and_oid_absent'] is True and retired['database']==v['pg_after']['database'] and retired['oid']==v['pg_after']['oid'],'Lane lifecycle mismatch')
        counts.append(test_receipt(lane,sel.raw('evidence/'+label+'/proof/'+lane+'-list.stdout'),sel.raw('evidence/'+label+'/proof/'+lane+'-test2json.stdout'),v['tests']))
    need(tuple(map(sum,zip(*counts)))==(config['native_roots_expected'],config['native_named_expected']),'Complete source-derived test counts differ')
    sel.native_epochs.append(dict(label=label,source=source,tree=x['tree'],result_sha256=binding['result_sha256'],method_pass=True,original_commands=len(x['commands']),original_artifact_rows=len(x['artifact_rows']),retained_raw_proof_rows=len(x['artifact_rows'])-1,excluded_archive_stdout=archives))
    return x


def ui(sel,label,binding,final=False):
    path=Path(binding['path']);need(path.parent==UI_ROOT,'Wrong UI epoch path')
    row=sel.add(path/'result.json','evidence/'+label+'/result.json','UI-result');need(row['sha256']==binding['result_sha256'],'UI result changed')
    x=sel.data('evidence/'+label+'/result.json');need(x['status']==('PASS' if final else 'FAIL'),'UI disposition differs')
    sel.add(path/'status.json','evidence/'+label+'/status.json','UI-status')
    for row in x['artifacts']:sel.add(path/literal(row['path']),'evidence/'+label+'/'+row['path'],'UI-raw-artifact',row,alias=not final and Path(row['path']).suffix in ('.png','.html'))
    if not final:need(x['benchmark_requested'] is True and x['benchmark']['status']=='REQUESTED_NOT_REACHED' and not any('benchmark' in Path(c['stdout']).stem for c in x['commands']),'Initial benchmark must remain requested/not reached')
    return x


def packets(sel,config):
    for root in map(Path,config['packet_roots']):
        need(root.parent==ROOT and 'notification' in root.name,'Foreign packet root')
        for path in sorted(root.rglob('*')):
            relative=path.relative_to(root)
            if any(part in BANNED for part in relative.parts) or path.is_dir():continue
            if path.name=='programme-ledger-review.json' or path.suffix not in PACKET_SUFFIXES:continue
            sel.add(path,'evidence/packets/'+str(path.relative_to(ROOT)),'source-packet-review-or-actual-check')
    for ref in config['historical_reviews']:
        r=record(Path(ref['path']));need(r['sha256']==ref['sha256'],'Pinned historical review changed')


def descendants(value):
    if isinstance(value,dict):
        for v in value.values():yield from descendants(v)
    elif isinstance(value,list):
        for v in value:yield from descendants(v)
    else:yield value


def final_reviews(sel,binding,config):
    for role,target in (('native_review','native_final'),('ui_review','ui_final')):
        ref=binding[role];path=Path(ref['path']);need(path.is_relative_to(ROOT) and path.suffix=='.json','Owned review JSON required')
        row=sel.add(path,'evidence/reviews/'+role+'.json','independent-actual-result-review');need(row['sha256']==ref['sha256'],'Independent review hash differs')
        x=json.loads(read(path)[0]);values=list(descendants(x));verdict=x.get('verdict','')
        need(verdict.startswith('ACCEPT_') and x.get('findings')==[] and config['final_source'] in values and binding[target]['result_sha256'] in values,'Independent actual-result review missing source/result/clear findings')

    ref=binding['collection_review'];path=Path(ref['path'])
    row=sel.add(path,'evidence/reviews/collection-method-review.json','independent-collection-source-review')
    need(row['sha256']==ref['sha256'],'Collection-method review hash differs')
    review=json.loads(read(path)[0]);values=list(descendants(review))
    verdict=review.get('verdict',review.get('status',''))
    need(verdict.startswith('ACCEPT_') and review.get('findings')==[] and config['final_source'] in values and sha(read(DRAFT/'keeper.py')[0]) in values,'Collection method lacks independent source/hash approval')


def admit_final(sel,config,binding):
    source=config['final_source'];n=sel.data('evidence/native-final/result.json');u=sel.data('evidence/ui-final/result.json');d=sel.data('evidence/ui-final/desktop/desktop-results.json')
    need(n['tree']==config['final_tree'] and u['PG_producer_source']==u['UI_method_source']==source and u['failures']==[] and u['benchmark_requested'] is True and u['benchmark']['status']=='EXECUTED_SEPARATE_NOT_ADMITTED' and u['benchmark']['rows']==12,'Exact final native/UI/benchmark join differs')
    need(u['owned_temp']['removed'] is True and u['git_after']=={'head':source,'porcelain_empty':True} and len(u['commands'])==4 and all(c['exit_code']==0 and c['timed_out'] is False for c in u['commands']),'Final actual child/source/temporary cleanup differs')
    need(d['status']=='pass' and not d['failures'] and d['sourceUnchanged'] is True and d['sourcesBefore']==d['sourcesAfter'] and [s['name'] for s in d['states']]==STATES and [s['name'] for s in d['noJavaScriptStates']]==STATES,'Final desktop complete matrix differs')
    need(d['ownership']['serverStopped'] is True and len(d['ownership']['profiles'])==2 and all(p['closed'] is True and p['removed'] is True for p in d['ownership']['profiles']) and all(not d[k] for k in ('requestFailures','pageErrors','consoleErrors','cspConsole','webSockets')),'Final browser/profile/console cleanup differs')
    audits=[a for s in d['states'] for a in s['audits']];need(len(audits)==18 and all(a['axe']['violations']==a['axe']['incomplete']==[] for a in audits),'Strict18 whole-document Axe audits required')
    need(len(d['previousBodyEquality'])==31 and len({(r['kind'],r['name']) for r in d['previousBodyEquality']})==31 and all(r['equal'] is True for r in d['previousBodyEquality']),'All31 distinct prior bodies must match')
    for key,name in (('capture_sha256','capture.json'),('desktop_report_sha256','desktop/desktop-results.json'),('fixture_manifest_sha256','fixtures/fixtures.json')):need(u[key]==sha(sel.raw('evidence/ui-final/'+name)),'Final UI artifact binding differs')
    need(u['benchmark']['stdout_sha256']==sha(sel.raw('evidence/ui-final/benchmark.stdout')),'Raw benchmark binding differs')
    benchmark=sel.raw('evidence/ui-final/benchmark.stdout').decode();names=re.findall(r'^(BenchmarkSocialNotificationInboxBodyRender/(?:en|ro)/(?:classic|native))(?:-[0-9]+)?\s+100\s+',benchmark,re.M)
    need(collections.Counter(names)==collections.Counter({'BenchmarkSocialNotificationInboxBodyRender/'+lang+'/'+engine:3 for lang in ('en','ro') for engine in ('classic','native')}) and not re.search(r'--- (FAIL|SKIP):',benchmark) and re.search(r'^ok\s+\S+\s+[0-9.]+s$',benchmark,re.M),'Raw12 matched benchmark rows/package pass required')
    capture=sel.data('evidence/ui-final/capture.json');need(capture['source_sha']==capture['ui_method_source']==source and capture['result_sha256']==binding['native_final']['result_sha256'] and capture['source_manifest_sha256']==sha(sel.raw('evidence/native-final/source-manifest.json')) and capture['raw_event_sha256']==sha(sel.raw('evidence/native-final/proof/app-test2json.stdout')),'Actual capture/native source/event join differs')
    projection=base64.b64decode(capture['projection_base64'],validate=True);need(len(projection)<=256<<10 and sha(projection)==capture['projection_sha256'],'Bounded actual display projection differs')
    value=json.loads(projection);need(set(value)=={'schema','variants','capture'} and value['schema']==1 and [v['language'] for v in value['variants']]==['en','ro'],'Display-only projection schema differs')
    for variant in value['variants']:
        need(set(variant)=={'language','projection'} and set(variant['projection'])=={'items'} and len(variant['projection']['items'])==100,'Display-only projection whitelist differs')
        need(all(set(r)=={'title','body','why','url','created_at','read_at'} and all(type(r[k]) is str for k in ('title','body','why','url','created_at')) and (r['read_at'] is None or r['read_at'] is True) for r in variant['projection']['items']),'Unexpected private projection field')
    need(value['capture']=='same registered-cookie GET callback; display whitelist only; no actor/IDs/credentials/render environment','Exact source capture explanation required')
    return dict(native_roots=config['native_roots_expected'],native_named=config['native_named_expected'],native_commands=len(n['commands']),native_artifact_rows=len(n['artifact_rows']),UI_artifact_rows=len(u['artifacts']),JS_states=6,noJS_states=6,audits=18,Axe_pass_occurrences=sum(len(a['axe']['passes']) for a in audits),benchmark_rows=12,prior_bodies=31)


def bind(config,binding):
    need(binding.get('schema')==1 and binding.get('status')=='BOUND_ACTUAL_RESULTS_PENDING_KEEPER_REVIEW','Actual binding remains unbound')
    for role in ('native_final','ui_final'):
        r=binding.get(role,{});need(isinstance(r.get('path'),str) and re.fullmatch('[0-9a-f]{64}',r.get('result_sha256') or ''),'Missing actual result binding: '+role)
    for role in ('native_review','ui_review','collection_review'):
        r=binding.get(role,{});need(isinstance(r.get('path'),str) and re.fullmatch('[0-9a-f]{64}',r.get('sha256') or ''),'Missing actual independent review binding: '+role)
    need(config['repo']==str(REPO),'Explicit owning repo required')



def failed_native_history(sel,config):
    ref=config['history_runs'][0];path=Path(ref['path']);prefix='evidence/history-native-f087'
    need(path.parent==ROOT/'notification-inbox-pg-qa','Owned original failed PG history required')
    row=sel.add(path/'result.json',prefix+'/result.json','failed-native-history-result')
    need(row['sha256']==ref['result_sha256'],'Failed native result digest changed')
    actual=sel.data(prefix+'/result.json')
    need(actual['source']==ref['source'] and actual['method_pass'] is False and actual['errors'] and set(actual['lanes'])=={'web'} and actual['lanes']['web']['state']=='PASS','Original failure remains partial failed seven-package campaign')
    roles={'db','web','reference-web','app','reference-app'}
    need(set(actual['cleanup'])==roles and all(v.get('stopped') is True and v.get('id_absent') is True and v.get('name_absent') is True for v in actual['cleanup'].values()),'Failed-history five created CIDs must be cleaned')
    cleanup=actual['pg_cleanup']
    need(cleanup['stop_exit']==0 and cleanup['status_exit']==3 and cleanup['pid_probe_exit']==1 and cleanup['pid_and_socket_files_absent']==1,'Failed-history private PG shutdown required')
    sel.add(path/'source-manifest.json',prefix+'/source-manifest.json','failed-source-manifest')
    for p in sorted(path.glob('*.cid')):sel.add(p,prefix+'/'+p.name,'failed-owned-resource')
    archive=[c['stdout']['path'] for c in actual['commands'] if c['argv'][0]=='git' and 'archive' in c['argv']]
    need(len(archive)==1,'Original failed source archive receipt required')
    for item in actual['artifact_rows']:
        name=literal(item['path']);need(name.startswith('proof/'),'Unexpected failed native artifact path')
        if name==archive[0]:
            sel.excluded.append(dict(source=str(path/name),**item,reason='Original failed Git archive stdout omitted; original digest/tree/source manifest/commands retained. No deletion.'))
        else:sel.add(path/name,prefix+'/'+name,'failed-native-raw-proof',item)
    attempts=[c for c in actual['commands'] if c.get('stdout',{}).get('path')=='proof/app-native.stdout']
    need(len(attempts)==1 and attempts[0]['exit']==1 and attempts[0]['argv']==['docker','start','-a',actual['cleanup']['app']['cid']],'Original App command must record its real failed exit')
    need(not (path/'proof/app-test2json.stdout').exists() and not any(r['path'].startswith('proof/app-test2json') for r in actual['artifact_rows']),'Failed App has no invented conversion/lane receipt')
    raw=sel.raw(prefix+'/proof/app-native.stdout')
    need(b'NATIVE_NOTIFICATION_INBOX_V1 ' not in raw,'Failed App must not acquire an admitted inbox capture marker')
    need(b'--- FAIL: TestNativeNotificationInboxRegisteredHTTPAndCurrentAuthority/registered-self-newest-first-100-and-read-only-get' in raw and b'source read-presence/date/plain-body aliases changed' in raw,'Original NEW-assertion failure must remain visible')
    need(hashlib.sha256(raw).hexdigest()==ref['app_raw_sha256'],'Original failed raw App stream changed')
    sel.native_epochs.append(dict(label='failed-native-f087',source=ref['source'],result_sha256=ref['result_sha256'],method_pass=False,scope='Web PASS only; original App FAIL; remaining five packages unrun. Never full qualification.'))


def history_fence(config,binding):
    history=config['history_runs']
    need(len(history)==1 and history[0]['kind']=='failed-native' and history[0]['source']=='f0874800b1de845f57ce79074fdb0a7151fabc6f','Exactly one explicit original failed-native history required')
    for parent,final in ((ROOT/'notification-inbox-pg-qa',Path(binding['native_final']['path'])),(UI_ROOT,Path(binding['ui_final']['path']))):
        attempts=set(parent.glob('run-*'));expected={final}|{Path(r['path']) for r in history if Path(r['path']).parent==parent}
        need(all(p.is_dir() and not p.is_symlink() and p.resolve()==p and p.stat().st_uid==os.getuid() for p in attempts),'Unexpected or nonowned actual campaign path; retain and explicitly review before collection')
        need(attempts==expected, 'Unbound complete or incomplete actual history exists; retain and review it before collection')


def build(config,binding=None,binding_path=None):
    sel=Selection();summary=None
    if binding is not None:
        bind(config,binding)
        native(sel,'native-final',binding['native_final'],config)
        ui(sel,'ui-final',binding['ui_final'],True)
        final_reviews(sel,binding,config)
        summary=admit_final(sel,config,binding)
        fence(config,sel.data('evidence/native-final/source-manifest.json'))
    history_fence(config,binding)
    failed_native_history(sel,config)
    packets(sel,config)
    for name in config['reproduction_paths']+config['native_reproduction_paths']:
        sel.add(REPO/literal(name),'reproduce/committed/'+name,'exact-current-reproduction-method')
    baseline=config['baseline_dependency'];need(sha(read(REPO/literal(baseline['path']))[0])==baseline['sha256'],'Original notification-preferences baseline keeper dependency changed')
    for p in sorted((DRAFT/'history-v1').iterdir()):
        need(p.is_file() and not p.is_symlink(),'Literal original collector draft history')
        sel.add(p,'reproduce/collection/history-v1/'+p.name,'original-unaccepted-collector-draft')
    for name in ('keeper.py','config.json','README.md','final-binding.example.json'):
        sel.add(DRAFT/name,'reproduce/collection/'+name,'collection-method')
    if binding_path is not None:sel.add(binding_path,'reproduce/collection/final-binding.json','actual-final-bindings')
    sel.excluded += [dict(scope='Full source exports/test executables/bootstrap binary/caches/DBs/socket/host-tmp/test-tmp/profiles/full proposed and before source trees',reason='Not selected. Exact source SHA/tree/full source manifest/commands/hash history preserved. No deletion by collector.'),dict(scope='Prior notification-preferences baseline archive',reason='Canonical dependency already retained at pinned repository path/hash, not duplicated. Complete source manifest retains its identity; preserve canonical keeper.'),dict(scope='Foreign programme/Teacher/other-module work',reason='Outside this bounded notification keeper.'),dict(scope='Duplicate historical HTML/PNG bytes',reason='Explicit exact content aliases retain each original path/hash/bytecount/mode/UID/GID/nsmtime. Alias bodies are not independent tar members or equal target metadata.')]
    data=dict(schema=1,status='READY_FOR_ROOT_SELECTION_REVIEW_NOT_COLLECTED' if binding is not None else 'HISTORY_INVENTORY_ONLY_FINAL_UNBOUND',qualified_source=config['final_source'],qualified_tree=config['final_tree'],scope=config['scope'],summary=summary,native_epochs=sel.native_epochs,files=sorted(sel.files,key=lambda r:r['member']),content_aliases=sorted(sel.aliases,key=lambda r:r['original_member']),excluded=sel.excluded,baseline_dependency=config['baseline_dependency'],claims=dict(archive_created=False,physical_deletion_performed=False,aliases_are_not_independent_archive_bodies=True,independent_keeper_acceptance='PENDING'))
    history_fence(config,binding)
    return sel,data


def archive(path,payload):
    manifest=[]
    with path.open('xb') as file:
        os.fchmod(file.fileno(),0o600)
        with gzip.GzipFile(fileobj=file,mode='wb',compresslevel=9,mtime=0) as compressed:
            with tarfile.open(fileobj=compressed,mode='w|',format=tarfile.PAX_FORMAT) as output:
                for name,(raw,info,original) in sorted(payload.items()):
                    entry=tarfile.TarInfo(literal(name));entry.size=len(raw)
                    entry.mode,entry.uid,entry.gid=stat.S_IMODE(info.st_mode),info.st_uid,info.st_gid
                    entry.mtime=info.st_mtime_ns//1_000_000_000
                    entry.pax_headers={'mtime':str(entry.mtime)+'.'+str(info.st_mtime_ns%1_000_000_000).zfill(9)}
                    output.addfile(entry,io.BytesIO(raw));manifest.append(dict(member=name,original=original,bytes=len(raw),sha256=sha(raw),**metadata(info)))
    with tarfile.open(path,'r:gz') as restored:
        entries=restored.getmembers();need([e.name for e in entries]==[r['member'] for r in manifest],'Exact archive member inventory required')
        for entry,row in zip(entries,manifest):
            stream=restored.extractfile(entry)
            need(entry.isfile() and stream is not None and entry.size==row['bytes'] and entry.mode==row['mode'] and entry.uid==row['uid'] and entry.gid==row['gid'] and int(Decimal(entry.pax_headers['mtime'])*1_000_000_000)==row['mtime_ns'] and sha(stream.read())==row['sha256'],'Archive bytes/mode/owner/nanosecondmtime roundtrip differs')
    return manifest


def emit(path,raw):
    with path.open('xb') as file:os.fchmod(file.fileno(),0o600);file.write(raw)


def encoded(value):return (json.dumps(value,indent=2)+chr(10)).encode()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode',choices=('prepare','collect'))
    parser.add_argument('--config',type=Path,default=DRAFT/'config.json')
    parser.add_argument('--binding',type=Path)
    parser.add_argument('--selection',type=Path)
    parser.add_argument('--approved-selection-sha256')
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();need(args.config==DRAFT/'config.json','Exact preparation config required')
    config=json.loads(read(args.config)[0]);need(config['schema']==1,'Config schema differs')
    binding=None
    if args.mode!='inventory':
        need(args.binding is not None and args.binding.parent==DRAFT,'Owned explicit final binding required')
        binding=json.loads(read(args.binding)[0]);bind(config,binding)
    sel,selection=build(config,binding,args.binding)
    need(args.output.is_absolute() and args.output.parent==DRAFT and not args.output.exists() and not args.output.is_symlink(),'Fresh direct owned output required')
    if args.mode!='collect':
        history_fence(config,binding)
        emit(args.output,encoded(selection))
        print(json.dumps(dict(status=selection['status'],sha256=sha(read(args.output)[0]),physical_files=len(sel.files),physical_bytes=sum(r['bytes'] for r in sel.files),aliases=len(sel.aliases),archive_created=False,physical_deletion_performed=False)))
        return
    need(args.selection is not None and args.selection.parent==DRAFT and re.fullmatch('[0-9a-f]{64}',args.approved_selection_sha256 or ''),'Root approved exact selection required')
    approved=read(args.selection)[0];need(sha(approved)==args.approved_selection_sha256 and approved==encoded(selection),'Approved selection differs from rebuilt/fenced inputs')
    payload={r['member']:(*pinned(r),r['source']) for r in sel.files}
    for row in sel.aliases:
        raw,_=pinned(row);need(row['content_member'] in payload and raw==payload[row['content_member']][0],'Alias target bytes differ')
    need(shutil.disk_usage(DRAFT).free>sum(len(v[0]) for v in payload.values())*2+(64<<20),'Free disk insufficient')
    args.output.mkdir(mode=0o700)
    result=dict(schema=1,status='COLLECTED_CANDIDATE_PENDING_INDEPENDENT_KEEPER_REVIEW',source=config['final_source'],tree=config['final_tree'],scope=config['scope'],actuals=selection['summary'],history='Original f087 complete web PASS/App FAIL at NEW raw datetime assertion; remaining five packages unrun. Exact failed raw result/cleanup retained, never promoted. Pure actual-renderer escape diagnostic and reviewed assertion-only successor retained. Prior preference failures remain in canonical29a9 dependency.',physical_deletion_performed=False,independent_keeper_review='PENDING')
    readme=('# Native notification inbox — collected candidate\n\nExact source `'+config['final_source']+'`. Independent keeper/feature acceptance remains pending.\n\nComplete affected-seven, actual desktop/no-JS, capture, benchmark and separate history are bound in result.json and selection.json. Benchmark is descriptive warmed body rendering only; no HTTP/DB/throughput/general-speedup claim.\n\nOriginal failed histories remain failed. Aliases preserve original metadata and exact content, not independent tar bodies or accepted epoch identity. Excluded full Git archives retain original digest/tree/manifest history. No raw output was deleted by this collector.\n\nReproduce using [committed methods](../../../tools/gui-native-notification-inbox/README.md) and the exact clean qualified checkout; this archive is not a full source/dependency distribution. Canonical prior notification-preferences baseline keeper remains a pinned dependency.\n\nNo all21/current-image/main/milestone/production/mobile/provider/government or real-child activation.\n').encode()
    for name,raw in [('selection.json',approved),('content-aliases.json',encoded(sel.aliases)),('excluded.json',encoded(sel.excluded)),('result.json',encoded(result)),('README.md',readme)]:
        emit(args.output/name,raw);data,info=read(args.output/name);payload[name]=(data,info,str(args.output/name))
    manifest=archive(args.output/'evidence.tar.gz',payload);emit(args.output/'archive-manifest.json',encoded(manifest))
    for row in sel.files+sel.aliases:pinned(row)
    fence(config,sel.data('evidence/native-final/source-manifest.json'))
    raw,_=read(args.output/'evidence.tar.gz')
    receipt=dict(schema=1,status='COLLECTED_PENDING_INDEPENDENT_KEEPER_REVIEW',qualified_source=config['final_source'],selection_sha256=sha(approved),archive_sha256=sha(raw),archive_bytes=len(raw),archive_members=len(manifest),archive_manifest_sha256=sha(read(args.output/'archive-manifest.json')[0]),aliases=len(sel.aliases),inputs_unchanged=True,full_readback=True,bytes_mode_UID_GID_nanosecondmtime=True,physical_deletion_performed=False)
    history_fence(config,binding)
    emit(args.output/'collection-result.json',encoded(receipt));print(json.dumps(receipt))


if __name__=='__main__':main()
