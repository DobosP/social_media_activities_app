# Inbox compact custody V4 source proposal

V4 is authored by notification_actual_review, who cannot independently accept it.
At this authoring checkpoint, another agent's exact collector/config review and
actual final qualification are pending. The explicit final binding must carry
that peer's approval before use; the author proof records proposal-time status.
Exact V3 approval0500 and every other V3 top file were preserved in history-v3
before these changes. That earlier source/hash cannot admit V4. V1/V2 are intact.

Final source is committed 496056a6a528d01d544abbf77e18877b60d629bd,
tree28b3d96d48e13b3e9befaa7ec7ab780130453363, source census2215.
Actual final complete-seven counts/results/reviews and final UI/benchmark
bindings are still null. No final success, prepare, collection or deletion has
been executed by this author. Only AST/source/data checks have run.

Mandatory separate history consists of:
- f087 web-only/App assertion FAIL,5cleanup roles, no App conversion.
- 0e31 six-suite PASS442/1327 then notifications reference FAIL before native,
 14cleanup roles and six qualified database retirements.
- Accepted3e complete-seven PG446/1338,340commands/695artifacts and5dfcd review,
 solely that PG/source/capture/cleanup epoch; its primary UI failed.
- First primary3e UIbd606:6JS6noJS/31previous bodies,12 link-in-text-block
 violations, benchmark requested/not reached. All71 raw artifacts are physical.
- Candidate underline diagnostic0177: globally FAIL exactly12 unchanged old-CSS
 asset guards,18 strict Axe audits clean, no benchmark. The report and all24
 original PNGs are selected explicitly with full original archive metadata;
 generic packet traversal skips this output directory and selects no PNG tree.

The earliest-read raw/full validated-stat registry remains unchanged. Known
complete/incomplete run entries are fenced against exactly the above PG/UI
attempts plus the final same-source runs. An extra attempt requires explicit
new source/selection review. Every current final PG/UI/capture/benchmark must
join the exact final SHA and clean Git source; no bridge exception, omission,
cap increase, test relaxation or historical failure promotion is allowed.

Root must bind actual successful final results and independent PG/UI/V4-method
reviews, review the exact prepared selection, then run collection. Full archive
bytes/mode/UID/GID/nsmtime readback, final input/source/history rechecks and
independent keeper/feature acceptance remain required. No DB/workspace/binary/
cache/profile duplication or deletion is introduced. Prior preference29a9 is
a pinned canonical dependency. No full21/main/milestone/production/provider/
government/real-child activation is authorized.
