# Social inbox assembly checkpoint — no product authored

Root requested pause to free the priority Teacher keeper reviewer slot. Accepted
contract copied into accepted-contract-e900; clean05e5 rebind.json proves runtime
and all287 original test files/6,878 assertion-call mentions unchanged from e900.
Only18 closing docs/keeper paths differ. No owning write, runtime or product code.

App child /root/next_ui_inventory/social_inbox_app_source continues independently
under app-author/. It proposes one standalone TestNative... root with six finite
leaves; Social uses automatic test discovery, no fictitious central registration.
It forwards the existing Web.API exact unversioned GET once from the successful
registered real-cookie App call and narrows display fields, no second private
query. It will preserve direct httptest App HEAD semantics; wire stripping is a
separate net/http server behavior and must not be invented in direct-handler proof.

Renderer design decided:
- New notification_inbox_native.go + pages/notification-inbox.gohtml + scoped
  static/css/notification-inbox-native.css; no old asset or producer edits.
- Cache only parsed template/immutable strings. Per-request typed rows/copy/shell
  use current trusted Actor, not AccountView-only user.id/is_active requirements.
  notificationPage supplies only items; Renderer default user lacks those keys.
- Body class="notification-inbox-native". Article data-notification-row="" plus
  data-notification-unread="true|false". h2 data-notification-title=""; optional p
  data-notification-body=""; small data-notification-why=""; time
  data-notification-time="" datetime=<same admitted timestamp's Bucharest RFC3339>;
  optional a data-notification-link="". App child agreed on these exact markers.
- Same native preferences header/footer navigation/scripts/nonce/display choices,
  new page scoped opaque header/intrinsic menu width as already proven in prefs.
  Base.css untouched. Mark-all POST only when rows exist, including all-read case;
  fixed settings link always. No invented unread total, cursor or per-item action.
- Original Why message key is "Why you got this: %(why)s". Translate only chrome
  via current catalogue, html.UnescapeString before plain GoHTML escaping; substitute
  the plain dynamic reason into translated key, never safe HTML. Keep dynamic
  title/body/reason raw admitted text, unknown reason optional. Exact djangoDate
  j M H:i Europe/Bucharest behavior, not SPA date/localized month variants.
- Strict href predicate copied literally from templates.go safe_href (url.Parse,
  no User, raw CR/LF/backslash rejection; local / not // OR Scheme http/https).
  Unsafe link suppressed while content remains. GoHTML contextual escaping too.

Dispatcher insertion point must preserve old literal mutation cutpoints. Insert
one new branch immediately BEFORE current notification_preferences branch, never
between that branch and group_detail, and never before the family-first `if`:

```
} else if name == "web/notifications.html" {
    raw, renderErr := r.renderNotificationInbox(request, defaults)
    if renderErr != nil { return renderErr }
    _, _ = output.Write(raw)
} else if name == "web/notification_preferences.html" {
```

Expected custody seam design (not implemented or accepted yet):
1. NEW strict notificationInboxSourcePreimage for exact whole new renderer → exact
   current6349B/367b05a8... renderer, unique new branch and full before/after hashes.
   New tests must reject missing/duplicate/modified branch, extra LF and previous
   current epoch; no rendering panic or no-op mutation admitted.
2. A NEW notificationInboxPriorSource permits that exact recovered old renderer
   only in explicitly retained old control paths, never as a physical live tuple.
3. Minimal reader adapter at start of notificationPreferencesSourcePreimage in
   notification_preferences_custody_test.go to invoke new PriorSource before its
   unchanged existing source relation. Non-renderer paths unchanged. Existing
   tests/source rows/pins remain exact under a closed inverse of this addition.
4. In group_create_source_guard_test.go, renderer live source path requires strict
   NEW source inverse after its existing physical tuple check, then feeds recovered
   old6349 bytes to unchanged notification/preferences→group→family/historical chain.
   This prevents rehashed former6349 bytes pretending to be physical current.
5. gui_public_get_walk_test.go can likely remain byte-exact: its current reader
   already calls notificationPreferencesSourcePreimage; extend through that seam.
   Group_detail/Family current source relations can likewise remain unchanged.
   Confirm all mutation controls/inverse chains by source analysis before review.

Do not add a frozen-Pongo inbox adapter speculatively. Existing ordinary inbox
assertion found is preferences_case_port2_test.go “Why you got this” and can check
actual new native body unchanged. Existing sealed public transport cases do not
appear to include authenticated inbox; confirm registry/source applicability.
If an exact old inbox template-loader predicate is found, isolate a labeled
reference helper and closed reader-only journal; it must not become native proof.

Pure fixtures to implement: empty-en, one-unread-ro, mixed-en, all-read-ro,
escaped-ro, unsafe-links-en with contrast/larger/reduced-motion combinations.
Extra pure malformed required rows/shell/no-Actor, unsafe-URL matrix, exact date,
old default-user shape admission, private-field exclusion, copy/row ownership,
headers/CSP/nonce/assets, strict production dispatcher. All31 prior native bodies
must stay byte-exact. Independent source review before application/runtime.
