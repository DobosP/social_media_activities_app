from pathlib import Path
import hashlib,json
repo=Path('/home/dobo/work/_worktrees/social_media_activities_app/feat__gui-app-migration-a');root=Path(__file__).resolve().parent;out=root/'proposed';web='services/server/internal/web/'
def sha(raw):return hashlib.sha256(raw).hexdigest()
renderer_before=(repo/(web+'renderer.go')).read_text();renderer_after=(out/(web+'renderer.go')).read_text()
renderer_literal_before='\t} else if name == "web/notification_preferences.html" {'
renderer_literal_after='\t} else if name == "web/notifications.html" {\n\t\traw, renderErr := r.renderNotificationInbox(request, defaults)\n\t\tif renderErr != nil {\n\t\t\treturn renderErr\n\t\t}\n\t\t_, _ = output.Write(raw)\n'+renderer_literal_before
assert renderer_before.count(renderer_literal_before)==renderer_after.count(renderer_literal_after)==1
journal=[]
def adapt(name,before,after):
 path=web+name;raw=(repo/path).read_text();assert raw.count(before)==1;result=raw.replace(before,after,1);assert result.count(after)==1 and result.replace(after,before,1)==raw
 (out/path).write_text(result);journal.append({'path':path,'before_sha256':sha(raw.encode()),'after_sha256':sha(result.encode()),'before_bytes':len(raw.encode()),'after_bytes':len(result.encode()),'before_literal':before,'after_literal':after,'closed_inverse':True});return raw,result
anchor='func notificationPreferencesSourcePreimage(path string, raw []byte) ([]byte, error) {\n'
adapt('notification_preferences_custody_test.go',anchor,anchor+'\t// Retained prior controls may enter on the exact recovered inbox preimage.\n\tvar inboxErr error\n\traw, inboxErr = notificationInboxPriorSource(path, raw)\n\tif inboxErr != nil {\n\t\treturn nil, inboxErr\n\t}\n')
anchor='\tprevious := raw\n\tvar err error\n'
adapt('group_create_source_guard_test.go',anchor,anchor+'\t// Live tuples require the complete newest inbox source before old inverses.\n\tif path == "services/server/internal/web/renderer.go" || path == "services/server/internal/web/gui_public_get_walk_test.go" {\n\t\traw, err = notificationInboxSourcePreimage(path, raw)\n\t\tif err != nil {\n\t\t\treturn guiG1Binding{}, err\n\t\t}\n\t\tprevious = raw\n\t}\n')
anchor='func guiPublicGetRowsPreimage(path string, raw []byte) ([]byte, error) {\n'
walker_before,walker_after=adapt('gui_public_get_walk_test.go',anchor,anchor+'\t// Require the actual newest physical source, then retain the entire old chain.\n\tswitch path {\n\tcase "services/server/internal/web/renderer.go", "services/server/internal/web/gui_public_get_walk_test.go":\n\t\tvar inboxErr error\n\t\traw, inboxErr = notificationInboxSourcePreimage(path, raw)\n\t\tif inboxErr != nil {\n\t\t\treturn nil, inboxErr\n\t\t}\n\t}\n')
walker_literal_after=journal[-1]['after_literal'];walker_literal_before=journal[-1]['before_literal']
relations=[{'path':web+'renderer.go','before_raw':renderer_before,'after_raw':renderer_after,'before_literal':renderer_literal_before,'after_literal':renderer_literal_after},{'path':web+'gui_public_get_walk_test.go','before_raw':walker_before,'after_raw':walker_after,'before_literal':walker_literal_before,'after_literal':walker_literal_after}]
header='''package web

import (
 "bytes"
 "fmt"
 "os"
 "path/filepath"
 "testing"
)

// Newest source custody only. Physical readers require the exact full current
// afterimage. Only explicitly retained controls consume its recovered old epoch.
func notificationInboxSourceRelation(path string) (beforeSHA, afterSHA string, beforeBytes, afterBytes int, before, after string, ok bool) {
 switch path {
'''
for row in relations:
 before,after=row['before_raw'].encode(),row['after_raw'].encode();header+=' case '+json.dumps(row['path'])+':\n  return '+', '.join([json.dumps(sha(before)),json.dumps(sha(after)),str(len(before)),str(len(after)),json.dumps(row['before_literal']),json.dumps(row['after_literal']),'true'])+'\n'
header+=''' }
 return "", "", 0, 0, "", "", false
}
func notificationInboxSourcePreimage(path string, raw []byte) ([]byte, error) {
 beforeSHA, afterSHA, beforeBytes, afterBytes, before, after, ok := notificationInboxSourceRelation(path)
 if !ok || len(raw)!=afterBytes || guiPublicHash(raw)!=afterSHA || bytes.Count(raw,[]byte(after))!=1 { return nil,fmt.Errorf("inbox-complete-current-source") }
 previous:=bytes.Replace(append([]byte(nil),raw...),[]byte(after),[]byte(before),1)
 if len(previous)!=beforeBytes || guiPublicHash(previous)!=beforeSHA { return nil,fmt.Errorf("inbox-exact-source-preimage") }
 return previous,nil
}
func notificationInboxPriorSource(path string, raw []byte) ([]byte, error) {
 beforeSHA,_,beforeBytes,_,_,_,ok:=notificationInboxSourceRelation(path)
 if !ok { return append([]byte(nil),raw...),nil }
 if len(raw)==beforeBytes && guiPublicHash(raw)==beforeSHA { return append([]byte(nil),raw...),nil }
 return notificationInboxSourcePreimage(path,raw)
}

func TestNativeNotificationInboxCustodyRetainsEveryOriginalAuthority(t *testing.T) {
 root,err:=filepath.Abs("../../../..")
 if err!=nil {t.Fatal(err)}
 var registry guiPreferenceGETRegistry
 if guiG1StrictJSON(guiPreferencesGETRegistryBytes,&registry)!=nil {t.Fatal("immutable preference registry unavailable")}
 for _,path:=range []string{"services/server/internal/web/renderer.go","services/server/internal/web/gui_public_get_walk_test.go"} {
  physical,err:=os.ReadFile(filepath.Join(root,path))
  if err!=nil {t.Fatal(err)}
  before,err:=notificationInboxSourcePreimage(path,physical)
  if err!=nil {t.Fatal("new whole-source inverse refused",path,err)}
  _,_,_,_,_,after,_:=notificationInboxSourceRelation(path)
  historical,err:=guiPublicGetRowsPreimage(path,physical)
  if err!=nil {t.Fatal("new plus complete original chain refused",path,err)}
  old,err:=notificationPreferencesSourcePreimage(path,before)
  if err!=nil {t.Fatal("explicit old control epoch unavailable",path,err)}
  current,err:=notificationPreferencesSourcePreimage(path,physical)
  if err!=nil || !bytes.Equal(old,current) {t.Fatal("new inverse changed a previous authority",path,err)}
  for name,changed:=range map[string][]byte{
   "previous-is-not-physical":before,
   "unrelated-LF":append(append([]byte(nil),physical...),'\\n'),
   "truncated":physical[:len(physical)-1],
   "missing-literal":bytes.Replace(physical,[]byte(after),nil,1),
   "duplicate-literal":append(append([]byte(nil),physical...),[]byte(after)...),
   "modified-literal":bytes.Replace(physical,[]byte(after),[]byte(after+" "),1),
  } {
   t.Run(filepath.Base(path)+"/"+name,func(t *testing.T){
    if bytes.Equal(physical,changed) {t.Fatal("source mutation became a no-op")}
    if _,err:=notificationInboxSourcePreimage(path,changed);err==nil {t.Fatal("unsupported newest source admitted")}
    if _,err:=guiPublicGetRowsPreimage(path,changed);err==nil {t.Fatal("old/rehashed source admitted as physical live input")}
    binding:=guiG1Binding{len(changed),guiPublicHash(changed),0o100644}
    if _,err:=groupCreatePreferenceSourceBinding(path,changed,binding,registry.Sources[path]);err==nil {t.Fatal("rehashed old physical tuple admitted")}
    again,err:=guiPublicGetRowsPreimage(path,physical)
    if err!=nil || !bytes.Equal(again,historical) {t.Fatal("negative probe changed the current source",err)}
   })
  }
 }
 inputs,err:=guiPreferenceGETInputs(root,registry)
 if err!=nil || len(inputs)!=138 {t.Fatal("all138 real current physical tuples must remain",err)}
 for path,binding:=range inputs {
  _,actual,err:=guiCurrentTransportReadBinding(root,path,2<<20)
  if err!=nil || binding!=actual {t.Fatal("historical tuple substituted for current physical input",path,err)}
 }
 rows:=guiPublicGetRepairRows()
 if len(rows)!=32 || len(groupDetailPreviousRepairRows(rows))!=31 || len(groupCreatePreviousRepairRows())!=27 {t.Fatal("all old32/31/27 control inventories must remain")}
}
'''
(out/(web+'notification_inbox_custody_test.go')).write_text(header)
(root/'exact-reader-inverses.json').write_text(json.dumps({'schema':1,'scope':'Only three old byte-reader adapters; all assertion bodies and old source relations/literals remain unchanged. New strict physical reader covers renderer and walker; explicit prior helper is control-only.','rows':journal},indent=2)+'\n')
print({'new_renderer_bytes':len(renderer_after.encode()),'new_renderer_sha256':sha(renderer_after.encode()),'new_walker_bytes':len(walker_after.encode()),'new_walker_sha256':sha(walker_after.encode()),'old_reader_files':len(journal)})
