# Source-only App HTTP packet

One new App test file, one ordinary registered root and six finite leaves. This is
an authored source proposal; no formatter, compiler, test, product runtime,
PostgreSQL, browser, network, deletion or owning-repo write was run by this author.
Root must assemble the product, independently review the complete packet, format
new Go source and qualify the exact committed successor before making any success
claim. No existing test or assertion is changed; Social has no central test
registry, so no registry diff is needed.

The test reuses newGroupNativeAppFixture only as the existing assembled App and
one expensive password-hash source. The peer receives a copy of that synthetic
hash and separately logs in through the real password endpoint and real rotated
cookies. Every protected HTTP request passes through App.ServeHTTP; the test does
not call WithActor or construct sessions for HTTP admission. Direct-handler HEAD
retains current httptest semantics and makes no wire-level body claim.

The primary own fixture contains104 notices and three newer foreign notices.
Row0 has a newer timestamp than its later IDs; other rows share timestamp pairs.
Expected first100 =0,103..5. Exactly35 own rows begin unread; row3 is unread and
outside the displayed bound. Mark-all must update all35 and preserve all foreign
rows, delivery preferences, existing read timestamps and audit count. A generated
unread SQL-failure row remains after the failure control and becomes first in the
later capture; this is one owned synthetic fixture, never real user content.

The final registered EN/RO GETs wrap the existing Web.API callback for exact
GET /api/notifications/, forward its original handler once, then whitelist only
title, body, reason→why, created_at, strict-safe url and boolean read-presence→
read_at. The original response is forwarded unchanged. No second private query
or API fetch is used for capture. No actor, IDs, raw JSON extras, credentials,
sessions, CSRF, nonce, DB rows or HTTP bodies are logged. Unsafe URLs become empty
in the display capture while the preceding actual HTML assertions prove original
unsafe records retain visible content without a link. The one bounded marker is
emitted only after all six leaves and both registered captures succeed.

DOM design agreed with parent: body.notification-inbox-native, linked scoped
/static/css/notification-inbox-native.css; article[data-notification-row=""] with
data-notification-unread=true|false; h2[data-notification-title=""]; optional
p[data-notification-body=""], small[data-notification-why=""],
time[data-notification-time=""][datetime] and a[data-notification-link=""]. No raw
notification ID or posted recipient control is allowed. Header/default account
fields are not assumed beyond current Renderer output; actor authority remains
request-derived. Date proof uses existing15 Jan14:00 Bucharest semantics; later
pure coverage owns the complete URL matrix and malformed projections.

A trigger on this test's private cloned notifications table causes the real
single read-all UPDATE to fail; the test asserts unchanged notices and generic
503 without false success. A separate forwarded callback control verifies source
failure status/body/Retry-After/custom-header propagation for ordinary and fetch
POSTs. This is labeled synthetic causal failure proof, not an external outage.

Current role/cohort/verification fields are temporarily changed in the existing
synthetic active account to prove no adult/guardian/participation gate was added;
then restored. A current inactive account and an actually expired independently
logged-in peer cookie must lose both read and write admission. These fixtures do
not certify minor identity, consent, government access or production readiness.
SPA/_data remains a separately protected source branch and retains its current
six-field projection and ordinary POST303 behavior; it is not hardened here.
