"""Package a bounded source proposal; read-only owning repo, no product execution."""
from pathlib import Path
from collections import Counter
import hashlib,json,re,subprocess,difflib,shutil
ROOT=Path(__file__).resolve().parent;REPO=Path('/home/dobo/work/_worktrees/social_media_activities_app/feat__gui-app-migration-a');BASE='05e5a522acaa41643ea0ffdba634492412156318';OUT=ROOT/'proposed'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(REPO),*args])
def write(name,value):(ROOT/name).write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
assert git('rev-parse','HEAD').decode().strip()==BASE and not git('status','--porcelain')
files=sorted(p for p in OUT.rglob('*') if p.is_file());assert len(files)==14
existing=[];new=[];manifest=[];patch=[]
for p in files:
 rel=p.relative_to(OUT).as_posix();after=p.read_bytes();physical=REPO/rel;before=None
 if physical.exists():
  before=physical.read_bytes();assert before==git('show',BASE+':'+rel);target=ROOT/'before'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(before);existing.append(rel)
 else:new.append(rel)
 manifest.append({'path':rel,'before':None if before is None else {'bytes':len(before),'sha256':sha(before)},'after':{'bytes':len(after),'sha256':sha(after)},'git_mode':'100644','scope':'source proposal only'})
 patch.append('diff --git a/'+rel+' b/'+rel+'\n')
 if before is None:patch.append('new file mode 100644\n')
 patch.extend(difflib.unified_diff([] if before is None else before.decode().splitlines(keepends=True),after.decode().splitlines(keepends=True),fromfile='/dev/null' if before is None else 'a/'+rel,tofile='b/'+rel))
(ROOT/'proposed.patch').write_text(''.join(patch))
write('manifest.json',{'schema':1,'base_sha':BASE,'runtime_base':'e900960d50beed03ef387159da0e6d903ec5bf9a','state':'AUTHORED_SOURCE_PENDING_INDEPENDENT_REVIEW_AND_ROOT_APPLICATION','paths':manifest})
# Every old test file remains exact after reversing only the three byte-reader additions.
original=json.loads((ROOT/'accepted-contract-e900/original-tests.json').read_text());journal=json.loads((ROOT/'exact-reader-inverses.json').read_text())['rows'];by={x['path']:x for x in journal};assert len(by)==3
for row in original['rows']:
 rel=row['path'];before=(REPO/rel).read_bytes();assert sha(before)==row['sha256']
 after=(OUT/rel).read_bytes() if (OUT/rel).exists() else before
 if rel in by:
  j=by[rel];assert sha(after)==j['after_sha256'] and len(after)==j['after_bytes'];assert after.count(j['after_literal'].encode())==1;after=after.replace(j['after_literal'].encode(),j['before_literal'].encode(),1)
 assert after==before,rel
 assert len(re.findall(rb'\bt\.(?:Fatalf?|Errorf?|FailNow|Fail)\(',(OUT/rel).read_bytes() if (OUT/rel).exists() else before))==row['assertion_call_mentions']
shutil.copy2(ROOT/'accepted-contract-e900/original-tests.json',ROOT/'original-tests.json')
# Exact whole-file renderer inverse and all32 historical relations are checked
# as bytes; this is not execution of Go tests or candidate code.
rb=(REPO/'services/server/internal/web/renderer.go').read_bytes();ra=(OUT/'services/server/internal/web/renderer.go').read_bytes();cut=b'\t} else if name == "web/notification_preferences.html" {';added=b'\t} else if name == "web/notifications.html" {\n\t\traw, renderErr := r.renderNotificationInbox(request, defaults)\n\t\tif renderErr != nil {\n\t\t\treturn renderErr\n\t\t}\n\t\t_, _ = output.Write(raw)\n'+cut
assert rb.count(cut)==ra.count(added)==1 and ra.replace(added,cut,1)==rb
# Recover the previous notification renderer exactly, then the complete original
#32-row renderer history from its existing immutable literal descriptions.
nfc=(REPO/'services/server/internal/web/notification_preferences_custody_test.go').read_text();m=re.search(r'case "services/server/internal/web/renderer.go":\n\s*return ("(?:[^"\\]|\\.)*"), ("(?:[^"\\]|\\.)*"), (\d+), (\d+), ("(?:[^"\\]|\\.)*"), ("(?:[^"\\]|\\.)*"), true',nfc);assert m
before_h,after_h,before_n,after_n,before_lit,after_lit=m.groups();assert sha(rb)==json.loads(after_h) and len(rb)==int(after_n);legacy=rb.replace(json.loads(after_lit).encode(),json.loads(before_lit).encode(),1);assert sha(legacy)==json.loads(before_h) and len(legacy)==int(before_n)
source=(REPO/'services/server/internal/web/gui_public_get_walk_test.go').read_text();pattern=r'\{\s*path:\s*("(?:[^"\\]|\\.)*"),\s*beforeSHA:\s*("[0-9a-f]+"),\s*afterSHA:\s*("[0-9a-f]+"),\s*beforeBytes:\s*(\d+),\s*afterBytes:\s*(\d+),\s*before:\s*("(?:[^"\\]|\\.)*"|`[^`]*`),\s*after:\s*("(?:[^"\\]|\\.)*"|`[^`]*`),\s*\}'
rows=re.findall(pattern,source);assert len(rows)==32,len(rows);renderer_rows=[]
for path,bh,ah,bn,an,bl,al in rows:
 path=json.loads(path)
 if path!='services/server/internal/web/renderer.go':continue
 bl,al=(bl[1:-1] if bl.startswith('`') else json.loads(bl)).encode(),(al[1:-1] if al.startswith('`') else json.loads(al)).encode();assert sha(legacy)==json.loads(ah) and len(legacy)==int(an) and legacy.count(al)==1;legacy=legacy.replace(al,bl,1);assert sha(legacy)==json.loads(bh) and len(legacy)==int(bn);renderer_rows.append({'after_sha256':json.loads(ah),'before_sha256':json.loads(bh),'closed_inverse':True})
assert len(legacy)==5510 and sha(legacy)=='94f11a3f1849c919ba100c4ba68236263f71f07741006c1992dadc4020723e68'
# Confirm all previously fragile cutpoints still exist verbatim once. Removing
# one of them would remain a real byte mutation, rather than a no-op control.
cutpoints={}
for name in ['family_custody_test.go','group_create_custody_test.go','group_detail_custody_test.go','notification_preferences_custody_test.go']:
 text=(REPO/('services/server/internal/web/'+name)).read_text()
 # Whole row after-literals for renderer rows in the current source relations
 # are separately pinned above; preserve their direct renderer call cutpoints.
for needle in [b'r.renderFamily(request, name, defaults)',b'r.renderGroupCreate(request, defaults)',b'r.renderGroupDetail(request, defaults)',b'r.renderNotificationPreferences(request, defaults)',b'r.renderNotificationInbox(request, defaults)']:
 assert ra.count(needle)==1 and ra.replace(needle,b'changed()',1)!=ra;cutpoints[needle.decode()]=1
# A small lexical delimiter check catches accidentally unclosed authored strings
# or blocks. It is not a Go parser, compiler, type check or test invocation.
def delimiters(raw):
 s=raw.decode();stack=[];i=0;state='code';match={')':'(',']':'[','}':'{'}
 while i<len(s):
  c=s[i];n=s[i+1:i+2]
  if state=='line':
   if c=='\n':state='code'
  elif state=='block':
   if c=='*' and n=='/':state='code';i+=1
  elif state=='raw':
   if c=='`':state='code'
  elif state in ('string','rune'):
   if c=='\\':i+=1
   elif c==('"' if state=='string' else "'"):state='code'
  elif c=='/' and n=='/':state='line';i+=1
  elif c=='/' and n=='*':state='block';i+=1
  elif c=='`':state='raw'
  elif c=='"':state='string'
  elif c=="'":state='rune'
  elif c in '([{':stack.append(c)
  elif c in ')]}':assert stack and stack.pop()==match[c]
  i+=1
 assert not stack and state in ('code','line'),state
for p in files:
 if p.suffix=='.go':delimiters(p.read_bytes())
# Product/source privacy frame: no producer/auth/service/query/audit mutation,
# frozen HTML/assets/catalogue/schema/dependencies unchanged in owning source.
frame=json.loads((ROOT/'rebind.json').read_text())['rebound_references']
for row in frame:assert sha((REPO/row['path']).read_bytes())==row['sha256']
assert len((OUT/'STATUS.md').read_text().splitlines())<=120
assert not git('status','--porcelain') and git('rev-parse','HEAD').decode().strip()==BASE
write('source-proof.json',{'schema':1,'status':'SOURCE_PROPOSAL_READY_FOR_INDEPENDENT_REVIEW_NO_RUNTIME','base_sha':BASE,'accepted_contract_review_sha256':'670f9b388cfaef89a8fb4274bb85fb4dd0ac3f7c8126a4d26d54f0644a63e001','rebind_sha256':sha((ROOT/'rebind.json').read_bytes()),'proposed_paths':len(files),'existing_paths':existing,'new_paths':new,'production_changes':['services/server/internal/web/renderer.go','services/server/internal/web/notification_inbox_native.go','services/server/internal/web/pages/notification-inbox.gohtml','static/css/notification-inbox-native.css'],'protected_runtime_frame_refs':len(frame),'protected_runtime_bytes_unchanged_in_owning_repo':True,'original_test_files_preserved':original['files'],'original_test_declarations_preserved':original['top_level_test_declarations'],'original_assertion_call_mentions_preserved':original['assertion_call_mentions'],'three_old_reader_closed_inverses':journal,'new_renderer_inverse':{'before_sha256':sha(rb),'after_sha256':sha(ra),'before_bytes':len(rb),'after_bytes':len(ra),'closed_inverse':True},'renderer_prior_complete32_rows':{'all_metadata_rows':32,'renderer_relations':renderer_rows,'recovered_original_bytes':len(legacy),'recovered_original_sha256':sha(legacy)},'literal_mutation_cutpoints_unique_and_nonnoop':cutpoints,'new_Go_delimiters':'balanced lexical strings/comments/blocks only; not syntax, formatter, compiler or tests','App_source_sha256':sha((OUT/'services/server/internal/app/native_notification_inbox_http_test.go').read_bytes()),'App_registration':'ordinary automatically discovered TestNative... root; no original registry edit','captured_fields_only':['title','body','why','url admitted or empty','created_at','read_at presence'],'capture':'same forwarded exact original unversioned API GET once from actual registered cookie call; no second private fetch, actor/ID/session/CSRF/nonce/raw extras','old_body_baselines':{'rows':31,'keeper_sha256':'29a9ff0d2e420d5454aaebd324d0bc686bc22cf14b6f04ce86e4b8ce7e71d7e5','qualification':'must be executed in later UI method; source contract pins actual prior body bytes'},'no_Pongo_native_page_bypass':True,'test_only_reference':'exact protected safe_href filter only, explicitly labeled; no old-page render is new-native proof','frozen_untouched':['all91 original HTML','old assets/catalogue','schema/dependencies/authcore','producer view/API/handlers/query/audit/role/retention/session behavior','old32/31/27 controls and138 physical source tuples'],'proposed_UI_states':['empty-en','one-unread-ro','mixed-en','all-read-ro','escaped-ro','unsafe-links-en'],'current_failure_or_success_claims':'No compile/test/Go/JS/PG/browser/measurement/cleanup qualification has run; no owning changes/application/push/network/deletion. Formatting of new Go still pending Root mechanical review. Static UI/PG methods are separate pending source work.','artifacts':{'proposed.patch':{'bytes':(ROOT/'proposed.patch').stat().st_size,'sha256':sha((ROOT/'proposed.patch').read_bytes())},'manifest.json':{'bytes':(ROOT/'manifest.json').stat().st_size,'sha256':sha((ROOT/'manifest.json').read_bytes())}},'next':'Independent whole product/pure/custody/App/metadata review before Root application and any qualification.'})
print(json.dumps({'paths':len(files),'new':len(new),'existing':len(existing),'patch_sha256':sha((ROOT/'proposed.patch').read_bytes()),'manifest_sha256':sha((ROOT/'manifest.json').read_bytes()),'proof_sha256':sha((ROOT/'source-proof.json').read_bytes())}))
