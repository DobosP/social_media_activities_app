# Social notification inbox — whole source packet for review

Status: authored source only, ready for independent whole-packet review before
Root application. No product compiler/formatter/tests, database, browser, network,
measurement, owning write or deletion ran. Root remains the only owning writer.
New Go files still need the ordinary mechanical formatting/application review.

Accepted source contract review670f9b38 is retained in accepted-contract-e900.
Rebind07ef1b14 proves clean published05e5a522 and its18 docs/keeper-only differences
from runtimee900960,133 current/Git refs, all287 old test files/854 declarations/
6,878 assertion-call mentions, and31 old body references from immutable29a9ff.

proposed.patch + manifest.json contain14 paths: four presentation production paths,
three old byte-reader additions, three NEW Go test files and four proposal docs.
There is no API/view/handler/service/query/audit/session/auth/schema/dependency/
locale/old-asset/original-template change. No central App registration is changed;
Social's ordinary TestNative... declaration is its registration.

Read new notification_inbox_native.go, pages/notification-inbox.gohtml and scoped
notification-inbox-native.css first. Parsed templates are cached; actor/default
shell and rows/copy are per request. The producer supplies only items, so no
AccountView-only user.id/is_active contract is invented. Only admitted display
fields are copied; no raw IDs/private maps enter HTML. Strict original safe_href,
Bucharest j M H:i, current source100/order, reason/read-presence/optional fields,
all-row mark-all and current private headers/nonce/assets/SPA remain. No fresh
age/guardian/MFA/verification prerequisite or unread total/cursor is added.

The NEW pure fixture suite has six finite EN/RO/comfort/escape/link states, strict
required-shape refusal, per-request ownership, exact original URL filter comparison
and date/DST/default-shell/CSP checks. The filter reference is explicitly labeled
test-only. It is not a frozen Pongo page rendering or current-native authority
proof. No speculative old inbox page bypass was introduced: the existing ordinary
“Why you got this” assertion can still inspect actual native markup.

The App child authored one NEW standalone root with six finite leaves; its source
9e8b3a07 and packet/proof are in app-author. It uses current App middleware and real
rotated login cookies, tests self-only100/order/no-write GET, beyond100/idempotent
mark-all/foreign isolation, CSRF/Origin/stale/inactive/cohort and source method/SPA/
fetch/errors. Direct httptest HEAD is distinguished from network wire suppression.
The final display capture forwards the exact same original API callback once and
copies only approved strings/timestamp/read presence; no second private fetch,
Actor/IDs/session/CSRF/nonce/raw record is logged. No product test has run yet.

Custody is deliberately strict at live reader boundaries. New current renderer
6535B/f7d5a2ea and walker63161B/1e2b7e65 invert to exact former6349/367b05a8 and
62819/ba643be2 before the unchanged prior chains. Three insertion journals in
exact-reader-inverses.json reverse byte-for-byte to every old test file; original
assertions and32/31/27 relations remain. The new strict tests refuse old/rehashed,
missing/duplicate/modified/truncated/LF inputs. Source checks prove all literal
render call cutpoints remain unique/non-noop, and every one of the32 prior metadata
rows remains; renderer inverses reach exact original5510B/94f11a3f. The guarded
prior-epoch helper is explicitly for old controls, never a physical live tuple.

assemble-source.py checks full before/after bytes, old test inversion and assertion
mentions, exact prior renderer hash chain and basic lexical delimiter balance.
Those are source identity checks, not Go syntax/type checking, compilation, a
runtime test pass or functional acceptance. before/ retains only six changed
original files; proposed/ retains only14 source paths, with no workspace/cache/
DB/binary copies. No previous print collector or Teacher files were changed.

ADR0065/execplan/index/STATUS all say proposal and pending actual qualification.
The ADR namespace is free on05e5, STATUS remains120 lines. Independent source review
must close product/custody/App capture/metadata findings before Root applies it.
Static PG/UI reproduction methods are separate pending source work, including
complete affected6 protocol plus complete notifications with a fresh explicit DSN,
all31-body equality, desktop/no-JS/Axe/keyboard/source assets and optional matched
measurements. No main/milestone/production/provider/government/real-child authority
or generalized efficiency improvement is claimed.
