# Native notification inbox — source contract proposal

Read-only source proposal for runtime e900960d50beed03ef387159da0e6d903ec5bf9a.
Social notification keeper metadata currently exists as pending promotion work;
its actual byte/Git status is recorded separately, never as part of e900 runtime.
Independent contract review and current notification closure/rebinding precede
application. No implementation, tests/compiler/browser, PG/network or owning edits.

Scope: cached typed GoHTML replacement for existing web/notifications.html at
GET/HEAD `/notifications/`; retain POST `/notifications/read-all/` as the existing
mark-all form action. Existing native preferences stay at `/notifications/preferences/`.
No new route, per-notice HTML action, unread filter, cursor, mark-on-view, push,
email, background polling, AI or browser-engine requirement. No schema change.

Current chain: typed legacy router → page → view/notificationPage → s.get of exact
`/api/notifications/` → s.call/current API → notifications.list. Protected producer
already authorizes current active actor, queries recipient_id=self, orders by
created_at DESC,id DESC, fetches limit+1 and returns first 100 for unversioned path.
HTML query parameters are not forwarded by notificationPage. Keep the returned
order/100-row bound, current unread count semantics and distinct versioned API
cursor/filter behavior; do not silently switch HTML to /api/v1 or invent pagination.
The current view drops API unread_count and passes only items; do not invent a
page-wide unread total or confuse first 100 rows with the entire inbox.

Unlike AccountView, current notificationPage supplies only items; Renderer defaults do
not contain account-row id/is_active fields. Build identity from the already trusted
request Actor and existing shell defaults. Do not reuse a family projector that
requires AccountView-only user fields, add queries or silently invent a producer
contract. CSRF/nonce/site/display fields still come from the existing render chain.

The view copies API records, aliases reason→why and maps is_read=true to read_at
presence; unread read_at stays nil. Keep this distinction without fabricating
read timestamps. New VM uses only title, optional body/why, created_at, safe URL
and read/unread state; no recipient identity, raw payload or arbitrary API fields.
Reason strings come from exact embedded notifications/reasons.json; unknown kind
has no reason. Do not localize dynamic event title/body/reason through invented
strings, infer consent/custody from a notice, or expose other recipients.

Presentation: one h1; meaningful empty state; settings link always; mark-all form
when items exist (even if all read), normal read/unread notices, title/body/reason,
created time and “view” only for an admitted URL. Exact original “Why you got this:
…” semantics and source catalogue strings remain. Use current catalogue entries
for EN/RO chrome; all native copy/parameter substitution is escaped. A DOM time
attribute may be derived solely from the same admitted timestamp. Date output
keeps current djangoDate(...,"j M H:i") Europe/Bucharest semantics, including the
current English month abbreviations; no switch to SPA's other token/localization.
No permanent truncation, hidden safety text or forced motion to pass layout/Axe.

URL admission must match the STRICT original safe_href implementation in
web/templates.go, never weaker spaSafeHref. url.Parse must succeed, User must be
nil, raw CR/LF/backslash forbidden, and raw local-leading-/ but not// OR parsed
scheme http/https. Preserve existing admitted spelling; do not create new scheme,
userinfo, protocol-relative, javascript/data/mailto or browser-normalized bypasses.
Unsafe URLs suppress the link while keeping notice content visible. Test safe
local/http/https and unsafe/malformed/userinfo/slash/CRLF/backslash inputs directly;
GoHTML's contextual escaping remains an additional layer, not the sole policy.

Read-all is already actionSpec POST `/api/notifications/read-all/`, return route
notifications. Common action verifies logged actor, parses form and checks CSRF;
s.call preserves request actor/context and API admission. Service readAll updates
only recipient_id=self AND read_at IS NULL in one SQL statement, returns actual
marked_read count and is idempotent. It also marks rows beyond the displayed 100;
copy must say “all,” never “this page.” Do not accept posted recipient/notice IDs
or ignore source failures. Preserve fetch JSON response `{marked_read,ok:true}`
for X-Requested-With:fetch, ordinary 303 redirect and propagated errors/headers.
There is no current extra audit call or new explicit transaction wrapper here;
retain that behavior, rather than silently changing failure/audit policy.

Admission remains current active account only; no adult/guardian/verified-age/
verified-email/cohort/MFA prerequisite is added through the renderer. Keep authcore
snapshot, cookie/Origin/Referer/form CSRF admission, stale/inactive account checks,
private response/Vary, nonce/CSP enforcement choice and assets. Anonymous GET/HEAD
retain login redirect with safe current next; anonymous mark-all keeps existing
/login/ redirect. Router allows notifications GET (HEAD follows), read-all POST;
other methods retain source405/Allow behavior. New templates never create GET
mutations or mark notices read merely because page/assets were requested.

Preserve explicit SPA/_data behavior and output when selected. Its notification
projection and weaker spaSafeHref are protected separate source; this native HTML
slice does not claim SPA hardening or UI parity. No shared source or asset churn:
new scoped page CSS if necessary; retain existing native shell/menu/keyboard,
reading comfort/display cookies and mandatory safe focus/contrast/reduced motion.

Delivery/retention remain unchanged: platform.Notify bypasses optional mutes for
exact system/moderation kinds; mod_alert remains optional. Notification preference
arrival warning stays byte-exact; opening/read-all does not mute arrival notices,
change guardianship/child presence access, or expire presence records. PurgeRead
and jobs retain unread and protected system/moderation records, bounded oldest
read-row removal remains separate. Actual arrival/presence expiry is a different
existing job/service policy and must not be altered or inferred from inbox state.
No new deletion/mute of safety/moderation records or reveal of sensitive reasons.

Proposed six desktop/no-JS fixtures: empty-en, one-unread-ro, mixed-en (including
mandatory/arrival notices), all-read-ro, escaped-ro and unsafe-links-en. Include
contrast/larger/reduced-motion settings in that inventory. Extra pure cases cover
the complete URL matrix and malformed required rows. Method source/inventory
requires independent review before execution. Pure fixtures are display proof, not authenticated
browser or provider proof. Require registered real-cookie App checks for current
actor scope and ordering/100 bound, safe href and no GET mutation, role/cohort
admission preservation, CSRF/Origin/stale/inactive denial, read-all beyond 100,
foreign-recipient isolation, idempotence, propagated failures and existing JSON/
SPA/HEAD/method variants. Protect all old assertions and frozen template/catalogue.

Qualification envelope is source-only: current complete affected six proof is
historical and cannot qualify later source. Reuse its reviewed source-bound
protocol, then also execute complete notifications package with explicit fresh
synthetic domain DSN (existing tests otherwise skip). Review the exact successor
profile/package census and controls before code/application; no source mentions
or synthetic checker receipt becomes runtime proof. No skip/cap/assertion weakening.
Desktop 1280×720/native and no-JS strict Axe/keyboard/positive current asset checks;
all 31 current accepted bodies stay exact: family 8/create 10/detail 7/preferences 6.
Current keeper 29a9ff is immutable reference; promotion/docs remain separate.
Optional matched body benchmark needs actual authorized GET display whitelist,
original aliases, same fixed synthetic render environment/native VM cost, retained
regressions and no generalized throughput/efficiency/speedup claim.

Readiness: Go account/notifications services, native HTTP/DB and local-session
mechanisms exist; source does not demonstrate enabled external delivery, EUDI,
government relationship integration, provider approval or deployed real-child
service. This slice connects none of them and cannot certify compliance. No
clinical/content/retention/privacy-policy expansion, deployment/image/main/Social
milestone, external provider/government or real-child activation is authorized.
