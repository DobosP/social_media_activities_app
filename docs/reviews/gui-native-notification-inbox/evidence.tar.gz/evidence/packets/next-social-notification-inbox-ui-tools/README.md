# Social notification inbox method source packet

Six new paths under `files/tools/gui-native-notification-inbox/`; the complete
patch and before/after manifest contain no owning changes. The new seven-package
PG driver is a separate file. The original six-package driver, four baseline
helpers, DB controls and every product file remain untouched.

`source-proof.json` binds the independently accepted fourteen-path product packet,
contract, immutable runtime controls and canonical keepers. `pg-driver-inverse.json`
records all finite old/new driver seams and recovers the old driver exactly; every
nested safety/lifecycle function and original constant remains byte-identical.
`baseline-bindings.json` independently hashes all31 HTML members in canonical
preference keeper29a9ff without extracting historical output trees.

The source images are authoritative proposals. `adapt-methods.py`, `build-export.py`
and `build-desktop.py` are initial authoring scaffolds; later source corrections
were applied to the images. `finalize-packet.py` regenerates patch/manifest/proof
from the current images and checks driver closure and canonical body hashes.

Only scratch source generation and read-only Git/hash/tar/Python AST work ran.
No compiler, Go, tests, PG, browser, network, dependency operation, owning edit or
deletion ran. Static source checks are not runtime qualification. Independent
method review is required before Root applies or uses any method.
