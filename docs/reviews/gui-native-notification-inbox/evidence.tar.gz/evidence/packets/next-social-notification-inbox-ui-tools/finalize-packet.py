from pathlib import Path
import ast,difflib,hashlib,json,tarfile,subprocess
p=Path(__file__).parent;r=Path('/home/dobo/work/_worktrees/social_media_activities_app/feat__gui-app-migration-a');product=p.parent/'next-social-notification-inbox-implementation';contract=p.parent/'next-social-notification-inbox-contract';d=p/'files/tools/gui-native-notification-inbox'
def H(b):return hashlib.sha256(b).hexdigest()
def F(f):raw=f.read_bytes();return {'path':str(f),'bytes':len(raw),'sha256':H(raw)}
def W(name,v):(p/name).write_text(json.dumps(v,indent=2)+'\n')
files=[];patch=[]
for f in sorted(d.iterdir()):
 assert f.is_file();name=f.relative_to(p/'files').as_posix();raw=f.read_bytes();assert not (r/name).exists();assert raw.endswith(b'\n') and not raw.endswith(b'\n\n');assert all(line.rstrip(b' \t')==line for line in raw.splitlines())
 if f.suffix=='.py':ast.parse(raw.decode(),filename=name)
 files.append({'path':name,'before':None,'after':{'bytes':len(raw),'sha256':H(raw)},'mode':'0644'});patch.append('diff --git a/'+name+' b/'+name+'\nnew file mode 100644\n');patch.extend(difflib.unified_diff([],raw.decode().splitlines(keepends=True),fromfile='/dev/null',tofile='b/'+name))
assert len(files)==6
(p/'source.patch').write_text(''.join(patch));W('manifest.json',{'schema':1,'base_sha':'05e5a522acaa41643ea0ffdba634492412156318','status':'SCRATCH_METHOD_SOURCE_ONLY_NO_RUNTIME','paths':files})
# Preserve exact original six-driver control bodies, constants and closed text inverse.
old=(r/'tools/gui-native-family/qualify.py').read_text();new=(d/'qualify-pg.py').read_text();ot,nt=ast.parse(old),ast.parse(new)
def functions(t,source):return {n.name:ast.get_source_segment(source,n)for n in ast.walk(t)if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
a,b=functions(ot,old),functions(nt,new);same=[]
for name in a:
 if name!='execute':assert a[name]==b[name],name;same.append(name)
constants=['DB_IMAGE','CODEC_IMAGE','DB_BINDING_SHA','DB_ENTRY_SHA','PKG_ROOT','PG','REQUIRED_FAMILY','INSPECT','MIGRATION_SQL','BIND_SQL','REFERENCE_SQL','REFERENCE_SEED','REFERENCE_HELPER','STORAGE_SQL']
def assignments(t):return {n.targets[0].id:ast.dump(n.value,include_attributes=False)for n in t.body if isinstance(n,ast.Assign)and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
oa,na=assignments(ot),assignments(nt)
for n in constants:assert oa[n]==na[n],n
changes=[]
for tag,i,j,k,l in difflib.SequenceMatcher(a=old.splitlines(keepends=True),b=new.splitlines(keepends=True),autojunk=False).get_opcodes():
 if tag!='equal':changes.append({'kind':tag,'old_line':i+1,'new_line':k+1,'before':''.join(old.splitlines(keepends=True)[i:j]),'after':''.join(new.splitlines(keepends=True)[k:l])})
recovered=new
for row in reversed(changes):
 if row['after']:assert recovered.count(row['after'])==1,(row['new_line'],'nonunique inverse seam');recovered=recovered.replace(row['after'],row['before'],1)
 else:raise AssertionError('deletion-only PG driver change forbidden')
assert recovered==old
W('pg-driver-inverse.json',{'schema':1,'status':'SOURCE_ONLY_NOT_EXECUTED','original':F(r/'tools/gui-native-family/qualify.py'),'new':F(d/'qualify-pg.py'),'closed_inverse_sha256':H(recovered.encode()),'all_original_functions_except_execute_byte_exact':same,'all_original_constants_exact':constants,'changes':changes,'retained_controls':'all resource caps, call/child timeouts, observe/create/remove/readiness, source/Git/export/hash, catalogue bootstrap/bindings, parse_tests, OID retirement/checkpoints, PG cleanup unchanged; only seven-lane extension, new committed driver input/path and finite required-root/exact cleanup census additions'})
# All 31 accepted HTML bytes are directly accessible in current canonical preferences keeper.
archives=[]
for name in ['family','group-create','group-detail','notification-preferences']:archives.append(F(r/('docs/reviews/gui-native-'+name+'/evidence.tar.gz')))
helpers=[F(r/x)for x in ['tools/gui-native-family/ui/fixture-export_test.go.txt','tools/gui-native-group/fixture-export_test.go.txt','tools/gui-native-group-detail/fixture-export_test.go.txt','tools/gui-native-notification-preferences/export_test.go.txt']]
with tarfile.open(r/'docs/reviews/gui-native-notification-preferences/evidence.tar.gz')as t:
 mf=json.load(t.extractfile('evidence/ui-final/fixtures/fixtures.json'));bodies=[]
 for row in mf['previous_body_equality']:
  member='evidence/ui-final/fixtures/'+row['path'];raw=t.extractfile(member).read();assert len(raw)==row['bytes'] and H(raw)==row['sha256'];bodies.append({'kind':row['kind'],'name':row['name'],'member':member,'bytes':len(raw),'sha256':H(raw)})
 for row in mf['states']:
  member='evidence/ui-final/fixtures/'+row['name']+'.html';raw=t.extractfile(member).read();assert len(raw)==row['bytes'] and H(raw)==row['sha256'];bodies.append({'kind':'notification-preferences','name':row['name'],'member':member,'bytes':len(raw),'sha256':H(raw)})
 assert len(bodies)==31
W('baseline-bindings.json',{'schema':1,'status':'READ_ONLY_CANONICAL_BINDINGS_NOT_NEW_BODY_EXECUTION','archives':archives,'old_helpers_unchanged':helpers,'bodies':bodies})
refs=[product/n for n in ['proposed.patch','manifest.json','source-proof.json','independent-source-review.json']]+[contract/n for n in ['contract.md','source-proof.json','independent-contract-review.json']]
refs += [r/'tools/gui-native-family'/name for name in ['qualify.py','db-entry.sh','db-binding.json','test_qualify.py']]+[r/'services/server/tools/gui-native-family-bootstrap/main.go',r/'tools/gui-native-family/ui/color-stability.mjs']
W('source-proof.json',{'schema':1,'status':'SIX_METHOD_SOURCE_PACKET_ONLY_NOT_APPLIED_COMPILED_OR_EXECUTED','author':'agent:codex /root/teacher_erasure_ui_tools; independent of inbox product author','base_sha':'05e5a522acaa41643ea0ffdba634492412156318','current_source_reference_head':subprocess.check_output(['git','-C',str(r),'rev-parse','HEAD']).decode().strip(),'new_paths':6,'existing_paths_modified':0,'files':files,'references':[F(x)for x in refs],'artifacts':{n:F(p/n)for n in ['source.patch','manifest.json','pg-driver-inverse.json','baseline-bindings.json']},'planned_inventory':{'complete_packages':['web','app','accounts','recommendations','social','messaging','notifications'],'notifications_DSN':'domain-test-dsn','owned_containers':15,'fresh_DB_retirements':7,'registered_App_root':'TestNativeNotificationInboxRegisteredHTTPAndCurrentAuthority','registered_App_leaves':6,'desktop':{'width':1280,'height':720},'JS_states':6,'no_JS_states':6,'strict_whole_document_Axe':18,'prior_bodies':{'family':8,'group-create':10,'group-detail':7,'notification-preferences':6},'optional_warmed_samples':12},'boundaries':['New PG driver only; exact original six driver/functions/DB controls and caps retained, full package inventories/no filters/no retries/no skips, original source/bootstrap/catalogue/OID/retirement/checkpoint/cleanup receipts preserved.','Source capture admits successful exact-seven result, every raw binary list/native/test2json stream, all fifteen owned cleanup/seven retirements; App ordinary root plus six exact leaves once.','Same forwarded registered cookie GET API callback once; no second private fetch. Exact bounded100 source order and title/body/why/strict admitted URL/timestamp/read presence; no IDs/Actor/session/CSRF/nonce/raw extras.','New exporter uses current request Actor/minimal defaults rather than AccountView-only id/is_active. No source policy/audit/method/notification changes.','All31 prior native bodies explicitly pinned and re-rendered by four unchanged original helper sources in absent virtual overlays; render-nonce-only normalization.','Browser read-all/logout/language forms serialized without submit activation; mark-all beyond100 and method/CSRF/current self scope remain actual complete App/notifications tests.','Desktop1280 only, actual comfort choices/assets/sourceheaders, real Tab focus, natural three-menu whole-doc Axe; no hidden contrast/style/scroll normalization, rule exclusion or device tests.','Optional EN/RO warmed matched body measurements include native VM/copy. Same actual display/fixed render environment; no equivalent HTML/general speedup/throughput/CPU-profile claim.','Independent method source review precedes Root application/use. Product implementation packet and Teacher accepted methods remain immutable.'],'static_validation':{'Python_AST':'three methods parsed without execution','whitespace':'six images single LF/no trailing spaces','canonical_HTML':'31 current canonical members independently hashed without extraction','driver_inverse':'exact old driver recovered; all nested safety/lifecycle functions and constants byte-identical','executed':'scratch-only source generation, read-only Git/hash/tar and AST; no compiler/Go/tests/PG/browser/network/owning writes/deletion'}})
print(json.dumps({name:F(p/name)for name in ['source.patch','manifest.json','source-proof.json','pg-driver-inverse.json','baseline-bindings.json']},indent=2))
