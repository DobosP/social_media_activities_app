from pathlib import Path
p=Path(__file__).parent/'files/tools/gui-native-notification-inbox/export_test.go.txt'
s=Path('/home/dobo/work/_worktrees/social_media_activities_app/feat__gui-app-migration-a/tools/gui-native-notification-preferences/export_test.go.txt').read_text()
s=s.replace('notificationQA','notificationInboxQA').replace('NotificationPreferences','NotificationInbox').replace('gui-native-notification-preferences','gui-native-notification-inbox').replace('notification-ui-','notification-inbox-ui-').replace('notification-benchmark-capture','notification-inbox-benchmark-capture').replace('notificationPreferencesFixture','notificationInboxFixture').replace('web/notification_preferences.html','web/notifications.html').replace('renderNotificationPreferences','renderNotificationInbox')
s=s.replace('var notificationInboxQAModes=[]string{"none-en","some-ro","all-ro","errors-en","escaped-ro","unassigned-en"}','var notificationInboxQAModes=[]string{"empty-en","one-unread-ro","mixed-en","all-read-ro","escaped-ro","unsafe-links-en"}')
s=s.replace('"testing"','"testing"\n "time"\n\n "github.com/DobosP/social_media_activities_app/services/server/internal/platform"')
a=s.index('func notificationInboxQAExpected');b=s.index('func TestSocialNotificationInboxQAExport',a)
s=s[:a]+'''// Expectations use source fields, protected catalogue/filter and source date
// formatting. They never read the new typed inbox decoder or row projection.
func notificationInboxQAExpected(t testing.TB,r *Renderer,request *http.Request,data pongo2.Context)map[string]any{
 t.Helper();lang:=data["language"].(string);tr:=func(value string)string{return html.UnescapeString(r.catalog.translate(lang,value,1))};source,ok:=data["items"].([]map[string]any);if !ok||len(source)>100{t.Fatal("bounded source-shaped inbox rows required")}
 filter,err:=r.set.FromString(`{{ value|safe_href }}`);if err!=nil{t.Fatal(err)};location,err:=time.LoadLocation("Europe/Bucharest");if err!=nil{t.Fatal(err)};rows:=[]map[string]any{}
 for _,row:=range source{stamp,err:=time.Parse(time.RFC3339Nano,row["created_at"].(string));if err!=nil{t.Fatal(err)};stamp=stamp.In(location);href,err:=filter.Execute(pongo2.Context{"value":row["url"]});if err!=nil{t.Fatal(err)};why:=row["why"].(string);if why!=""{why=strings.ReplaceAll(tr("Why you got this: %(why)s"),"%(why)s",why)};rows=append(rows,map[string]any{"title":row["title"],"body":row["body"],"why":why,"url":html.UnescapeString(href),"when":stamp.Format("2 Jan 15:04"),"iso":stamp.Format(time.RFC3339),"unread":row["read_at"]==nil})}
 actions:=[]string{"/logout/","/i18n/setlang/"};if len(rows)>0{actions=append(actions,"/notifications/read-all/")};actor,ok:=platform.ActorFrom(request);if !ok{t.Fatal("current fixture request actor required")}
 return map[string]any{"title":tr("Notifications"),"settings":tr("Notification settings"),"mark_all":tr("Mark all read"),"new":tr("new"),"view":tr("view"),"empty":tr("No notifications yet."),"rows":rows,"csrf":data["csrf"],"script_sources":[]string{"/static/js/hovercard.js","/static/js/site.js"},"form_actions":actions,"canonical":"/notifications/","language":lang,"theme":data["display_theme"],"text":data["display_text"],"motion":data["display_motion"],"owner":actor.PublicID}
}
var notificationInboxPreferencesBaseline=[]struct{Name string;Bytes int;SHA string}{
 {"none-en",14907,"2f71224f26e2828e768b9fe92ca0e3ed3baa59332cb48b3b368cf8b8db75e7e0"},
 {"some-ro",15301,"157fd5f77d6fbe03018eff910132b050ff49a59339c40a716e3fdd6b49d43eae"},
 {"all-ro",15413,"49427801261d32b0bdfc39d31a57b5d18c31d4a327a1ae094994de8d1b24b237"},
 {"errors-en",15051,"5edda90c1f19a9c36d5ff2ed78f14cc979f7fe167c457ad21edd61b83c4211af"},
 {"escaped-ro",15406,"c0abb3d13783e00af75bcf78f79d62ef5869e448f756c55f81c5f1087f31e738"},
 {"unassigned-en",14910,"60c47d64c34c3191018313270663dbf7d3306d575ae160215f552d6042d96e24"},
}
func notificationInboxQAPrior(t *testing.T,root,output string,r *Renderer)[]map[string]any{
 t.Helper();rows:=notificationQAPrior(t,root,output,r);if err:=os.Mkdir(filepath.Join(output,"notification-preferences"),0700);err!=nil{t.Fatal(err)};if len(notificationInboxPreferencesBaseline)!=len(notificationQAModes){t.Fatal("accepted preferences census changed")}
 for i,mode:=range notificationQAModes{want:=notificationInboxPreferencesBaseline[i];if mode!=want.Name{t.Fatal("accepted preferences order changed")};request,data:=notificationPreferencesFixture(mode);request.Header.Set("Accept-Language",data["language"].(string));data["csrf"]="synthetic-notification-ui-csrf";delete(data,"request");w:=httptest.NewRecorder();if err:=r.Render(w,request,"web/notification_preferences.html",data);err!=nil{t.Fatal(err)};body,_,_:=notificationQANormalize(t,w,"synthetic-notification-ui-nonce");if len(body)!=want.Bytes||groupDetailQAHash(body)!=want.SHA{t.Fatal("inbox disturbed accepted preferences body",mode)};path:="notification-preferences/"+mode+".html";groupDetailQAWrite(t,filepath.Join(output,path),body);rows=append(rows,map[string]any{"kind":"notification-preferences","name":mode,"path":path,"bytes":len(body),"sha256":groupDetailQAHash(body),"equal":true})}
 if len(rows)!=31{t.Fatal("complete prior31 native bodies required")};return rows
}
''' +s[b:]
s=s.replace('"synthetic-notification-ui-csrf";delete(data,"request")','"synthetic-notification-inbox-ui-csrf";delete(data,"request")',1) if False else s
# Only new fixture output uses new fixed CSRF/nonce; accepted preferences constructor above retains old values.
s=s.replace('data["csrf"]="synthetic-notification-ui-csrf";delete(data,"request")\n\t\texpected:=notificationInboxQAExpected', 'data["csrf"]="synthetic-notification-inbox-ui-csrf";delete(data,"request")\n\t\texpected:=notificationInboxQAExpected')
s=s.replace('notificationInboxQANormalize(t,w,"synthetic-notification-ui-nonce");normalized["name"]=mode','notificationInboxQANormalize(t,w,"synthetic-notification-inbox-ui-nonce");normalized["name"]=mode')
s=s.replace('"canonical":"/notifications/preferences/","synthetic_csrf":"synthetic-notification-ui-csrf"','"canonical":"/notifications/","synthetic_csrf":"synthetic-notification-inbox-ui-csrf"')
s=s.replace('"replacement":"synthetic-notification-ui-nonce"','"replacement":"synthetic-notification-inbox-ui-nonce"').replace('"baseline_keeper_sha256":"f1fc63527352bbb41a4d7640a0634dac6164d7e34eaddca0209fe355ecc14153"','"baseline_keeper_sha256":"29a9ff0d2e420d5454aaebd324d0bc686bc22cf14b6f04ce86e4b8ce7e71d7e5"')
s=s.replace('Six real native Renderer presentation fixtures and25priorbody equalities only. Real registered/current-authority proof is in canonical six-package App/PG; only current displayed row values enter matched benchmark.','Six real native Renderer inbox fixtures and31priorbody equalities only. Actual registered/current-authority proof is complete seven-package App/PG; only same-call display whitelist enters measurements.')
a=s.index('\ttype row struct{');b=s.index('\n\tt.Fatal("captured language missing")',a)
s=s[:a]+''' type item struct{Title,Body,Why,URL string;Created string `json:"created_at"`;ReadAt *bool `json:"read_at"`}
 var value struct{Schema int `json:"schema"`;Variants []struct{Language string `json:"language"`;Projection struct{Items []item `json:"items"`} `json:"projection"`} `json:"variants"`;Capture string `json:"capture"`}
 decoder:=json.NewDecoder(bytes.NewReader(projection));decoder.DisallowUnknownFields()
 if decoder.Decode(&value)!=nil||value.Schema!=1||len(value.Variants)!=2||value.Variants[0].Language!="en"||value.Variants[1].Language!="ro"||value.Capture!="same registered-cookie GET callback; display whitelist only; no actor/IDs/credentials/render environment"{t.Fatal("exact same-call display schema required")}
 for _,variant:=range value.Variants{if variant.Language==lang{
  if len(variant.Projection.Items)!=100{t.Fatal("current bounded100 source rows required")};items:=make([]map[string]any,0,100)
  for _,row:=range variant.Projection.Items{if _,err:=time.Parse(time.RFC3339Nano,row.Created);err!=nil||row.ReadAt!=nil&&!*row.ReadAt{t.Fatal("actual timestamp/read presence malformed",err)};var readAt any;if row.ReadAt!=nil{readAt=true};items=append(items,map[string]any{"title":row.Title,"body":row.Body,"why":row.Why,"url":row.URL,"created_at":row.Created,"read_at":readAt})}
  // Only the explicit fixed render environment is synthetic. Actor comes
  // from the same request for both engines; no AccountView id contract.
  request,data:=notificationInboxFixture("empty-en");request.Header.Set("Accept-Language",lang);delete(data,"PRIVATE-extra")
  data["language"],data["csrf"],data["items"]=lang,"synthetic-notification-inbox-benchmark-csrf",items
  data["display_theme"],data["display_text"],data["display_motion"]="light","normal","reduce"
  t.Logf("actual same-call display body-only source=%s method=%s projection=%s language=%s; fixed shared synthetic request actor/defaults",artifact.Source,artifact.Method,artifact.SHA,lang)
  return request,data
 }}''' +s[b:]
s=s.replace('artifact.Root!="TestNativeNotificationInboxRegisteredHTTPAndDelivery"','artifact.Root!="TestNativeNotificationInboxRegisteredHTTPAndCurrentAuthority"').replace('len(projection)>64<<10','len(projection)>256<<10')
s=s.replace('the successful current authorized projection','the actual same-call registered source projection')
p.write_text(s)
