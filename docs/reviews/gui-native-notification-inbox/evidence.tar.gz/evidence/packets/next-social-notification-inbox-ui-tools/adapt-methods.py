from pathlib import Path
p=Path(__file__).parent/'files/tools/gui-native-notification-inbox';r=Path('/home/dobo/work/_worktrees/social_media_activities_app/feat__gui-app-migration-a')
# New seven-lane driver. Original six-lane method and reusable DB controls remain exact.
f=p/'qualify-pg.py';s=f.read_text();s=s.replace('Qualify six complete Social family PG lanes','Qualify seven complete Social notification-inbox PG lanes')
s=s.replace("('social', 'social-test-dsn'), ('messaging', 'messaging-test-dsn')]","('social', 'social-test-dsn'), ('messaging', 'messaging-test-dsn'),\n         ('notifications', 'domain-test-dsn')]")
needle='INSPECT = '
a=s.index(needle)
s=s[:a]+"REQUIRED_INBOX = {'web': ['TestNativeNotificationInboxCustodyRetainsEveryOriginalAuthority', 'TestNativeNotificationInboxProjectionAndOrdinaryControls', 'TestNativeNotificationInboxExactStrictHrefAndDates', 'TestNativeNotificationInboxMalformedSnapshotsRefuseBeforeOutput', 'TestNativeNotificationInboxRendererHeadersAndStrictDispatch'],\n                  'app': ['TestNativeNotificationInboxRegisteredHTTPAndCurrentAuthority'],\n                  'notifications': ['TestNativeNotificationMuteChokepointAndProtectedRetention', 'TestRetirementPostgresOrganizerPrepNudgeMatrix', 'TestRetirementPostgresNotificationInboxQueryGrowth', 'TestNativeNotificationOwnershipAndCursor']}\n"+s[a:]
s=s.replace("method = REPO / 'tools/gui-native-family'","method = REPO / 'tools/gui-native-notification-inbox'\n    db_method = REPO / 'tools/gui-native-family'")
s=s.replace("method / 'qualify.py'","method / 'qualify-pg.py'").replace("DB_BINDING = method / 'db-binding.json'","DB_BINDING = db_method / 'db-binding.json'").replace("db_entry = regular(method / 'db-entry.sh')","db_entry = regular(db_method / 'db-entry.sh')")
s=s.replace("'Six affected complete synthetic PG packages only;", "'Seven affected complete synthetic PG packages only; original six plus complete notifications;")
s=s.replace("method_inputs = {str((method / name).relative_to(REPO)): regular(method / name)","method_inputs = {str((db_method / name).relative_to(REPO)): regular(db_method / name)")
s=s.replace("        method_inputs[REFERENCE_HELPER] = regular(REPO / REFERENCE_HELPER)","        method_inputs[REFERENCE_HELPER] = regular(REPO / REFERENCE_HELPER)\n        method_inputs['tools/gui-native-notification-inbox/qualify-pg.py'] = regular(Path(__file__).absolute())")
s=s.replace("            print(json.dumps({'lane': lane, 'phase': 'complete native PG package starting'", "            need(set(REQUIRED_INBOX.get(lane, ())).issubset(expected), 'Required current inbox/notifications declaration missing from actual complete binary inventory')\n            print(json.dumps({'lane': lane, 'phase': 'complete native PG package starting'")
s=s.replace("and all(value.get('id_absent') and value.get('name_absent') for value in result['cleanup'].values()))", "and set(result['cleanup']) == {'db', *[role for lane, _ in LANES for role in (lane, 'reference-' + lane)]}\n                                 and all(value.get('stopped') and value.get('id_absent') and value.get('name_absent') for value in result['cleanup'].values()))")
f.write_text(s)
# Five UI methods; new PG driver is a protected product input, never a UI-only exception.
f=p/'qualify.py';s=f.read_text().replace('notification preferences','notification inbox').replace('notification-preferences','notification-inbox').replace('NotificationPreferences','NotificationInbox').replace('notification_preferences','notification_inbox').replace('np-','ni-')
s=s.replace('STATES = ["none-en", "some-ro", "all-ro", "errors-en", "escaped-ro", "unassigned-en"]','STATES = ["empty-en", "one-unread-ro", "mixed-en", "all-read-ro", "escaped-ro", "unsafe-links-en"]')
s=s.replace('BASELINE_KEEPER = "docs/reviews/gui-native-group-detail/evidence.tar.gz"','BASELINE_KEEPER = "docs/reviews/gui-native-notification-preferences/evidence.tar.gz"').replace('BASELINE_SHA = "f1fc63527352bbb41a4d7640a0634dac6164d7e34eaddca0209fe355ecc14153"','BASELINE_SHA = "29a9ff0d2e420d5454aaebd324d0bc686bc22cf14b6f04ce86e4b8ce7e71d7e5"')
s=s.replace('    products = sorted(set(names) - allowed)','    pg_driver = "tools/gui-native-notification-inbox/qualify-pg.py"\n    need(pg_driver in names and git(repo, "show", "HEAD:" + pg_driver) == regular(repo / pg_driver), "new seven-package PG driver must be committed and protected")\n    products = sorted(set(names) - allowed)')
s=s.replace('original accepted Group/family baseline keeper differs','accepted notification-preferences31 baseline keeper differs').replace('twenty-five prior HTML equalities','thirty-one prior HTML equalities')
s=s.replace('            "notification_inbox_ui_qa_overlay_test.go": METHOD / "export_test.go.txt",','            "notification_inbox_ui_qa_overlay_test.go": METHOD / "export_test.go.txt",\n            "notification_preferences_ui_qa_overlay_test.go": repo / "tools/gui-native-notification-preferences/export_test.go.txt",')
s=s.replace('-notification-ui-producer-source','-notification-inbox-ui-producer-source').replace('-notification-ui-qa-output-dir','-notification-inbox-ui-qa-output-dir').replace('-notification-benchmark-capture','-notification-inbox-benchmark-capture')
s=s.replace('len(previous) == 25','len(previous) == 31').replace('for row in previous}) == 25','for row in previous}) == 31').replace('Counter({"family": 8, "group-create": 10, "group-detail": 7})','Counter({"family": 8, "group-create": 10, "group-detail": 7, "notification-preferences": 6})').replace('all eight family, ten Group-create and seven Group-detail bodies must remain exact','all family8, Group-create10, Group-detail7 and preferences6 bodies must remain exact').replace('(?:family|group-create|group-detail)/','(?:family|group-create|group-detail|notification-preferences)/')
s=s.replace('same captured actual semantic projection','same-call forwarded registered API display projection')
s=s.replace('Same captured actual semantic projection','Same-call forwarded registered API display projection')
f.write_text(s)
# Actual exact-seven result/capture admission; preserve source, teardown, retirement and raw-event controls.
f=p/'extract-projection.py';s=f.read_text().replace('NotificationPreferencesRegisteredHTTPAndDelivery','NotificationInboxRegisteredHTTPAndCurrentAuthority').replace('NATIVE_NOTIFICATION_PREFERENCES_V1','NATIVE_NOTIFICATION_INBOX_V1').replace('gui-native-notification-preferences','gui-native-notification-inbox')
a=s.index('ORDER = ');b=s.index('\n\ndef need',a)
s=s[:a]+"LANES = ('web', 'app', 'accounts', 'recommendations', 'social', 'messaging', 'notifications')\nSUBTESTS = ['registered-self-newest-first-100-and-read-only-get', 'csrf-origin-head-and-existing-method-admission', 'mark-all-beyond-100-self-only-idempotent-and-fetch', 'current-active-account-and-existing-cohort-admission', 'upstream-failure-preserves-state-and-response', 'registered-display-whitelist-and-existing-spa-source']\n"+s[b:]
s=s.replace('import collections','import collections\nimport datetime\nfrom urllib.parse import urlsplit')
s=s.replace("{'web', 'app', 'accounts', 'recommendations', 'social', 'messaging'}","set(LANES)")
s=s.replace('Complete successful six-lane result required','Complete successful seven-lane result required')
s=s.replace('len(method_rows) == 5 and len({row[\'path\'] for row in method_rows}) == 5','len(method_rows) == 6 and len({row[\'path\'] for row in method_rows}) == 6')
s=s.replace("any(row['path'] == 'tools/gui-native-family/qualify.py'", "any(row['path'] == 'tools/gui-native-notification-inbox/qualify-pg.py'")
a=s.index("    expected_roles = ");b=s.index("    need(set(result['cleanup'])",a)
s=s[:a]+"    expected_roles = {'db', *LANES, *('reference-' + name for name in LANES)}\n"+s[b:]
s=s.replace('All thirteen owned objects','All fifteen owned objects').replace('Complete six-lane catalogue','Complete seven-lane catalogue')
s=s.replace('All seven exact registered HTTP/security/delivery/capture leaves','All six exact registered HTTP/current-source/capture leaves')
s=s.replace('len(projection) <= 64 << 10','len(projection) <= 256 << 10')
a=s.index('    value = json.loads(projection)');b=s.index('    need(fence() == before',a)
s=s[:a]+'''    value = json.loads(projection)
    need(isinstance(value, dict) and set(value) == {'schema', 'variants', 'capture'} and type(value['schema']) is int and value['schema'] == 1
         and value['capture'] == 'same registered-cookie GET callback; display whitelist only; no actor/IDs/credentials/render environment'
         and isinstance(value['variants'], list) and [v.get('language') for v in value['variants']] == ['en', 'ro'],
         'Exact minimal same-callback source schema/languages required; no actor or private environment')
    for variant in value['variants']:
        need(isinstance(variant, dict) and set(variant) == {'language', 'projection'}
             and isinstance(variant['projection'], dict) and set(variant['projection']) == {'items'}, 'Display whitelist only')
        items = variant['projection']['items']
        need(isinstance(items, list) and len(items) == 100, 'Exact actual current bounded100 rows required; do not sort, paginate or infer unread totals')
        stamps = []
        for row in items:
            need(isinstance(row, dict) and set(row) == {'title', 'body', 'why', 'url', 'created_at', 'read_at'}
                 and all(isinstance(row[name], str) and len(row[name].encode()) <= 16384 for name in ('title', 'body', 'why', 'url', 'created_at'))
                 and (row['read_at'] is None or row['read_at'] is True), 'Exact plain display/timestamp/read-presence whitelist required')
            stamp = datetime.datetime.fromisoformat(row['created_at'].replace('Z', '+00:00'))
            need(stamp.tzinfo is not None, 'Actual source timestamp with timezone required')
            stamps.append(stamp)
            href = row['url']
            if href:
                parsed = urlsplit(href)
                need(not any(c in href for c in ('\\r', '\\n', '\\\\')) and parsed.username is None
                     and not re.search(r'%(?![0-9A-Fa-f]{2})', href)
                     and (href.startswith('/') and not href.startswith('//') or parsed.scheme in ('http', 'https')),
                     'Only already-admitted original strict safe_href spelling may enter capture')
        need(all(a >= b for a, b in zip(stamps, stamps[1:])), 'Actual newest-first source order must be retained, never re-sorted')
    need(value['variants'][0]['projection'] == value['variants'][1]['projection'], 'Identical actual source item order/read presence across display languages required')
''' +s[b:]
s=s.replace('After real registered cookie GETs, same current authority AccountView display rows only; this is a second authorized side-effect-free projection, not a captured Render invocation. No Actor/cookie/session/CSRF/nonce/ward/access payload. Both engines receive identical fixed render environment; body-only, no HTTP/DB/throughput/general speedup claim.','Actual successful registered cookie GET, exact same forwarded API callback once; only ordered100 admitted title/body/why/strict URL/timestamp/read presence. No second private fetch, Actor/IDs/cookie/session/CSRF/nonce/raw extras. Both engines receive identical fixed current default environment; native VM included. Body-only, no HTTP/DB/equivalent-markup/general speedup/CPU-profile claim.')
f.write_text(s)
