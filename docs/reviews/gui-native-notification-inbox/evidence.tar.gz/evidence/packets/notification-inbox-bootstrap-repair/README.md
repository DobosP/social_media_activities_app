# Isolated notifications reference-bootstrap repair

Scratch source proposal against clean `0e31da9bc26f8286b559102c163cbaf8edc682ea`.
Exactly nine owning paths are proposed: two new qualification-only Go helper
files, the inbox PG driver, its strict extractor method-input join, the module
reproduction README and the four existing current documentation paths. No owning
file has been edited, no candidate parser/compiler/Go/DB/Docker/browser runtime
has run, and nothing has been deleted. This author must not independently accept
this repair. Root must obtain `notification_actual_review` before application.

The frozen original family helper's anchored DSN expression accepts only the six
earlier suffixes. Actual0e31 completed those six packages:442 roots/1,327 named
PASS, six owned database retirements/checkpoints, then notifications reference
setup returned `explicit isolated qualification DSN required` with exit1. Its
native notifications package never ran. All14 created CIDs/names were removed
and PostgreSQL stopped. This is a failed partial campaign. It is a distinct
failure from f087's NEW App timestamp assertion; both actual result/proof/cleanup
histories are bound unmodified in `failed-history-bindings.json`.

The separate helper accepts only this exact existing local fixture grammar:

```text
host=/pgsocket port=55434 user=app dbname=social_family_<12-lowercase-hex>_notifications sslmode=disable
```

It rejects all six original suffixes and other hosts/sockets/ports/users/names,
extra options, URI/quoted/injection forms and whitespace variants. It uses the
same canonical `catalog.New(db).Migrate`,30-second context, errors, JSON success
and main exit contract. The original helper, original four DB method/binding/test
files, catalogue service/schema/dependencies and every existing test remain exact.
No local rows, simplified seed, broader DSN or production admission is added.

Three new pure test roots cover valid grammar/flags, malformed/foreign grammar
and invalid `run` invocations returning before database construction/output. Valid
controls call only `qualificationDSN`, never `run` or a database. Invalid-run
controls have no valid DSN and require the exact early error with no output.
These are authored source controls, not executed test results.

The current inbox driver retains the original six-role bootstrap build/record
and all original affected-package compile/vet commands. It adds a distinct
`reference-notifications-bootstrap` build and hash, separate pure-helper unit/vet
commands, and chooses the new entrypoint only when `lane == 'notifications'`.
Seven package inventories, current DSN flags, fifteen final roles, seven guarded
database retirements, canonical reference comparisons, caps, timeouts, image/DB
binding, source/archive fences and cleanup are unchanged. Added helper sources
are exact committed method inputs. The extractor's exact set grows6→8 by those
two paths only; all previous entries and every other predicate remain identical.

`replacement-journal.json` restores each of the seven existing files exactly;
the new Go files are additions with no previous image. `source.patch` and
`inverse.patch` encode the exact nine forward/reverse paths and modes.
`original-source-bindings.json` binds all2,213 current tracked files to the actual
0e31 source manifest/current bytes, including304 current test files. The original
ADR-0065 bytes remain an exact prefix of its proposed afterimage; only the new
checkpoint is appended. No older decision body is rewritten.

After independent review, Root can apply the exact patch, format only the two new
Go files, check helper tests/vet and changed Python/source/docs/whitespace, inspect
the byte/format bridge and commit. The committed driver itself records separate
helper unit/vet/build proof before the fixture. Root then runs one fresh complete
seven-package campaign on the exact new source. No reduced lane/subtree, filter,
skip, cap enlargement, old assertion change or retry loop is proposed. Actual
UI/no-JS/strict Axe/31 old bodies/capture/descriptive measurement and compact keeper
acceptance remain pending. Collector/retention history must rebind both failed
attempts and the actual accepted successor;0e31 is not a latest seven-package
success. No full21/current-image/main/milestone/production/provider/government or
real-child authority is supplied by this packet.
