# Social GUI preparation and S3A execution plan

Last verified: 2026-10-19. Bounded functional work follows programme ADR-0032.
The formal sequence below retains its historical PROGRAM E5/E6/ADR-0019/0020 scope.
This branch is pre-S3A preparation; formal S3A starts after the S0b templ-kit tag
and owner kit sync. No milestone or owner signature is recorded here.

## Completed finite preparation

- Committed reproducible default17/preference28/currentG1-45 runner. Actual
  source79b31af passed all90 profile identities/89labels and3packages, strict
  current-current HTML canonical equality/hard0, native negatives and owning
  refusal controls.100registered GETs plus12settingsAPI reads; no skips/cache/race.
  [One compact record](../reviews/gui-preferences-get-transport/repro-current-checkpoint.json).
- Reverified the four previously pending documentation units against ee39a70
  and their literal22f result/review hashes.22f remains historical; ADR-0056/Q6
  source-only defaults and portable source type/executable binding are separate.
- Rechecked the sealed13-member unsigned ownership keeper against current source:
  91loader templates =84port candidates+7frozen,155route names.13template bodies
  differ from the old keeper; no baseline or receipt was rewritten. Reproduce:
  `python3 -I tools/gui-public-golden/preparation_inventory.py`.
- Added SIGTERM handling into the runner's existing failure/finally cleanup;
  an offline subprocess proves cleanup executes on termination. This successor
  is source-only relative to the completed79b31af transport run; no repeat of
  that completed run is required for these source/plan changes.

## Concrete entry blockers and next action

| Blocker | Evidence | Action |
|---|---|---|
| S0b templ-kit tag and owner kit sync | PROGRAM §10.2/10.3; no templ kit adopted | After Cat M2 acceptance and S0b tag, owner syncs the kit; then begin S3A M0 below |
| Exact group ownership | Current inventory still hasG0=6/G5=12 and historical `web/login.html` in `HOLD_BOLD_OWNER` | Owner reviews `capture-preparation.tar.gz` members `partition-draft.json`/`capture-ownership.json`; chooses exact ownership without reassigning files to hit estimates |
| Native-versus-historical applicability | Original keeper89case drafts/17mutations remain unsigned; authcore/inline output identities differ from historical templates | Owner/independent reviewer settle the matrix and original capture applicability before formal capture/conversion; historical drafts do not establish current Live behavior |

The remaining formal work is BLOCKED-DEP, with these explicit owner items.
There is no unspecified READY preparation slice. In particular, source inventory
and current-current transport do not supply an original semantic oracle,
accepted normalized baseline, privacy admission, CSP/browser/device or templ proof.
Historical safety questions are retained as history and require current source
review before being used as a new requirement.

## Formal S3A sequence after entry

1. M0: current versions/kit check, loader-root and DSN fixture inventories,
   fresh frontend baseline, authorized pre-M1 golden capture and frozen legacy
   bundle from the exact parent. Keep all existing golden/refusal gates.
2. M1: Pongo delivery/embed/nonce/CSP-safe externalization and PhaseA widgets;
   compression, canonical debian-slim/media-worker image, report-only CSP zero.
   Frozen SPA/snapshots remain. Paul performs the physical Samsung checkpoint.
3. M2: retire the20SPA routes with frozen per-route fallback, hovercard, lazy
   MapLibre and enforced CSP. Never alter worker logic, media or policy gates.
4. M3: G0–G4 plusG2p oracle, complete fixture/mutation matrix, capture provenance,
   native web zero-skip lane and qualifying full. Only then port groups.
5. M4/M5: G0–G2, then boldG2p andG3/G4 with required Paul/independent reviews,
   100%bold conditional arms, replay/Live/shadow zero and per-route fallback.
6. M6: browse island/CSS/budgets and full; owner qualification/review/landing.
   S3B still needs S3A landing/soak and signedG5–G6 matrix.

No main push, landing, kit/pin/budget edit or Paul-only target is authorized by
this plan. At most two product runtimes, none during timed Cat runs; immutable
exports, task-owned rolling caches, exact owned cleanup and compact records apply.


## Bounded functional family pages (2026-10-19)

Programme ADR-0032 permits selected functional native Go pages without opening
an automatic whole-template conversion. [ADR-0061](../adr/0061-native-family-pages.md)
covers `/wards/` and `/guardianship/`: typed escaped presentation, cached embedded
HTML, existing actions and services. Original templates, source-case declarations,
route policy, schema and dependencies remain. Source review and focused family
race/vet/header/custody checks pass. Actual V3 isolated fixtures passed eight EN/RO
desktop states plus two no-JS cases, 192 Axe predicates and all 27 initial/settled
button-color samples. The new scoped stylesheet removes the observed color tween;
original base styles and important reduced-motion rules remain. V1 Axe/list failures
and V2 stable-only pass remain honest history; no all-frame certification follows.
No S3A milestone, speedup over Pongo, main landing or deployment is claimed.
The old Samsung/device step above is historical: PROGRAM E10 requires no device
measurements anywhere. Teacher/Social milestone landing remains owner-only.

Next: check source/authcore and run the committed `tools/gui-native-family/qualify.py`
against the exact clean feature SHA with explicit owned scratch/cache paths.
Complete six-package PG and publication remain pending. Matched body measurement
completed: smaller native HTML and about 47% fewer native allocation bytes than
before optimization, but higher CPU than Pongo; no full HTTP speedup is claimed.
Final source exports preserve the eight accepted fixture bodies byte-for-byte.
Historical captures/receipts are unchanged; source-only defaults are not an
original semantic oracle. Teacher/Social milestone landing remains owner-only.

## Notification inbox current checkpoint

[ADR-0065](../adr/0065-native-notification-inbox.md) retains the complete3e536
seven-package PASS446/1338 and failed first UIbd606:6JS6no-JS/31prior bodies,
12 inline-link distinction violations, benchmark not reached. A reviewed
owned-CSS underline repair clears all18Axe audits in causal diagnostic0177;
its12 unchanged old-asset guard failures remain deliberate failures. Next is
a fresh complete7 on the committed CSS source and the second primary UI run.
No serving/backend/authority expansion or final feature acceptance is claimed.
