# Pure collector V4 controls

Actual result5dd2e919 binds keeper1e323 and independent757ad. The unbound example
was passed to prepare and refused before any output; stdout/stderr are retained.
The exact production read function was loaded without invoking main. Each new
owned regular file accepted an unchanged re-read, then refused either content,
mode or inode replacement; a replaced symlink was also refused. Fixtures used
only the literal bytes before/after and were never product or archive inputs.
No full collector prepare/archive or deletion ran in those controls.
