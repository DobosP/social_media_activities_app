#!/usr/bin/env python3
"""Read-only independent source/raw joins; never import the qualification method."""
import collections
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import tarfile


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    run = Path(sys.argv[1]).resolve(strict=True)
    result_raw = (run / 'result.json').read_bytes()
    x = json.loads(result_raw)
    repo = Path(x['paths']['repo'])
    lanes = ('web', 'app', 'accounts', 'recommendations', 'social', 'messaging', 'notifications')
    def git(*args):
        return subprocess.check_output(['git', '-C', str(repo), *args])
    assert x['method_pass'] is True and x['errors'] == []
    assert x['source'] == '0e31da9bc26f8286b559102c163cbaf8edc682ea'
    assert x['tree'] == '4dcaa7e06726eac3d1b57ddfbbbf5cdb04b20c67'
    assert git('rev-parse', 'HEAD').decode().strip() == x['source']
    assert git('rev-parse', 'HEAD^{tree}').decode().strip() == x['tree']
    assert not git('status', '--porcelain')
    assert set(x['lanes']) == set(lanes)
    assert len(x['commands']) > 250
    artifact_rows = x['artifact_rows']
    assert len({a['path'] for a in artifact_rows}) == len(artifact_rows)
    assert {a['path'] for a in artifact_rows} == {p.relative_to(run).as_posix() for p in (run/'proof').iterdir()}
    for row in artifact_rows:
        p = run/row['path']; assert p.is_file() and not p.is_symlink()
        raw = p.read_bytes()
        assert len(raw) == row['bytes'] and sha(raw) == row['sha256'], p
    for c in x['commands']:
        assert c['exit'] == 0 and c['seconds'] >= 0 and c['seconds'] < c['timeout'] + 5, c['argv'][:3]
        for stream in ('stdout', 'stderr'):
            assert c[stream] in artifact_rows
    manifests_raw = (run/'source-manifest.json').read_bytes()
    manifest = json.loads(manifests_raw)
    assert len(manifest) == 2213 and len({r['path'] for r in manifest}) == 2213
    rows = {r['path']: r for r in manifest}
    tree = {}
    for raw in git('ls-tree', '-r', '-z', x['source']).split(b'\0'):
        if not raw: continue
        head, path = raw.split(b'\t', 1)
        mode, kind, oid = head.split()
        assert kind == b'blob'
        tree[path.decode()] = (int(mode, 8), oid.decode())
    assert set(tree) == set(rows)
    blobs = subprocess.Popen(['git', '-C', str(repo), 'cat-file', '--batch'], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    for path, row in rows.items():
        mode, oid = tree[path]
        blobs.stdin.write((oid+'\n').encode()); blobs.stdin.flush()
        header = blobs.stdout.readline().decode().split(); assert header[:2] == [oid, 'blob']
        raw = blobs.stdout.read(int(header[2])); assert blobs.stdout.read(1) == b'\n'
        for root in (repo, run/'source'):
            p = root/path
            if mode == 0o120000:
                assert p.is_symlink() and os.readlink(p).encode() == raw and row['link'].encode() == raw
            else:
                assert p.is_file() and not p.is_symlink()
                actual = p.read_bytes()
                assert actual == raw and sha(actual) == row['sha256'] and len(actual) == row['bytes']
                assert row['mode'] == mode & 0o777
                assert (stat.S_IMODE(p.stat().st_mode) & 0o111) == (mode & 0o111)
                if root != repo: assert stat.S_IMODE(p.stat().st_mode) == row['mode']
    blobs.stdin.close(); assert blobs.wait() == 0
    archives = [c for c in x['commands'] if c['argv'][0] == 'git' and 'archive' in c['argv']]
    assert len(archives) == 1
    archive = run/archives[0]['stdout']['path']
    assert archives[0]['stdout']['sha256'] == x['git_archive']['sha256']
    assert archive.stat().st_size == x['git_archive']['bytes']
    with tarfile.open(archive, 'r:') as tf:
        members = {m.name:m for m in tf if not m.isdir()}
        assert set(members) == set(rows)
        for path, row in rows.items():
            m = members[path]
            if 'link' in row:
                assert m.issym() and m.linkname == row['link']
            else:
                raw = tf.extractfile(m).read()
                assert m.isfile() and sha(raw) == row['sha256'] and len(raw) == row['bytes']
                assert m.mode & ~0o022 == row['mode']  # tarfile data filter strips group/other write
    for row in x['method_inputs']:
        assert rows[row['path']]['bytes'] == row['bytes'] and rows[row['path']]['sha256'] == row['sha256']
    assert len(x['method_inputs']) == 6
    assert x['method_sha256'] == rows['tools/gui-native-notification-inbox/qualify-pg.py']['sha256'] == '76bf06b39fabece4aa17c6778dd269591204e93cbcfe63777876863da554c5bd'
    counts = {}
    identity_lists = {}
    for lane in lanes:
        current = x['lanes'][lane]
        expected = [n for n in (run/'proof'/f'{lane}-list.stdout').read_text().splitlines() if re.fullmatch(r'(?:Test|Example|Fuzz)[A-Za-z0-9_]+', n)]
        assert expected and len(expected) == len(set(expected))
        declarations = []
        for p in sorted((run/'source/services/server/internal'/lane).glob('*_test.go')):
            declarations += re.findall(r'^func ((?:Test|Example|Fuzz)[A-Za-z0-9_]+)\(', p.read_text(), re.M)
        assert set(expected) == set(declarations) and len(declarations) == len(set(declarations))
        raw = (run/'proof'/f'{lane}-test2json.stdout').read_bytes()
        events = [json.loads(line) for line in raw.splitlines()]
        assert all(e.get('Package') == 'github.com/DobosP/social_media_activities_app/services/server/internal/'+lane for e in events)
        runs = [e['Test'] for e in events if e.get('Action') == 'run' and 'Test' in e]
        passes = [e['Test'] for e in events if e.get('Action') == 'pass' and 'Test' in e]
        assert collections.Counter(runs) == collections.Counter(passes) and len(runs) == len(set(runs))
        assert {name for name in runs if '/' not in name} == set(expected)
        assert not any(e.get('Action') in ('fail', 'skip') or '(cached)' in e.get('Output', '') or 'DATA RACE' in e.get('Output', '') for e in events)
        assert sum(e.get('Action') == 'pass' and 'Test' not in e for e in events) == 1
        assert current['state'] == 'PASS' and current['tests'] == {'top_level':len(expected),'named_passes':len(passes),'skip':0,'fail':0,'identities':runs,'json_events':len(events)}
        raw_native = (run/'proof'/f'{lane}-native.stdout').read_bytes()
        conversion = [c for c in x['commands'] if c['stdout']['path'] == f'proof/{lane}-test2json.stdout']
        assert len(conversion) == 1 and conversion[0]['stdin'] == {'bytes':len(raw_native),'sha256':sha(raw_native)}
        assert conversion[0]['argv'] == [x['paths']['go'], 'tool', 'test2json', '-p', 'github.com/DobosP/social_media_activities_app/services/server/internal/'+lane]
        assert sha((run/'binaries'/f'{lane}.test').read_bytes()) == current['binary']['sha256']
        compile_receipts = [c for c in x['commands'] if c['stdout']['path'] == f'proof/{lane}-compile.stdout']
        assert len(compile_receipts) == 1 and '-race' in compile_receipts[0]['argv'] and '-c' in compile_receipts[0]['argv']
        native_commands = [c for c in x['commands'] if c['stdout']['path'] == f'proof/{lane}-native.stdout']
        assert len(native_commands) == 1 and native_commands[0]['argv'] == ['docker','start','-a',x['cleanup'][lane]['cid']]
        assert not (run/'proof'/f'{lane}-native.stderr').read_bytes()
        counts[lane] = {'roots':len(expected),'named':len(passes),'raw_sha256':sha(raw)}
        identity_lists[lane] = runs
    assert len(x['cleanup']) == 15 and set(x['cleanup']) == {'db',*lanes,*(f'reference-{lane}' for lane in lanes)}
    inspections = []
    for role, cleanup in x['cleanup'].items():
        assert cleanup == {'cid':cleanup['cid'],'stopped':True,'id_absent':True,'name_absent':True}
        cid = cleanup['cid']; assert re.fullmatch('[a-f0-9]{64}', cid)
        assert (run/(role+'.cid')).read_text().strip() == cid
        created = json.loads((run/'proof'/(role+'-created.json')).read_text())
        assert created['id'] == cid and not created['running'] and not created['oom']
        assert created['name'] == '/social-family-'+role+'-'+x['invocation']
        assert created['network'] == 'none' and not created['ports'] and created['readonly'] and not created['privileged']
        assert created['caps'] == ['ALL'] and created['security'] == ['no-new-privileges']
        assert created['labels']['io.dobolabs.gui.owner'] == x['invocation']
        assert (created['cpus'],created['memory'],created['pids']) == ((1000000000,2<<30,256) if role=='db' else (2000000000,3<<30,512))
        assert all(m['Type'] != 'volume' for m in created['mounts'])
        if role=='db':
            assert created['tmpfs']['/var/lib/postgresql/data'] == 'rw,nosuid,nodev,size=1g,uid=999,gid=999,mode=0700'
        else:
            assert created['cmd'][0] == ('-dsn' if role.startswith('reference-') else '-test.v=test2json')
            assert not any(a.startswith(('-test.run','-test.skip','-test.count')) for a in created['cmd'])
            assert {(m['Destination'],m['RW']) for m in created['mounts']} == {('/src',False),('/tests',False),('/scratch',True),('/pgsocket',False)}
        own_inspects = []
        for c in x['commands']:
            if c['argv'][:4] == ['docker','container','inspect',cid]:
                actual = json.loads((run/c['stdout']['path']).read_text()); own_inspects.append(actual)
                assert set(actual) == set(created)
                assert {k:v for k,v in actual.items() if k not in ('running','exit','mounts')} == {k:v for k,v in created.items() if k not in ('running','exit','mounts')}
                assert sorted(actual['mounts'],key=lambda m:m['Destination']) == sorted(created['mounts'],key=lambda m:m['Destination'])
                assert actual['oom'] is False and actual['exit'] == 0
        assert own_inspects
        inspections += own_inspects
        removals = [i for i,c in enumerate(x['commands']) if c['argv'] == ['docker','container','rm',cid]]
        assert len(removals) == 1
        for args in (['docker','container','ls','-aq','--no-trunc','--filter','id='+cid],['docker','container','ls','-aq','--filter','name=^'+created['name']+'$']):
            found = [(i,c) for i,c in enumerate(x['commands']) if c['argv'] == args and i>removals[0]]
            assert len(found)==1 and (run/found[0][1]['stdout']['path']).read_bytes() == b''
    assert set(x['retired_databases']) == set(lanes)
    canonical_reference = json.loads((repo/x['catalog_reference_source']['path']).read_text())
    canonical_reference = {k:sorted(v,key=lambda z:z['id']) for k,v in canonical_reference.items()}
    canonical_summary = {'canonical_json_sha256':sha(json.dumps(canonical_reference,sort_keys=True,separators=(',',':')).encode()),'rows':{k:len(v) for k,v in canonical_reference.items()}}
    db_cid=x['cleanup']['db']['cid']; oid_set=set()
    for lane in lanes:
        before=x['lanes'][lane]['pg_before'];after=x['lanes'][lane]['pg_after']
        assert before==after and before['catalog_reference']==canonical_summary
        for when in ('before','after'):
            raw=json.loads((run/'proof'/f'{lane}-pg-{when}.stdout').read_text())
            assert {k:v for k,v in before.items() if k!='catalog_reference'}==raw
            assert json.loads((run/'proof'/f'{lane}-pg-{when}-reference.stdout').read_text())==canonical_reference
        assert before['fixtures']==0 and before['listen']=='' and before['budgets'] is True
        assert before['oid'] not in oid_set;oid_set.add(before['oid'])
        retired=x['retired_databases'][lane];database='social_family_'+x['invocation'].replace('-','')[:12]+'_'+lane
        assert retired['database']==database==before['database'] and retired['oid']==before['oid']
        assert retired['checkpoint_completed'] is True and retired['name_and_oid_absent'] is True
        for key,label in (('before_drop','before'),('after_drop','dropped'),('after_checkpoint','checkpointed')):
            snapshot=retired[key]
            raw=json.loads((run/'proof'/f'{lane}-retire-{label}-catalog.stdout').read_text())
            assert {k:v for k,v in snapshot.items() if k!='tmpfs'}==raw
            assert snapshot['server_start']==x['pg_storage_initial']['server_start'] and snapshot['listen']=='' and snapshot['maintenance_database']=='postgres'
            fields=(run/'proof'/f'{lane}-retire-{label}-tmpfs.stdout').read_text().splitlines()[1].split()
            assert fields[3]=='/var/lib/postgresql/data'
            assert snapshot['tmpfs']==dict(zip(('bytes','used_bytes','available_bytes'),map(int,fields[:3]))) and snapshot['tmpfs']['bytes']==1<<30
            if key!='before_drop':
                assert {v['name'] for v in snapshot['databases']}=={'postgres','template0','template1'}
                assert all(v['oid']!=before['oid'] for v in snapshot['databases'])
        identity=[v for v in retired['before_drop']['databases'] if v['name']==database]
        assert len(identity)==1 and identity[0]==retired['qualified_identity'] and identity[0]['owner']=='app' and identity[0]['client_connections']==0 and identity[0]['template'] is False
        drop=[c for c in x['commands'] if c['stdout']['path']==f'proof/{lane}-retire-drop.stdout']
        assert len(drop)==1 and drop[0]['argv'][-1]=='DROP DATABASE "'+database+'"'
    pg=x['pg_cleanup']; assert pg==json.loads((run/'socket/pg-cleanup.json').read_text())
    assert pg['stop_exit']==0 and pg['status_exit']==3 and pg['owned_pid']>0 and pg['pid_probe_exit']==1 and pg['pid_and_socket_files_absent']==1
    assert not any((run/'socket'/p).exists() for p in ('postmaster.pid','.s.PGSQL.55434','.s.PGSQL.55434.lock'))
    assert not git('status','--porcelain') and git('rev-parse','HEAD').decode().strip()==x['source']
    print(json.dumps({'result_sha256':sha(result_raw),'source_manifest_sha256':sha(manifests_raw),'source_files':len(rows),'artifact_rows':len(artifact_rows),'commands':len(x['commands']),'inspections':len(inspections),'inventories':counts,'total_roots':sum(v['roots'] for v in counts.values()),'total_named':sum(v['named'] for v in counts.values()),'raw_pg_cleanup':pg,'git_archive':x['git_archive'],'app_inbox_identities':[n for n in identity_lists['app'] if n.startswith('TestNativeNotificationInbox')]},indent=2))


if __name__ == '__main__':
    main()
