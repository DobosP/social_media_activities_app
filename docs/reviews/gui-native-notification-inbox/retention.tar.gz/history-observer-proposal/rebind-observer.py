"""Re-inventory the exact approved rows in the intended host execution view.

No deletion or predicate change. Only five protected, non-target PostgreSQL
cleanup records may change their namespace-projected UID/GID from 65534 to999.
Every other field and all delete-target owners must remain exact.
"""
from pathlib import Path
import copy
import gzip
import hashlib
import json
import os
import shutil

root = Path(__file__).resolve().parent
digest = lambda raw: hashlib.sha256(raw).hexdigest()
source = (root / "retain.py").read_bytes()
assert digest(source) == "3e95f35b1d16c63981306a71d783f771f3591dceb6963b67e1ae7d1f9d6756cb"
old_inventory_raw = (root / "inventory.json.gz").read_bytes()
old_latest_raw = (root / "latest-snapshot.json.gz").read_bytes()
old_plan_raw = (root / "plan.json").read_bytes()
assert digest(old_inventory_raw) == "61e8884c7779a255972cc10ccd99cd3edfc03f95aaeca35cf9ac3771795222ef"
assert digest(old_latest_raw) == "7549fd9625e904d47efcdfdfd5d3212afc88953081d577dcb9eca15066b66e74"
assert digest(old_plan_raw) == "f37eb66d52a7e6393f5347bc01daad3b09498040d8d3de9ffbfdd31fcddba62f"
namespace = {"__file__": str(root / "retain.py"), "__name__": "observer_rebind_read_only"}
exec(compile(source, str(root / "retain.py"), "exec"), namespace)
inventory = json.loads(gzip.decompress(old_inventory_raw))
latest = json.loads(gzip.decompress(old_latest_raw))
plan = json.loads(old_plan_raw)
target_paths = {r["path"] for r in inventory["targets"] + inventory["directories_bottom_up"]}
allowed_foreign = {str(p / "socket/pg-cleanup.json") for p in namespace["OLD"] + [namespace["LATEST"]]}
changes = []
checked = 0


def visit(value):
    global checked
    if isinstance(value, dict):
        if "path" in value and type(value.get("file")) is bool:
            observed = namespace["current"](Path(value["path"]))
            different = [k for k in observed if observed[k] != value[k]]
            assert set(different) <= {"uid", "gid"}, (value["path"], different)
            if value["path"] in target_paths:
                assert not different and value["uid"] == os.getuid(), value["path"]
            if different:
                assert value["path"] in allowed_foreign and value["path"] not in target_paths
                assert (value["uid"], value["gid"]) == (65534, 65534)
                assert (observed["uid"], observed["gid"]) == (999, 999)
                changes.append({"path": value["path"], "sandbox_uid_gid": [65534, 65534],
                                "host_uid_gid": [999, 999],
                                "all_other_fields_identical": True,
                                "dev": observed["dev"], "ino": observed["ino"],
                                "ctime_ns": observed["ctime_ns"], "mtime_ns": observed["mtime_ns"],
                                "bytes": observed["bytes"], "sha256": observed["sha256"]})
                value["uid"], value["gid"] = observed["uid"], observed["gid"]
            checked += 1
        else:
            for child in value.values():
                visit(child)
    elif isinstance(value, list):
        for child in value:
            visit(child)


visit(inventory)
visit(latest)
assert {r["path"] for r in changes} == allowed_foreign and len(changes) == 5
assert len(inventory["targets"]) == 8863 and len(inventory["directories_bottom_up"]) == 967
assert sum(r["bytes"] for r in inventory["targets"]) == 1278664437
encode = lambda value: (json.dumps(value, indent=2) + "\n").encode()
inventory_decoded = encode(inventory)
latest_decoded = encode(latest)
inventory_raw = gzip.compress(inventory_decoded, compresslevel=9, mtime=0)
latest_raw = gzip.compress(latest_decoded, compresslevel=9, mtime=0)
proof = {
    "schema": 1, "status": "HOST_OBSERVER_REBIND_ONLY_NO_VERIFIER_OR_DELETION",
    "source_sha": namespace["SOURCE"], "method_sha256": digest(source),
    "original_inventory_sha256": digest(old_inventory_raw),
    "original_latest_snapshot_sha256": digest(old_latest_raw),
    "original_plan_sha256": digest(old_plan_raw),
    "inventory_sha256": digest(inventory_raw), "latest_snapshot_sha256": digest(latest_raw),
    "observer": {"uid": os.getuid(), "gid": os.getgid(),
                 "uid_map": Path("/proc/self/uid_map").read_text(),
                 "gid_map": Path("/proc/self/gid_map").read_text()},
    "all_rows_checked": checked, "target_owner_changes": 0,
    "non_uid_gid_field_changes": 0, "protected_foreign_view_changes": changes,
    "all_guards_and_target_scope_unchanged": True, "physical_deletion_performed": False,
}
proof_raw = encode(proof)
plan["status"] = "PROPOSAL_HOST_VIEW_METADATA_REBIND_NO_VERIFIER_OR_DELETION"
plan["inventory_sha256"] = digest(inventory_raw)
plan["inventory_decoded_sha256"] = digest(inventory_decoded)
plan["latest_snapshot_sha256"] = digest(latest_raw)
plan["observer_rebind_proof_sha256"] = digest(proof_raw)
history = root / "history-sandbox-view"
history.mkdir()
for name in ("inventory.json.gz", "latest-snapshot.json.gz", "plan.json"):
    shutil.copy2(root / name, history / name)
(root / "host-observer-rebind.json").write_bytes(proof_raw)
(root / "inventory.json.gz").write_bytes(inventory_raw)
(root / "latest-snapshot.json.gz").write_bytes(latest_raw)
(root / "plan.json").write_bytes(encode(plan))
print(json.dumps({"status": proof["status"], "rows_checked": checked,
                  "protected_foreign_changes": len(changes),
                  "inventory_sha256": digest(inventory_raw),
                  "latest_snapshot_sha256": digest(latest_raw),
                  "plan_sha256": digest((root / "plan.json").read_bytes()),
                  "proof_sha256": digest(proof_raw), "deleted": 0}))
