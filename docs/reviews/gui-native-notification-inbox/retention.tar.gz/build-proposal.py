#!/usr/bin/env python3
"""Draft narrow Social inbox retention; no recursive removal or implicit approval.

Unexecuted source. Pending bindings refuse before bulk reads/removal. Root must
bind accepted successor custody, terminal latest snapshot and independent review.
"""
import argparse
from decimal import Decimal
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import tarfile
import time
import uuid

BASE = Path('/home/dobo/work/_temp/feat__gui-app-migration-a/social-family')
HERE = BASE / 'notification-inbox-closure-preparation/retention-v4'
CANDIDATE = BASE / 'notification-inbox-closure-preparation/candidate-496'
CURRENT_UI = Path('/home/dobo/work/_temp/ni-ui/run-496056a6a528-7da60674-4319-40ce-9231-b40dad1d3e39')
REPO = Path('/home/dobo/work/_worktrees/social_media_activities_app/feat__gui-app-migration-a')
OLD = [
    BASE / 'notification-preferences-pg-qa/run-e900960d50be-2503620e-5e0f-4acb-9ea2-09f713d162ae',
    BASE / 'notification-inbox-pg-qa/run-f0874800b1de-9f0eaafa-44f5-4df3-ba44-e40a419e5350',
    BASE / 'notification-inbox-pg-qa/run-0e31da9bc26f-dfae1f27-76e5-48ab-865c-9a8a2b6fb9c5',
    BASE / 'notification-inbox-pg-qa/run-3e536f9e1c88-42f1d122-b499-4659-89e1-68c180bffc1f']
LATEST = BASE / 'notification-inbox-pg-qa/run-496056a6a528-9681bb2d-06e5-4b23-9b62-8ab6f4ce3b80'
SOURCES = ['e900960d50beed03ef387159da0e6d903ec5bf9a',
           'f0874800b1de845f57ce79074fdb0a7151fabc6f',
           '0e31da9bc26f8286b559102c163cbaf8edc682ea',
           '3e536f9e1c8858dd9faa6b7bc9002fb1f66aa0b6']
SOURCE = '496056a6a528d01d544abbf77e18877b60d629bd'
TREE = '28b3d96d48e13b3e9befaa7ec7ab780130453363'
LANES = {'web', 'app', 'accounts', 'recommendations', 'social', 'messaging', 'notifications'}
STAT_KEYS = ('dev', 'ino', 'mode', 'uid', 'gid', 'bytes', 'mtime_ns', 'ctime_ns', 'nlink')
PORTABLE = ('bytes', 'sha256', 'mode', 'uid', 'gid', 'mtime_ns')


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def hex64(value):
    return isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value) is not None


def literal(value):
    need(isinstance(value, str) and not value.startswith('/') and '\\' not in value
         and all(x not in ('', '.', '..') for x in value.split('/')), 'literal relative path')
    return value


def parent_fd(path):
    need(path.is_absolute() and path == Path(os.path.normpath(path)), 'literal absolute path')
    fd = os.open('/', os.O_RDONLY | os.O_DIRECTORY)
    try:
        for part in path.parts[1:-1]:
            following = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            os.close(fd); fd = following
        return fd
    except BaseException:
        os.close(fd); raise


def meta(info):
    return dict(dev=info.st_dev, ino=info.st_ino, mode=stat.S_IMODE(info.st_mode), uid=info.st_uid,
                gid=info.st_gid, bytes=info.st_size, mtime_ns=info.st_mtime_ns,
                ctime_ns=info.st_ctime_ns, nlink=info.st_nlink)


def same(info, row, directory=False, removing=False):
    need(stat.S_ISDIR(info.st_mode) if directory else stat.S_ISREG(info.st_mode), 'original regular type')
    keys = ('dev', 'ino', 'mode', 'uid', 'gid') if directory and removing else STAT_KEYS
    need(all(meta(info)[k] == row[k] for k in keys), 'original inode/full metadata changed')
    if not directory:
        need(info.st_nlink == 1, 'hardlink refused')


def current(path, collect=False):
    need(path.is_absolute() and path.resolve() == path, 'canonical input path')
    parent = parent_fd(path); fd = None
    try:
        before = os.stat(path.name, dir_fd=parent, follow_symlinks=False)
        need(stat.S_ISREG(before.st_mode) or stat.S_ISDIR(before.st_mode), 'no symlink/special file')
        if stat.S_ISDIR(before.st_mode):
            fd = os.open(path.name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent)
            need(meta(os.fstat(fd)) == meta(before), 'directory swapped before open')
            entries = sorted(os.listdir(fd)); need(meta(os.fstat(fd)) == meta(before), 'directory changed during read')
            return dict(path=str(path), file=False, **meta(before), sha256=None, git_blob=None, entries=entries)
        need(before.st_nlink == 1, 'single-link regular file')
        fd = os.open(path.name, os.O_RDONLY | os.O_NOFOLLOW, dir_fd=parent)
        need(meta(os.fstat(fd)) == meta(before), 'file swapped before open')
        digest = hashlib.sha256(); blob = hashlib.sha1(('blob ' + str(before.st_size) + '\0').encode())
        size = 0; chunks = []
        while True:
            block = os.read(fd, 1 << 20)
            if not block:
                break
            size += len(block); digest.update(block); blob.update(block)
            if collect:
                need(size <= 64 << 20, 'bounded metadata/keeper input'); chunks.append(block)
        need(meta(os.fstat(fd)) == meta(before) and size == before.st_size, 'file changed during read')
        row = dict(path=str(path), file=True, **meta(before), sha256=digest.hexdigest(), git_blob=blob.hexdigest(), entries=None)
        return (b''.join(chunks), row) if collect else row
    finally:
        if fd is not None:
            os.close(fd)
        os.close(parent)


def compare(path, row, removing_directory=False):
    if removing_directory:
        need(row['file'] is False and path.lstat().st_uid == row['uid'] == os.getuid(), 'owned planned directory')
        now = current(path); same(path.lstat(), row, directory=True, removing=True)
        need(not now['entries'], 'only empty planned directories; no recursive fallback')
        return
    now = current(path)
    need(all(now[k] == row[k] for k in now), 'exact original path/hash/stat/membership changed')


def snapshot(root):
    return [current(path) for path in [root] + sorted(root.rglob('*'))]


# Proposal-only read/hash inventory: no verifier, Docker call or removal is invoked.
import shutil
import collections

def encoded(v):return (json.dumps(v,separators=(',',':'))+'\n').encode()
def compressed(path,v):
    raw=encoded(v)
    with path.open('xb')as f:
        with gzip.GzipFile(fileobj=f,mode='wb',mtime=0)as out:out.write(raw)
    return dict(sha256=sha(path.read_bytes()),decoded_sha256=sha(raw),bytes=path.stat().st_size)

def protected_old(root):
    result=[]
    for directory,dirs,files in os.walk(root,followlinks=False):
        parent=Path(directory)
        dirs[:]=[n for n in dirs if parent/n not in (root/'source',root/'binaries')]
        result.append(current(parent))
        for name in sorted(files):
            p=parent/name
            if p==root/'proof/command-006.stdout':continue
            result.append(current(p))
    return result

def build_proposal():
    need(not (HERE/'plan.json').exists(),'exclusive proposal output')
    original=BASE/'notification-inbox-closure-preparation/retention/DRAFT_PENDING.json'
    old_pending=sha(original.read_bytes());need(old_pending=='7b9458a3163f76f26d6d54b661911cf8f491e9f4cf7632de1a940143d9de3567','old pending proposal unchanged')
    disk=dict(zip(('total','used','free'),shutil.disk_usage(BASE)))
    targets=[];directories=[];epochs=[];preserved=[]
    for root,source in zip(OLD,SOURCES):
        raw,resultrow=current(root/'result.json',collect=True);result=json.loads(raw)
        source_raw,sourcerow=current(root/'source-manifest.json',collect=True);manifest=json.loads(source_raw)
        need(result['source']==source and all('link'not in r for r in manifest),'literal old source; no source symlink targets')
        byname={r['path']:r for r in manifest};need(len(byname)==len(manifest),'unique source manifest')
        source_snapshot=snapshot(root/'source')
        need({str(Path(r['path']).relative_to(root/'source'))for r in source_snapshot if r['file']}==set(byname),'all exact source files')
        for row in source_snapshot:
            need(row['uid']==os.getuid(),'owned old source targets')
            if row['file']:
                rel=str(Path(row['path']).relative_to(root/'source'));wanted=byname[rel]
                need(row['bytes']==wanted['bytes']and row['sha256']==wanted['sha256']and bool(row['mode']&0o111)==bool(wanted['mode']&0o111),'old export matches original manifest')
                targets.append(dict(row,category='old-generated-source',epoch=source,relative=rel))
            else:directories.append(dict(row,category='old-generated-directory',epoch=source))
        bins=snapshot(root/'binaries')
        for row in bins:
            need(row['uid']==os.getuid(),'owned old binary targets')
            if not row['file']:directories.append(dict(row,category='old-generated-directory',epoch=source));continue
            path=Path(row['path']);matches=[c for c in result['commands']if '-o'in c['argv']and c['argv'][c['argv'].index('-o')+1]==str(path)]
            need(len(matches)==1 and matches[0]['exit']==0,'successful original compile beforeimage')
            recorded=result.get('reference_bootstrap_binary')if path.name=='reference-bootstrap'else(result.get('notifications_reference_bootstrap_binary')if path.name=='reference-notifications-bootstrap'else result['lanes'].get(path.stem,{}).get('binary'))
            need(recorded is None or recorded['sha256']==row['sha256'],'recorded runtime/bootstrap binary identity')
            targets.append(dict(row,category='old-generated-binary',epoch=source,build_provenance=dict(command=matches[0]['argv'],exit=0,stdout=matches[0]['stdout'],stderr=matches[0]['stderr'],historical_binary_digest_recorded=recorded is not None,meaning='Successful original build plus current pinned beforeimage; absent runtime hash never implies this lane qualified.')))
        preserved+=protected_old(root)
        epochs.append(dict(root=str(root),source=source,tree=result['tree'],method_pass=result['method_pass'],qualified_lanes=list(result['lanes']),result_sha256=resultrow['sha256'],source_manifest_sha256=sourcerow['sha256'],source_files=len(manifest),binary_files=sum(r['file']for r in bins)))
        print(root.name,'sourcefiles',len(manifest),'binaries',sum(r['file']for r in bins),flush=True)
    for root in OLD[1:]+[LATEST]:
        raw,_=current(root/'result.json',collect=True);result=json.loads(raw);commands=[c for c in result['commands']if c['argv'][0]=='git'and 'archive'in c['argv']]
        need(len(commands)==1 and commands[0]['stdout']['path']=='proof/command-006.stdout','one exact redundant original Git tar')
        row=current(root/'proof/command-006.stdout');need(row['bytes']==commands[0]['stdout']['bytes']and row['sha256']==commands[0]['stdout']['sha256'],'original tar bytes/hash')
        targets.append(dict(row,category='redundant-original-git-archive-stdout',epoch=result['source']))
    old_archive=OLD[0]/'proof/command-006.stdout';need(not os.path.lexists(old_archive),'e900 tar already pruned; never count new deletion')
    prior=REPO/'docs/reviews/gui-native-notification-preferences/retention-result.json';raw,pr=current(prior,collect=True);previous=json.loads(raw);matches=[r for r in previous['deleted']if r['path']==str(old_archive)]
    need(len(matches)==1 and matches[0]['sha256']=='2081ba49bc398d18b6535e90f794831539fcfc88ff59ff546d9ee7fbd9a41339','exact old already-pruned receipt')
    already=[dict(path=str(old_archive),action='NONE_ALREADY_PRUNED',raw_bytes_available=False,receipt=dict(path=str(prior),sha256=pr['sha256']),previous_record=matches[0])]
    latest_rows=[r for r in snapshot(LATEST)if r['path']!=str(LATEST/'proof/command-006.stdout')]
    latest=dict(schema=1,root=str(LATEST),UI_root=str(CURRENT_UI),rows=latest_rows,UI_rows=snapshot(CURRENT_UI))
    candidate_snapshot=snapshot(CANDIDATE)
    inventory=dict(schema=1,targets=sorted(targets,key=lambda r:r['path']),directories_bottom_up=sorted(directories,key=lambda r:(-len(Path(r['path']).parts),r['path'])),preserved_old=preserved,candidate_snapshot=candidate_snapshot)
    need(len({r['path']for r in targets})==len(targets),'unique exact target paths')
    need(all(not Path(r['path']).is_relative_to(CANDIDATE)and not Path(r['path']).is_relative_to(CURRENT_UI)for r in targets),'no current UI/candidate target')
    inv=compressed(HERE/'inventory.json.gz',inventory);last=compressed(HERE/'latest-snapshot.json.gz',latest)
    categories=[dict(category=k,files=len(v),logical_bytes=sum(r['bytes']for r in v))for k,v in __import__('itertools').groupby([],lambda _:None)]
    groups=collections.defaultdict(list)
    for row in targets:groups[row['category']].append(row)
    categories=[dict(category=k,files=len(v),logical_bytes=sum(r['bytes']for r in v))for k,v in sorted(groups.items())]
    plan=dict(schema=1,status='PROPOSAL_ONLY_NO_VERIFIER_DRYRUN_OR_DELETION',source=SOURCE,tree=TREE,method_sha256=sha((HERE/'retain.py').read_bytes()),epochs=epochs,inventory_sha256=inv['sha256'],inventory_decoded_sha256=inv['decoded_sha256'],latest_snapshot_sha256=last['sha256'],target_files=len(targets),target_directories=len(directories),logical_bytes=sum(r['bytes']for r in targets),categories=categories,already_unavailable=already,disk_before=disk,candidate=dict(path=str(CANDIDATE),archive_sha256='e007db95293927d330e574efeb4938e52edd2309b520f07895ce0c5fa77b5eb5',archive_bytes=8921346,members=2695,keeper_review_sha256='205b60d81c51e277d4c0167fa24b40905e7f60ecd4dac3b0e8cb4a0207dd8427',feature_review_sha256='38abd7473228855908d9e4a1e5bd85efccfd0346d27dd3e7a7e1402095fb4c8b'),portable_fields=list(PORTABLE),inode_guard_fields=list(STAT_KEYS),preserved=['Latest496 source/binaries/current73artifact UI and all current raw proof/logs except duplicate full Git stdout','All historical raw test/proof/log/report/capture/CID/source-manifest/HTML/PNG and source-method packets','All Git source branches/objects/unmerged packets/original baselines/canonical keepers/caches/Docker images','Accepted candidate496 immutable until post-retention canonical promotion; Teacher/programme/future-date/other-owner paths excluded'],physical_deletion_performed=False,author_verifier_executed=False,source_plan_reviews='PENDING_ROOT_AND_INDEPENDENT_PEER')
    with(HERE/'plan.json').open('x')as f:json.dump(plan,f,indent=2);f.write('\n')
    need(sha(original.read_bytes())==old_pending,'old pending proposal preserved')
    print(json.dumps(dict(files=len(targets),directories=len(directories),logical_bytes=plan['logical_bytes'],inventory_sha256=inv['sha256'],latest_snapshot_sha256=last['sha256'],plan_sha256=sha((HERE/'plan.json').read_bytes()))))

if __name__=='__main__':build_proposal()
