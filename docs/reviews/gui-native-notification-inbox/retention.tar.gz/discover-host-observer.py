"""Read-only ownership-view discovery; does not rebind or delete anything."""
from pathlib import Path
import gzip
import hashlib
import json
import os

root = Path(__file__).resolve().parent
source = (root / "retain.py").read_bytes()
assert hashlib.sha256(source).hexdigest() == "3e95f35b1d16c63981306a71d783f771f3591dceb6963b67e1ae7d1f9d6756cb"
ns = {"__file__": str(root / "retain.py"), "__name__": "host_observer_discovery"}
exec(compile(source, str(root / "retain.py"), "exec"), ns)
inventory_raw = (root / "inventory.json.gz").read_bytes()
latest_raw = (root / "latest-snapshot.json.gz").read_bytes()
assert hashlib.sha256(inventory_raw).hexdigest() == "61e8884c7779a255972cc10ccd99cd3edfc03f95aaeca35cf9ac3771795222ef"
assert hashlib.sha256(latest_raw).hexdigest() == "7549fd9625e904d47efcdfdfd5d3212afc88953081d577dcb9eca15066b66e74"
inventory = json.loads(gzip.decompress(inventory_raw))
latest = json.loads(gzip.decompress(latest_raw))
target_paths = {r["path"] for r in inventory["targets"] + inventory["directories_bottom_up"]}
changes, other, target_owner_changes = [], [], []
checked = 0


def visit(value):
    global checked
    if isinstance(value, dict):
        if "path" in value and type(value.get("file")) is bool:
            now = ns["current"](Path(value["path"]))
            differences = {k: {"sandbox": value[k], "host": v}
                           for k, v in now.items() if value[k] != v}
            non_owner = {k: v for k, v in differences.items() if k not in ("uid", "gid")}
            if non_owner:
                other.append({"path": value["path"], "differences": non_owner})
            if any(k in differences for k in ("uid", "gid")):
                record = {"path": value["path"], "sandbox_uid_gid": [value["uid"], value["gid"]],
                          "host_uid_gid": [now["uid"], now["gid"]],
                          "delete_target": value["path"] in target_paths,
                          "all_non_uid_gid_fields_identical": not non_owner,
                          "dev": now["dev"], "ino": now["ino"], "bytes": now["bytes"],
                          "mtime_ns": now["mtime_ns"], "ctime_ns": now["ctime_ns"],
                          "sha256": now["sha256"]}
                changes.append(record)
                if record["delete_target"]:
                    target_owner_changes.append(record)
            checked += 1
        else:
            for child in value.values():
                visit(child)
    elif isinstance(value, list):
        for child in value:
            visit(child)


visit(inventory)
visit(latest)
report = {
    "schema": 1, "status": "READ_ONLY_HOST_OBSERVER_DISCOVERY_NO_REBIND_OR_DELETION",
    "method_sha256": hashlib.sha256(source).hexdigest(),
    "original_inventory_sha256": hashlib.sha256(inventory_raw).hexdigest(),
    "original_latest_snapshot_sha256": hashlib.sha256(latest_raw).hexdigest(),
    "observer": {"uid": os.getuid(), "gid": os.getgid(),
                 "uid_map": Path("/proc/self/uid_map").read_text(),
                 "gid_map": Path("/proc/self/gid_map").read_text()},
    "rows_checked": checked, "ownership_view_differences": changes,
    "non_owner_field_differences": other, "delete_target_owner_differences": target_owner_changes,
    "physical_deletion_performed": False, "current_manifests_modified": False,
}
output = root / "host-observer-discovery.json"
assert not output.exists()
output.write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"rows_checked": checked, "ownership_view_differences": len(changes),
                  "non_owner_field_differences": len(other),
                  "delete_target_owner_differences": len(target_owner_changes),
                  "report_sha256": hashlib.sha256(output.read_bytes()).hexdigest()}))
