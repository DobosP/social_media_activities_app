# Exact Social rolling-retention proposal

Author: notification_actual_review. Source/plan requires Root and a different
agent's review. No verifier, dry-run, Docker action or remover has been run.
The standalone proposal inventory only read/hashes owned files and writes these
metadata files. Existing retention/DRAFT_PENDING.json and all its siblings stay
untouched. No old draft or prior approval admits this proposal.

Exact clean HEAD496056a6a528d01d544abbf77e18877b60d629bd/tree28b3 is required.
Keeper candidate-496/e007 is now independently accepted205b60 and bounded-feature
accepted38abd, including known negative rendering tradeoffs. Candidate files and
metadata are immutable/protected. Canonical docs promotion occurs after retention;
no dirty-docs or source bridge is allowed here.

Only targets: four superseded generated source/binary setups e900/f087/0e31/3e,
and the four exact redundant original Git stdout streams f087/0e31/3e/current496.
Actual inventory:8863files,967directories,1,278,664,437logical bytes.
e900 archive stdout is NONE_ALREADY_PRUNED, bound to its old actual receipt.
No HTML, PNG, report, capture, raw test/proof/log, method source, packet, branch,
canonical keeper, baseline, cache, image, Teacher/programme/future-date path is
targeted. Latest496 source/binaries/currentUI and all other current proof remain.

F087's unused/failed-lane binaries have original successful compile receipts and
current exact beforeimages; missing historical runtime hashes do not imply those
lanes were qualified. All failed results remain failed. Source copies match full
original manifests and preserved Git blobs/commits; no source branches are removed.

Binding example has accepted keeper references but remains PENDING until Root
and independent peer source/plan reviews are added, exact bound hashes retained,
and actual issued_unix_ns/UUID4 nonce are freshly issued. Use issued_unix_ns (the
field in JSON), within one hour after both keeper reviews. Verification and
execution both require that bound status before bulk/custody work. Root must
change status to BOUND_ACCEPTED_KEEPER_REVIEWED_EXACT_RETENTION only after review.

The remover full-reads both keepers/member metadata, verifies exact allowlist,
original successful compile receipts/current binary beforeimages, all62 owned
CID/name absences and live target-bind absence, clean source, immutable candidate,
latest snapshots and all current inode/hash/owner/membership. Execution repeats
each exact file check, unlinks only that regular single-link file through
O_NOFOLLOW parent descriptors, then removes only planned empty directories.
No recursive fallback or image/cache pruning. A consumed UUID marker prevents
automatic replay; partial receipts are always retained. Any drift stops work.

After source/plan acceptance, Root can fill a NEW binding and first run:
python3 -I retain.py --binding binding.json --receipt dry-run.json
Then independently inspect the concrete verifier receipt before the separate
--execute call with a fresh receipt path. This README is not execution approval.

Deleted raw source/binary/Git stdout paths become unavailable. Git refs,
accepted compact keeper bytes/original metadata and all raw proof/report/log/
capture/HTML/PNG/source packets remain; history must never claim full old setups
are still available. Final actual deletion and metadata review remain separate.
