#!/usr/bin/env python3
"""Causal no-delete diagnostic; never canonical dry-run acceptance."""
from pathlib import Path
import hashlib,inspect,json,sys
root=Path(__file__).resolve().parent
source=root/'retain.py'
raw=source.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='3e95f35b1d16c63981306a71d783f771f3591dceb6963b67e1ae7d1f9d6756cb'
assert len(sys.argv)==1
ns={'__file__':str(source),'__name__':'causal_retention_namespace'}
exec(compile(raw,str(source),'exec'),ns)
original=ns['need'];witness=[]
def traced_need(ok,message):
    if not ok:
        caller=inspect.currentframe().f_back
        local=caller.f_locals
        record={'function':caller.f_code.co_name,'line':caller.f_lineno,'message':message}
        if caller.f_code.co_name=='compare':
            record['path']=str(local['path'])
            record['differences']={k:{'expected':local['row'].get(k),'observed':v} for k,v in local['now'].items() if local['row'].get(k)!=v}
        witness.append(record)
    return original(ok,message)
ns['need']=traced_need
receipt=root/'causal-no-delete-receipt.json'
assert not receipt.exists()
sys.argv=[str(source),'--binding',str(root/'binding-dry-run.json'),'--receipt',str(receipt)]
assert '--execute' not in sys.argv
try:
    ns['main']()
finally:
    if receipt.exists():
        d=json.loads(receipt.read_text());d['original_validator_status']=d['status'];d['status']='CAUSAL_ONLY_NOT_CANONICAL_DRYRUN';d['diagnostic_source_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();d['guard_semantics']='All original guards/comparisons delegated unchanged; only false-need caller metadata observed; no execute option admitted.';d['failure_witness']=witness;assert d['executed'] is False and not d['deleted'];receipt.write_text(json.dumps(d,indent=2)+'\n')
    (root/'causal-no-delete-witness.json').write_text(json.dumps({'schema':1,'scope':'Diagnostic only; no predicate modified or failure promoted','witness':witness,'physical_deletion_performed':False},indent=2)+'\n')
