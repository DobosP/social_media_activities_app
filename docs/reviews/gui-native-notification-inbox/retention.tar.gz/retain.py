#!/usr/bin/env python3
"""Draft narrow Social inbox retention; no recursive removal or implicit approval.

Unexecuted source. Pending bindings refuse before bulk reads/removal. Root must
bind accepted successor custody, terminal latest snapshot and independent review.
"""
import argparse
from decimal import Decimal
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import tarfile
import time
import uuid

BASE = Path('/home/dobo/work/_temp/feat__gui-app-migration-a/social-family')
HERE = BASE / 'notification-inbox-closure-preparation/retention-v4'
CANDIDATE = BASE / 'notification-inbox-closure-preparation/candidate-496'
CURRENT_UI = Path('/home/dobo/work/_temp/ni-ui/run-496056a6a528-7da60674-4319-40ce-9231-b40dad1d3e39')
REPO = Path('/home/dobo/work/_worktrees/social_media_activities_app/feat__gui-app-migration-a')
OLD = [
    BASE / 'notification-preferences-pg-qa/run-e900960d50be-2503620e-5e0f-4acb-9ea2-09f713d162ae',
    BASE / 'notification-inbox-pg-qa/run-f0874800b1de-9f0eaafa-44f5-4df3-ba44-e40a419e5350',
    BASE / 'notification-inbox-pg-qa/run-0e31da9bc26f-dfae1f27-76e5-48ab-865c-9a8a2b6fb9c5',
    BASE / 'notification-inbox-pg-qa/run-3e536f9e1c88-42f1d122-b499-4659-89e1-68c180bffc1f']
LATEST = BASE / 'notification-inbox-pg-qa/run-496056a6a528-9681bb2d-06e5-4b23-9b62-8ab6f4ce3b80'
SOURCES = ['e900960d50beed03ef387159da0e6d903ec5bf9a',
           'f0874800b1de845f57ce79074fdb0a7151fabc6f',
           '0e31da9bc26f8286b559102c163cbaf8edc682ea',
           '3e536f9e1c8858dd9faa6b7bc9002fb1f66aa0b6']
SOURCE = '496056a6a528d01d544abbf77e18877b60d629bd'
TREE = '28b3d96d48e13b3e9befaa7ec7ab780130453363'
LANES = {'web', 'app', 'accounts', 'recommendations', 'social', 'messaging', 'notifications'}
STAT_KEYS = ('dev', 'ino', 'mode', 'uid', 'gid', 'bytes', 'mtime_ns', 'ctime_ns', 'nlink')
PORTABLE = ('bytes', 'sha256', 'mode', 'uid', 'gid', 'mtime_ns')


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def hex64(value):
    return isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value) is not None


def literal(value):
    need(isinstance(value, str) and not value.startswith('/') and '\\' not in value
         and all(x not in ('', '.', '..') for x in value.split('/')), 'literal relative path')
    return value


def parent_fd(path):
    need(path.is_absolute() and path == Path(os.path.normpath(path)), 'literal absolute path')
    fd = os.open('/', os.O_RDONLY | os.O_DIRECTORY)
    try:
        for part in path.parts[1:-1]:
            following = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            os.close(fd); fd = following
        return fd
    except BaseException:
        os.close(fd); raise


def meta(info):
    return dict(dev=info.st_dev, ino=info.st_ino, mode=stat.S_IMODE(info.st_mode), uid=info.st_uid,
                gid=info.st_gid, bytes=info.st_size, mtime_ns=info.st_mtime_ns,
                ctime_ns=info.st_ctime_ns, nlink=info.st_nlink)


def same(info, row, directory=False, removing=False):
    need(stat.S_ISDIR(info.st_mode) if directory else stat.S_ISREG(info.st_mode), 'original regular type')
    keys = ('dev', 'ino', 'mode', 'uid', 'gid') if directory and removing else STAT_KEYS
    need(all(meta(info)[k] == row[k] for k in keys), 'original inode/full metadata changed')
    if not directory:
        need(info.st_nlink == 1, 'hardlink refused')


def current(path, collect=False):
    need(path.is_absolute() and path.resolve() == path, 'canonical input path')
    parent = parent_fd(path); fd = None
    try:
        before = os.stat(path.name, dir_fd=parent, follow_symlinks=False)
        need(stat.S_ISREG(before.st_mode) or stat.S_ISDIR(before.st_mode), 'no symlink/special file')
        if stat.S_ISDIR(before.st_mode):
            fd = os.open(path.name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent)
            need(meta(os.fstat(fd)) == meta(before), 'directory swapped before open')
            entries = sorted(os.listdir(fd)); need(meta(os.fstat(fd)) == meta(before), 'directory changed during read')
            return dict(path=str(path), file=False, **meta(before), sha256=None, git_blob=None, entries=entries)
        need(before.st_nlink == 1, 'single-link regular file')
        fd = os.open(path.name, os.O_RDONLY | os.O_NOFOLLOW, dir_fd=parent)
        need(meta(os.fstat(fd)) == meta(before), 'file swapped before open')
        digest = hashlib.sha256(); blob = hashlib.sha1(('blob ' + str(before.st_size) + '\0').encode())
        size = 0; chunks = []
        while True:
            block = os.read(fd, 1 << 20)
            if not block:
                break
            size += len(block); digest.update(block); blob.update(block)
            if collect:
                need(size <= 64 << 20, 'bounded metadata/keeper input'); chunks.append(block)
        need(meta(os.fstat(fd)) == meta(before) and size == before.st_size, 'file changed during read')
        row = dict(path=str(path), file=True, **meta(before), sha256=digest.hexdigest(), git_blob=blob.hexdigest(), entries=None)
        return (b''.join(chunks), row) if collect else row
    finally:
        if fd is not None:
            os.close(fd)
        os.close(parent)


def compare(path, row, removing_directory=False):
    if removing_directory:
        need(row['file'] is False and path.lstat().st_uid == row['uid'] == os.getuid(), 'owned planned directory')
        now = current(path); same(path.lstat(), row, directory=True, removing=True)
        need(not now['entries'], 'only empty planned directories; no recursive fallback')
        return
    now = current(path)
    need(all(now[k] == row[k] for k in now), 'exact original path/hash/stat/membership changed')


def snapshot(root):
    return [current(path) for path in [root] + sorted(root.rglob('*'))]


class Inputs:
    """Keep first validated raw bytes/stat; never validate one read then consume another."""
    def __init__(self):
        self.rows = {}
    def read(self, path, digest=None):
        if path not in self.rows:
            self.rows[path] = current(path, collect=True)
        raw, row = self.rows[path]
        if digest is not None:
            need(hex64(digest) and sha(raw) == digest, 'explicit bound input differs: ' + str(path))
        return raw
    def json(self, path, digest=None):
        return json.loads(self.read(path, digest))
    def fence(self):
        for path, (raw, row) in self.rows.items():
            now, info = current(path, collect=True)
            need(now == raw and info == row, 'first-read input drift: ' + str(path))


def scalars(value):
    if isinstance(value, str):
        return {value}
    if isinstance(value, dict):
        return set().union(*(scalars(x) for x in value.values()), set())
    if isinstance(value, list):
        return set().union(*(scalars(x) for x in value), set())
    return set()


def accepted(inputs, spec, digests, source=None):
    need(set(spec) == {'path', 'sha256', 'field', 'expected'}, 'explicit independent review binding')
    path = Path(spec['path']); need(path.is_relative_to(BASE) or path.is_relative_to(REPO / 'docs/reviews'), 'owned/canonical review')
    value = inputs.json(path, spec['sha256']); expected = spec['expected']
    need(spec['field'] in ('status', 'verdict') and isinstance(expected, str)
         and (expected.startswith('ACCEPT') or 'ACCEPTED' in expected) and 'NOT_ACCEPTED' not in expected
         and value.get(spec['field']) == expected and value.get('findings') == [], 'actual independently accepted review')
    need(all(x in scalars(value) for x in list(digests) + ([] if source is None else [source])), 'review must contain actual bound source/digest scalars')
    return value


def keeper(inputs, spec, kind):
    directory = REPO / 'docs/reviews/gui-native-notification-preferences' if kind == 'preferences' else CANDIDATE
    need(spec['path'] == str(directory), 'literal accepted keeper role')
    raw = inputs.read(directory / 'evidence.tar.gz', spec['archive_sha256'])
    manifest = inputs.json(directory / 'archive-manifest.json', spec['manifest_sha256'])
    selection_raw = inputs.read(directory / 'selection.json', spec['selection_sha256']); selection = json.loads(selection_raw)
    need(isinstance(manifest, list) and len({r['member'] for r in manifest}) == len(manifest), 'unique complete Social keeper manifest')
    if kind == 'preferences':
        need(spec['archive_sha256'] == '29a9ff0d2e420d5454aaebd324d0bc686bc22cf14b6f04ce86e4b8ce7e71d7e5'
             and spec['manifest_sha256'] == 'f308fef6e70d9148ae91617cf949ed30ad9e94adc87116cb5e219d1e001885ed'
             and spec['selection_sha256'] == '292307e96ab6a703c24e4a591b8ed3e35a780c7d133c5a0b9b050810f6b46c32', 'unchanged accepted preference keeper')
    if kind == 'inbox':
        need(spec['archive_sha256'] == 'e007db95293927d330e574efeb4938e52edd2309b520f07895ce0c5fa77b5eb5'
             and spec['manifest_sha256'] == '6720016f22139a372003b81c2d4ce6f2fe2be01ffb04eda4d91c941f23fceead'
             and spec['selection_sha256'] == '8eb2204317187acf5d37c5dafc72e7352a5a5d5a57df2a552500f26007a272a8','exact accepted pre-publication candidate')
        receipt = inputs.json(directory / 'collection-result.json', spec['collection_result_sha256'])
        need(receipt['qualified_source'] == SOURCE and receipt['archive_sha256'] == spec['archive_sha256']
             and receipt['archive_members'] == 2695 and receipt['archive_bytes'] == 8921346
             and receipt['inputs_unchanged'] is True and receipt['full_readback'] is True
             and receipt['bytes_mode_UID_GID_nanosecondmtime'] is True and receipt['physical_deletion_performed'] is False,'actual unchanged candidate collection custody')
    need(set(spec['reviews']) == {'keeper', 'feature'}, 'independent keeper AND feature acceptance')
    source = SOURCES[0] if kind == 'preferences' else SOURCE
    for role, review in spec['reviews'].items():
        accepted(inputs, review, [spec['archive_sha256']] + ([spec['manifest_sha256'], spec['selection_sha256']] if role == 'keeper' else []), source)
    index = {}; member_hashes = set(); total = 0
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as archive:
        members = archive.getmembers(); need([m.name for m in members] == [r['member'] for r in manifest], 'complete canonical member inventory')
        for member, row in zip(members, manifest):
            literal(member.name)
            need(member.isfile() and member.size == row['bytes'] and member.mode == row['mode']
                 and member.uid == row['uid'] and member.gid == row['gid']
                 and int(Decimal(member.pax_headers['mtime']) * 10 ** 9) == row['mtime_ns'], 'canonical full portable metadata')
            total += member.size; need(0 <= member.size <= 64 << 20 and total <= 256 << 20, 'bounded keeper readback')
            body = archive.extractfile(member).read(); need(sha(body) == row['sha256'], 'canonical complete member bytes')
            if member.name == 'selection.json':
                need(body == selection_raw, 'outer/archived selection exact')
            index.setdefault(row['original'], []).append(row); member_hashes.add(row['sha256'])
    return {'index': index, 'selection': selection, 'member_hashes': member_hashes}


def lifecycle(inputs, root, value, final=False):
    expected_roles = {'db', *LANES, *('reference-' + lane for lane in LANES)} if final else None
    if expected_roles is not None:
        need(set(value['cleanup']) == expected_roles and value['method_pass'] is True and not value['errors']
             and set(value['lanes']) == LANES and all(x['state'] == 'PASS' for x in value['lanes'].values()), 'accepted terminal complete-seven latest required')
    need(all(x['stopped'] is True and x['id_absent'] is True and x['name_absent'] is True for x in value['cleanup'].values()), 'original created-container stop receipts')
    p = value['pg_cleanup']; need(p['stop_exit'] == 0 and p['status_exit'] == 3 and p['pid_probe_exit'] == 1 and p['pid_and_socket_files_absent'] == 1, 'original exact PostgreSQL shutdown receipt')
    need(inputs.json(root / 'socket/pg-cleanup.json') == p and not list((root / 'socket').glob('.s.PGSQL.*')), 'current original cleanup JSON/socket/lock absence')
    need({f.stem for f in root.glob('*.cid')} == set(value['cleanup']), 'exact created CID file census')
    for role, row in value['cleanup'].items():
        need(re.fullmatch('[0-9a-f]{64}', row['cid']) and inputs.read(root / (role + '.cid')).decode().strip() == row['cid'], 'original exact CID identity')
    names = {c['argv'][c['argv'].index('--name') + 1] for c in value['commands'] if c['argv'][:2] == ['docker', 'create'] and '--name' in c['argv']}
    need(len(names) == len(value['cleanup']), 'owned create-name/CID census')
    return {x['cid'] for x in value['cleanup'].values()}, names


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args], env={'PATH': os.defpath, 'LANG': 'C.UTF-8'})


def source_export(inputs, root, result, rows):
    manifest = inputs.json(root / 'source-manifest.json'); lookup = {x['path']: x for x in manifest}
    need(len(lookup) == len(manifest), 'complete unique source manifest')
    tree = {}
    for entry in git('ls-tree', '-r', '-z', result['source']).split(b'\0'):
        if entry:
            header, name = entry.split(b'\t', 1); tree[name.decode()] = tuple(header.decode().split())
    need(set(tree) == set(lookup) == {r['relative'] for r in rows}, 'all generated source paths map exact recorded Git tree')
    need(git('rev-parse', result['source'] + '^{tree}').decode().strip() == result['tree'], 'recorded source commit/tree remains available')
    git('merge-base', '--is-ancestor', result['source'], SOURCE)
    for row in rows:
        name = literal(row['relative']); wanted = lookup[name]
        need(row['bytes'] == wanted['bytes'] and row['sha256'] == wanted['sha256']
             and tree[name] == (('100755' if wanted['mode'] & 0o111 else '100644'), 'blob', row['git_blob']), 'exact source bytes/blob/mode in preserved Git')


def unpack(inputs, path, digest):
    raw = inputs.read(path, digest)
    with gzip.GzipFile(fileobj=io.BytesIO(raw), mode='rb') as stream:
        decoded = stream.read((128 << 20) + 1)
    need(len(decoded) <= 128 << 20, 'bounded portable manifest')
    return decoded, json.loads(decoded)


def protected(rows, removed=()):
    removed = set(removed)
    for row in rows:
        path = Path(row['path'])
        if row['file']:
            compare(path, row)
        elif removed:
            now = current(path); same(path.lstat(), row, directory=True, removing=True)
            need(now['entries'] == [name for name in row['entries'] if str(path / name) not in removed], 'only exact planned child entries may disappear')
        else:
            compare(path, row)


def source_fence():
    need(git('rev-parse', 'HEAD').decode().strip() == SOURCE
         and git('rev-parse', 'HEAD^{tree}').decode().strip() == TREE
         and not git('status', '--porcelain', '--untracked-files=all'), 'exact clean496 source required before canonical promotion')


def fresh(binding, inputs):
    stamp = binding['issued_unix_ns']; now = time.time_ns()
    need(type(stamp) is int and 0 <= now - stamp <= 3600 * 10**9, 'fresh binding issued within the preceding hour')
    token = uuid.UUID(binding['execution_nonce'])
    need(str(token) == binding['execution_nonce'] and token.version == 4, 'fresh literal UUID4 execution nonce')
    for review in binding['keepers']['inbox']['reviews'].values():
        need(stamp >= Path(review['path']).stat().st_mtime_ns, 'binding must follow actual independent keeper/feature acceptance')
    inputs.fence()


def live_absence(cids, names, targets):
    raw = subprocess.check_output(['docker', 'container', 'ls', '-a', '--no-trunc', '--format', '{{json .}}'])
    rows = [json.loads(line) for line in raw.splitlines()]
    for value in rows:
        need(value['ID'] not in cids and not (set(value['Names'].split(',')) & names), 'an owned original CID/name still exists')
        if value.get('State') != 'running':
            continue
        mounts = json.loads(subprocess.check_output(['docker', 'container', 'inspect', value['ID'], '--format', '{{json .Mounts}}']))
        for mount in mounts:
            if mount.get('Type') != 'bind':
                continue
            source = Path(mount['Source'])
            need(not any(source == p or source.is_relative_to(p) or p.is_relative_to(source) for p in targets), 'a running container bind overlaps a planned output')
    return dict(successful_daemon_inventory=True, original_CIDs_names_absent=len(cids),
                no_running_bind_overlap=True, containers_checked=len(rows), inventory_sha256=sha(raw))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binding', type=Path, required=True)
    parser.add_argument('--receipt', type=Path, required=True)
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    need(Path(__file__).resolve() == HERE/'retain.py' and args.binding.parent == HERE
         and args.receipt.parent == HERE and args.receipt.resolve() == args.receipt
         and not os.path.lexists(args.receipt), 'fresh literal owned receipt/binding')
    result = dict(schema=1, status='REFUSED_BEFORE_DELETION', executed=False, deleted=[],
                  removed_directories=[], logical_bytes_deleted=0)
    inputs = Inputs()
    try:
        binding = inputs.json(args.binding)
        need(binding.get('schema') == 1 and binding.get('status') == 'BOUND_ACCEPTED_KEEPER_REVIEWED_EXACT_RETENTION',
             'pending bindings refuse before bulk verification or removal')
        need(binding['source_sha'] == SOURCE and binding['source_tree'] == TREE, 'literal reviewed current source')
        inputs.read(HERE/'retain.py', binding['method_sha256'])
        plan = inputs.json(HERE/'plan.json', binding['plan_sha256'])
        decoded, inventory = unpack(inputs, HERE/'inventory.json.gz', binding['inventory_sha256'])
        _, latest = unpack(inputs, HERE/'latest-snapshot.json.gz', binding['latest_snapshot_sha256'])
        need(plan['schema'] == inventory['schema'] == latest['schema'] == 1
             and plan['source'] == SOURCE and plan['tree'] == TREE
             and plan['physical_deletion_performed'] is False
             and plan['inventory_sha256'] == binding['inventory_sha256']
             and plan['inventory_decoded_sha256'] == sha(decoded)
             and [Path(e['root']) for e in plan['epochs']] == OLD
             and latest['root'] == str(LATEST) and latest['UI_root'] == str(CURRENT_UI),
             'exact reviewed four superseded setups and current protected source/UI')
        need(set(binding['retention_reviews']) == {'root', 'peer'}, 'Root AND independent source/plan acceptance')
        root_review, peer_review = binding['retention_reviews']['root'], binding['retention_reviews']['peer']
        need(isinstance(root_review.get('path'), str) and isinstance(peer_review.get('path'), str)
             and Path(root_review['path']) != Path(peer_review['path'])
             and hex64(root_review.get('sha256')) and hex64(peer_review.get('sha256'))
             and root_review['sha256'] != peer_review['sha256'],
             'distinct Root and independent peer review paths AND content digests required')
        for ref in binding['retention_reviews'].values():
            accepted(inputs, ref, [binding['method_sha256'], binding['plan_sha256'],
                     binding['inventory_sha256'], binding['latest_snapshot_sha256']], SOURCE)
        need(set(binding['keepers']) == {'preferences', 'inbox'}, 'both independently accepted custody keepers')
        keepers = {kind: keeper(inputs, spec, kind) for kind, spec in binding['keepers'].items()}
        need(binding['native_result_sha256'] in keepers['inbox']['member_hashes']
             and binding['ui_result_sha256'] in keepers['inbox']['member_hashes'], 'actual latest PG/UI results must be in accepted custody')
        fresh(binding, inputs); source_fence()
        targets = inventory['targets']; directories = inventory['directories_bottom_up']
        need(len({r['path'] for r in targets}) == len(targets)
             and len({r['path'] for r in directories}) == len(directories), 'unique exact allowlist')
        all_cids, all_names = set(), set()
        old_results = {}
        for epoch, root, source in zip(plan['epochs'], OLD, SOURCES):
            value = inputs.json(root/'result.json', epoch['result_sha256']); old_results[str(root)] = value
            need(value['source'] == source and value['tree'] == epoch['tree'], 'original per-epoch source/tree')
            states = [(True, 13, 6), (False, 5, 1), (False, 14, 6), (True, 15, 7)]
            passed, role_count, lane_count = states[OLD.index(root)]
            need(value['method_pass'] is passed and len(value['cleanup']) == role_count
                 and len(value['lanes']) == lane_count
                 and (not value['errors'] if passed else bool(value['errors'])), 'original successful/failed disposition must not be promoted')
            cids, names = lifecycle(inputs, root, value); all_cids |= cids; all_names |= names
            source_rows = [r for r in targets if r['epoch'] == source and r['category'] == 'old-generated-source']
            source_export(inputs, root, value, source_rows)
            for row in source_rows:
                need(Path(row['path']) == root/'source'/literal(row['relative']), 'exact source member allowlist')
            binary_rows = [r for r in targets if r['epoch'] == source and r['category'] == 'old-generated-binary']
            expected_bins = {Path(c['argv'][c['argv'].index('-o')+1]) for c in value['commands']
                             if c['exit'] == 0 and '-o' in c['argv']
                             and Path(c['argv'][c['argv'].index('-o')+1]).parent == root/'binaries'}
            need({Path(r['path']) for r in binary_rows} == expected_bins
                 and {p for p in (root/'binaries').iterdir()} == expected_bins, 'only complete original successfully built outputs')
            for row in binary_rows:
                path = Path(row['path'])
                need(path.parent == root/'binaries' and path.name in {v+'.test' for v in LANES}|{'reference-bootstrap','reference-notifications-bootstrap'}, 'literal compiled binary names only')
                matches = [c for c in value['commands'] if '-o' in c['argv'] and c['argv'][c['argv'].index('-o')+1] == str(path)]
                need(len(matches) == 1 and matches[0]['exit'] == 0
                     and matches[0]['argv'][0:3] == ['/usr/local/go/bin/go','-C',str(root/'source/services/server')], 'original successful build command, not qualification')
                for stream in ('stdout','stderr'):
                    saved = matches[0][stream]; inputs.read(root/literal(saved['path']), saved['sha256'])
                recorded = value.get('reference_bootstrap_binary') if path.name == 'reference-bootstrap' else (
                    value.get('notifications_reference_bootstrap_binary') if path.name == 'reference-notifications-bootstrap' else value['lanes'].get(path.stem,{}).get('binary'))
                need(recorded is None or recorded['sha256'] == row['sha256'], 'recorded binary hash when available')
            wanted_source = {r['path'] for r in source_rows}
            actual_source = {str(p) for p in (root/'source').rglob('*') if p.is_file()}
            need(actual_source == wanted_source, 'complete source membership, no extra files')
            index = keepers['preferences' if root == OLD[0] else 'inbox']['index']
            for row in inventory['preserved_old']:
                path = Path(row['path'])
                if row['file'] and path.is_relative_to(root) and path.parent in (root,root/'proof'):
                    need(any(all(row[k] == m[k] for k in PORTABLE) for m in index.get(str(path),[])),
                         'original proof/result/CID/source manifest survives exact accepted custody')
        already = plan['already_unavailable']
        need(len(already) == 1 and already[0]['path'] == str(OLD[0]/'proof/command-006.stdout')
             and already[0]['action'] == 'NONE_ALREADY_PRUNED'
             and not os.path.lexists(already[0]['path']), 'e900 duplicate archive already unavailable; never count twice')
        previous = inputs.json(Path(already[0]['receipt']['path']), already[0]['receipt']['sha256'])
        need(previous['status'] == 'COMPLETE_EXACT_OWNED_TRANSIENT_RETENTION'
             and already[0]['previous_record'] in previous['deleted'], 'exact previous actual retention receipt')
        archive_rows = [r for r in targets if r['category'] == 'redundant-original-git-archive-stdout']
        need({r['path'] for r in archive_rows} == {str(run/'proof/command-006.stdout') for run in OLD[1:]+[LATEST]}, 'exact four newly redundant tar stdout files')
        for row in archive_rows:
            root = Path(row['path']).parent.parent
            value = old_results.get(str(root)) or inputs.json(root/'result.json', binding['native_result_sha256'])
            need(row['bytes'] == value['git_archive']['bytes'] and row['sha256'] == value['git_archive']['sha256'], 'original full tar digest')
            need(any(e.get('source') == row['path'] and e.get('sha256') == row['sha256']
                     and e.get('bytes') == row['bytes'] for e in keepers['inbox']['selection']['excluded']), 'accepted keeper retains exact excluded tar provenance')
        need(len(targets) == sum(r['files'] for r in plan['categories'])
             and sum(r['bytes'] for r in targets) == plan['logical_bytes'], 'exact reviewed aggregate')
        for row in targets:
            path = Path(row['path'])
            allowed = (row['category'] == 'old-generated-source' and any(path == root/'source'/literal(row['relative']) for root in OLD)) or (
                row['category'] == 'old-generated-binary' and any(path.parent == root/'binaries' for root in OLD)) or (
                row['category'] == 'redundant-original-git-archive-stdout' and path in {run/'proof/command-006.stdout' for run in OLD[1:]+[LATEST]})
            need(allowed and row['uid'] == os.getuid() and not path.is_relative_to(CANDIDATE)
                 and not path.is_relative_to(CURRENT_UI), 'exact authorized owned scope; never latestUI/candidate')
            compare(path,row)
        for row in directories:
            path = Path(row['path'])
            need(row['uid'] == os.getuid() and any(path.is_relative_to(root/'source') or path == root/'binaries' for root in OLD), 'only empty exact source/binary directories')
            compare(path,row)
        protected(inventory['preserved_old'])
        latest_native = inputs.json(LATEST/'result.json', binding['native_result_sha256'])
        need(latest_native['source'] == SOURCE and latest_native['tree'] == TREE, 'same exact current qualified source')
        cids,names = lifecycle(inputs,LATEST,latest_native,final=True);all_cids |= cids;all_names |= names
        need(len(all_cids) == len(all_names) == 62, 'all old13+5+14+15 and latest15 lifecycle identities')
        need(inputs.json(CURRENT_UI/'result.json',binding['ui_result_sha256'])['status'] == 'PASS', 'current full UI preserved')
        protected(latest['rows']);protected(latest['UI_rows']);protected(inventory['candidate_snapshot'])
        stable_source = [dict(row,relative=str(Path(row['path']).relative_to(LATEST/'source'))) for row in latest['rows'] if row['file'] and Path(row['path']).is_relative_to(LATEST/'source')]
        source_export(inputs,LATEST,latest_native,stable_source)
        targets_paths = [Path(r['path']) for r in targets+directories]
        source_fence();fresh(binding,inputs)
        result.update(status='VERIFIED_NOT_EXECUTED', method_sha256=binding['method_sha256'],
                      plan_sha256=binding['plan_sha256'], inventory_sha256=binding['inventory_sha256'],
                      latest_snapshot_sha256=binding['latest_snapshot_sha256'],
                      accepted_candidate_sha256=binding['keepers']['inbox']['archive_sha256'],
                      live_absence=live_absence(all_cids,all_names,targets_paths))
        if args.execute:
            fresh(binding,inputs);source_fence()
            marker = HERE/('used-'+binding['execution_nonce']+'.json')
            with marker.open('x') as stream:json.dump(dict(binding_sha256=sha(inputs.read(args.binding))),stream)
            result.update(executed=True,status='PARTIAL_EXACT_RETENTION_RETAIN_RECEIPT')
            for row in targets:
                need(time.time_ns()-binding['issued_unix_ns'] <= 3600*10**9,'binding expired during exact removal')
                path=Path(row['path']);compare(path,row);parent=parent_fd(path)
                try:
                    same(os.stat(path.name,dir_fd=parent,follow_symlinks=False),row)
                    os.unlink(path.name,dir_fd=parent)
                finally:os.close(parent)
                result['deleted'].append({k:row[k] for k in ('path','bytes','sha256','category')});result['logical_bytes_deleted']+=row['bytes']
            for row in directories:
                path=Path(row['path']);compare(path,row,removing_directory=True);parent=parent_fd(path)
                try:
                    same(os.stat(path.name,dir_fd=parent,follow_symlinks=False),row,directory=True,removing=True);os.rmdir(path.name,dir_fd=parent)
                finally:os.close(parent)
                result['removed_directories'].append(row['path'])
            need(all(not os.path.lexists(row['path']) for row in targets+directories),'all exact targets absent')
            removed={r['path'] for r in targets+directories}
            protected(inventory['preserved_old'],removed)
            protected(latest['rows'],removed);protected(latest['UI_rows']);protected(inventory['candidate_snapshot'])
            source_fence();inputs.fence()
            result['status']='COMPLETE_EXACT_SOCIAL_ROLLING_RETENTION'
    except BaseException as error:
        result['error']=type(error).__name__+': '+str(error)
        raise
    finally:
        result['raw_deleted_paths_unavailable']=bool(result['deleted'])
        result['retained_history_semantics']='Deleted generated source/binary/duplicate full Git stdout paths are unavailable. All historical HTML/PNG paths remain untouched. Original Git commits/branches, accepted candidate/canonical keeper payloads with original metadata, compact manifests/reviews and all nonduplicated raw test/proof/log/capture/source packets remain. Neither failed campaigns nor an available full old workspace are claimed.'
        with args.receipt.open('x') as stream:json.dump(result,stream,separators=(',',':'));stream.write('\n')
        print(json.dumps(dict(status=result['status'],deleted=len(result['deleted']),
              directories=len(result['removed_directories']),logical_bytes_deleted=result['logical_bytes_deleted'])))


if __name__=='__main__':main()
